"""The Alfred Digital Butler integration."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.typing import ConfigType

from .const import DOMAIN
from .conversation import AlfredConversationAgent
from .intelligence import AlfredIntelligenceEngine
from .panel import async_register_panel, async_unregister_panel
from .views import async_register_views
from .emergency_coordinator import EmergencyCoordinator
from .services_handlers import AlfredServiceHandlers

_LOGGER = logging.getLogger(__name__)

# No platforms to forward - conversation is registered manually
PLATFORMS: list[Platform] = []

CONFIG_SCHEMA = cv.config_entry_only_config_schema(DOMAIN)


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    """Set up the Alfred integration."""
    hass.data.setdefault(DOMAIN, {})
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Alfred from a config entry."""
    _LOGGER.info("Setting up Alfred Digital Butler")

    # Initialize the intelligence engine
    intelligence_engine = AlfredIntelligenceEngine(hass, entry)
    await intelligence_engine.async_setup()

    # Initialize the conversation agent
    conversation_agent = AlfredConversationAgent(hass, entry, intelligence_engine)

    # Initialize the emergency coordinator
    emergency_coordinator = EmergencyCoordinator(hass)
    await emergency_coordinator.async_setup()

    # Store in hass.data
    # Note: Using properties would be better than accessing private attributes
    # TODO: Add public accessor properties to AlfredIntelligenceEngine
    hass.data[DOMAIN][entry.entry_id] = {
        "intelligence_engine": intelligence_engine,
        "conversation_agent": conversation_agent,
        "degradation_detector": intelligence_engine._degradation_detector,
        "diagnosis_engine": intelligence_engine._diagnosis_engine,
        "battery_manager": intelligence_engine._battery_manager,
        "energy_analyzer": intelligence_engine._energy_analyzer,
        "hazard_detector": intelligence_engine._hazard_detector,
        "freeze_predictor": intelligence_engine._freeze_predictor,
        "emergency_coordinator": emergency_coordinator,
        "security_report_generator": intelligence_engine._security_report_generator,
        "smart_lock_intelligence": intelligence_engine._smart_lock_intelligence,
    }

    # Register the conversation agent
    await conversation_agent.async_setup()

    # Set up platforms
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    # Register services using the new handler class
    service_handlers = AlfredServiceHandlers(hass, conversation_agent)
    await service_handlers.async_register_all()

    # Start the intelligence engine
    await intelligence_engine.async_start()

    # Register views for serving frontend
    await async_register_views(hass)

    # Register the custom panel
    await async_register_panel(hass)

    _LOGGER.info("Alfred Digital Butler setup complete")
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    if unload_ok := await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        # Stop intelligence engine
        intelligence_engine = hass.data[DOMAIN][entry.entry_id]["intelligence_engine"]
        await intelligence_engine.async_stop()

        # Unregister panel
        await async_unregister_panel(hass)

        # Remove data
        hass.data[DOMAIN].pop(entry.entry_id)

    return unload_ok


async def async_reload_entry(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Reload config entry."""
    await async_unload_entry(hass, entry)
    await async_setup_entry(hass, entry)
