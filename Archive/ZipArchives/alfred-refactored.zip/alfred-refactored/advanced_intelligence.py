"""Advanced intelligence features for Alfred Digital Butler."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers import sun

from .const import EVENT_ALFRED_SUGGESTION

_LOGGER = logging.getLogger(__name__)


class AdvancedIntelligence:
    """Advanced intelligence features for pattern recognition and predictions."""

    def __init__(self, hass: HomeAssistant):
        """Initialize advanced intelligence."""
        self.hass = hass
        self._usage_patterns: dict[str, list[dict]] = {}
        self._correlations: dict[str, list[str]] = {}

    async def analyze_routine_patterns(self) -> list[dict[str, Any]]:
        """Analyze daily routines and suggest automations."""
        suggestions = []

        # Coffee maker pattern detection
        coffee_pattern = await self._detect_coffee_pattern()
        if coffee_pattern:
            suggestions.append(coffee_pattern)

        # Lighting patterns
        light_patterns = await self._detect_lighting_patterns()
        suggestions.extend(light_patterns)

        # Climate patterns with location
        climate_suggestions = await self._analyze_climate_with_location()
        suggestions.extend(climate_suggestions)

        return suggestions

    async def _detect_coffee_pattern(self) -> dict[str, Any] | None:
        """Detect coffee maker usage patterns."""
        # Look for devices that might be coffee makers
        coffee_devices = [
            state
            for state in self.hass.states.async_all()
            if "coffee" in state.name.lower()
            or ("switch" in state.entity_id and "kitchen" in state.name.lower())
        ]

        if not coffee_devices:
            return None

        for device in coffee_devices:
            entity_id = device.entity_id

            # Check if we have pattern data
            if entity_id not in self._usage_patterns:
                continue

            patterns = self._usage_patterns[entity_id]

            # Look for weekday morning patterns
            weekday_morning_uses = [
                p
                for p in patterns
                if p["timestamp"].weekday() < 5  # Monday-Friday
                and 5 <= p["timestamp"].hour <= 9  # 5 AM to 9 AM
                and p["new_state"] == "on"
            ]

            if len(weekday_morning_uses) >= 3:
                # Calculate average time
                avg_hour = sum(p["timestamp"].hour for p in weekday_morning_uses) // len(
                    weekday_morning_uses
                )
                avg_minute = sum(p["timestamp"].minute for p in weekday_morning_uses) // len(
                    weekday_morning_uses
                )

                return {
                    "type": "routine_pattern",
                    "title": "Coffee Routine Detected",
                    "message": f"I've noticed your {device.name} typically activates around {avg_hour}:{avg_minute:02d} on weekdays. Would you like me to create an automation to prepare it automatically?",
                    "entity_id": entity_id,
                    "suggested_time": f"{avg_hour}:{avg_minute:02d}",
                    "confidence": len(weekday_morning_uses) / 5 * 100,
                }

        return None

    async def _detect_lighting_patterns(self) -> list[dict[str, Any]]:
        """Detect lighting usage patterns."""
        suggestions = []

        # Get sunset time for context
        next_sunset = sun.get_astral_event_date(
            self.hass, sun.SUN_EVENT_SUNSET, datetime.now()
        )

        # Analyze outdoor lights
        outdoor_lights = [
            state
            for state in self.hass.states.async_all("light")
            if any(
                keyword in state.name.lower()
                for keyword in ["outdoor", "patio", "porch", "garden", "front door", "back door"]
            )
        ]

        for light in outdoor_lights:
            entity_id = light.entity_id

            if entity_id not in self._usage_patterns:
                continue

            patterns = self._usage_patterns[entity_id]

            # Look for evening activation patterns
            evening_activations = [
                p
                for p in patterns
                if 17 <= p["timestamp"].hour <= 22  # 5 PM to 10 PM
                and p["new_state"] == "on"
            ]

            if len(evening_activations) >= 3:
                suggestions.append({
                    "type": "automation_suggestion",
                    "title": "Outdoor Lighting Pattern",
                    "message": f"I've noticed you often turn on {light.name} in the evening. Shall I create an automation to turn it on at sunset and off at 11 PM?",
                    "entity_id": entity_id,
                    "suggested_trigger": "sunset",
                    "confidence": len(evening_activations) / 5 * 100,
                })

        return suggestions

    async def _analyze_climate_with_location(self) -> list[dict[str, Any]]:
        """Analyze climate control with person location."""
        suggestions = []

        # Get all climate entities
        climate_entities = list(self.hass.states.async_all("climate"))
        if not climate_entities:
            return suggestions

        # Get all person entities
        person_entities = list(self.hass.states.async_all("person"))
        if not person_entities:
            return suggestions

        # Check if everyone is away
        all_away = all(person.state != "home" for person in person_entities)

        if all_away:
            for climate in climate_entities:
                current_temp = climate.attributes.get("temperature")
                if current_temp and current_temp > 20:  # If heating/cooling is active
                    suggestions.append({
                        "type": "energy_optimization",
                        "title": "Energy Saving Opportunity",
                        "message": f"Everyone is away and {climate.name} is set to {current_temp}°C. I can reduce it to 18°C to save energy. Estimated savings: $2-3 per day.",
                        "entity_id": climate.entity_id,
                        "current_temp": current_temp,
                        "suggested_temp": 18,
                        "estimated_savings_daily": 2.5,
                    })

        return suggestions

    async def detect_device_correlations(self) -> list[dict[str, Any]]:
        """Detect correlations between devices for smart suggestions."""
        correlations = []

        # Motion sensor + Lights correlation
        motion_lights = await self._correlate_motion_with_lights()
        correlations.extend(motion_lights)

        # Door sensor + Lights correlation
        door_lights = await self._correlate_door_with_lights()
        correlations.extend(door_lights)

        # Alarm + Climate correlation
        alarm_climate = await self._correlate_alarm_with_climate()
        correlations.extend(alarm_climate)

        return correlations

    async def _correlate_motion_with_lights(self) -> list[dict[str, Any]]:
        """Find motion sensors that could trigger lights."""
        suggestions = []

        motion_sensors = list(self.hass.states.async_all("binary_sensor"))
        motion_sensors = [
            s for s in motion_sensors if s.attributes.get("device_class") == "motion"
        ]

        lights = list(self.hass.states.async_all("light"))

        for motion in motion_sensors:
            # Find lights in the same area
            motion_area = motion.attributes.get("area_id") or self._guess_area(motion.name)

            for light in lights:
                light_area = light.attributes.get("area_id") or self._guess_area(light.name)

                if motion_area and light_area and motion_area == light_area:
                    # Check if they're not already linked
                    if not await self._devices_are_linked(motion.entity_id, light.entity_id):
                        suggestions.append({
                            "type": "device_correlation",
                            "title": "Motion-Activated Lighting",
                            "message": f"I notice {motion.name} and {light.name} are in the same area. Would you like me to turn on the light when motion is detected?",
                            "trigger_entity": motion.entity_id,
                            "action_entity": light.entity_id,
                            "suggested_automation": {
                                "trigger": "motion",
                                "action": "turn_on_light",
                                "auto_off_minutes": 5,
                            },
                        })

        return suggestions

    async def _correlate_door_with_lights(self) -> list[dict[str, Any]]:
        """Find door sensors that could trigger lights."""
        suggestions = []

        door_sensors = [
            s
            for s in self.hass.states.async_all("binary_sensor")
            if s.attributes.get("device_class") in ["door", "opening"]
        ]

        for door in door_sensors:
            # Check for outdoor/entry doors
            if any(
                keyword in door.name.lower()
                for keyword in ["front", "back", "entry", "garage"]
            ):
                # Find nearby lights
                area = door.attributes.get("area_id") or self._guess_area(door.name)

                lights_in_area = [
                    light
                    for light in self.hass.states.async_all("light")
                    if (light.attributes.get("area_id") or self._guess_area(light.name)) == area
                ]

                for light in lights_in_area:
                    if not await self._devices_are_linked(door.entity_id, light.entity_id):
                        suggestions.append({
                            "type": "device_correlation",
                            "title": "Entry Lighting",
                            "message": f"When {door.name} opens in the evening, shall I turn on {light.name} automatically?",
                            "trigger_entity": door.entity_id,
                            "action_entity": light.entity_id,
                            "condition": "after_sunset",
                        })

        return suggestions

    async def _correlate_alarm_with_climate(self) -> list[dict[str, Any]]:
        """Correlate alarm state with climate control."""
        suggestions = []

        alarms = list(self.hass.states.async_all("alarm_control_panel"))
        climates = list(self.hass.states.async_all("climate"))

        if not alarms or not climates:
            return suggestions

        for alarm in alarms:
            if alarm.state == "armed_away":
                for climate in climates:
                    current_temp = climate.attributes.get("temperature")
                    if current_temp and current_temp > 19:
                        suggestions.append({
                            "type": "cross_device_intelligence",
                            "title": "Security-Climate Optimization",
                            "message": f"The alarm is in away mode. I can automatically adjust {climate.name} to eco mode (18°C) when the house is secured, and restore it when disarmed. Estimated savings: $50/month.",
                            "devices": [alarm.entity_id, climate.entity_id],
                            "automation_type": "security_climate",
                            "estimated_savings_monthly": 50,
                        })

        return suggestions

    def _guess_area(self, name: str) -> str | None:
        """Guess area from device name."""
        areas = ["kitchen", "bedroom", "living room", "bathroom", "garage", "office", "hallway"]

        name_lower = name.lower()
        for area in areas:
            if area in name_lower:
                return area

        return None

    async def _devices_are_linked(self, entity1: str, entity2: str) -> bool:
        """Check if devices are already linked in an automation."""
        # This would check HA automations
        # For now, return False (not implemented)
        return False

    async def predict_maintenance_needs(self) -> list[dict[str, Any]]:
        """Predict maintenance needs based on usage patterns."""
        predictions = []

        # HVAC filter prediction
        hvac_predictions = await self._predict_hvac_filter()
        predictions.extend(hvac_predictions)

        # Battery life predictions
        battery_predictions = await self._predict_battery_replacements()
        predictions.extend(battery_predictions)

        return predictions

    async def _predict_hvac_filter(self) -> list[dict[str, Any]]:
        """Predict HVAC filter replacement needs."""
        predictions = []

        climate_entities = list(self.hass.states.async_all("climate"))

        for climate in climate_entities:
            entity_id = climate.entity_id

            if entity_id not in self._usage_patterns:
                continue

            # Calculate runtime hours from patterns
            patterns = self._usage_patterns[entity_id]
            on_states = [p for p in patterns if p["new_state"] in ["heat", "cool", "heat_cool"]]

            if len(on_states) >= 10:
                # Estimate filter life (3 months typical)
                estimated_filter_days_remaining = 90 - (len(on_states) // 24)

                if estimated_filter_days_remaining < 14:
                    predictions.append({
                        "type": "predictive_maintenance",
                        "title": "HVAC Filter Replacement Due",
                        "message": f"{climate.name} filter should be replaced soon (estimated {estimated_filter_days_remaining} days remaining). I can order a replacement filter for you.",
                        "entity_id": entity_id,
                        "days_remaining": estimated_filter_days_remaining,
                        "priority": "high" if estimated_filter_days_remaining < 7 else "medium",
                    })

        return predictions

    async def _predict_battery_replacements(self) -> list[dict[str, Any]]:
        """Predict when batteries will need replacement."""
        predictions = []

        battery_sensors = [
            state
            for state in self.hass.states.async_all()
            if state.attributes.get("battery_level") is not None
        ]

        for sensor in battery_sensors:
            battery_level = sensor.attributes.get("battery_level")
            entity_id = sensor.entity_id

            if battery_level and battery_level < 30 and entity_id in self._usage_patterns:
                # Analyze battery drain rate
                patterns = self._usage_patterns[entity_id]
                battery_patterns = [
                    p for p in patterns if "battery_level" in p.get("attributes", {})
                ]

                if len(battery_patterns) >= 3:
                    # Simple linear prediction
                    first = battery_patterns[0]["attributes"]["battery_level"]
                    last = battery_patterns[-1]["attributes"]["battery_level"]
                    days_span = (
                        battery_patterns[-1]["timestamp"] - battery_patterns[0]["timestamp"]
                    ).days

                    if days_span > 0:
                        drain_per_day = (first - last) / days_span
                        days_until_dead = int(battery_level / drain_per_day) if drain_per_day > 0 else 999

                        if days_until_dead < 30:
                            predictions.append({
                                "type": "predictive_maintenance",
                                "title": "Battery Replacement Predicted",
                                "message": f"{sensor.name} battery is at {battery_level}%. Based on usage patterns, it will need replacement in approximately {days_until_dead} days.",
                                "entity_id": entity_id,
                                "current_level": battery_level,
                                "days_until_replacement": days_until_dead,
                                "priority": "high" if days_until_dead < 7 else "medium",
                            })

        return predictions

    def record_usage(self, entity_id: str, old_state: str, new_state: str, attributes: dict) -> None:
        """Record device usage for pattern analysis."""
        if entity_id not in self._usage_patterns:
            self._usage_patterns[entity_id] = []

        self._usage_patterns[entity_id].append({
            "timestamp": datetime.now(),
            "old_state": old_state,
            "new_state": new_state,
            "attributes": attributes,
        })

        # Keep only last 1000 records per device
        if len(self._usage_patterns[entity_id]) > 1000:
            self._usage_patterns[entity_id] = self._usage_patterns[entity_id][-1000:]
