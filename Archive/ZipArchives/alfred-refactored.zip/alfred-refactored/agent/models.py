"""Data models for Alfred AI Agent.

Following the BMAD architecture specification section 4.1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class RiskLevel(Enum):
    """Risk level classification for actions."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PermissionLevel(Enum):
    """Agent permission levels."""

    OBSERVE = 0  # Observe only, no actions
    LOW_RISK = 1  # Lights, media, comfort (reversible)
    MEDIUM_RISK = 2  # Climate, routines (impactful)
    HIGH_RISK = 3  # Security, modifications (critical)


class ActionStatus(Enum):
    """Status of an agent action."""

    PENDING = "pending"
    VALIDATING = "validating"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


@dataclass
class Action:
    """Represents an action the agent can take."""

    id: str
    type: str
    domain: str
    service: str
    entity_id: str
    service_data: Dict[str, Any]
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class Decision:
    """Represents an agent decision."""

    id: str
    action: Action
    confidence: float  # 0-100
    reasoning: str
    risk_level: RiskLevel
    expected_outcome: str
    alternatives: List[Action] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class Situation:
    """Represents a situation requiring agent attention."""

    id: str
    type: str
    description: str
    context: Dict[str, Any]
    priority: int
    detected_at: datetime = field(default_factory=datetime.now)


@dataclass
class Goal:
    """Represents an agent goal."""

    id: str
    type: str
    description: str
    priority: int
    deadline: Optional[datetime] = None
    constraints: Dict[str, Any] = field(default_factory=dict)
    status: str = "active"


@dataclass
class Plan:
    """Represents a multi-step plan."""

    id: str
    goal_id: str
    steps: List[Action]
    current_step: int = 0
    status: str = "pending"
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class ExecutionResult:
    """Result of an action execution."""

    action_id: str
    success: bool
    error: Optional[str] = None
    state_before: Dict[str, Any] = field(default_factory=dict)
    state_after: Dict[str, Any] = field(default_factory=dict)
    executed_at: datetime = field(default_factory=datetime.now)


@dataclass
class Feedback:
    """User feedback on an action."""

    action_id: str
    feedback_type: str  # "explicit", "implicit"
    value: str  # "positive", "negative", "neutral"
    details: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class LearningMetrics:
    """Learning performance metrics."""

    total_actions: int
    successful_actions: int
    failed_actions: int
    accuracy: float
    average_confidence: float
    user_satisfaction: float
    period: str


@dataclass
class AgentConfig:
    """Agent configuration."""

    enabled: bool = False
    permission_level: PermissionLevel = PermissionLevel.OBSERVE
    confidence_threshold: float = 80.0
    max_actions_per_hour: int = 20
    max_risk_level: RiskLevel = RiskLevel.LOW

    # LLM settings
    local_llm_enabled: bool = True
    cloud_llm_enabled: bool = True
    cloud_llm_provider: str = "gemini"

    # Safety settings
    require_user_presence: bool = True
    safe_hours_start: str = "06:00"
    safe_hours_end: str = "23:00"

    # Learning settings
    learning_enabled: bool = True
    feedback_timeout_seconds: int = 3600

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "enabled": self.enabled,
            "permission_level": self.permission_level.value,
            "confidence_threshold": self.confidence_threshold,
            "max_actions_per_hour": self.max_actions_per_hour,
            "max_risk_level": self.max_risk_level.value,
            "local_llm_enabled": self.local_llm_enabled,
            "cloud_llm_enabled": self.cloud_llm_enabled,
            "cloud_llm_provider": self.cloud_llm_provider,
            "require_user_presence": self.require_user_presence,
            "safe_hours_start": self.safe_hours_start,
            "safe_hours_end": self.safe_hours_end,
            "learning_enabled": self.learning_enabled,
            "feedback_timeout_seconds": self.feedback_timeout_seconds,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AgentConfig:
        """Create from dictionary."""
        return cls(
            enabled=data.get("enabled", False),
            permission_level=PermissionLevel(data.get("permission_level", 0)),
            confidence_threshold=data.get("confidence_threshold", 80.0),
            max_actions_per_hour=data.get("max_actions_per_hour", 20),
            max_risk_level=RiskLevel(data.get("max_risk_level", "low")),
            local_llm_enabled=data.get("local_llm_enabled", True),
            cloud_llm_enabled=data.get("cloud_llm_enabled", True),
            cloud_llm_provider=data.get("cloud_llm_provider", "gemini"),
            require_user_presence=data.get("require_user_presence", True),
            safe_hours_start=data.get("safe_hours_start", "06:00"),
            safe_hours_end=data.get("safe_hours_end", "23:00"),
            learning_enabled=data.get("learning_enabled", True),
            feedback_timeout_seconds=data.get("feedback_timeout_seconds", 3600),
        )
