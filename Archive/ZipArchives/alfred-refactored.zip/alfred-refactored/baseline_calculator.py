"""Baseline calculation engine for Alfred Digital Butler."""
from __future__ import annotations

import logging
import statistics
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .historical_data import HistoricalDataAccess
from .performance_metrics import PerformanceMetricsCollector
from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)

# Default observation period
DEFAULT_OBSERVATION_DAYS = 30
MIN_SAMPLES_FOR_CONFIDENCE = 100
OUTLIER_THRESHOLD_STD_DEV = 3.0  # Remove values beyond 3 std deviations


class BaselineCalculator:
    """Calculate and manage device performance baselines."""

    def __init__(
        self,
        hass: HomeAssistant,
        historical_data: HistoricalDataAccess,
        metrics_collector: PerformanceMetricsCollector,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize baseline calculator."""
        self.hass = hass
        self._historical_data = historical_data
        self._metrics_collector = metrics_collector
        self._storage = pattern_storage
        self._enabled = True

    async def async_setup(self) -> None:
        """Set up the baseline calculator."""
        _LOGGER.info("Setting up Alfred Baseline Calculator")
        self._enabled = True

    async def calculate_entity_baselines(
        self,
        entity_id: str,
        observation_days: int = DEFAULT_OBSERVATION_DAYS,
        condition_type: str = "default",
    ) -> dict[str, dict[str, Any]] | None:
        """
        Calculate baselines for all metrics of an entity.

        Args:
            entity_id: Entity ID to calculate baselines for
            observation_days: Number of days to observe (default 30)
            condition_type: Condition type for conditional baselines

        Returns:
            Dictionary of baselines by metric name, or None if insufficient data
            Example:
            {
                "temperature": {
                    "metric_value": 21.5,
                    "std_dev": 1.2,
                    "min_value": 18.5,
                    "max_value": 24.2,
                    "confidence_score": 0.95,
                    "sample_count": 720,
                    "observation_period_days": 30
                },
                "battery_level": {...}
            }
        """
        if not self._enabled:
            return None

        try:
            # Get historical states
            end_time = dt_util.now()
            start_time = end_time - timedelta(days=observation_days)

            _LOGGER.debug(
                "Calculating baselines for %s over %d days",
                entity_id,
                observation_days,
            )

            # Get historical data
            historical_states = await self._historical_data.get_entity_history(
                entity_id, start_time, end_time
            )

            if not historical_states:
                _LOGGER.debug("No historical data for %s", entity_id)
                return None

            # Collect metrics from historical states
            metrics_by_type = await self._extract_metrics_from_history(
                entity_id, historical_states, condition_type
            )

            if not metrics_by_type:
                _LOGGER.debug("No metrics extracted from history for %s", entity_id)
                return None

            # Calculate baselines for each metric type
            baselines = {}

            for metric_name, metric_values in metrics_by_type.items():
                baseline = await self._calculate_baseline_statistics(
                    metric_name, metric_values, observation_days
                )

                if baseline:
                    baselines[metric_name] = baseline

            if baselines:
                _LOGGER.info(
                    "Calculated %d baselines for %s", len(baselines), entity_id
                )
                return baselines

            return None

        except Exception as err:
            _LOGGER.error(
                "Error calculating baselines for %s: %s", entity_id, err, exc_info=True
            )
            return None

    async def _extract_metrics_from_history(
        self, entity_id: str, states: list, condition_type: str
    ) -> dict[str, list[float]]:
        """
        Extract metric values from historical states.

        Args:
            entity_id: Entity ID
            states: List of historical State objects
            condition_type: Condition filter (e.g., "weekday", "weekend")

        Returns:
            Dictionary mapping metric names to lists of values
        """
        metrics_by_type: dict[str, list[float]] = {}

        for state in states:
            # Filter by condition if needed
            if condition_type != "default":
                # Check if state matches condition
                if not await self._matches_condition(state, condition_type):
                    continue

            # Extract numeric metrics from state
            metric_values = await self._extract_metrics_from_state(state, entity_id)

            for metric_name, value in metric_values.items():
                if metric_name not in metrics_by_type:
                    metrics_by_type[metric_name] = []
                metrics_by_type[metric_name].append(value)

        return metrics_by_type

    async def _extract_metrics_from_state(
        self, state, entity_id: str
    ) -> dict[str, float]:
        """Extract numeric metric values from a state object."""
        metrics = {}

        try:
            # Try to get numeric state value
            try:
                state_value = float(state.state)
                # Use entity type as metric name
                domain = entity_id.split(".")[0]
                if domain == "sensor":
                    # For sensors, try to determine metric type from entity name
                    if "temperature" in entity_id.lower():
                        metrics["temperature"] = state_value
                    elif "battery" in entity_id.lower():
                        metrics["battery_level"] = state_value
                    elif "power" in entity_id.lower():
                        metrics["power_consumption"] = state_value
                    elif "humidity" in entity_id.lower():
                        metrics["humidity"] = state_value
                    else:
                        # Generic sensor value
                        metrics["value"] = state_value
            except (ValueError, TypeError):
                pass

            # Extract from attributes
            if hasattr(state, "attributes"):
                # Battery
                battery = state.attributes.get("battery_level")
                if battery is not None:
                    try:
                        metrics["battery_level"] = float(battery)
                    except (ValueError, TypeError):
                        pass

                # Temperature
                for temp_attr in ["temperature", "current_temperature"]:
                    temp = state.attributes.get(temp_attr)
                    if temp is not None:
                        try:
                            metrics["temperature"] = float(temp)
                            break
                        except (ValueError, TypeError):
                            pass

                # Power
                power = state.attributes.get("current_power_w")
                if power is not None:
                    try:
                        metrics["power_consumption"] = float(power)
                    except (ValueError, TypeError):
                        pass

                # Brightness (lights)
                brightness = state.attributes.get("brightness")
                if brightness is not None:
                    try:
                        # Convert 0-255 to 0-100
                        metrics["brightness"] = (float(brightness) / 255.0) * 100.0
                    except (ValueError, TypeError):
                        pass

                # Humidity
                for humidity_attr in ["humidity", "current_humidity"]:
                    humidity = state.attributes.get(humidity_attr)
                    if humidity is not None:
                        try:
                            metrics["humidity"] = float(humidity)
                            break
                        except (ValueError, TypeError):
                            pass

        except Exception as err:
            _LOGGER.debug("Error extracting metrics from state: %s", err)

        return metrics

    async def _matches_condition(self, state, condition_type: str) -> bool:
        """Check if state matches the given condition."""
        try:
            if condition_type == "weekday":
                # Monday = 0, Sunday = 6
                return state.last_changed.weekday() < 5
            elif condition_type == "weekend":
                return state.last_changed.weekday() >= 5
            # Add more conditions as needed (weather, time of day, etc.)

            return True

        except Exception:
            return True

    async def _calculate_baseline_statistics(
        self, metric_name: str, values: list[float], observation_days: int
    ) -> dict[str, Any] | None:
        """
        Calculate statistical baseline from metric values.

        Args:
            metric_name: Name of the metric
            values: List of metric values
            observation_days: Observation period in days

        Returns:
            Baseline statistics dictionary or None if insufficient data
        """
        if not values or len(values) < 2:
            return None

        try:
            # Remove outliers
            clean_values = await self._remove_outliers(values)

            if len(clean_values) < 2:
                _LOGGER.debug(
                    "Insufficient data after outlier removal for %s", metric_name
                )
                return None

            # Calculate statistics
            mean_value = statistics.mean(clean_values)
            std_dev = statistics.stdev(clean_values) if len(clean_values) > 1 else 0.0
            min_value = min(clean_values)
            max_value = max(clean_values)
            sample_count = len(clean_values)

            # Calculate confidence score
            confidence_score = await self._calculate_confidence(
                sample_count, observation_days, std_dev, mean_value
            )

            baseline = {
                "metric_value": round(mean_value, 2),
                "std_dev": round(std_dev, 2),
                "min_value": round(min_value, 2),
                "max_value": round(max_value, 2),
                "confidence_score": round(confidence_score, 2),
                "sample_count": sample_count,
                "observation_period_days": observation_days,
            }

            _LOGGER.debug(
                "Baseline for %s: mean=%.2f, std_dev=%.2f, samples=%d, confidence=%.2f",
                metric_name,
                mean_value,
                std_dev,
                sample_count,
                confidence_score,
            )

            return baseline

        except Exception as err:
            _LOGGER.error("Error calculating baseline statistics: %s", err)
            return None

    async def _remove_outliers(self, values: list[float]) -> list[float]:
        """
        Remove statistical outliers from values.

        Uses standard deviation method: removes values beyond 3 std deviations.

        Args:
            values: List of numeric values

        Returns:
            List with outliers removed
        """
        if len(values) < 3:
            return values

        try:
            mean = statistics.mean(values)
            std_dev = statistics.stdev(values)

            if std_dev == 0:
                return values

            # Filter values within threshold
            clean_values = [
                v
                for v in values
                if abs(v - mean) <= OUTLIER_THRESHOLD_STD_DEV * std_dev
            ]

            removed = len(values) - len(clean_values)
            if removed > 0:
                _LOGGER.debug("Removed %d outliers from %d values", removed, len(values))

            return clean_values if clean_values else values

        except Exception as err:
            _LOGGER.debug("Error removing outliers: %s", err)
            return values

    async def _calculate_confidence(
        self, sample_count: int, observation_days: int, std_dev: float, mean_value: float
    ) -> float:
        """
        Calculate confidence score for baseline (0.0 - 1.0).

        Factors:
        - Sample count (more samples = higher confidence)
        - Observation period (30+ days = higher confidence)
        - Consistency (lower std_dev relative to mean = higher confidence)

        Args:
            sample_count: Number of samples
            observation_days: Observation period in days
            std_dev: Standard deviation
            mean_value: Mean value

        Returns:
            Confidence score between 0.0 and 1.0
        """
        # Duration confidence (0.0-0.4)
        # Full confidence at 30+ days
        duration_confidence = min(observation_days / DEFAULT_OBSERVATION_DAYS, 1.0) * 0.4

        # Sample confidence (0.0-0.4)
        # Full confidence at 100+ samples
        sample_confidence = min(sample_count / MIN_SAMPLES_FOR_CONFIDENCE, 1.0) * 0.4

        # Consistency confidence (0.0-0.2)
        # Lower coefficient of variation = higher confidence
        if mean_value != 0:
            coefficient_of_variation = std_dev / abs(mean_value)
            # CV of 0.05 (5%) = excellent (0.2), CV of 0.5 (50%) = poor (0.0)
            consistency_confidence = max(0, 0.2 * (1 - min(coefficient_of_variation / 0.5, 1.0)))
        else:
            consistency_confidence = 0.1  # Some confidence for zero-mean metrics

        total_confidence = duration_confidence + sample_confidence + consistency_confidence

        return min(total_confidence, 1.0)

    async def save_entity_baselines(
        self,
        entity_id: str,
        baselines: dict[str, dict[str, Any]],
        condition_type: str = "default",
    ) -> int:
        """
        Save calculated baselines to database.

        Args:
            entity_id: Entity ID
            baselines: Dictionary of baselines by metric name
            condition_type: Condition type for baselines

        Returns:
            Number of baselines saved
        """
        saved_count = 0

        for metric_name, baseline in baselines.items():
            try:
                # Get metric unit (from current state if available)
                metric_unit = await self._get_metric_unit(entity_id, metric_name)

                await self._storage.save_baseline(
                    entity_id=entity_id,
                    metric_name=metric_name,
                    metric_value=baseline["metric_value"],
                    metric_unit=metric_unit,
                    std_dev=baseline["std_dev"],
                    sample_count=baseline["sample_count"],
                    min_value=baseline["min_value"],
                    max_value=baseline["max_value"],
                    confidence_score=baseline["confidence_score"],
                    observation_period_days=baseline["observation_period_days"],
                    condition_type=condition_type,
                )

                saved_count += 1

            except Exception as err:
                _LOGGER.error(
                    "Error saving baseline %s for %s: %s",
                    metric_name,
                    entity_id,
                    err,
                    exc_info=True,
                )

        _LOGGER.info("Saved %d baselines for %s", saved_count, entity_id)

        return saved_count

    async def _get_metric_unit(self, entity_id: str, metric_name: str) -> str | None:
        """Get the unit of measurement for a metric."""
        # Map metric names to typical units
        unit_map = {
            "temperature": "°C",
            "battery_level": "%",
            "power_consumption": "W",
            "brightness": "%",
            "humidity": "%",
        }

        # Try to get from map
        unit = unit_map.get(metric_name)
        if unit:
            return unit

        # Try to get from current state
        state = self.hass.states.get(entity_id)
        if state and hasattr(state, "attributes"):
            return state.attributes.get("unit_of_measurement")

        return None

    async def calculate_all_trackable_baselines(
        self, observation_days: int = DEFAULT_OBSERVATION_DAYS
    ) -> dict[str, int]:
        """
        Calculate baselines for all trackable entities.

        Args:
            observation_days: Observation period in days

        Returns:
            Dictionary with statistics:
            {
                "entities_processed": 10,
                "baselines_calculated": 25,
                "entities_with_baselines": 8
            }
        """
        stats = {
            "entities_processed": 0,
            "baselines_calculated": 0,
            "entities_with_baselines": 0,
        }

        try:
            # Get trackable entities
            trackable = await self._metrics_collector.get_trackable_entities()

            _LOGGER.info(
                "Calculating baselines for %d trackable entities", len(trackable)
            )

            for entity_id in trackable:
                stats["entities_processed"] += 1

                # Calculate baselines
                baselines = await self.calculate_entity_baselines(
                    entity_id, observation_days
                )

                if baselines:
                    # Save baselines
                    saved = await self.save_entity_baselines(entity_id, baselines)

                    if saved > 0:
                        stats["baselines_calculated"] += saved
                        stats["entities_with_baselines"] += 1

            _LOGGER.info(
                "Baseline calculation complete: %d entities, %d baselines",
                stats["entities_with_baselines"],
                stats["baselines_calculated"],
            )

        except Exception as err:
            _LOGGER.error("Error in batch baseline calculation: %s", err, exc_info=True)

        return stats
