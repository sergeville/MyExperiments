"""Battery Intelligence & Management for Alfred Digital Butler."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers import (
    entity_registry as er,
    device_registry as dr,
)
import homeassistant.util.dt as dt_util

from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)

# Alert thresholds (%)
ALERT_THRESHOLDS = [20, 10, 5]

# Voltage to percentage curves (simplified linear approximation)
# Format: (min_voltage, max_voltage) for common battery types
VOLTAGE_CURVES = {
    "1.5V": (0.9, 1.6),   # AA, AAA, C, D
    "3V": (2.0, 3.3),      # CR2032, CR2450
    "9V": (6.0, 9.6),      # 9V batteries
    "3.7V": (3.0, 4.2),    # Li-ion 18650
}


@dataclass
class BatteryStatus:
    """Battery status information."""

    entity_id: str
    name: str
    current_level: float
    battery_type: str | None
    last_updated: datetime
    last_alerted_threshold: int | None
    alert_needed: list[int]  # List of thresholds to alert on


class BatteryManager:
    """Manages battery-powered device monitoring and predictions."""

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize battery manager."""
        self.hass = hass
        self._storage = pattern_storage

        # Discovery cache
        self._discovery_cache: list[str] = []
        self._discovery_cache_time: datetime | None = None
        self._cache_ttl = timedelta(hours=1)

        # Tracking
        self._monitored_batteries: dict[str, BatteryStatus] = {}

    async def async_setup(self) -> None:
        """Set up battery manager."""
        _LOGGER.info("Setting up Battery Manager")

        # Initial discovery
        await self.discover_battery_sensors()

        _LOGGER.info("Battery Manager setup complete")

    async def async_start(self) -> None:
        """Start battery manager."""
        _LOGGER.info("Starting Battery Manager")

        # Initial monitoring
        await self.monitor_all_batteries()

    async def async_stop(self) -> None:
        """Stop battery manager."""
        _LOGGER.info("Stopping Battery Manager")

    # ========================================================================
    # DISCOVERY
    # ========================================================================

    async def discover_battery_sensors(self, force_refresh: bool = False) -> list[str]:
        """
        Discover all battery-powered entities in Home Assistant.

        Checks for:
        1. Entities with 'battery' or 'battery_level' attributes
        2. Entities with device_class = 'battery'
        3. Sensor domain with 'battery' in name

        Args:
            force_refresh: Force cache refresh

        Returns:
            List of entity IDs with battery monitoring
        """
        now = dt_util.now()

        # Check cache
        if (not force_refresh and
            self._discovery_cache_time and
            now - self._discovery_cache_time < self._cache_ttl):
            return self._discovery_cache

        _LOGGER.info("Discovering battery sensors...")

        battery_entities = set()

        # Strategy 1: Check all entities for battery attribute
        for state in self.hass.states.async_all():
            if self._is_battery_entity(state):
                battery_entities.add(state.entity_id)

        # Strategy 2: Filter sensor domain with battery device class
        for state in self.hass.states.async_all("sensor"):
            if state.attributes.get("device_class") == "battery":
                battery_entities.add(state.entity_id)

        # Strategy 3: Find entities with 'battery' in name
        for state in self.hass.states.async_all():
            if "battery" in state.entity_id.lower():
                level = self._get_battery_level(state.entity_id)
                if level is not None:
                    battery_entities.add(state.entity_id)

        # Update cache
        self._discovery_cache = sorted(battery_entities)
        self._discovery_cache_time = now

        _LOGGER.info("Discovered %d battery entities", len(self._discovery_cache))

        return self._discovery_cache

    def _is_battery_entity(self, state) -> bool:
        """Check if entity has battery attribute."""
        if not state:
            return False

        # Check for battery or battery_level attributes
        if "battery" in state.attributes:
            return True
        if "battery_level" in state.attributes:
            return True

        # Check if it's a battery sensor
        if state.attributes.get("device_class") == "battery":
            return True

        return False

    # ========================================================================
    # BATTERY LEVEL EXTRACTION
    # ========================================================================

    def _get_battery_level(self, entity_id: str) -> float | None:
        """
        Extract battery level in percentage (0-100).

        Handles multiple formats:
        - Percentage (0-100)
        - Decimal (0-1)
        - Millivolts (mV)
        - Voltage (V)
        - Boolean/String (Low, OK, etc.)

        Args:
            entity_id: Entity ID

        Returns:
            Battery level as percentage (0-100) or None
        """
        state = self.hass.states.get(entity_id)
        if not state:
            return None

        # Try battery_level attribute first
        level = state.attributes.get("battery_level")
        if level is not None:
            return self._normalize_battery_value(level)

        # Try battery attribute
        level = state.attributes.get("battery")
        if level is not None:
            return self._normalize_battery_value(level)

        # Try state value
        try:
            value = float(state.state)
            return self._normalize_battery_value(value)
        except (ValueError, TypeError):
            pass

        # Handle boolean/string states
        state_lower = state.state.lower()
        if state_lower in ["low", "critical"]:
            return 10.0  # Assume 10% for low
        elif state_lower in ["ok", "normal", "full"]:
            return 85.0  # Assume 85% for OK

        return None

    def _normalize_battery_value(self, value: Any) -> float | None:
        """
        Normalize battery value to percentage (0-100).

        Args:
            value: Raw battery value

        Returns:
            Percentage (0-100) or None
        """
        if not isinstance(value, (int, float)):
            return None

        # Decimal format (0-1)
        if 0 <= value <= 1:
            return float(value * 100)

        # Percentage format (0-100)
        if 0 <= value <= 100:
            return float(value)

        # Millivolts (likely > 1000)
        if value > 1000:
            return self._voltage_to_percentage(value / 1000)

        # Voltage (1-12V range)
        if 1 < value <= 12:
            return self._voltage_to_percentage(value)

        return None

    def _voltage_to_percentage(self, voltage: float) -> float:
        """
        Convert voltage to percentage using voltage curves.

        Args:
            voltage: Voltage value

        Returns:
            Estimated percentage (0-100)
        """
        # Determine battery type based on voltage range
        curve = None
        if 0.9 <= voltage <= 1.6:
            curve = VOLTAGE_CURVES["1.5V"]
        elif 2.0 <= voltage <= 3.3:
            curve = VOLTAGE_CURVES["3V"]
        elif 6.0 <= voltage <= 9.6:
            curve = VOLTAGE_CURVES["9V"]
        elif 3.0 <= voltage <= 4.2:
            curve = VOLTAGE_CURVES["3.7V"]

        if not curve:
            # Unknown voltage range, estimate
            return 50.0

        min_v, max_v = curve

        # Linear interpolation
        if voltage <= min_v:
            return 0.0
        elif voltage >= max_v:
            return 100.0
        else:
            percentage = ((voltage - min_v) / (max_v - min_v)) * 100
            return max(0.0, min(100.0, percentage))

    # ========================================================================
    # MONITORING
    # ========================================================================

    async def monitor_all_batteries(self) -> dict[str, BatteryStatus]:
        """
        Monitor all discovered battery entities.

        Returns:
            Dictionary mapping entity_id to BatteryStatus
        """
        batteries = await self.discover_battery_sensors()

        results = {}
        for entity_id in batteries:
            status = await self.monitor_battery(entity_id)
            if status:
                results[entity_id] = status

        _LOGGER.info("Monitored %d batteries", len(results))

        return results

    async def monitor_battery(self, entity_id: str) -> BatteryStatus | None:
        """
        Monitor single battery entity.

        Args:
            entity_id: Entity ID to monitor

        Returns:
            BatteryStatus or None if not available
        """
        # Get current level
        current_level = self._get_battery_level(entity_id)
        if current_level is None:
            return None

        # Get friendly name
        state = self.hass.states.get(entity_id)
        name = state.name if state else entity_id

        # Get tracking info from database
        tracking = await self._storage.get_battery_tracking(entity_id)

        last_alerted_threshold = tracking.get("last_alerted_threshold") if tracking else None

        # Check alert thresholds
        alert_needed = await self._check_alert_thresholds(
            entity_id,
            current_level,
            last_alerted_threshold
        )

        # Calculate drain rate and prediction
        drain_info = await self.calculate_drain_rate(entity_id)
        prediction_info = None

        update_data = {
            "friendly_name": name,
            "current_level": current_level,
            "last_updated": dt_util.now(),
        }

        if drain_info:
            # Update drain rate info
            update_data.update({
                "drain_rate_per_day": drain_info["drain_rate_per_day"],
                "drain_rate_confidence": drain_info["confidence"],
                "drain_rate_quality": drain_info["quality"],
                "drain_rate_calculated_at": dt_util.now(),
            })

            # Calculate prediction
            prediction_info = await self.predict_replacement_date(
                entity_id,
                current_level,
                drain_info["drain_rate_per_day"]
            )

            if prediction_info:
                update_data.update({
                    "predicted_replacement_date": prediction_info["predicted_date"],
                    "days_remaining": prediction_info["days_remaining"],
                    "prediction_confidence": prediction_info["confidence"],
                    "prediction_confidence_interval_days": prediction_info["confidence_interval_days"],
                })

            # Detect abnormal drain
            abnormal_info = await self.detect_abnormal_drain(entity_id)
            if abnormal_info and abnormal_info["abnormal_drain_detected"]:
                _LOGGER.info(
                    "Abnormal drain detected for %s: %.2f%% per day (%.0f%% faster)",
                    name,
                    abnormal_info["current_drain_rate"],
                    abnormal_info["percentage_faster"]
                )

        # Create status
        status = BatteryStatus(
            entity_id=entity_id,
            name=name,
            current_level=current_level,
            battery_type=tracking.get("battery_type") if tracking else None,
            last_updated=dt_util.now(),
            last_alerted_threshold=last_alerted_threshold,
            alert_needed=alert_needed
        )

        # Update database
        await self._storage.save_battery_tracking(
            entity_id=entity_id,
            data=update_data
        )

        # Send alerts if needed
        for threshold in alert_needed:
            await self._send_low_battery_alert(entity_id, current_level, threshold)

            # Update last alerted threshold
            await self._storage.save_battery_tracking(
                entity_id=entity_id,
                data={
                    "last_alerted_threshold": threshold,
                    "last_alerted_at": dt_util.now(),
                    "alert_count": tracking.get("alert_count", 0) + 1 if tracking else 1,
                }
            )

        # Store in memory
        self._monitored_batteries[entity_id] = status

        return status

    # ========================================================================
    # ALERT LOGIC
    # ========================================================================

    async def _check_alert_thresholds(
        self,
        entity_id: str,
        current_level: float,
        last_alerted_threshold: int | None
    ) -> list[int]:
        """
        Check if entity crossed any alert thresholds.

        Args:
            entity_id: Entity ID
            current_level: Current battery level (%)
            last_alerted_threshold: Last threshold that triggered alert

        Returns:
            List of thresholds to alert on
        """
        if last_alerted_threshold is None:
            last_alerted_threshold = 100

        # Get tracking info for rate limiting
        tracking = await self._storage.get_battery_tracking(entity_id)
        if tracking:
            last_alerted_at = tracking.get("last_alerted_at")

            # Rate limiting: max 1 alert per day
            if last_alerted_at:
                hours_since_last = (dt_util.now() - last_alerted_at).total_seconds() / 3600
                if hours_since_last < 24:
                    return []

        # Find triggered thresholds
        triggered = []
        for threshold in ALERT_THRESHOLDS:
            # Only alert if we crossed this threshold since last alert
            if current_level <= threshold < last_alerted_threshold:
                triggered.append(threshold)

        return triggered

    async def _send_low_battery_alert(
        self,
        entity_id: str,
        level: float,
        threshold: int
    ) -> None:
        """
        Send low battery alert notification.

        Args:
            entity_id: Entity ID
            level: Current battery level (%)
            threshold: Threshold that triggered alert (20, 10, or 5)
        """
        state = self.hass.states.get(entity_id)
        name = state.name if state else entity_id

        # Severity based on threshold
        if threshold == 5:
            icon = "🔴"
            urgency = "CRITICAL"
            action = "Replace immediately"
        elif threshold == 10:
            icon = "🟠"
            urgency = "LOW"
            action = "Replace soon"
        else:  # 20%
            icon = "🟡"
            urgency = "NOTICE"
            action = "Plan replacement"

        # Build message
        message = f"""{icon} Battery Alert: {name}

Battery level: {level:.0f}%
Status: {urgency}

Action: {action}

— Alfred"""

        # Send notification
        notification_id = f"alfred_battery_{entity_id}_{threshold}"

        await self.hass.services.async_call(
            "persistent_notification",
            "create",
            {
                "title": f"Battery {urgency}: {name}",
                "message": message,
                "notification_id": notification_id,
            },
            blocking=False,
        )

        _LOGGER.info(
            "Sent battery alert for %s: %d%% (threshold: %d%%)",
            name,
            level,
            threshold
        )

    # ========================================================================
    # DRAIN RATE CALCULATION & PREDICTION
    # ========================================================================

    async def calculate_drain_rate(
        self,
        entity_id: str,
        min_days: int = 7,
        max_days: int = 90
    ) -> dict[str, Any] | None:
        """
        Calculate battery drain rate using linear regression.

        Args:
            entity_id: Entity ID
            min_days: Minimum days of data required
            max_days: Maximum days of historical data to use

        Returns:
            Dictionary with drain rate info or None if insufficient data:
            {
                "drain_rate_per_day": float,  # % per day
                "confidence": float,  # 0-1
                "quality": str,  # "high", "medium", "low"
                "data_points": int,
                "r_squared": float,
                "days_of_data": int,
            }
        """
        # Get historical battery levels from performance metrics
        history = await self._get_battery_history(entity_id, max_days)

        if not history or len(history) < 2:
            _LOGGER.debug("Insufficient history for %s: %d points", entity_id, len(history) if history else 0)
            return None

        # Check if we have enough days of data
        first_date = history[0]["timestamp"]
        last_date = history[-1]["timestamp"]
        days_of_data = (last_date - first_date).days

        if days_of_data < min_days:
            _LOGGER.debug("Insufficient time range for %s: %d days (min: %d)", entity_id, days_of_data, min_days)
            return None

        # Prepare data for linear regression
        # X: days since first measurement
        # Y: battery level (%)
        x_values = []
        y_values = []

        for point in history:
            days_since_start = (point["timestamp"] - first_date).total_seconds() / 86400
            x_values.append(days_since_start)
            y_values.append(point["level"])

        # Calculate linear regression
        # Using simple least squares: y = mx + b
        n = len(x_values)
        sum_x = sum(x_values)
        sum_y = sum(y_values)
        sum_xy = sum(x * y for x, y in zip(x_values, y_values))
        sum_x2 = sum(x * x for x in x_values)

        # Slope (m) = (n*sum_xy - sum_x*sum_y) / (n*sum_x2 - sum_x^2)
        denominator = n * sum_x2 - sum_x * sum_x
        if denominator == 0:
            _LOGGER.debug("Cannot calculate regression for %s: denominator is zero", entity_id)
            return None

        slope = (n * sum_xy - sum_x * sum_y) / denominator
        intercept = (sum_y - slope * sum_x) / n

        # Drain rate is the negative slope (% per day)
        drain_rate_per_day = abs(slope)  # Absolute value

        # Calculate R-squared for confidence
        mean_y = sum_y / n
        ss_tot = sum((y - mean_y) ** 2 for y in y_values)
        ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(x_values, y_values))

        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
        r_squared = max(0, min(1, r_squared))  # Clamp to [0, 1]

        # Calculate confidence based on R-squared and data quality
        confidence = self._calculate_drain_confidence(r_squared, len(history), days_of_data)

        # Determine quality rating
        if confidence >= 0.8 and len(history) >= 20:
            quality = "high"
        elif confidence >= 0.6 and len(history) >= 10:
            quality = "medium"
        else:
            quality = "low"

        return {
            "drain_rate_per_day": drain_rate_per_day,
            "confidence": confidence,
            "quality": quality,
            "data_points": len(history),
            "r_squared": r_squared,
            "days_of_data": days_of_data,
        }

    def _calculate_drain_confidence(
        self,
        r_squared: float,
        data_points: int,
        days_of_data: int
    ) -> float:
        """
        Calculate confidence score for drain rate.

        Args:
            r_squared: R-squared from regression
            data_points: Number of data points
            days_of_data: Days of historical data

        Returns:
            Confidence score (0-1)
        """
        # Base confidence from R-squared
        confidence = r_squared

        # Penalty for insufficient data points
        if data_points < 10:
            confidence *= 0.7
        elif data_points < 20:
            confidence *= 0.85

        # Penalty for insufficient time range
        if days_of_data < 14:
            confidence *= 0.8
        elif days_of_data < 30:
            confidence *= 0.9

        # Bonus for lots of data
        if data_points >= 50 and days_of_data >= 60:
            confidence = min(1.0, confidence * 1.1)

        return max(0, min(1, confidence))

    async def predict_replacement_date(
        self,
        entity_id: str,
        current_level: float | None = None,
        drain_rate_per_day: float | None = None
    ) -> dict[str, Any] | None:
        """
        Predict battery replacement date.

        Args:
            entity_id: Entity ID
            current_level: Current battery level (if None, fetches current)
            drain_rate_per_day: Drain rate (if None, calculates)

        Returns:
            Dictionary with prediction info or None:
            {
                "predicted_date": datetime,
                "days_remaining": int,
                "confidence": float,  # 0-1
                "confidence_interval_days": int,  # ± days
                "current_level": float,
                "drain_rate_per_day": float,
            }
        """
        # Get current level if not provided
        if current_level is None:
            current_level = self._get_battery_level(entity_id)
            if current_level is None:
                return None

        # Calculate drain rate if not provided
        if drain_rate_per_day is None:
            drain_info = await self.calculate_drain_rate(entity_id)
            if not drain_info:
                return None
            drain_rate_per_day = drain_info["drain_rate_per_day"]
            confidence = drain_info["confidence"]
        else:
            # Use provided drain rate, but calculate confidence
            drain_info = await self.calculate_drain_rate(entity_id)
            confidence = drain_info["confidence"] if drain_info else 0.5

        # Safety check: minimum drain rate
        if drain_rate_per_day <= 0:
            _LOGGER.debug("Invalid drain rate for %s: %f", entity_id, drain_rate_per_day)
            return None

        # Calculate days until replacement (conservative: replace at 5%, not 0%)
        REPLACEMENT_THRESHOLD = 5.0  # Replace at 5%
        usable_level = max(0, current_level - REPLACEMENT_THRESHOLD)
        days_remaining = int(usable_level / drain_rate_per_day)

        # Apply conservative bias (add 10% margin for safety)
        days_remaining = int(days_remaining * 0.9)

        # Calculate confidence interval based on drain rate confidence
        # Lower confidence = wider interval
        if confidence >= 0.8:
            confidence_interval_days = 2
        elif confidence >= 0.6:
            confidence_interval_days = 5
        else:
            confidence_interval_days = 10

        # Calculate predicted date
        predicted_date = dt_util.now() + timedelta(days=days_remaining)

        return {
            "predicted_date": predicted_date,
            "days_remaining": days_remaining,
            "confidence": confidence,
            "confidence_interval_days": confidence_interval_days,
            "current_level": current_level,
            "drain_rate_per_day": drain_rate_per_day,
        }

    async def _get_battery_history(
        self,
        entity_id: str,
        max_days: int = 90
    ) -> list[dict[str, Any]]:
        """
        Get historical battery level data from performance metrics.

        Args:
            entity_id: Entity ID
            max_days: Maximum days of history

        Returns:
            List of {timestamp, level} dicts, sorted by timestamp
        """
        cutoff_date = dt_util.now() - timedelta(days=max_days)

        # Get historical data from performance metrics table
        history = await self._storage.get_battery_level_history(
            entity_id,
            cutoff_date
        )

        return history

    # ========================================================================
    # ABNORMAL DRAIN DETECTION
    # ========================================================================

    async def detect_abnormal_drain(
        self,
        entity_id: str,
        threshold_percentage: float = 50.0
    ) -> dict[str, Any] | None:
        """
        Detect if battery is draining abnormally fast.

        Compares current drain rate to baseline (historical average).
        Flags if current drain is >threshold% faster than baseline.

        Args:
            entity_id: Entity ID
            threshold_percentage: % faster than baseline to trigger (default: 50%)

        Returns:
            Dictionary with abnormal drain info or None if not detected:
            {
                "abnormal_drain_detected": bool,
                "current_drain_rate": float,
                "baseline_drain_rate": float,
                "percentage_faster": float,
                "severity": str,  # "minor", "moderate", "severe"
            }
        """
        # Get current drain rate
        drain_info = await self.calculate_drain_rate(entity_id)
        if not drain_info:
            return None

        current_drain_rate = drain_info["drain_rate_per_day"]

        # Calculate baseline drain rate
        baseline_drain_rate = await self._calculate_baseline_drain_rate(entity_id)
        if not baseline_drain_rate:
            # No baseline yet, store current as baseline
            await self._storage.save_battery_tracking(
                entity_id,
                {"baseline_drain_rate": current_drain_rate}
            )
            return None

        # Calculate percentage faster
        if baseline_drain_rate <= 0:
            return None

        percentage_faster = ((current_drain_rate - baseline_drain_rate) / baseline_drain_rate) * 100

        # Check if abnormal
        abnormal_detected = percentage_faster >= threshold_percentage

        # Determine severity
        if percentage_faster >= 100:
            severity = "severe"  # 2x or more
        elif percentage_faster >= 75:
            severity = "moderate"  # 1.75x
        else:
            severity = "minor"  # 1.5x

        result = {
            "abnormal_drain_detected": abnormal_detected,
            "current_drain_rate": current_drain_rate,
            "baseline_drain_rate": baseline_drain_rate,
            "percentage_faster": percentage_faster,
            "severity": severity,
        }

        # Update database if abnormal drain detected
        if abnormal_detected:
            tracking = await self._storage.get_battery_tracking(entity_id)

            # Check if this is a new abnormal drain event
            was_abnormal = tracking.get("abnormal_drain_detected") if tracking else False

            await self._storage.save_battery_tracking(
                entity_id,
                {
                    "abnormal_drain_detected": True,
                    "abnormal_drain_percentage": percentage_faster,
                    "abnormal_drain_since": tracking.get("abnormal_drain_since") or dt_util.now(),
                }
            )

            # Send alert if this is a new event
            if not was_abnormal:
                await self._send_abnormal_drain_alert(
                    entity_id,
                    current_drain_rate,
                    baseline_drain_rate,
                    percentage_faster,
                    severity
                )
        else:
            # Clear abnormal drain flag if previously set
            tracking = await self._storage.get_battery_tracking(entity_id)
            if tracking and tracking.get("abnormal_drain_detected"):
                await self._storage.save_battery_tracking(
                    entity_id,
                    {
                        "abnormal_drain_detected": False,
                        "abnormal_drain_percentage": None,
                        "abnormal_drain_since": None,
                    }
                )

        return result

    async def _calculate_baseline_drain_rate(
        self,
        entity_id: str,
        lookback_days: int = 180
    ) -> float | None:
        """
        Calculate baseline (average) drain rate from historical data.

        Uses battery replacement history to calculate average drain rate
        between replacements. If no replacement history, uses stored baseline.

        Args:
            entity_id: Entity ID
            lookback_days: Days of history to consider

        Returns:
            Baseline drain rate (% per day) or None
        """
        # Check for stored baseline
        tracking = await self._storage.get_battery_tracking(entity_id)
        if tracking and tracking.get("baseline_drain_rate"):
            return tracking["baseline_drain_rate"]

        # Try to calculate from replacement history
        replacement_history = await self._storage.get_battery_replacement_history(
            entity_id,
            limit=5  # Last 5 replacements
        )

        if not replacement_history or len(replacement_history) < 2:
            # Not enough history, use current drain rate as baseline
            drain_info = await self.calculate_drain_rate(entity_id)
            if drain_info:
                baseline = drain_info["drain_rate_per_day"]
                # Store for future use
                await self._storage.save_battery_tracking(
                    entity_id,
                    {"baseline_drain_rate": baseline}
                )
                return baseline
            return None

        # Calculate average time between replacements
        total_days = 0
        count = 0

        for i in range(len(replacement_history) - 1):
            current_replacement = replacement_history[i]["replacement_date"]
            previous_replacement = replacement_history[i + 1]["replacement_date"]

            days_between = (current_replacement - previous_replacement).days

            # Only include reasonable intervals (7-365 days)
            if 7 <= days_between <= 365:
                total_days += days_between
                count += 1

        if count == 0:
            return None

        avg_days_between = total_days / count

        # Assume battery goes from 100% to 5% (replacement threshold)
        # Drain rate = 95% / avg_days
        baseline_drain_rate = 95.0 / avg_days_between

        # Store baseline for future use
        await self._storage.save_battery_tracking(
            entity_id,
            {"baseline_drain_rate": baseline_drain_rate}
        )

        return baseline_drain_rate

    async def _send_abnormal_drain_alert(
        self,
        entity_id: str,
        current_drain_rate: float,
        baseline_drain_rate: float,
        percentage_faster: float,
        severity: str
    ) -> None:
        """
        Send abnormal drain alert notification.

        Args:
            entity_id: Entity ID
            current_drain_rate: Current drain rate (% per day)
            baseline_drain_rate: Baseline drain rate (% per day)
            percentage_faster: Percentage faster than baseline
            severity: "minor", "moderate", "severe"
        """
        state = self.hass.states.get(entity_id)
        name = state.name if state else entity_id

        # Severity-based formatting
        if severity == "severe":
            icon = "🔴"
            urgency = "CRITICAL"
        elif severity == "moderate":
            icon = "🟠"
            urgency = "WARNING"
        else:  # minor
            icon = "🟡"
            urgency = "NOTICE"

        # Estimate impact on battery life
        current_level = self._get_battery_level(entity_id)
        if current_level:
            normal_days = (current_level - 5) / baseline_drain_rate
            abnormal_days = (current_level - 5) / current_drain_rate
            days_lost = int(normal_days - abnormal_days)
        else:
            days_lost = None

        # Build message
        message = f"""{icon} Abnormal Battery Drain: {name}

Current drain: {current_drain_rate:.2f}% per day
Normal drain: {baseline_drain_rate:.2f}% per day
Draining {percentage_faster:.0f}% faster than normal

Severity: {urgency}
"""

        if days_lost:
            message += f"\nEstimated battery life reduced by ~{days_lost} days\n"

        message += """
Possible causes:
- Device malfunction or stuck in active state
- Poor signal strength (excessive retries)
- Environmental changes (temperature)
- Battery degradation

Recommended actions:
- Check device status and logs
- Verify signal strength
- Replace battery if old
- Contact support if issue persists

— Alfred"""

        # Send notification
        notification_id = f"alfred_abnormal_drain_{entity_id}"

        await self.hass.services.async_call(
            "persistent_notification",
            "create",
            {
                "title": f"Abnormal Battery Drain: {name}",
                "message": message,
                "notification_id": notification_id,
            },
            blocking=False,
        )

        _LOGGER.warning(
            "Abnormal battery drain detected for %s: %.2f%% per day (%.0f%% faster than baseline)",
            name,
            current_drain_rate,
            percentage_faster
        )

    # ========================================================================
    # BATTERY TYPE CLASSIFICATION & GROUPING
    # ========================================================================

    BATTERY_TYPE_KEYWORDS = {
        "AA": ["aa", "double a", "aa battery"],
        "AAA": ["aaa", "triple a", "aaa battery"],
        "CR2032": ["cr2032", "coin cell", "2032"],
        "CR2450": ["cr2450", "2450"],
        "9V": ["9v", "9 volt", "pp3"],
        "18650": ["18650", "li-ion"],
        "CR123A": ["cr123", "123a"],
        "LR44": ["lr44", "ag13"],
        "rechargeable": ["rechargeable", "nimh", "nicd"],
    }

    async def classify_battery_type(self, entity_id: str) -> str | None:
        """
        Classify battery type for a device.

        Checks:
        1. Manual override from database
        2. Device name keywords
        3. Manufacturer/model info
        4. Default to "unknown"

        Args:
            entity_id: Entity ID

        Returns:
            Battery type (e.g., "AA", "AAA", "CR2032") or None
        """
        # Check for manual override in database
        tracking = await self._storage.get_battery_tracking(entity_id)
        if tracking and tracking.get("battery_type_override"):
            return tracking["battery_type_override"]

        # Get device info
        state = self.hass.states.get(entity_id)
        if not state:
            return None

        # Check device name for keywords
        device_name = state.name.lower() if state.name else entity_id.lower()

        for battery_type, keywords in self.BATTERY_TYPE_KEYWORDS.items():
            for keyword in keywords:
                if keyword in device_name:
                    return battery_type

        # Check manufacturer/model attributes
        manufacturer = state.attributes.get("manufacturer", "").lower()
        model = state.attributes.get("model", "").lower()

        for battery_type, keywords in self.BATTERY_TYPE_KEYWORDS.items():
            for keyword in keywords:
                if keyword in manufacturer or keyword in model:
                    return battery_type

        # Check entity registry for device info
        entity_registry = er.async_get(self.hass)
        entity_entry = entity_registry.async_get(entity_id)

        if entity_entry:
            device_registry = dr.async_get(self.hass)
            device = device_registry.async_get(entity_entry.device_id) if entity_entry.device_id else None

            if device:
                device_model = (device.model or "").lower()
                device_mfg = (device.manufacturer or "").lower()

                for battery_type, keywords in self.BATTERY_TYPE_KEYWORDS.items():
                    for keyword in keywords:
                        if keyword in device_model or keyword in device_mfg:
                            return battery_type

        # Return None if type cannot be determined
        return None

    async def group_by_battery_type(self) -> dict[str, list[dict[str, Any]]]:
        """
        Group all batteries by type.

        Returns:
            Dictionary mapping battery type to list of devices:
            {
                "AA": [{"entity_id": ..., "name": ..., "level": ...}, ...],
                "CR2032": [...],
                "unknown": [...]
            }
        """
        batteries = await self.monitor_all_batteries()
        grouped: dict[str, list[dict[str, Any]]] = {}

        for entity_id, status in batteries.items():
            # Classify battery type
            battery_type = await self.classify_battery_type(entity_id)
            if not battery_type:
                battery_type = "unknown"

            # Add to group
            if battery_type not in grouped:
                grouped[battery_type] = []

            # Get tracking info for predictions
            tracking = await self._storage.get_battery_tracking(entity_id)

            device_info = {
                "entity_id": entity_id,
                "name": status.name,
                "current_level": status.current_level,
                "days_remaining": tracking.get("days_remaining") if tracking else None,
                "predicted_replacement_date": tracking.get("predicted_replacement_date") if tracking else None,
            }

            grouped[battery_type].append(device_info)

        # Sort each group by days_remaining (lowest first)
        for battery_type in grouped:
            grouped[battery_type].sort(
                key=lambda x: x["days_remaining"] if x["days_remaining"] is not None else 999999
            )

        return grouped

    async def generate_bulk_order_suggestion(
        self,
        days_threshold: int = 60
    ) -> dict[str, Any]:
        """
        Generate bulk ordering suggestions for batteries.

        Groups batteries by type and suggests quantities based on:
        - Batteries needing replacement soon (within threshold)
        - Spare batteries for commonly used types

        Args:
            days_threshold: Days ahead to plan for (default: 60)

        Returns:
            Dictionary with shopping list and details:
            {
                "shopping_list": {
                    "AA": {"quantity": 8, "devices": [...], "cost_estimate": 12.00},
                    "CR2032": {"quantity": 6, "devices": [...], "cost_estimate": 9.00},
                },
                "total_estimated_cost": 21.00,
                "replacement_count": 14,
                "next_replacement_date": datetime,
            }
        """
        grouped = await self.group_by_battery_type()
        shopping_list: dict[str, dict[str, Any]] = {}
        total_cost = 0.0
        replacement_count = 0
        next_replacement_date = None

        # Cost estimates (approximate, in USD)
        BATTERY_COSTS = {
            "AA": 1.50,  # Per battery
            "AAA": 1.50,
            "CR2032": 1.50,
            "CR2450": 2.00,
            "9V": 3.00,
            "18650": 5.00,
            "CR123A": 3.00,
            "LR44": 1.00,
            "rechargeable": 4.00,
            "unknown": 2.00,
        }

        cutoff_date = dt_util.now() + timedelta(days=days_threshold)

        for battery_type, devices in grouped.items():
            needing_replacement = []

            for device in devices:
                # Check if replacement needed within threshold
                if device["predicted_replacement_date"]:
                    if device["predicted_replacement_date"] <= cutoff_date:
                        needing_replacement.append(device)

                        # Track earliest replacement date
                        if not next_replacement_date or device["predicted_replacement_date"] < next_replacement_date:
                            next_replacement_date = device["predicted_replacement_date"]

            # Skip if no devices need replacement
            if not needing_replacement:
                continue

            # Calculate quantity
            # Base: number of devices needing replacement
            # Bonus: +2 spares for frequently used types (≥4 devices)
            quantity = len(needing_replacement)
            if len(devices) >= 4:
                quantity += 2  # Add spares

            # Calculate cost
            unit_cost = BATTERY_COSTS.get(battery_type, 2.00)
            cost_estimate = quantity * unit_cost

            shopping_list[battery_type] = {
                "quantity": quantity,
                "devices": needing_replacement,
                "cost_estimate": round(cost_estimate, 2),
                "unit_cost": unit_cost,
            }

            total_cost += cost_estimate
            replacement_count += len(needing_replacement)

        return {
            "shopping_list": shopping_list,
            "total_estimated_cost": round(total_cost, 2),
            "replacement_count": replacement_count,
            "next_replacement_date": next_replacement_date,
            "days_threshold": days_threshold,
        }

    async def set_battery_type_override(
        self,
        entity_id: str,
        battery_type: str
    ) -> None:
        """
        Manually set battery type for a device.

        Args:
            entity_id: Entity ID
            battery_type: Battery type (e.g., "AA", "CR2032")
        """
        await self._storage.save_battery_tracking(
            entity_id,
            {
                "battery_type_override": battery_type,
                "battery_type_confidence": "manual_override",
            }
        )

        _LOGGER.info("Set battery type override for %s: %s", entity_id, battery_type)

    # ========================================================================
    # HELPER METHODS
    # ========================================================================

    async def get_battery_count(self) -> int:
        """Get count of discovered batteries."""
        batteries = await self.discover_battery_sensors()
        return len(batteries)

    async def get_low_batteries(self, threshold: int = 20) -> list[str]:
        """
        Get list of batteries below threshold.

        Args:
            threshold: Battery level threshold (%)

        Returns:
            List of entity IDs below threshold
        """
        batteries = await self.monitor_all_batteries()

        low_batteries = [
            entity_id
            for entity_id, status in batteries.items()
            if status.current_level <= threshold
        ]

        return low_batteries

    async def get_battery_summary(self) -> dict[str, Any]:
        """
        Get summary of all batteries.

        Returns:
            Dictionary with battery statistics
        """
        batteries = await self.monitor_all_batteries()

        if not batteries:
            return {
                "total_count": 0,
                "low_count": 0,
                "critical_count": 0,
                "average_level": 0,
            }

        levels = [s.current_level for s in batteries.values()]

        return {
            "total_count": len(batteries),
            "low_count": sum(1 for level in levels if level <= 20),
            "critical_count": sum(1 for level in levels if level <= 10),
            "average_level": sum(levels) / len(levels),
            "min_level": min(levels),
            "max_level": max(levels),
        }
