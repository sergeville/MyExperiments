"""Config flow for Alfred Digital Butler integration."""
from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import HomeAssistant, callback
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers import config_validation as cv

from .const import (
    AI_PROVIDER_GEMINI,
    AI_PROVIDER_OLLAMA,
    AI_PROVIDER_OPENAI,
    CONF_AI_PROVIDER,
    CONF_API_KEY,
    CONF_FORMAL_ADDRESS,
    CONF_MODEL,
    CONF_USER_NAME,
    DEFAULT_AI_PROVIDER,
    DEFAULT_FORMAL_ADDRESS,
    DEFAULT_MODEL_GEMINI,
    DEFAULT_MODEL_OPENAI,
    DEFAULT_USER_NAME,
    DOMAIN,
)

_LOGGER = logging.getLogger(__name__)


class AlfredConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for Alfred Digital Butler."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle the initial step."""
        errors: dict[str, str] = {}

        if user_input is not None:
            # Validate API key if not using Ollama
            if user_input[CONF_AI_PROVIDER] != AI_PROVIDER_OLLAMA:
                if not user_input.get(CONF_API_KEY):
                    errors["base"] = "api_key_required"
                else:
                    # Test the API key
                    is_valid = await self._test_api_key(
                        user_input[CONF_AI_PROVIDER],
                        user_input[CONF_API_KEY],
                        user_input.get(CONF_MODEL),
                    )
                    if not is_valid:
                        errors["base"] = "invalid_api_key"

            if not errors:
                # Create the entry
                return self.async_create_entry(
                    title=f"Alfred ({user_input.get(CONF_USER_NAME, 'sir')})",
                    data=user_input,
                )

        # Show the form
        data_schema = vol.Schema(
            {
                vol.Required(CONF_USER_NAME, default=DEFAULT_USER_NAME): cv.string,
                vol.Required(
                    CONF_FORMAL_ADDRESS, default=DEFAULT_FORMAL_ADDRESS
                ): cv.string,
                vol.Required(CONF_AI_PROVIDER, default=DEFAULT_AI_PROVIDER): vol.In(
                    [AI_PROVIDER_GEMINI, AI_PROVIDER_OPENAI, AI_PROVIDER_OLLAMA]
                ),
                vol.Optional(CONF_API_KEY): cv.string,
                vol.Optional(CONF_MODEL): cv.string,
            }
        )

        return self.async_show_form(
            step_id="user",
            data_schema=data_schema,
            errors=errors,
            description_placeholders={
                "user_name": "What shall I call you?",
                "formal_address": "How should Alfred address you? (sir/madam/etc)",
            },
        )

    async def _test_api_key(
        self, provider: str, api_key: str, model: str | None = None
    ) -> bool:
        """Test if the API key is valid."""
        try:
            if provider == AI_PROVIDER_GEMINI:
                import google.generativeai as genai

                genai.configure(api_key=api_key)
                model_name = model or DEFAULT_MODEL_GEMINI
                genai_model = genai.GenerativeModel(model_name)
                response = await genai_model.generate_content_async("Hello")
                return bool(response.text)

            elif provider == AI_PROVIDER_OPENAI:
                from openai import AsyncOpenAI

                client = AsyncOpenAI(api_key=api_key)
                model_name = model or DEFAULT_MODEL_OPENAI
                response = await client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": "Hello"}],
                    max_tokens=10,
                )
                return bool(response.choices[0].message.content)

            return True

        except Exception as err:
            _LOGGER.error("Error testing API key: %s", err)
            return False

    @staticmethod
    @callback
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> AlfredOptionsFlow:
        """Get the options flow for this handler."""
        return AlfredOptionsFlow(config_entry)


class AlfredOptionsFlow(config_entries.OptionsFlow):
    """Handle options flow for Alfred."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        """Initialize options flow."""
        self.config_entry = config_entry

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Manage the options."""
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        return self.async_show_form(
            step_id="init",
            data_schema=vol.Schema(
                {
                    vol.Optional(
                        CONF_USER_NAME,
                        default=self.config_entry.data.get(
                            CONF_USER_NAME, DEFAULT_USER_NAME
                        ),
                    ): cv.string,
                    vol.Optional(
                        CONF_FORMAL_ADDRESS,
                        default=self.config_entry.data.get(
                            CONF_FORMAL_ADDRESS, DEFAULT_FORMAL_ADDRESS
                        ),
                    ): cv.string,
                }
            ),
        )
