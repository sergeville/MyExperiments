"""Constants for the Alfred Digital Butler integration."""

DOMAIN = "alfred"

# ============================================================================
# Configuration Keys
# ============================================================================
CONF_AI_PROVIDER = "ai_provider"
CONF_API_KEY = "api_key"
CONF_MODEL = "model"
CONF_USER_NAME = "user_name"
CONF_FORMAL_ADDRESS = "formal_address"

# ============================================================================
# AI Providers
# ============================================================================
AI_PROVIDER_GEMINI = "gemini"
AI_PROVIDER_OPENAI = "openai"
AI_PROVIDER_OLLAMA = "ollama"

DEFAULT_AI_PROVIDER = AI_PROVIDER_GEMINI
DEFAULT_MODEL_GEMINI = "gemini-1.5-flash"
DEFAULT_MODEL_OPENAI = "gpt-4"
DEFAULT_MODEL_OLLAMA = "llama3.2:3b"
DEFAULT_USER_NAME = "sir"
DEFAULT_FORMAL_ADDRESS = "sir"

# ============================================================================
# Network Configuration
# ============================================================================
# Ollama URL - can be overridden in config
DEFAULT_OLLAMA_URL = "http://host.docker.internal:11434"

# Alfred Agent Service URL (for chat_with_memory)
DEFAULT_AGENT_URL = "http://host.docker.internal:8052"

# ============================================================================
# Rate Limiting
# ============================================================================
RATE_LIMIT_CALLS_PER_MINUTE = 10

# ============================================================================
# Conversation Settings
# ============================================================================
CONVERSATION_HISTORY_LIMIT = 10  # Max messages to keep in history
LLM_TIMEOUT_SECONDS = 60  # Timeout for LLM API calls

# ============================================================================
# LLM Response Settings  
# ============================================================================
LLM_TEMPERATURE = 0.3  # Lower for more deterministic responses
LLM_MAX_TOKENS_ACTION = 80  # Tokens for action confirmations
LLM_MAX_TOKENS_INFO = 150  # Tokens for information responses
LLM_CONTEXT_WINDOW = 2048  # Context window size
LLM_TOP_P = 0.9
LLM_REPEAT_PENALTY = 1.3  # Higher to reduce repetition

# Services
SERVICE_SEND_MESSAGE = "send_message"
SERVICE_START_CONVERSATION = "start_conversation"
SERVICE_CHAT_WITH_MEMORY = "chat_with_memory"
SERVICE_GET_DEVICE_RUNTIME = "get_device_runtime"
SERVICE_RESET_DEVICE_RUNTIME = "reset_device_runtime"
SERVICE_GET_POWER_QUALITY = "get_power_quality"
SERVICE_GET_DEVICE_HEALTH = "get_device_health"
SERVICE_ANALYZE_DEGRADATION = "analyze_degradation"
SERVICE_DISMISS_DEGRADATION_ALERT = "dismiss_degradation_alert"
SERVICE_DIAGNOSE_DEVICE = "diagnose_device"
SERVICE_GET_BATTERY_STATUS = "get_battery_status"
SERVICE_GET_BATTERY_SHOPPING_LIST = "get_battery_shopping_list"
SERVICE_RECORD_BATTERY_REPLACEMENT = "record_battery_replacement"
SERVICE_SET_BATTERY_TYPE = "set_battery_type"
SERVICE_GET_ENERGY_CONSUMPTION = "get_energy_consumption"
SERVICE_GET_ENERGY_PATTERNS = "get_energy_patterns"
SERVICE_GET_ENERGY_INSIGHTS = "get_energy_insights"
SERVICE_ANALYZE_ENERGY_DEVICE = "analyze_energy_device"
SERVICE_PREDICT_PIPE_FREEZE = "predict_pipe_freeze"
SERVICE_TRIGGER_EMERGENCY = "trigger_emergency"
SERVICE_RESOLVE_EMERGENCY = "resolve_emergency"
SERVICE_GET_EMERGENCY_STATUS = "get_emergency_status"
SERVICE_GET_EMERGENCY_LOG = "get_emergency_log"
SERVICE_GENERATE_SECURITY_REPORT = "generate_security_report"
SERVICE_ADD_GUEST_CODE = "add_guest_code"
SERVICE_GET_ACCESS_HISTORY = "get_access_history"
SERVICE_GET_GUEST_CODES = "get_guest_codes"
SERVICE_GENERATE_WEEKLY_ACCESS_SUMMARY = "generate_weekly_access_summary"

# Events
EVENT_ALFRED_SUGGESTION = "alfred_suggestion"
EVENT_ALFRED_ALERT = "alfred_alert"
EVENT_USER_TYPING = "alfred_user_typing"
EVENT_DEGRADATION_DETECTED = "alfred_degradation_detected"
EVENT_PERFORMANCE_RESTORED = "alfred_performance_restored"
EVENT_DEGRADATION_ESCALATED = "alfred_degradation_escalated"
EVENT_EMERGENCY_ACTIVATED = "alfred_emergency_activated"
EVENT_EMERGENCY_DEACTIVATED = "alfred_emergency_deactivated"
EVENT_EMERGENCY_ACTION_EXECUTED = "alfred_emergency_action_executed"
EVENT_SECURITY_REPORT_AVAILABLE = "alfred_security_report_available"
EVENT_LOCK_ACCESS = "alfred_lock_access"
EVENT_LOCK_ANOMALY = "alfred_lock_anomaly"

# Attributes
ATTR_MESSAGE = "message"
ATTR_SUGGESTION_TYPE = "suggestion_type"
ATTR_ACTION_ID = "action_id"
ATTR_CONVERSATION_ID = "conversation_id"
ATTR_MODE = "mode"  # "text" or "voice"

# Notification IDs
NOTIFICATION_PREFIX = "alfred_"

# Greeting times
GREETING_MORNING = 12
GREETING_AFTERNOON = 17
GREETING_EVENING = 21

# TTS Configuration
CONF_TTS_ENABLED = "tts_enabled"
CONF_TTS_ENTITY = "tts_entity"
CONF_TTS_LANGUAGE = "tts_language"
CONF_TTS_VOICE = "tts_voice"
DEFAULT_TTS_ENABLED = True
DEFAULT_TTS_ENTITY = "tts.google_ai_tts"
DEFAULT_TTS_LANGUAGE = "en-GB"  # British English
DEFAULT_TTS_VOICE = "en-GB-Standard-B"  # British male voice
