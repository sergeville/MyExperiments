"""Conversation agent for Alfred Digital Butler."""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any

from homeassistant.components import conversation
from homeassistant.core import HomeAssistant
from homeassistant.helpers import intent
from homeassistant.config_entries import ConfigEntry

from .const import (
    CONF_AI_PROVIDER,
    CONF_API_KEY,
    CONF_FORMAL_ADDRESS,
    CONF_MODEL,
    CONF_USER_NAME,
    DEFAULT_FORMAL_ADDRESS,
    DEFAULT_MODEL_GEMINI,
    DEFAULT_MODEL_OPENAI,
    DEFAULT_USER_NAME,
    DOMAIN,
    EVENT_USER_TYPING,
    GREETING_AFTERNOON,
    GREETING_EVENING,
    GREETING_MORNING,
    AI_PROVIDER_GEMINI,
    AI_PROVIDER_OPENAI,
    AI_PROVIDER_OLLAMA,
)

_LOGGER = logging.getLogger(__name__)


class AlfredConversationAgent(conversation.AbstractConversationAgent):
    """Alfred Digital Butler conversation agent."""

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        intelligence_engine,
    ) -> None:
        """Initialize Alfred conversation agent."""
        self.hass = hass
        self.entry = entry
        self.intelligence_engine = intelligence_engine
        self._conversation_history: dict[str, list[dict]] = {}
        self._llm_client = None
        self._user_name = entry.data.get(CONF_USER_NAME, DEFAULT_USER_NAME)
        self._formal_address = entry.data.get(CONF_FORMAL_ADDRESS, DEFAULT_FORMAL_ADDRESS)
        self._last_interaction: dict[str, float] = {}  # Track last interaction time per conversation

    async def async_setup(self) -> None:
        """Set up the conversation agent."""
        # Initialize LLM client
        await self._async_init_llm_client()

        # Register with conversation component
        conversation.async_set_agent(self.hass, self.entry, self)

        _LOGGER.info("Alfred conversation agent registered")

    async def _async_init_llm_client(self) -> None:
        """Initialize the LLM client based on provider."""
        provider = self.entry.data.get(CONF_AI_PROVIDER)
        api_key = self.entry.data.get(CONF_API_KEY)
        model = self.entry.data.get(CONF_MODEL)

        if provider == AI_PROVIDER_GEMINI:
            import google.generativeai as genai

            genai.configure(api_key=api_key)
            # Try different model names - some APIs use different formats
            model_name = model or DEFAULT_MODEL_GEMINI

            # Remove 'models/' prefix if present
            if model_name.startswith('models/'):
                model_name = model_name.replace('models/', '')

            self._llm_client = genai.GenerativeModel(
                model_name=model_name,
                system_instruction=self._get_system_prompt("default"),
            )
            _LOGGER.info("Alfred initialized with Gemini: %s", model_name)

        elif provider == AI_PROVIDER_OPENAI:
            from openai import AsyncOpenAI

            self._llm_client = AsyncOpenAI(api_key=api_key)
            self._model = model or DEFAULT_MODEL_OPENAI
            _LOGGER.info("Alfred initialized with OpenAI: %s", self._model)

        elif provider == AI_PROVIDER_OLLAMA:
            # For Ollama, we use HTTP client
            self._ollama_url = "http://host.docker.internal:11434"  # Ollama default
            self._model = model or "llama3.2:3b"
            _LOGGER.info(f"Alfred initialized with Ollama: {self._model} at {self._ollama_url}")

    def _get_system_prompt(self, conversation_id: str = "default") -> str:
        """Get the system prompt that defines Alfred's personality."""
        import time
        from datetime import datetime

        # Check if we should greet (first interaction or 3+ hours since last)
        current_time = time.time()
        last_time = self._last_interaction.get(conversation_id, 0)
        hours_since = (current_time - last_time) / 3600
        should_greet = hours_since >= 3

        # Update last interaction time
        self._last_interaction[conversation_id] = current_time

        greeting_instruction = ""
        if should_greet:
            hour = datetime.now().hour
            if 5 <= hour < 12:
                time_greeting = "Good morning"
            elif 12 <= hour < 18:
                time_greeting = "Good afternoon"
            else:
                time_greeting = "Good evening"
            greeting_instruction = f'\nSTART your response with: "{time_greeting}, {self._formal_address}."'
        else:
            greeting_instruction = '\nDO NOT greet - respond directly to the request.'

        return f"""You are Alfred, a Digital Butler managing a Home Assistant smart home.

CRITICAL RULES - NEVER BREAK THESE:
1. ALWAYS address the user ONLY as "{self._formal_address}" - NEVER use their name, NEVER use "Master"
2. ONLY report ACTUAL data from the current home state provided below
3. NEVER invent, imagine, or make up devices, alerts, messages, or scenarios
4. NEVER reference Batman, Batcomputer, Wayne Manor, or any fictional content
5. If you don't have real data, say "I don't have that information at the moment, {self._formal_address}."

CORE PERSONA:
- **Action-Oriented**: When actions have been executed, confirm them directly
- **Direct and Efficient**: Provide concise, actionable responses based ONLY on real data
- **Truthful**: NEVER make up data - only use what's in CURRENT HOME STATE below
- Address user ONLY as "{self._formal_address}"

YOUR CAPABILITIES:
- Real-time monitoring: All lights, switches, climate, doors/windows, sensors
- Device control: Turn devices on/off, adjust temperatures, change settings
- Data analysis: Pattern detection, trend identification, outcome forecasting
- You are PART OF Home Assistant with complete home awareness and control

COMMUNICATION STYLE:
- **Direct First**: Confirm executed actions immediately, then provide context if helpful
- **Concise**: 1-2 sentences for simple requests, 2-3 for complex analysis
- **Actionable**: When confirming an action, state what was done clearly
- **Confident**: Speak with authority about the home state and executed actions

ACTION CONFIRMATION FORMAT:
- Device control: "Certainly, {self._formal_address}. [Device] is now [state]."
- Settings change: "Very good, {self._formal_address}. I've adjusted [device] to [setting]."
- Information: "[Direct answer]. [Additional relevant context if helpful]"

RESPONSE LENGTH GUIDELINES:
- Simple action confirmation: 1 sentence
- Information request: 1-2 sentences
- Analysis request: 2-3 sentences maximum
- Complex explanation: 3-4 sentences maximum
NEVER exceed 4 sentences unless explicitly asked for detailed analysis.

UNITS AND MEASUREMENTS:
- Always use METRIC SYSTEM: Celsius (°C), meters (m), kilometers (km), kilograms (kg)
- Time: 24-hour format (17:00, not 5 PM)
- Energy: kilowatt-hours (kWh), watts (W){greeting_instruction}

EXAMPLES:

CORRECT EXAMPLES:

Action Confirmation:
[ACTION EXECUTED]: turn_on on switch.living_room - Result: success
You: "Certainly, {self._formal_address}. The living room switch is now on."

Information Request:
User: "What's the temperature?"
[CURRENT HOME STATE shows: sensor.temperature = 8.4°C]
You: "The current temperature is 8.4°C, {self._formal_address}."

No Data Available:
User: "Any alerts?"
[CURRENT HOME STATE shows: No alerts]
You: "No alerts at the moment, {self._formal_address}."

WRONG EXAMPLES - NEVER DO THIS:

❌ WRONG: "Right then, Master Serge..." (uses name + wrong title)
✅ CORRECT: "Certainly, {self._formal_address}..."

❌ WRONG: "Batman is running behind..." (invented fictional content)
✅ CORRECT: Only report actual home state data

❌ WRONG: "The Batcomputer says..." (made-up device)
✅ CORRECT: Only mention real devices from CURRENT HOME STATE

REMEMBER: Use ONLY "{self._formal_address}" as the title. Use ONLY real data from CURRENT HOME STATE."""

    async def async_acknowledge_user(self, mode: str = "text") -> str:
        """Acknowledge user initiating contact - the 'I'm listening' moment."""
        greeting = self._get_contextual_greeting()

        # Fire event so frontend can show acknowledgment
        self.hass.bus.async_fire(
            EVENT_USER_TYPING,
            {"greeting": greeting, "mode": mode},
        )

        return greeting

    def _get_contextual_greeting(self) -> str:
        """Get context-aware greeting based on time and recent activity."""
        hour = datetime.now().hour

        if hour < GREETING_MORNING:
            time_greeting = "Good morning"
        elif hour < GREETING_AFTERNOON:
            time_greeting = "Good afternoon"
        elif hour < GREETING_EVENING:
            time_greeting = "Good evening"
        else:
            time_greeting = "Good evening"

        # Check if this is a returning conversation
        # For now, simple greeting. Can be enhanced with activity context
        return f"{time_greeting}, {self._formal_address}. I'm listening."

    @property
    def supported_languages(self) -> list[str]:
        """Return supported languages."""
        return ["en"]

    async def async_process(
        self,
        user_input: conversation.ConversationInput,
    ) -> conversation.ConversationResult:
        """Process a user message."""
        _LOGGER.debug("Alfred processing: %s", user_input.text)

        # Get conversation ID
        conversation_id = user_input.conversation_id or "default"

        # Initialize conversation history if needed
        if conversation_id not in self._conversation_history:
            self._conversation_history[conversation_id] = []

        # NEW: Detect and execute intents BEFORE LLM call
        action_executed = await self._detect_and_execute_intent(user_input.text)

        # Build context from Home Assistant state
        context = await self._build_context()

        # Add user message to history
        self._conversation_history[conversation_id].append({
            "role": "user",
            "content": user_input.text,
        })

        # Limit conversation history to last 10 messages (5 exchanges)
        if len(self._conversation_history[conversation_id]) > 10:
            self._conversation_history[conversation_id] = \
                self._conversation_history[conversation_id][-10:]

        try:
            # Get response from LLM (now with action execution status)
            response_text = await self._get_llm_response(
                user_input.text,
                conversation_id,
                context,
                action_executed=action_executed,
            )

            # Add assistant response to history
            self._conversation_history[conversation_id].append({
                "role": "assistant",
                "content": response_text,
            })

            # Create intent response with speech
            intent_response = intent.IntentResponse(language=user_input.language)
            intent_response.async_set_speech(response_text)

            return conversation.ConversationResult(
                response=intent_response,
                conversation_id=conversation_id,
            )

        except Exception as err:
            _LOGGER.error("Error processing conversation: %s", err)
            error_response = f"My apologies, {self._formal_address}. I encountered a difficulty. Please try again."

            # Create intent response with error message
            intent_response = intent.IntentResponse(language=user_input.language)
            intent_response.async_set_speech(error_response)

            return conversation.ConversationResult(
                response=intent_response,
                conversation_id=conversation_id,
            )

    async def _get_llm_response(
        self,
        user_message: str,
        conversation_id: str,
        context: dict[str, Any],
        action_executed: dict[str, Any] | None = None,
    ) -> str:
        """Get response from LLM."""
        provider = self.entry.data.get(CONF_AI_PROVIDER)

        _LOGGER.debug(f"Getting LLM response for: {user_message}")
        _LOGGER.debug(f"Provider: {provider}, LLM client initialized: {self._llm_client is not None}")

        # Build enhanced prompt with context and action status
        enhanced_prompt = self._build_enhanced_prompt(user_message, context, action_executed)

        if provider == AI_PROVIDER_GEMINI:
            if not self._llm_client:
                _LOGGER.error("Gemini client not initialized!")
                return f"My apologies, {self._formal_address}. My systems are not fully operational."

            try:
                # Use Gemini
                _LOGGER.debug(f"Sending to Gemini: {enhanced_prompt[:100]}...")
                response = await self._llm_client.generate_content_async(enhanced_prompt)
                _LOGGER.debug(f"Gemini response: {response.text[:100]}...")
                return response.text
            except Exception as e:
                _LOGGER.error(f"Error calling Gemini: {e}")
                return f"My apologies, {self._formal_address}. I encountered a difficulty accessing my intelligence systems."

        elif provider == AI_PROVIDER_OPENAI:
            # Use OpenAI
            messages = [
                {"role": "system", "content": self._get_system_prompt(conversation_id)},
            ]
            messages.extend(self._conversation_history.get(conversation_id, []))

            response = await self._llm_client.chat.completions.create(
                model=self._model,
                messages=messages,
                temperature=0.7,
                max_tokens=500,
            )
            return response.choices[0].message.content

        elif provider == AI_PROVIDER_OLLAMA:
            # Use Ollama via HTTP
            try:
                import aiohttp
                import json as json_module
                import traceback

                _LOGGER.debug(f"Calling Ollama at {self._ollama_url} with model {self._model}")

                async with aiohttp.ClientSession() as session:
                    # Use chat endpoint with proper system message separation
                    system_prompt = self._get_system_prompt(conversation_id)

                    # Build messages array with system role
                    messages = [{"role": "system", "content": system_prompt}]

                    # Add conversation history
                    history = self._conversation_history.get(conversation_id, [])
                    messages.extend(history[-6:])  # Last 3 exchanges

                    # Add current user message
                    messages.append({"role": "user", "content": enhanced_prompt})

                    # Adjust num_predict based on whether action was executed
                    if action_executed and action_executed.get("action"):
                        # Action confirmation needs fewer tokens
                        num_predict = 80
                    else:
                        # Information/analysis needs more tokens
                        num_predict = 150

                    payload = {
                        "model": self._model,
                        "messages": messages,
                        "stream": False,
                        "options": {
                            "temperature": 0.3,      # Lower for more deterministic responses
                            "num_predict": num_predict,
                            "num_ctx": 2048,
                            "top_p": 0.9,
                            "repeat_penalty": 1.3,   # Higher to reduce repetition
                        }
                    }

                    _LOGGER.debug(f"Sending request to Ollama /api/chat...")

                    async with session.post(
                        f"{self._ollama_url}/api/chat",
                        json=payload,
                        timeout=aiohttp.ClientTimeout(total=60)
                    ) as response:
                        _LOGGER.debug(f"Ollama response status: {response.status}")
                        if response.status == 200:
                            result = await response.json()
                            ollama_response = result.get("message", {}).get("content", f"I'm here, {self._formal_address}.")
                            _LOGGER.debug(f"Ollama response text: {ollama_response[:100]}")

                            # Validate and fix response
                            validated_response = self._validate_response(ollama_response)
                            return validated_response
                        else:
                            error_text = await response.text()
                            _LOGGER.error(f"Ollama returned status {response.status}: {error_text}")
                            return f"My apologies, {self._formal_address}. I'm having difficulty with my systems."

            except Exception as e:
                _LOGGER.error(f"Error calling Ollama: {type(e).__name__}: {str(e)}")
                _LOGGER.error(f"Traceback: {traceback.format_exc()}")
                return f"My apologies, {self._formal_address}. I encountered a difficulty."

        return f"I'm ready to assist, {self._formal_address}."

    def _validate_response(self, response: str) -> str:
        """Validate and fix response to enforce constraints."""
        import re

        original_response = response
        violations = []

        # 1. Check for "Master" title with any name after it (case-insensitive)
        master_pattern = r'\bmaster\s+([A-Z][a-z]+)\b'
        if re.search(master_pattern, response, re.IGNORECASE):
            violations.append("Used 'Master [Name]' format")
            # Replace "Master [Name]" with just the formal address
            response = re.sub(master_pattern, self._formal_address, response, flags=re.IGNORECASE)

        # Also catch standalone "Master"
        if re.search(r'\bmaster\b', response, re.IGNORECASE):
            violations.append("Used 'Master' title")
            response = re.sub(r'\bmaster\b', self._formal_address, response, flags=re.IGNORECASE)

        # 2. Check for any capitalized names (likely user names) - be aggressive
        # Common first names that should be replaced with formal address
        common_names = ['Serge', 'John', 'James', 'Robert', 'Michael', 'William', 'David',
                       'Richard', 'Joseph', 'Thomas', 'Charles', 'Christopher', 'Daniel',
                       'Matthew', 'Anthony', 'Mark', 'Donald', 'Steven', 'Paul', 'Andrew']

        for name in common_names:
            if re.search(rf'\b{name}\b', response):
                violations.append(f"Used name '{name}'")
                response = re.sub(rf'\b{name}\b', self._formal_address, response)

        # Also check configured user_name if different from "sir"
        if self._user_name != "sir":
            if re.search(rf'\b{re.escape(self._user_name)}\b', response, re.IGNORECASE):
                violations.append(f"Used configured user name '{self._user_name}'")
                response = re.sub(rf'\b{re.escape(self._user_name)}\b', self._formal_address, response, flags=re.IGNORECASE)

        # 3. Check for Fahrenheit mentions
        fahrenheit_pattern = r'(\d+(?:\.\d+)?)\s*(?:degrees?\s*)?(?:fahrenheit|°F|F\b)'
        if re.search(fahrenheit_pattern, response, re.IGNORECASE):
            violations.append("Used Fahrenheit instead of Celsius")
            # Convert Fahrenheit to Celsius
            def convert_f_to_c(match):
                f_temp = float(match.group(1))
                c_temp = round((f_temp - 32) * 5/9, 1)
                return f"{c_temp}°C"
            response = re.sub(fahrenheit_pattern, convert_f_to_c, response, flags=re.IGNORECASE)

        # 4. Check for Batman/Wayne Manor references
        batman_keywords = ['batman', 'batcomputer', 'wayne manor', 'gotham', 'bruce wayne']
        for keyword in batman_keywords:
            if re.search(rf'\b{re.escape(keyword)}\b', response, re.IGNORECASE):
                violations.append(f"Referenced fictional content: {keyword}")
                # This is harder to fix automatically - log and warn
                _LOGGER.warning(f"LLM hallucinated Batman reference: {keyword}")

        # Log violations
        if violations:
            _LOGGER.warning(f"Response validation found violations: {', '.join(violations)}")
            _LOGGER.debug(f"Original: {original_response[:200]}")
            _LOGGER.debug(f"Fixed: {response[:200]}")

        return response

    def _build_enhanced_prompt(self, user_message: str, context: dict[str, Any], action_executed: dict[str, Any] | None = None) -> str:
        """Build enhanced prompt with home context and action execution status."""
        context_parts = []

        # NEW: If action was executed, inform LLM at the top
        if action_executed and action_executed.get("action"):
            if action_executed.get("success", True):
                action_notice = f"\n[ACTION EXECUTED]: {action_executed['action']} on {action_executed['entity']} - Result: {action_executed['result']}"
                context_parts.append(action_notice + "\nYour response must confirm this action was completed.")
            else:
                action_notice = f"\n[ACTION FAILED]: {action_executed['action']} on {action_executed['entity']} - Error: {action_executed['result']}"
                context_parts.append(action_notice + "\nExplain the error to the user and suggest alternatives.")

        # Add home state information - be explicit about what exists
        if context.get("total_lights") == 0:
            context_parts.append("Lights: NONE configured")
        elif context.get("lights_on"):
            context_parts.append(f"Lights ON: {', '.join(context['lights_on'])}")
        else:
            context_parts.append(f"Lights: {context.get('total_lights', 0)} exist, all OFF")

        if context.get("total_switches") == 0:
            context_parts.append("Switches: NONE configured")
        else:
            switch_states = []
            if context.get("switches_on"):
                for switch in context['switches_on']:
                    switch_states.append(f"{switch} is ON")
            if context.get("switches_off"):
                for switch in context['switches_off']:
                    switch_states.append(f"{switch} is OFF")
            if switch_states:
                context_parts.append(f"Switches ({context.get('total_switches', 0)} total): {', '.join(switch_states)}")
            else:
                context_parts.append(f"Switches: {context.get('total_switches', 0)} exist")

        # Temperature sensors
        if context.get("temperature_sensors"):
            context_parts.append(f"Temperature: {', '.join(context['temperature_sensors'])}")

        # Humidity sensors
        if context.get("humidity_sensors"):
            context_parts.append(f"Humidity: {', '.join(context['humidity_sensors'])}")

        if context.get("climate_info"):
            context_parts.append(f"Climate: {context['climate_info']}")

        if context.get("doors_windows"):
            context_parts.append(f"Doors/Windows: {context['doors_windows']}")

        if context.get("alerts"):
            context_parts.append(f"Alerts: {', '.join(context['alerts'])}")

        # Always include state - never let LLM make things up
        context_str = "\n\n[CURRENT HOME STATE - USE ONLY THIS DATA]\n" + "\n".join(context_parts)
        context_str += "\nIMPORTANT: Only mention devices listed above. If user asks about something not listed, say you don't have that device."
        full_prompt = f"{user_message}{context_str}"
        _LOGGER.debug(f"Enhanced prompt context: {context_str[:200]}...")
        return full_prompt

    async def _build_context(self) -> dict[str, Any]:
        """Build context from current home state."""
        context = {
            "lights_on": [],
            "switches_on": [],
            "switches_off": [],
            "climate_info": "",
            "doors_windows": "",
            "alerts": [],
            "total_lights": 0,
            "total_switches": 0,
            "temperature_sensors": [],
            "humidity_sensors": [],
        }

        # Get all lights
        all_lights = list(self.hass.states.async_all("light"))
        context["total_lights"] = len(all_lights)

        lights_on = [
            state.name
            for state in all_lights
            if state.state == "on"
        ]
        if lights_on:
            context["lights_on"] = lights_on[:5]  # Limit to 5

        # Get all switches
        all_switches = list(self.hass.states.async_all("switch"))
        # Filter out LED and pulse switches for cleaner reporting
        main_switches = [s for s in all_switches if not any(x in s.entity_id for x in ['_led', '_pulse'])]
        context["total_switches"] = len(main_switches)

        switches_on = [
            state.name
            for state in main_switches
            if state.state == "on"
        ]
        switches_off = [
            state.name
            for state in main_switches
            if state.state == "off"
        ]
        if switches_on:
            context["switches_on"] = switches_on[:5]
        if switches_off:
            context["switches_off"] = switches_off[:5]

        # Get temperature sensors
        all_sensors = list(self.hass.states.async_all("sensor"))
        temp_sensors = [
            state for state in all_sensors
            if "temperature" in state.entity_id.lower() and state.state not in ["unknown", "unavailable", ""]
        ]
        _LOGGER.debug(f"Found {len(temp_sensors)} temperature sensors")
        for sensor in temp_sensors[:3]:  # Limit to 3
            try:
                temp_value = float(sensor.state)
                unit = sensor.attributes.get("unit_of_measurement", "°C")
                friendly_name = sensor.attributes.get("friendly_name", sensor.name)
                context["temperature_sensors"].append(f"{friendly_name}: {temp_value}{unit}")
                _LOGGER.debug(f"Added temp sensor: {friendly_name} = {temp_value}{unit}")
            except (ValueError, TypeError) as e:
                _LOGGER.debug(f"Failed to parse temp sensor {sensor.entity_id}: {e}")

        # Get humidity sensors
        humidity_sensors = [
            state for state in all_sensors
            if "humidity" in state.entity_id.lower() and state.state not in ["unknown", "unavailable", ""]
        ]
        _LOGGER.debug(f"Found {len(humidity_sensors)} humidity sensors")
        for sensor in humidity_sensors[:3]:  # Limit to 3
            try:
                humidity_value = float(sensor.state)
                unit = sensor.attributes.get("unit_of_measurement", "%")
                friendly_name = sensor.attributes.get("friendly_name", sensor.name)
                context["humidity_sensors"].append(f"{friendly_name}: {humidity_value}{unit}")
                _LOGGER.debug(f"Added humidity sensor: {friendly_name} = {humidity_value}{unit}")
            except (ValueError, TypeError) as e:
                _LOGGER.debug(f"Failed to parse humidity sensor {sensor.entity_id}: {e}")

        # Get climate info
        climate_states = list(self.hass.states.async_all("climate"))
        if climate_states:
            climate = climate_states[0]
            temp = climate.attributes.get("current_temperature", "unknown")
            target = climate.attributes.get("temperature", "unknown")
            context["climate_info"] = f"{temp}°C (target: {target}°C)"

        # Check doors and windows
        door_sensors = [
            state for state in self.hass.states.async_all("binary_sensor")
            if "door" in state.entity_id or "window" in state.entity_id
        ]
        open_doors = [s.name for s in door_sensors if s.state == "on"]
        if open_doors:
            context["doors_windows"] = f"{len(open_doors)} open"
        else:
            context["doors_windows"] = "all closed"

        # Check for low battery devices
        low_battery = [
            state.name
            for state in self.hass.states.async_all()
            if state.attributes.get("battery_level", 100) < 20
        ]
        if low_battery:
            context["alerts"].extend([f"{name} battery low" for name in low_battery[:3]])

        return context

    async def _process_intents(self, response: str, user_input: conversation.ConversationInput) -> None:
        """Process any actionable intents from the user input."""
        user_message = user_input.text.lower()

        _LOGGER.debug(f"Processing intents for: {user_message}")

        # Detect switch control intents
        if any(word in user_message for word in ["turn on", "switch on", "enable"]):
            await self._handle_turn_on_intent(user_message)
        elif any(word in user_message for word in ["turn off", "switch off", "disable"]):
            await self._handle_turn_off_intent(user_message)

        # Detect temperature control intents
        elif any(phrase in user_message for phrase in ["set temperature", "change temperature", "adjust temperature"]):
            await self._handle_temperature_intent(user_message)

    async def _handle_turn_on_intent(self, message: str) -> None:
        """Handle turn on intent with state awareness."""
        entity_id = await self._find_entity_from_message(message, "switch")
        if entity_id:
            # Check current state
            state = self.hass.states.get(entity_id)
            device_name = state.attributes.get("friendly_name", entity_id) if state else entity_id

            if state and state.state == "on":
                _LOGGER.warning(f"{device_name} is already ON - possible defect or user confusion")
                # Fire event for potential bulb issue
                self.hass.bus.async_fire(
                    "alfred_device_alert",
                    {
                        "entity_id": entity_id,
                        "alert_type": "already_on",
                        "message": f"{device_name} already on but user requested activation",
                        "suggestion": "Possible defective bulb, bad connection, or user confusion"
                    }
                )
            else:
                _LOGGER.info(f"Turning on {device_name}")
                try:
                    await self.hass.services.async_call(
                        "switch",
                        "turn_on",
                        {"entity_id": entity_id},
                        blocking=True
                    )
                    _LOGGER.info(f"Successfully turned on {device_name}")
                except Exception as e:
                    _LOGGER.error(f"Failed to turn on {device_name}: {e}")
        else:
            _LOGGER.debug("Could not identify device to turn on")

    async def _handle_turn_off_intent(self, message: str) -> None:
        """Handle turn off intent with state awareness."""
        entity_id = await self._find_entity_from_message(message, "switch")
        if entity_id:
            # Check current state
            state = self.hass.states.get(entity_id)
            device_name = state.attributes.get("friendly_name", entity_id) if state else entity_id

            if state and state.state == "off":
                _LOGGER.info(f"{device_name} is already OFF - no action needed")
                # Already off, no action needed
            else:
                _LOGGER.info(f"Turning off {device_name}")
                try:
                    await self.hass.services.async_call(
                        "switch",
                        "turn_off",
                        {"entity_id": entity_id},
                        blocking=True
                    )
                    _LOGGER.info(f"Successfully turned off {device_name}")
                except Exception as e:
                    _LOGGER.error(f"Failed to turn off {device_name}: {e}")
        else:
            _LOGGER.debug("Could not identify device to turn off")

    async def _handle_temperature_intent(self, message: str) -> None:
        """Handle temperature adjustment intent."""
        # Extract temperature value from message
        import re
        temp_match = re.search(r'(\d+)\s*(?:degrees?|°)?', message)
        if temp_match:
            target_temp = float(temp_match.group(1))
            # Find climate entity
            climate_states = list(self.hass.states.async_all("climate"))
            if climate_states:
                entity_id = climate_states[0].entity_id
                _LOGGER.info(f"Setting {entity_id} to {target_temp}°C")
                try:
                    await self.hass.services.async_call(
                        "climate",
                        "set_temperature",
                        {"entity_id": entity_id, "temperature": target_temp},
                        blocking=True
                    )
                    _LOGGER.info(f"Successfully set temperature to {target_temp}°C")
                except Exception as e:
                    _LOGGER.error(f"Failed to set temperature: {e}")

    async def _find_entity_from_message(self, message: str, domain: str) -> str | None:
        """Find entity ID from message keywords."""
        # Get all entities of the domain
        entities = list(self.hass.states.async_all(domain))

        # Filter LED and pulse switches
        if domain == "switch":
            entities = [e for e in entities if not any(x in e.entity_id for x in ['_led', '_pulse'])]

        # Match keywords to friendly names
        for entity in entities:
            friendly_name = entity.attributes.get("friendly_name", "").lower()
            entity_id_parts = entity.entity_id.lower().split("_")

            # Check if any word from friendly name or entity ID is in message
            if friendly_name and any(word in message for word in friendly_name.split()):
                return entity.entity_id

            # Common name mappings
            name_map = {
                "shed": ["shed", "shack"],
                "basement": ["basement", "cellar"],
                "starlink": ["starlink", "satellite"],
                "th16": ["th16", "thermostat", "temperature"],
            }

            for key, aliases in name_map.items():
                if key in entity.entity_id.lower():
                    if any(alias in message for alias in aliases):
                        return entity.entity_id

        return None

    async def _find_climate_entity(self, message: str) -> str | None:
        """Find climate entity from message."""
        message_lower = message.lower()
        climate_states = list(self.hass.states.async_all("climate"))

        # Check for specific device mentions
        for climate in climate_states:
            entity_id = climate.entity_id.lower()
            friendly_name = climate.attributes.get("friendly_name", "").lower()

            # Check entity ID for TH16 variants
            if "th16" in entity_id or "th16r2" in entity_id:
                if "th16" in message_lower or "r2" in message_lower:
                    return climate.entity_id

            # Check friendly name
            if friendly_name and any(word in message_lower for word in friendly_name.split()):
                return climate.entity_id

        # Return first climate device if no specific match
        return climate_states[0].entity_id if climate_states else None

    async def _detect_and_execute_intent(self, message: str) -> dict[str, Any]:
        """Detect intent and execute action before LLM response."""
        message_lower = message.lower()
        action_executed = {"action": None, "entity": None, "result": None, "success": True}

        # Check for range adjustment first (most specific)
        range_result = await self._handle_range_adjustment_intent(message_lower)
        if range_result.get("action"):
            return range_result

        # Check for device control
        if any(word in message_lower for word in ["turn on", "switch on", "enable"]):
            entity_id = await self._find_entity_from_message(message_lower, "switch")
            if entity_id:
                try:
                    state = self.hass.states.get(entity_id)
                    device_name = state.attributes.get("friendly_name", entity_id) if state else entity_id

                    await self.hass.services.async_call(
                        "switch",
                        "turn_on",
                        {"entity_id": entity_id},
                        blocking=True
                    )
                    action_executed = {
                        "action": "turn_on",
                        "entity": device_name,
                        "result": "success",
                        "success": True
                    }
                    _LOGGER.info(f"Pre-LLM execution: Turned on {device_name}")
                except Exception as e:
                    _LOGGER.error(f"Failed to turn on {entity_id}: {e}")
                    action_executed = {
                        "action": "turn_on",
                        "entity": entity_id,
                        "result": f"Error: {str(e)}",
                        "success": False
                    }

        elif any(word in message_lower for word in ["turn off", "switch off", "disable"]):
            entity_id = await self._find_entity_from_message(message_lower, "switch")
            if entity_id:
                try:
                    state = self.hass.states.get(entity_id)
                    device_name = state.attributes.get("friendly_name", entity_id) if state else entity_id

                    await self.hass.services.async_call(
                        "switch",
                        "turn_off",
                        {"entity_id": entity_id},
                        blocking=True
                    )
                    action_executed = {
                        "action": "turn_off",
                        "entity": device_name,
                        "result": "success",
                        "success": True
                    }
                    _LOGGER.info(f"Pre-LLM execution: Turned off {device_name}")
                except Exception as e:
                    _LOGGER.error(f"Failed to turn off {entity_id}: {e}")
                    action_executed = {
                        "action": "turn_off",
                        "entity": entity_id,
                        "result": f"Error: {str(e)}",
                        "success": False
                    }

        return action_executed

    async def _handle_range_adjustment_intent(self, message: str) -> dict[str, Any]:
        """Handle temperature range adjustment intent."""
        import re

        # Pattern: "increase/set/adjust range between X and Y"
        patterns = [
            r'(?:increase|set|adjust|change).*?range.*?(?:between|to)?\s*(\d+).*?(?:and|to)\s*(\d+)',
            r'range.*?(?:between|to)?\s*(\d+).*?(?:and|to)\s*(\d+)',
            r'(?:between|from)\s*(\d+).*?(?:and|to)\s*(\d+)',
        ]

        low = None
        high = None

        for pattern in patterns:
            match = re.search(pattern, message.lower())
            if match:
                low = int(match.group(1))
                high = int(match.group(2))
                # Ensure low < high
                if low > high:
                    low, high = high, low
                break

        if low is not None and high is not None:
            # Find climate entity
            entity_id = await self._find_climate_entity(message)

            if entity_id:
                try:
                    state = self.hass.states.get(entity_id)
                    device_name = state.attributes.get("friendly_name", entity_id) if state else entity_id

                    await self.hass.services.async_call(
                        "climate",
                        "set_temperature",
                        {
                            "entity_id": entity_id,
                            "target_temp_low": low,
                            "target_temp_high": high,
                        },
                        blocking=True
                    )
                    _LOGGER.info(f"Pre-LLM execution: Set {device_name} range to {low}-{high}°C")
                    return {
                        "action": "set_temperature_range",
                        "entity": device_name,
                        "result": f"Range set to {low}-{high}°C",
                        "success": True
                    }
                except Exception as e:
                    _LOGGER.error(f"Failed to set range: {e}")
                    return {
                        "action": "set_temperature_range",
                        "entity": entity_id,
                        "result": f"Error: {str(e)}",
                        "success": False
                    }

        return {"action": None}

    def get_conversation_history(self, conversation_id: str = "default") -> list[dict]:
        """Get conversation history for a given conversation ID."""
        return self._conversation_history.get(conversation_id, [])

    def clear_conversation_history(self, conversation_id: str = "default") -> None:
        """Clear conversation history."""
        if conversation_id in self._conversation_history:
            self._conversation_history.pop(conversation_id)
