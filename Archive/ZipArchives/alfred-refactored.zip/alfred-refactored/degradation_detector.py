"""Degradation detection engine for Alfred Digital Butler - Epic 3 Story 3.3."""
from __future__ import annotations

import logging
import statistics
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .performance_metrics import PerformanceMetricsCollector
from .baseline_calculator import BaselineCalculator
from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)

# Statistical thresholds
Z_SCORE_MINOR = 1.5  # 1.5 standard deviations
Z_SCORE_MODERATE = 2.0  # 2.0 standard deviations
Z_SCORE_SEVERE = 3.0  # 3.0 standard deviations
SIGNIFICANCE_THRESHOLD = 1.96  # p < 0.05 (95% confidence)

# Severity deviation percentages
DEVIATION_MINOR = 0.05  # 5%
DEVIATION_MODERATE = 0.15  # 15%
DEVIATION_SEVERE = 0.30  # 30%

# Sustained degradation confirmation
CONFIRMATION_DAYS = 3  # Require 3 days of observations
OBSERVATION_WINDOW_DAYS = 5  # Look back 5 days for observations

# Trend analysis
TREND_HISTORY_DAYS = 7  # Analyze 7-day trend
SUDDEN_DROP_THRESHOLD = 0.20  # 20% drop in 24 hours


@dataclass
class DegradationReport:
    """Report of detected degradation for a device."""

    entity_id: str
    metric_name: str
    degradation_type: str
    severity: str
    current_value: float
    baseline_value: float
    deviation_percentage: float
    z_score: float
    statistical_significance: bool
    trend_type: str | None
    degradation_rate: float | None
    days_degraded: int
    confidence: float
    recommendation: str
    timestamp: datetime

    def dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        data["timestamp"] = self.timestamp.isoformat()
        return data


@dataclass
class TrendReport:
    """Report of performance trend analysis."""

    entity_id: str
    metric_name: str
    trend_type: str
    degradation_rate: float
    slope: float
    r_squared: float
    moving_average_3d: float | None
    moving_average_7d: float | None
    values: list[float]
    timestamps: list[datetime]


class DegradationDetector:
    """Detects device performance degradation from established baselines."""

    def __init__(
        self,
        hass: HomeAssistant,
        performance_metrics: PerformanceMetricsCollector,
        baseline_calculator: BaselineCalculator,
        pattern_storage: PatternStorage,
    ) -> None:
        """
        Initialize degradation detector.

        Args:
            hass: Home Assistant instance
            performance_metrics: Performance metrics collector
            baseline_calculator: Baseline calculator
            pattern_storage: Pattern storage for database access
        """
        self.hass = hass
        self._metrics_collector = performance_metrics
        self._baseline_calculator = baseline_calculator
        self._storage = pattern_storage
        self._enabled = True

        # Cache for baselines (refresh every 6 hours)
        self._baseline_cache: dict[str, dict[str, Any]] = {}
        self._cache_timestamp: datetime | None = None
        self._cache_ttl = timedelta(hours=6)

    async def async_setup(self) -> None:
        """Set up the degradation detector."""
        _LOGGER.info("Setting up Alfred Degradation Detector")
        self._enabled = True

    async def analyze_all_devices(self) -> dict[str, Any]:
        """
        Analyze all devices with baselines for degradation.

        Returns:
            Summary statistics:
            {
                "devices_analyzed": 10,
                "degradation_detected": 3,
                "alerts_generated": 2,
                "devices_restored": 1
            }
        """
        if not self._enabled:
            return {"error": "Degradation detector not enabled"}

        stats = {
            "devices_analyzed": 0,
            "degradation_detected": 0,
            "alerts_generated": 0,
            "devices_restored": 0,
        }

        try:
            # Get all entities with baselines
            entities_with_baselines = await self._get_entities_with_baselines()

            _LOGGER.info(
                "Analyzing %d devices with baselines for degradation",
                len(entities_with_baselines)
            )

            # Process in batches of 10
            batch_size = 10
            for i in range(0, len(entities_with_baselines), batch_size):
                batch = entities_with_baselines[i:i + batch_size]

                for entity_id in batch:
                    stats["devices_analyzed"] += 1

                    try:
                        # Analyze device
                        report = await self.analyze_device_performance(entity_id)

                        if report:
                            stats["degradation_detected"] += 1

                            # Check if sustained (3-day confirmation)
                            is_sustained = await self.check_sustained_degradation(
                                entity_id,
                                report,
                            )

                            if is_sustained:
                                # Generate alert
                                await self.generate_alert(entity_id, report)
                                stats["alerts_generated"] += 1

                        else:
                            # Check if previously degraded device is now restored
                            restored = await self._check_performance_restored(entity_id)
                            if restored:
                                stats["devices_restored"] += restored

                    except Exception as err:
                        _LOGGER.error(
                            "Error analyzing device %s: %s",
                            entity_id,
                            err,
                            exc_info=True
                        )

            _LOGGER.info(
                "Degradation analysis complete: %d analyzed, %d degraded, %d alerts",
                stats["devices_analyzed"],
                stats["degradation_detected"],
                stats["alerts_generated"]
            )

            return stats

        except Exception as err:
            _LOGGER.error("Error in analyze_all_devices: %s", err, exc_info=True)
            return {"error": str(err)}

    async def analyze_device_performance(
        self,
        entity_id: str
    ) -> DegradationReport | None:
        """
        Analyze single device performance vs baseline.

        Args:
            entity_id: Entity ID to analyze

        Returns:
            DegradationReport if degradation detected, None otherwise
        """
        try:
            # Get current metrics
            current_metrics = await self._metrics_collector.collect_entity_metrics(entity_id)
            if not current_metrics or not current_metrics.get("metrics"):
                _LOGGER.debug("No current metrics for %s", entity_id)
                return None

            # Get baseline
            baselines = await self._get_entity_baselines(entity_id)
            if not baselines:
                _LOGGER.debug("No baseline for %s", entity_id)
                return None

            # Compare each metric to baseline
            for metric_name, current_metric in current_metrics["metrics"].items():
                if metric_name not in baselines:
                    continue

                baseline = baselines[metric_name]
                current_value = current_metric.get("value")

                if current_value is None:
                    continue

                # Compare to baseline
                comparison = await self.compare_to_baseline(
                    current_value,
                    baseline,
                    metric_name
                )

                # Check if statistically significant
                if comparison["statistical_significance"]:
                    # Get trend analysis
                    trend_report = await self.analyze_performance_trend(
                        entity_id,
                        metric_name,
                        days=TREND_HISTORY_DAYS
                    )

                    # Build degradation report
                    report = DegradationReport(
                        entity_id=entity_id,
                        metric_name=metric_name,
                        degradation_type=comparison["degradation_type"],
                        severity=comparison["severity"],
                        current_value=current_value,
                        baseline_value=baseline["metric_value"],
                        deviation_percentage=comparison["deviation_percentage"],
                        z_score=comparison["z_score"],
                        statistical_significance=True,
                        trend_type=trend_report.trend_type if trend_report else None,
                        degradation_rate=trend_report.degradation_rate if trend_report else None,
                        days_degraded=await self._get_days_degraded(entity_id, metric_name),
                        confidence=comparison["confidence"],
                        recommendation=self._generate_recommendation(
                            comparison["severity"],
                            comparison["degradation_type"],
                            trend_report.trend_type if trend_report else None
                        ),
                        timestamp=dt_util.now(),
                    )

                    _LOGGER.info(
                        "Degradation detected: %s - %s (%s, %.1f%% deviation)",
                        entity_id,
                        metric_name,
                        report.severity,
                        report.deviation_percentage * 100
                    )

                    return report

            return None

        except Exception as err:
            _LOGGER.error(
                "Error analyzing device %s: %s",
                entity_id,
                err,
                exc_info=True
            )
            return None

    async def compare_to_baseline(
        self,
        current_value: float,
        baseline: dict[str, Any],
        metric_name: str,
    ) -> dict[str, Any]:
        """
        Compare current value to baseline using statistical tests.

        Args:
            current_value: Current metric value
            baseline: Baseline dictionary with mean, std_dev, etc.
            metric_name: Name of the metric

        Returns:
            Dictionary with comparison results:
            {
                "z_score": 2.5,
                "deviation_percentage": 0.18,
                "statistical_significance": True,
                "severity": "moderate",
                "degradation_type": "higher_power",
                "confidence": 0.95
            }
        """
        baseline_mean = baseline["metric_value"]
        baseline_std_dev = baseline["std_dev"]
        baseline_confidence = baseline.get("confidence_score", 0.8)

        # Calculate Z-score
        z_score = self.calculate_z_score(
            current_value,
            baseline_mean,
            baseline_std_dev
        )

        # Calculate deviation percentage
        if baseline_mean != 0:
            deviation_pct = abs(current_value - baseline_mean) / abs(baseline_mean)
        else:
            deviation_pct = abs(current_value - baseline_mean)

        # Check statistical significance
        is_significant = self.is_statistically_significant(
            z_score,
            baseline.get("sample_count", 100)
        )

        # Classify severity
        severity = self.classify_severity(z_score, deviation_pct)

        # Detect degradation type
        degradation_type = self.detect_degradation_type(
            metric_name,
            current_value,
            baseline_mean
        )

        # Calculate confidence (combines baseline confidence and z-score)
        confidence = min(baseline_confidence * (abs(z_score) / 3.0), 1.0)

        return {
            "z_score": z_score,
            "deviation_percentage": deviation_pct,
            "statistical_significance": is_significant,
            "severity": severity,
            "degradation_type": degradation_type,
            "confidence": confidence,
        }

    def calculate_z_score(
        self,
        current_value: float,
        baseline_mean: float,
        baseline_std_dev: float,
    ) -> float:
        """
        Calculate Z-score for deviation magnitude.

        Z = (current_value - mean) / std_dev

        Args:
            current_value: Current measured value
            baseline_mean: Baseline mean
            baseline_std_dev: Baseline standard deviation

        Returns:
            Z-score (positive indicates above baseline, negative below)
        """
        if baseline_std_dev == 0:
            # No variance in baseline - use percentage deviation
            if baseline_mean == 0:
                return 0.0
            return (current_value - baseline_mean) / abs(baseline_mean) * 10

        return (current_value - baseline_mean) / baseline_std_dev

    def is_statistically_significant(
        self,
        z_score: float,
        sample_size: int,
    ) -> bool:
        """
        Determine if deviation is statistically significant.

        Uses 95% confidence level (Z > 1.96) for p < 0.05.

        Args:
            z_score: Calculated Z-score
            sample_size: Number of samples in baseline

        Returns:
            True if statistically significant
        """
        # Require minimum sample size for reliability
        if sample_size < 10:
            return False

        # Check if Z-score exceeds significance threshold
        return abs(z_score) >= SIGNIFICANCE_THRESHOLD

    def classify_severity(
        self,
        z_score: float,
        deviation_pct: float,
    ) -> str:
        """
        Classify degradation severity.

        Considers both Z-score and percentage deviation.

        Args:
            z_score: Z-score magnitude
            deviation_pct: Percentage deviation from baseline

        Returns:
            Severity: "minor", "moderate", or "severe"
        """
        abs_z = abs(z_score)

        # Severe: Z > 3.0 OR deviation > 30%
        if abs_z >= Z_SCORE_SEVERE or deviation_pct >= DEVIATION_SEVERE:
            return "severe"

        # Moderate: Z > 2.0 OR deviation > 15%
        if abs_z >= Z_SCORE_MODERATE or deviation_pct >= DEVIATION_MODERATE:
            return "moderate"

        # Minor: Z > 1.5 OR deviation > 5%
        if abs_z >= Z_SCORE_MINOR or deviation_pct >= DEVIATION_MINOR:
            return "minor"

        return "negligible"

    def detect_degradation_type(
        self,
        metric_name: str,
        current_value: float,
        baseline_value: float,
    ) -> str:
        """
        Detect type of degradation based on metric and direction.

        Args:
            metric_name: Name of the metric
            current_value: Current value
            baseline_value: Baseline value

        Returns:
            Degradation type: slower_response, higher_power, hotter, etc.
        """
        direction = "increase" if current_value > baseline_value else "decrease"

        # Map metric + direction to degradation type
        degradation_map = {
            ("response_time", "increase"): "slower_response",
            ("power_consumption", "increase"): "higher_power",
            ("power", "increase"): "higher_power",
            ("temperature", "increase"): "hotter",
            ("battery_level", "decrease"): "battery_drain",
            ("brightness", "decrease"): "reduced_brightness",
            ("signal_strength", "decrease"): "low_signal",
            ("humidity", "increase"): "high_humidity",
            ("humidity", "decrease"): "low_humidity",
        }

        key = (metric_name, direction)
        degradation_type = degradation_map.get(key)

        if degradation_type:
            return degradation_type

        # Generic fallback
        if direction == "increase":
            return f"{metric_name}_increase"
        else:
            return f"{metric_name}_decrease"

    async def analyze_performance_trend(
        self,
        entity_id: str,
        metric_name: str,
        days: int = TREND_HISTORY_DAYS,
    ) -> TrendReport | None:
        """
        Analyze performance trend over time.

        Args:
            entity_id: Entity ID
            metric_name: Metric to analyze
            days: Number of days to analyze

        Returns:
            TrendReport with trend analysis, or None if insufficient data
        """
        try:
            # Get historical baselines for trend analysis
            historical_data = await self._storage.get_baseline_history(
                entity_id,
                metric_name,
                days=days
            )

            if not historical_data or len(historical_data) < 3:
                _LOGGER.debug(
                    "Insufficient historical data for trend analysis: %s",
                    entity_id
                )
                return None

            # Extract values and timestamps
            values = [record["metric_value"] for record in historical_data]
            timestamps = [record["updated_at"] for record in historical_data]

            # Detect trend type
            trend_type = self.detect_trend_type(values, timestamps)

            # Calculate degradation rate
            degradation_rate = self.calculate_degradation_rate(values, timestamps)

            # Calculate linear regression
            slope, r_squared = self._calculate_linear_regression(values, timestamps)

            # Calculate moving averages
            ma_3d = self._calculate_moving_average(values, window=3)
            ma_7d = self._calculate_moving_average(values, window=7)

            report = TrendReport(
                entity_id=entity_id,
                metric_name=metric_name,
                trend_type=trend_type,
                degradation_rate=degradation_rate,
                slope=slope,
                r_squared=r_squared,
                moving_average_3d=ma_3d,
                moving_average_7d=ma_7d,
                values=values,
                timestamps=timestamps,
            )

            _LOGGER.debug(
                "Trend analysis for %s - %s: %s (rate: %.3f/day)",
                entity_id,
                metric_name,
                trend_type,
                degradation_rate
            )

            return report

        except Exception as err:
            _LOGGER.error("Error analyzing trend for %s: %s", entity_id, err)
            return None

    async def check_sustained_degradation(
        self,
        entity_id: str,
        report: DegradationReport,
    ) -> bool:
        """
        Check if degradation sustained for 3+ days (confirmation filter).

        Args:
            entity_id: Entity ID
            report: Degradation report with all metrics

        Returns:
            True if degradation confirmed (3+ observations in 5 days)
        """
        try:
            # Record current observation
            await self.record_observation(
                entity_id,
                report,
            )

            # Get recent observations
            recent_observations = await self.get_recent_observations(
                entity_id,
                report.degradation_type,
                days=OBSERVATION_WINDOW_DAYS
            )

            if len(recent_observations) < CONFIRMATION_DAYS:
                _LOGGER.debug(
                    "Only %d observations for %s, need %d for confirmation",
                    len(recent_observations),
                    entity_id,
                    CONFIRMATION_DAYS
                )
                return False

            # Check if same degradation type in all observations
            degradation_types = [obs["degradation_type"] for obs in recent_observations]
            if len(set(degradation_types)) > 1:
                _LOGGER.debug(
                    "Inconsistent degradation types for %s: %s",
                    entity_id,
                    degradation_types
                )
                return False

            # Confirmed! Mark observations as confirmed
            for obs in recent_observations:
                if not obs["confirmed"]:
                    await self._storage.mark_observation_confirmed(obs["id"])

            _LOGGER.info(
                "Sustained degradation confirmed for %s - %s (%d days)",
                entity_id,
                report.metric_name,
                len(recent_observations)
            )
            return True

        except Exception as err:
            _LOGGER.error("Error checking sustained degradation: %s", err)
            return False

    async def record_observation(
        self,
        entity_id: str,
        report: DegradationReport,
    ) -> None:
        """
        Record degradation observation for confirmation tracking.

        Args:
            entity_id: Entity ID
            report: Degradation report with full metrics
        """
        try:
            observation_id = await self._storage.save_degradation_observation(
                entity_id=entity_id,
                observation_date=report.timestamp,
                degradation_type=report.degradation_type,
                severity=report.severity,
                z_score=report.z_score,
                deviation_percentage=report.deviation_percentage,
                current_value=report.current_value,
                baseline_value=report.baseline_value,
                metric_name=report.metric_name,
                trend_type=report.trend_type,
                degradation_rate=report.degradation_rate,
            )

            _LOGGER.debug(
                "Recorded observation #%d for %s - %s: %s",
                observation_id,
                entity_id,
                report.metric_name,
                report.degradation_type
            )

        except Exception as err:
            _LOGGER.error("Error recording observation: %s", err, exc_info=True)

    async def get_recent_observations(
        self,
        entity_id: str,
        degradation_type: str,
        days: int = OBSERVATION_WINDOW_DAYS,
    ) -> list[dict[str, Any]]:
        """
        Get recent degradation observations.

        Args:
            entity_id: Entity ID
            degradation_type: Type of degradation to filter by
            days: Number of days to look back

        Returns:
            List of observation dictionaries
        """
        try:
            observations = await self._storage.get_recent_observations(
                entity_id=entity_id,
                degradation_type=degradation_type,
                days=days
            )

            _LOGGER.debug(
                "Retrieved %d recent observations for %s (%s)",
                len(observations),
                entity_id,
                degradation_type
            )

            return observations

        except Exception as err:
            _LOGGER.error("Error getting recent observations: %s", err)
            return []

    async def generate_alert(
        self,
        entity_id: str,
        degradation_report: DegradationReport,
    ) -> None:
        """
        Generate degradation alert after confirmation.

        Fires alfred_degradation_detected event and stores in database.

        Args:
            entity_id: Entity ID
            degradation_report: Degradation report
        """
        try:
            # Check if this is an escalation
            is_escalation = await self.check_alert_escalation(
                entity_id,
                degradation_report.severity
            )

            # Store alert in database
            alert_type = "escalation" if is_escalation else "initial"
            message = self._generate_alert_message(degradation_report)

            alert_id = await self._storage.save_degradation_alert(
                entity_id=entity_id,
                alert_type=alert_type,
                degradation_type=degradation_report.degradation_type,
                severity=degradation_report.severity,
                message=message,
                recommendation=degradation_report.recommendation,
                first_detected=degradation_report.timestamp,
            )

            # For SEVERE degradation, automatically run AI diagnosis
            if degradation_report.severity == "severe":
                try:
                    _LOGGER.info(
                        "Severe degradation detected for %s, running AI diagnosis",
                        entity_id
                    )

                    # Get diagnosis engine from hass.data
                    from .const import DOMAIN
                    entry_id = list(self.hass.data[DOMAIN].keys())[0]
                    diagnosis_engine = self.hass.data[DOMAIN][entry_id].get("diagnosis_engine")

                    if diagnosis_engine:
                        # Run diagnosis
                        diagnosis = await diagnosis_engine.diagnose_device_failure(
                            entity_id,
                            degradation_report,
                        )

                        # Send enhanced notification with diagnosis
                        await self._send_enhanced_notification(
                            entity_id,
                            degradation_report,
                            diagnosis,
                            alert_id,
                        )
                    else:
                        # Fall back to standard notification if diagnosis unavailable
                        _LOGGER.warning("Diagnosis engine not available, sending standard notification")
                        await self._send_degradation_notification(
                            entity_id=entity_id,
                            report=degradation_report,
                            alert_type=alert_type,
                            alert_id=alert_id,
                        )

                except Exception as err:
                    _LOGGER.error("Auto-diagnosis failed for %s: %s", entity_id, err)
                    # Fall back to standard notification
                    await self._send_degradation_notification(
                        entity_id=entity_id,
                        report=degradation_report,
                        alert_type=alert_type,
                        alert_id=alert_id,
                    )
            else:
                # For minor/moderate, send standard notification
                await self._send_degradation_notification(
                    entity_id=entity_id,
                    report=degradation_report,
                    alert_type=alert_type,
                    alert_id=alert_id,
                )

            # Fire event
            event_type = (
                "alfred_degradation_escalated" if is_escalation
                else "alfred_degradation_detected"
            )

            self.hass.bus.async_fire(
                event_type,
                {
                    "entity_id": degradation_report.entity_id,
                    "metric_name": degradation_report.metric_name,
                    "degradation_type": degradation_report.degradation_type,
                    "severity": degradation_report.severity,
                    "deviation_percentage": degradation_report.deviation_percentage,
                    "trend_type": degradation_report.trend_type,
                    "days_degraded": degradation_report.days_degraded,
                    "confidence": degradation_report.confidence,
                    "recommendation": degradation_report.recommendation,
                }
            )

            _LOGGER.info(
                "Alert generated for %s: %s (%s) - %s",
                entity_id,
                degradation_report.degradation_type,
                degradation_report.severity,
                alert_type
            )

        except Exception as err:
            _LOGGER.error("Error generating alert: %s", err)

    async def check_alert_escalation(
        self,
        entity_id: str,
        current_severity: str,
    ) -> bool:
        """
        Check if severity increased since last alert.

        Args:
            entity_id: Entity ID
            current_severity: Current severity level

        Returns:
            True if severity increased
        """
        try:
            # Get active alerts for this entity
            alerts = await self._storage.get_active_alerts(entity_id)

            if not alerts:
                return False

            # Check if severity increased
            severity_levels = {"minor": 1, "moderate": 2, "severe": 3}
            current_level = severity_levels.get(current_severity, 0)

            for alert in alerts:
                previous_level = severity_levels.get(alert["severity"], 0)
                if current_level > previous_level:
                    return True

            return False

        except Exception as err:
            _LOGGER.error("Error checking alert escalation: %s", err)
            return False

    async def mark_performance_restored(
        self,
        entity_id: str,
        metric_name: str | None = None,
    ) -> None:
        """
        Mark device performance as restored to baseline.

        Args:
            entity_id: Entity ID
            metric_name: Metric name (optional)
        """
        try:
            # Mark all active alerts for this entity as resolved
            alerts = await self._storage.get_active_alerts(entity_id)

            for alert in alerts:
                await self._storage.mark_alert_resolved(alert["id"])

            if alerts:
                _LOGGER.info(
                    "Marked %d alerts as resolved for %s",
                    len(alerts),
                    entity_id
                )

            # Send restoration notification
            if alerts:
                await self._send_restoration_notification(entity_id, len(alerts))

            # Fire event
            self.hass.bus.async_fire(
                "alfred_performance_restored",
                {
                    "entity_id": entity_id,
                    "metric_name": metric_name,
                    "alerts_resolved": len(alerts),
                    "resolved_at": dt_util.now().isoformat(),
                }
            )

            _LOGGER.info("Performance restored for %s - %s", entity_id, metric_name)

        except Exception as err:
            _LOGGER.error("Error marking performance restored: %s", err)

    async def _get_entities_with_baselines(self) -> list[str]:
        """
        Get list of entities that have established baselines.

        Returns:
            List of entity IDs
        """
        try:
            # TODO: Query pattern_storage for entities with baselines
            # For now, return empty list - will be implemented when integrated
            return []

        except Exception as err:
            _LOGGER.error("Error getting entities with baselines: %s", err)
            return []

    async def _get_entity_baselines(self, entity_id: str) -> dict[str, Any] | None:
        """
        Get baselines for entity (with caching).

        Args:
            entity_id: Entity ID

        Returns:
            Dictionary of baselines by metric name
        """
        # Check cache validity
        now = dt_util.now()
        if self._cache_timestamp and (now - self._cache_timestamp) < self._cache_ttl:
            if entity_id in self._baseline_cache:
                return self._baseline_cache[entity_id]

        # Refresh cache if needed
        if not self._cache_timestamp or (now - self._cache_timestamp) >= self._cache_ttl:
            self._baseline_cache.clear()
            self._cache_timestamp = now

        # Get baselines from database
        try:
            # TODO: Query all baselines for entity from pattern_storage
            # For now, return None - will be implemented when integrated
            return None

        except Exception as err:
            _LOGGER.error("Error getting baselines for %s: %s", entity_id, err)
            return None

    async def _get_days_degraded(self, entity_id: str, metric_name: str) -> int:
        """
        Get number of consecutive days device has been degraded.

        Args:
            entity_id: Entity ID
            metric_name: Metric name

        Returns:
            Number of days degraded
        """
        observations = await self.get_recent_observations(entity_id, metric_name)
        return len(observations)

    async def _check_performance_restored(self, entity_id: str) -> int:
        """
        Check if previously degraded device has restored to normal.

        Args:
            entity_id: Entity ID

        Returns:
            Number of metrics restored (0 if none)
        """
        # TODO: Query unresolved alerts for this entity
        # Check if current performance is back within baseline
        # Mark as restored if so
        return 0

    def detect_trend_type(
        self,
        values: list[float],
        timestamps: list[datetime],
    ) -> str:
        """
        Classify trend type based on values over time.

        Args:
            values: List of metric values
            timestamps: List of timestamps

        Returns:
            Trend type: sudden_drop, gradual_decline, stable, or intermittent
        """
        if len(values) < 2:
            return "unknown"

        try:
            # Check for sudden drop (>20% decrease in last 24 hours)
            if len(values) >= 2:
                latest_value = values[-1]
                previous_value = values[-2]
                time_diff = (timestamps[-1] - timestamps[-2]).total_seconds() / 86400  # days

                if time_diff <= 1.0:  # Within 24 hours
                    pct_change = (latest_value - previous_value) / abs(previous_value) if previous_value != 0 else 0
                    if abs(pct_change) >= SUDDEN_DROP_THRESHOLD:
                        return "sudden_drop"

            # Check for gradual decline (negative slope over time)
            if len(values) >= 3:
                slope, r_squared = self._calculate_linear_regression(values, timestamps)

                # Strong negative trend (R² > 0.7, slope < -0.1)
                if r_squared > 0.7 and slope < -0.1:
                    return "gradual_decline"

                # Stable (low variance, slight negative or no trend)
                if r_squared > 0.5 and abs(slope) < 0.1:
                    return "stable"

            # Check for intermittent (high variance, no clear trend)
            if len(values) >= 5:
                variance = statistics.variance(values)
                mean = statistics.mean(values)
                coeff_variation = variance / abs(mean) if mean != 0 else 0

                if coeff_variation > 0.3:  # High variance relative to mean
                    return "intermittent"

            # Default to stable if no other pattern detected
            return "stable"

        except Exception as err:
            _LOGGER.error("Error detecting trend type: %s", err)
            return "unknown"

    def calculate_degradation_rate(
        self,
        values: list[float],
        timestamps: list[datetime],
    ) -> float:
        """
        Calculate rate of degradation (units per day).

        Args:
            values: List of metric values
            timestamps: List of timestamps

        Returns:
            Degradation rate (negative = getting worse, positive = improving)
        """
        if len(values) < 2:
            return 0.0

        try:
            # Calculate slope (units per day)
            slope, _ = self._calculate_linear_regression(values, timestamps)
            return slope

        except Exception as err:
            _LOGGER.error("Error calculating degradation rate: %s", err)
            return 0.0

    def _calculate_linear_regression(
        self,
        values: list[float],
        timestamps: list[datetime],
    ) -> tuple[float, float]:
        """
        Calculate linear regression slope and R-squared.

        Args:
            values: List of metric values
            timestamps: List of timestamps

        Returns:
            Tuple of (slope in units/day, R-squared fit quality)
        """
        if len(values) < 2:
            return 0.0, 0.0

        try:
            # Convert timestamps to days since first timestamp
            first_time = timestamps[0]
            x = [(t - first_time).total_seconds() / 86400 for t in timestamps]
            y = values

            n = len(x)

            # Calculate means
            x_mean = statistics.mean(x)
            y_mean = statistics.mean(y)

            # Calculate slope (β1)
            numerator = sum((x[i] - x_mean) * (y[i] - y_mean) for i in range(n))
            denominator = sum((x[i] - x_mean) ** 2 for i in range(n))

            if denominator == 0:
                return 0.0, 0.0

            slope = numerator / denominator

            # Calculate R-squared
            # Total sum of squares
            ss_tot = sum((y[i] - y_mean) ** 2 for i in range(n))

            # Residual sum of squares
            y_pred = [slope * (x[i] - x_mean) + y_mean for i in range(n)]
            ss_res = sum((y[i] - y_pred[i]) ** 2 for i in range(n))

            if ss_tot == 0:
                r_squared = 0.0
            else:
                r_squared = 1 - (ss_res / ss_tot)
                r_squared = max(0.0, min(1.0, r_squared))  # Clamp to [0, 1]

            return slope, r_squared

        except Exception as err:
            _LOGGER.error("Error calculating linear regression: %s", err)
            return 0.0, 0.0

    def _calculate_moving_average(
        self,
        values: list[float],
        window: int,
    ) -> float | None:
        """
        Calculate moving average for the most recent values.

        Args:
            values: List of values
            window: Window size (e.g., 3 for 3-day average)

        Returns:
            Moving average for most recent window, or None if insufficient data
        """
        if len(values) < window:
            return None

        try:
            recent_values = values[-window:]
            return statistics.mean(recent_values)

        except Exception as err:
            _LOGGER.error("Error calculating moving average: %s", err)
            return None

    def _generate_recommendation(
        self,
        severity: str,
        degradation_type: str,
        trend_type: str | None,
    ) -> str:
        """
        Generate user-friendly recommendation based on degradation.

        Args:
            severity: Severity level
            degradation_type: Type of degradation
            trend_type: Trend type (if available)

        Returns:
            Recommendation string
        """
        if severity == "severe":
            if trend_type == "sudden_drop":
                return "Might be worth restarting it or checking if something changed. Could need replacement if it doesn't improve."
            else:
                return "I'd suggest looking into this soon - maybe schedule maintenance or consider replacement."

        elif severity == "moderate":
            if trend_type == "gradual_decline":
                return "Keep an eye on it. If it keeps declining, maybe plan some maintenance in the next few weeks."
            else:
                return "Worth checking out when you get a chance. Might need some maintenance."

        else:  # minor
            return "Just a heads up - nothing urgent, but I'll keep watching it."

    def _generate_alert_message(self, report: DegradationReport) -> str:
        """
        Generate user-friendly alert message.

        Args:
            report: Degradation report

        Returns:
            Alert message string
        """
        # Get friendly entity name
        state = self.hass.states.get(report.entity_id)
        device_name = state.name if state else report.entity_id

        # Format the message
        degradation_descriptions = {
            "slower_response": "responding slower than usual",
            "higher_power": "using more power than baseline",
            "hotter": "running hotter than normal",
            "lower_efficiency": "less efficient than before",
            "unstable_power": "power consumption looks unstable",
        }

        description = degradation_descriptions.get(
            report.degradation_type,
            "not performing as well"
        )

        severity_prefix = {
            "severe": "HEADS UP:",
            "moderate": "FYI:",
            "minor": "Note:",
        }

        prefix = severity_prefix.get(report.severity, "Note:")

        message = (
            f"{prefix} {device_name} is {description}. "
            f"Current {report.metric_name}: {report.current_value:.2f}, "
            f"baseline: {report.baseline_value:.2f} "
            f"({report.deviation_percentage:.1%} deviation). "
        )

        if report.trend_type == "sudden_drop":
            message += "Dropped suddenly. "
        elif report.trend_type == "gradual_decline":
            message += "Declining gradually. "

        message += report.recommendation

        return message

    async def _send_degradation_notification(
        self,
        entity_id: str,
        report: DegradationReport,
        alert_type: str,
        alert_id: int,
    ) -> None:
        """
        Send degradation notification to user.

        Args:
            entity_id: Entity ID
            report: Degradation report
            alert_type: "initial" or "escalation"
            alert_id: Alert ID for actions
        """
        try:
            # Get friendly entity name
            state = self.hass.states.get(entity_id)
            device_name = state.name if state else entity_id

            # Determine notification title and message
            if alert_type == "escalation":
                title = "⚠️ Device Performance Getting Worse"
                intro = f"Hey, I noticed {device_name} is performing worse than before. "
            else:
                title = "⚠️ Device Performance Issue Detected"
                intro = f"I've been tracking {device_name} and noticed something off. "

            # Build notification message
            message = intro

            # Add degradation details
            degradation_phrases = {
                "slower_response": "It's responding slower than usual",
                "higher_power": "It's using more power than normal",
                "hotter": "It's running hotter than it should",
                "lower_efficiency": "It seems less efficient",
                "unstable_power": "Power consumption looks unstable",
            }

            degradation_phrase = degradation_phrases.get(
                report.degradation_type,
                "Performance seems degraded"
            )

            message += f"{degradation_phrase}. "

            # Add severity context
            if report.severity == "severe":
                message += "This looks pretty serious and probably needs attention soon. "
            elif report.severity == "moderate":
                message += "It's noticeable enough that you might want to check it out. "
            else:
                message += "Not urgent, but worth keeping an eye on. "

            # Add recommendation
            message += report.recommendation

            # Add Alfred signature
            message += "\n\n— Alfred"

            # Send persistent notification
            notification_id = f"alfred_degradation_{entity_id}_{alert_id}"

            await self.hass.services.async_call(
                "persistent_notification",
                "create",
                {
                    "title": title,
                    "message": message,
                    "notification_id": notification_id,
                },
                blocking=False,
            )

            _LOGGER.info(
                "Sent degradation notification for %s (%s)",
                device_name,
                report.severity
            )

        except Exception as err:
            _LOGGER.error("Error sending degradation notification: %s", err)

    async def _send_enhanced_notification(
        self,
        entity_id: str,
        degradation_report: DegradationReport,
        diagnosis,
        alert_id: int,
    ) -> None:
        """
        Send enhanced notification with AI diagnosis.

        Args:
            entity_id: Entity ID
            degradation_report: Degradation report
            diagnosis: DiagnosisResult object
            alert_id: Alert ID
        """
        try:
            # Get friendly entity name
            state = self.hass.states.get(entity_id)
            device_name = state.name if state else entity_id

            # Build enhanced message
            title = "⚠️ URGENT: Device Failure Diagnosed"

            message = f"Hey, I've analyzed {device_name} and found something concerning.\n\n"

            message += f"**Diagnosis:** {diagnosis.primary_cause}\n"
            message += f"**Confidence:** {diagnosis.confidence_percentage}%\n"
            message += f"**Severity:** {diagnosis.severity_assessment.upper()}\n\n"

            # Add evidence
            message += "**What I found:**\n"
            for evidence in diagnosis.supporting_evidence[:3]:  # Top 3
                message += f"• {evidence}\n"

            # Add recommendations
            message += "\n**What you should do:**\n"

            diy_steps = diagnosis.recommendations.get("diy_steps", [])
            if diy_steps:
                message += "\nDIY Steps:\n"
                for i, step in enumerate(diy_steps[:3], 1):  # Top 3
                    message += f"{i}. {step}\n"

            prof_service = diagnosis.recommendations.get("professional_service")
            if prof_service:
                message += f"\nProfessional Service: {prof_service}\n"

            # Add timeline
            if diagnosis.estimated_timeline:
                message += f"\n**Timeline:** {diagnosis.estimated_timeline}\n"

            # Add cost estimate
            if diagnosis.estimated_cost:
                diy_cost = diagnosis.estimated_cost.get("diy")
                if diy_cost:
                    message += f"**Estimated Cost:** {diy_cost}\n"

            message += "\n— Alfred"

            # Send persistent notification
            notification_id = f"alfred_diagnosis_{entity_id}_{alert_id}"

            await self.hass.services.async_call(
                "persistent_notification",
                "create",
                {
                    "title": title,
                    "message": message,
                    "notification_id": notification_id,
                },
                blocking=False,
            )

            _LOGGER.info("Sent enhanced diagnosis notification for %s", device_name)

        except Exception as err:
            _LOGGER.error("Error sending enhanced notification: %s", err)

    async def _send_restoration_notification(
        self,
        entity_id: str,
        alerts_resolved: int,
    ) -> None:
        """
        Send performance restoration notification.

        Args:
            entity_id: Entity ID
            alerts_resolved: Number of alerts that were resolved
        """
        try:
            # Get friendly entity name
            state = self.hass.states.get(entity_id)
            device_name = state.name if state else entity_id

            # Build notification
            title = "✅ Device Performance Back to Normal"

            message = (
                f"Good news - {device_name} looks like it's back to normal. "
            )

            if alerts_resolved == 1:
                message += "The performance issue seems resolved. "
            else:
                message += f"All {alerts_resolved} issues seem resolved. "

            message += (
                "I'll keep monitoring to make sure it stays stable.\n\n"
                "— Alfred"
            )

            # Send persistent notification
            notification_id = f"alfred_restored_{entity_id}_{dt_util.now().timestamp()}"

            await self.hass.services.async_call(
                "persistent_notification",
                "create",
                {
                    "title": title,
                    "message": message,
                    "notification_id": notification_id,
                },
                blocking=False,
            )

            _LOGGER.info("Sent restoration notification for %s", device_name)

        except Exception as err:
            _LOGGER.error("Error sending restoration notification: %s", err)
