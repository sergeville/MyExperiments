"""Diagnosis context builder for Alfred Digital Butler - Epic 3 Story 3.4."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util
from homeassistant.helpers import (
    entity_registry as er,
    device_registry as dr,
    area_registry as ar,
)

from .degradation_detector import DegradationReport
from .performance_metrics import PerformanceMetricsCollector
from .baseline_calculator import BaselineCalculator
from .runtime_tracker import RuntimeTracker
from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)

# Context gathering timeout
CONTEXT_TIMEOUT = 5.0  # 5 seconds max


class DiagnosisContextBuilder:
    """Builds comprehensive diagnostic context from multiple data sources."""

    def __init__(
        self,
        hass: HomeAssistant,
        metrics_collector: PerformanceMetricsCollector,
        baseline_calculator: BaselineCalculator,
        runtime_tracker: RuntimeTracker,
        pattern_storage: PatternStorage,
    ) -> None:
        """
        Initialize diagnosis context builder.

        Args:
            hass: Home Assistant instance
            metrics_collector: Performance metrics collector
            baseline_calculator: Baseline calculator
            runtime_tracker: Runtime tracker
            pattern_storage: Pattern storage for database access
        """
        self.hass = hass
        self._metrics = metrics_collector
        self._baseline = baseline_calculator
        self._runtime = runtime_tracker
        self._storage = pattern_storage

    async def build_diagnosis_context(
        self,
        entity_id: str,
        degradation_report: DegradationReport,
    ) -> dict[str, Any]:
        """
        Gather all relevant data for AI diagnosis.

        This method collects comprehensive context from multiple sources:
        - Device metadata (name, type, manufacturer, area)
        - Current symptoms (from degradation report)
        - Baseline performance data
        - Runtime statistics
        - Performance history (7-14 days)
        - Environmental context
        - Power quality (if available)

        Args:
            entity_id: Entity ID to diagnose
            degradation_report: Degradation report with current symptoms

        Returns:
            Comprehensive context dictionary for LLM diagnosis

        Example:
            {
                "device": {
                    "entity_id": "light.living_room",
                    "friendly_name": "Living Room Light",
                    "domain": "light",
                    "manufacturer": "Philips",
                    "model": "Hue White A19",
                    "area": "Living Room"
                },
                "current_symptoms": {...},
                "baseline": {...},
                "runtime": {...},
                "performance_history": [...],
                "environment": {...},
                "power_quality": {...}
            }
        """
        try:
            _LOGGER.info(
                "Building diagnosis context for %s (%s)",
                entity_id,
                degradation_report.degradation_type
            )

            context = {}

            # 1. Device Identification & Metadata
            context["device"] = await self._get_device_metadata(entity_id)

            # 2. Current Symptoms (from degradation report)
            context["current_symptoms"] = self._format_symptoms(degradation_report)

            # 3. Baseline Performance
            context["baseline"] = await self._get_baseline_data(entity_id)

            # 4. Runtime Statistics
            context["runtime"] = await self._get_runtime_stats(entity_id)

            # 5. Performance History (last 14 days)
            context["performance_history"] = await self._get_performance_history(
                entity_id,
                degradation_report.metric_name,
                days=14
            )

            # 6. Environmental Context
            context["environment"] = await self._get_environmental_context(entity_id)

            # 7. Power Quality (if power monitoring available)
            if await self._has_power_monitoring(entity_id):
                context["power_quality"] = await self._get_power_quality(entity_id)

            _LOGGER.info(
                "Context built successfully for %s (%d data sources)",
                entity_id,
                len([k for k, v in context.items() if v])
            )

            return context

        except Exception as err:
            _LOGGER.error(
                "Error building diagnosis context for %s: %s",
                entity_id,
                err,
                exc_info=True
            )
            # Return minimal context with error
            return {
                "device": {"entity_id": entity_id},
                "current_symptoms": self._format_symptoms(degradation_report),
                "error": str(err),
            }

    async def _get_device_metadata(self, entity_id: str) -> dict[str, Any]:
        """
        Get comprehensive device metadata.

        Args:
            entity_id: Entity ID

        Returns:
            Device metadata dictionary
        """
        try:
            state = self.hass.states.get(entity_id)
            entity_registry = er.async_get(self.hass)
            entity_entry = entity_registry.async_get(entity_id)

            metadata = {
                "entity_id": entity_id,
                "friendly_name": state.name if state else entity_id,
                "domain": entity_id.split(".")[0],
                "device_class": state.attributes.get("device_class") if state else None,
            }

            # Add entity registry information
            if entity_entry:
                # Get device information
                if entity_entry.device_id:
                    device_registry = dr.async_get(self.hass)
                    device_entry = device_registry.async_get(entity_entry.device_id)

                    if device_entry:
                        metadata["manufacturer"] = device_entry.manufacturer
                        metadata["model"] = device_entry.model
                        metadata["sw_version"] = device_entry.sw_version
                        metadata["hw_version"] = device_entry.hw_version

                # Get area information
                if entity_entry.area_id:
                    area_registry = ar.async_get(self.hass)
                    area = area_registry.async_get_area(entity_entry.area_id)
                    metadata["area"] = area.name if area else None

                # Add entity configuration
                metadata["disabled"] = entity_entry.disabled
                metadata["entity_category"] = entity_entry.entity_category

            # Add current state attributes
            if state:
                metadata["current_state"] = state.state
                metadata["unit_of_measurement"] = state.attributes.get("unit_of_measurement")
                metadata["state_attributes"] = {
                    k: v for k, v in state.attributes.items()
                    if k not in ["friendly_name", "device_class", "unit_of_measurement"]
                }

            return metadata

        except Exception as err:
            _LOGGER.error("Error getting device metadata: %s", err)
            return {
                "entity_id": entity_id,
                "error": str(err),
            }

    def _format_symptoms(self, report: DegradationReport) -> dict[str, Any]:
        """
        Format degradation report into symptoms dictionary.

        Args:
            report: Degradation report

        Returns:
            Formatted symptoms dictionary
        """
        return {
            "metric_name": report.metric_name,
            "degradation_type": report.degradation_type,
            "severity": report.severity,
            "current_value": report.current_value,
            "baseline_value": report.baseline_value,
            "deviation_percentage": report.deviation_percentage,
            "z_score": report.z_score,
            "statistical_significance": report.statistical_significance,
            "trend_type": report.trend_type,
            "degradation_rate": report.degradation_rate,
            "days_degraded": report.days_degraded,
            "confidence": report.confidence,
            "recommendation": report.recommendation,
            "timestamp": report.timestamp.isoformat(),
        }

    async def _get_baseline_data(self, entity_id: str) -> dict[str, Any]:
        """
        Get baseline performance data for entity.

        Args:
            entity_id: Entity ID

        Returns:
            Baseline data dictionary
        """
        try:
            baselines = await self._storage.get_baselines_for_entity(entity_id)

            if not baselines:
                _LOGGER.debug("No baseline data for %s", entity_id)
                return {"status": "no_baseline"}

            # Format baseline data for diagnosis
            baseline_info = {}

            for baseline in baselines:
                metric_name = baseline["metric_name"]
                baseline_info[metric_name] = {
                    "value": baseline["metric_value"],
                    "std_dev": baseline["std_dev"],
                    "min_value": baseline["min_value"],
                    "max_value": baseline["max_value"],
                    "confidence_score": baseline["confidence_score"],
                    "sample_count": baseline["sample_count"],
                    "observation_days": baseline["observation_period_days"],
                    "calculated_at": baseline["calculated_at"],
                }

            return baseline_info

        except Exception as err:
            _LOGGER.error("Error getting baseline data: %s", err)
            return {"error": str(err)}

    async def _get_runtime_stats(self, entity_id: str) -> dict[str, Any]:
        """
        Get runtime statistics for entity.

        Args:
            entity_id: Entity ID

        Returns:
            Runtime statistics dictionary
        """
        try:
            # Try to get runtime stats from runtime tracker
            runtime_stats = await self._runtime.get_runtime_stats(entity_id)

            if not runtime_stats:
                _LOGGER.debug("No runtime stats for %s", entity_id)
                return {"status": "no_runtime_tracking"}

            # Format runtime data for diagnosis
            return {
                "total_runtime_hours": runtime_stats.get("total_runtime_hours", 0),
                "runtime_since_baseline": runtime_stats.get("runtime_since_baseline", 0),
                "on_cycles_count": runtime_stats.get("on_cycles_count", 0),
                "current_state": runtime_stats.get("current_state"),
                "last_on_time": runtime_stats.get("last_on_time"),
                "last_off_time": runtime_stats.get("last_off_time"),
                "average_cycle_duration": runtime_stats.get("avg_cycle_duration_hours"),
                "cycles_per_day": runtime_stats.get("cycles_per_day"),
            }

        except Exception as err:
            _LOGGER.error("Error getting runtime stats: %s", err)
            return {"error": str(err)}

    async def _get_performance_history(
        self,
        entity_id: str,
        metric_name: str,
        days: int = 14,
    ) -> list[dict[str, Any]]:
        """
        Get performance history for the last N days.

        Args:
            entity_id: Entity ID
            metric_name: Metric to get history for
            days: Number of days to look back

        Returns:
            List of historical data points
        """
        try:
            # Get baseline history from database
            history = await self._storage.get_baseline_history(
                entity_id,
                metric_name,
                days=days
            )

            if not history:
                _LOGGER.debug("No performance history for %s", entity_id)
                return []

            # Format history data
            formatted_history = []
            for record in history:
                formatted_history.append({
                    "date": record["updated_at"],
                    "value": record["metric_value"],
                    "std_dev": record.get("std_dev"),
                    "sample_count": record.get("sample_count"),
                })

            return formatted_history

        except Exception as err:
            _LOGGER.error("Error getting performance history: %s", err)
            return []

    async def _get_environmental_context(self, entity_id: str) -> dict[str, Any]:
        """
        Get environmental context (area, related devices).

        Args:
            entity_id: Entity ID

        Returns:
            Environmental context dictionary
        """
        try:
            entity_registry = er.async_get(self.hass)
            entity_entry = entity_registry.async_get(entity_id)

            context = {}

            if entity_entry and entity_entry.area_id:
                area_registry = ar.async_get(self.hass)
                area = area_registry.async_get_area(entity_entry.area_id)

                if area:
                    context["area"] = area.name

                    # Get other entities in same area
                    area_entities = [
                        e.entity_id
                        for e in entity_registry.entities.values()
                        if e.area_id == entity_entry.area_id
                    ]

                    # Count devices by domain
                    domain_counts = {}
                    for ent_id in area_entities:
                        domain = ent_id.split(".")[0]
                        domain_counts[domain] = domain_counts.get(domain, 0) + 1

                    context["area_device_count"] = len(area_entities)
                    context["area_domains"] = domain_counts

            # Get current time of day context
            now = dt_util.now()
            hour = now.hour

            if 5 <= hour < 12:
                context["time_of_day"] = "morning"
            elif 12 <= hour < 17:
                context["time_of_day"] = "afternoon"
            elif 17 <= hour < 22:
                context["time_of_day"] = "evening"
            else:
                context["time_of_day"] = "night"

            # Day of week
            context["day_of_week"] = now.strftime("%A")
            context["is_weekend"] = now.weekday() >= 5

            return context

        except Exception as err:
            _LOGGER.error("Error getting environmental context: %s", err)
            return {"error": str(err)}

    async def _has_power_monitoring(self, entity_id: str) -> bool:
        """
        Check if entity has power monitoring capabilities.

        Args:
            entity_id: Entity ID

        Returns:
            True if power monitoring is available
        """
        try:
            state = self.hass.states.get(entity_id)
            if not state:
                return False

            # Check if entity has power-related attributes
            power_attrs = [
                "power",
                "current_power_w",
                "power_consumption",
                "voltage",
                "current",
            ]

            return any(attr in state.attributes for attr in power_attrs)

        except Exception as err:
            _LOGGER.error("Error checking power monitoring: %s", err)
            return False

    async def _get_power_quality(self, entity_id: str) -> dict[str, Any]:
        """
        Get power quality data if available.

        Args:
            entity_id: Entity ID

        Returns:
            Power quality data dictionary
        """
        try:
            state = self.hass.states.get(entity_id)
            if not state:
                return {}

            power_data = {}

            # Extract power-related attributes
            if "power" in state.attributes:
                power_data["current_power"] = state.attributes["power"]

            if "voltage" in state.attributes:
                power_data["current_voltage"] = state.attributes["voltage"]

            if "current" in state.attributes:
                power_data["current_amperage"] = state.attributes["current"]

            if "energy" in state.attributes:
                power_data["total_energy"] = state.attributes["energy"]

            # Try to get power quality issues from storage
            # This would require the degradation detector to track power quality
            # For now, just return current readings

            return power_data

        except Exception as err:
            _LOGGER.error("Error getting power quality: %s", err)
            return {"error": str(err)}
