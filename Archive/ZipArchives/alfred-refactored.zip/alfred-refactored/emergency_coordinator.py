"""Emergency Response Coordinator for Alfred.

Epic 5: Security & Environmental Safety
Story 5.9: Emergency Response Coordination

Coordinates rapid responses to emergency situations such as fire, flood, CO detection,
and security breaches. Executes automated actions, sends notifications, and maintains
detailed logs for insurance and review.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any
from enum import Enum
import json

from homeassistant.core import HomeAssistant, Event, callback
from homeassistant.const import EVENT_STATE_CHANGED
from homeassistant.util import dt as dt_util
from homeassistant.helpers import entity_registry

from .const import (
    EVENT_EMERGENCY_ACTIVATED,
    EVENT_EMERGENCY_DEACTIVATED,
    EVENT_EMERGENCY_ACTION_EXECUTED,
)

_LOGGER = logging.getLogger(__name__)


class EmergencyType(Enum):
    """Types of emergencies."""

    FIRE = "fire"
    CARBON_MONOXIDE = "carbon_monoxide"
    SECURITY_BREACH = "security_breach"
    FLOOD = "flood"
    MANUAL = "manual"
    GAS_LEAK = "gas_leak"
    MEDICAL = "medical"


class EmergencySeverity(Enum):
    """Emergency severity levels."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ActionStatus(Enum):
    """Status of emergency action execution."""

    PENDING = "pending"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class EmergencyCoordinator:
    """Handles the coordination of emergency responses.

    Features:
    - Automatic emergency detection from sensors
    - Configurable automated actions
    - Emergency notifications with context
    - Detailed logging for insurance/review
    - Manual trigger option
    - Reversible emergency mode
    - False activation prevention
    """

    def __init__(self, hass: HomeAssistant) -> None:
        """Initialize the emergency coordinator.

        Args:
            hass: Home Assistant instance
        """
        self.hass = hass
        self._is_emergency = False
        self._active_emergency = None
        self._emergency_log = []
        self._emergency_start_time = None
        self._unsub = None
        self._actions_executed = []

        # Configuration (can be made configurable via UI later)
        self._config = {
            "enabled": True,
            "confirmation_required": {
                EmergencyType.MANUAL: True,  # Always require confirmation for manual
                EmergencyType.SECURITY_BREACH: True,  # May be false alarm
                EmergencyType.FLOOD: False,  # Act immediately
                EmergencyType.FIRE: False,  # Act immediately
                EmergencyType.CARBON_MONOXIDE: False,  # Act immediately
            },
            "actions": {
                "unlock_doors": True,
                "turn_on_lights": True,
                "disable_automations": True,
                "shut_off_water": False,  # Too aggressive for most
                "notify_contacts": True,
            },
            "notification_contacts": [
                "notify.notify",  # Default Home Assistant notification
            ],
        }

        # Sensor patterns for emergency detection
        self._emergency_patterns = {
            EmergencyType.FIRE: {
                "states": ["on", "detected", "alarm", "fire"],
                "keywords": ["smoke", "fire"],
                "severity": EmergencySeverity.CRITICAL,
            },
            EmergencyType.CARBON_MONOXIDE: {
                "states": ["on", "detected", "alarm"],
                "keywords": ["co", "carbon_monoxide"],
                "severity": EmergencySeverity.CRITICAL,
            },
            EmergencyType.SECURITY_BREACH: {
                "states": ["on", "detected", "triggered"],
                "keywords": ["alarm", "security", "intrusion", "motion"],
                "severity": EmergencySeverity.HIGH,
            },
            EmergencyType.FLOOD: {
                "states": ["on", "wet", "detected"],
                "keywords": ["leak", "water", "flood"],
                "severity": EmergencySeverity.HIGH,
            },
        }

    async def async_setup(self) -> None:
        """Set up the emergency coordinator."""
        _LOGGER.info("Setting up emergency coordinator")

        # Subscribe to state changes for emergency detection
        self._unsub = self.hass.bus.async_listen(
            EVENT_STATE_CHANGED,
            self._handle_state_change,
        )

        _LOGGER.info("Emergency coordinator initialized")

    async def async_close(self) -> None:
        """Close the emergency coordinator."""
        if self._unsub:
            self._unsub()
        _LOGGER.info("Emergency coordinator closed")

    @callback
    def _handle_state_change(self, event: Event) -> None:
        """Handle state change events for emergency detection.

        Args:
            event: State change event
        """
        entity_id = event.data.get("entity_id")
        new_state = event.data.get("new_state")
        old_state = event.data.get("old_state")

        if not entity_id or not new_state:
            return

        # Skip if already in emergency mode
        if self._is_emergency:
            return

        # Check for emergency conditions
        self.hass.async_create_task(
            self._check_for_emergency(entity_id, new_state, old_state)
        )

    async def _check_for_emergency(
        self,
        entity_id: str,
        new_state: Any,
        old_state: Any,
    ) -> None:
        """Check if state change indicates an emergency.

        Args:
            entity_id: Entity that changed state
            new_state: New state object
            old_state: Old state object
        """
        try:
            # Check each emergency type
            for emergency_type, pattern in self._emergency_patterns.items():
                # Check if entity matches emergency pattern
                if self._matches_emergency_pattern(
                    entity_id, new_state, pattern
                ):
                    # Get context for emergency
                    context = await self._build_emergency_context(
                        entity_id, emergency_type
                    )

                    # Trigger emergency
                    await self.trigger_emergency(
                        emergency_type=emergency_type,
                        context=context,
                        severity=pattern["severity"],
                        triggering_entity=entity_id,
                    )
                    break

        except Exception as err:
            _LOGGER.error("Error checking for emergency: %s", err, exc_info=True)

    def _matches_emergency_pattern(
        self,
        entity_id: str,
        state: Any,
        pattern: dict[str, Any],
    ) -> bool:
        """Check if entity state matches emergency pattern.

        Args:
            entity_id: Entity ID
            state: State object
            pattern: Emergency pattern

        Returns:
            True if matches emergency pattern
        """
        # Check entity ID keywords
        entity_lower = entity_id.lower()
        if not any(keyword in entity_lower for keyword in pattern["keywords"]):
            return False

        # Check state value
        state_value = str(state.state).lower()
        if state_value not in pattern["states"]:
            return False

        return True

    async def _build_emergency_context(
        self,
        entity_id: str,
        emergency_type: EmergencyType,
    ) -> str:
        """Build context description for emergency.

        Args:
            entity_id: Triggering entity
            emergency_type: Type of emergency

        Returns:
            Context description
        """
        context_parts = []

        # Get friendly name of triggering entity
        state = self.hass.states.get(entity_id)
        if state and state.attributes.get("friendly_name"):
            friendly_name = state.attributes["friendly_name"]
            context_parts.append(f"{friendly_name} triggered")

        # Add location if available
        area_id = None
        ent_reg = entity_registry.async_get(self.hass)
        entry = ent_reg.async_get(entity_id)
        if entry and entry.area_id:
            area_reg = self.hass.data.get("area_registry")
            if area_reg:
                area = area_reg.async_get_area(entry.area_id)
                if area:
                    context_parts.append(f"in {area.name}")

        # Count people present
        person_count = sum(
            1
            for entity_id in self.hass.states.async_entity_ids("person")
            if self.hass.states.get(entity_id).state == "home"
        )
        if person_count > 0:
            context_parts.append(f"{person_count} person(s) detected at home")

        # Build final context
        if context_parts:
            return ", ".join(context_parts)
        else:
            return f"{emergency_type.value} detected"

    async def trigger_emergency(
        self,
        emergency_type: EmergencyType | str,
        context: str = "",
        severity: EmergencySeverity = EmergencySeverity.HIGH,
        triggering_entity: str | None = None,
        confirmation_override: bool = False,
    ) -> dict[str, Any]:
        """Trigger emergency mode.

        Args:
            emergency_type: Type of emergency
            context: Context description
            severity: Emergency severity
            triggering_entity: Entity that triggered emergency
            confirmation_override: Skip confirmation requirement

        Returns:
            Emergency activation result
        """
        try:
            # Convert string to enum if needed
            if isinstance(emergency_type, str):
                emergency_type = EmergencyType(emergency_type)

            # Check if confirmation required
            needs_confirmation = self._config["confirmation_required"].get(
                emergency_type, True
            )
            if needs_confirmation and not confirmation_override:
                _LOGGER.info(
                    "Emergency type %s requires confirmation - not auto-activating",
                    emergency_type.value,
                )
                return {
                    "success": False,
                    "requires_confirmation": True,
                    "emergency_type": emergency_type.value,
                    "context": context,
                }

            # Activate emergency mode
            self._is_emergency = True
            self._emergency_start_time = dt_util.now()
            self._active_emergency = {
                "type": emergency_type,
                "severity": severity,
                "context": context,
                "triggering_entity": triggering_entity,
                "start_time": self._emergency_start_time,
            }

            # Initialize log
            self._emergency_log = [
                {
                    "timestamp": self._emergency_start_time.isoformat(),
                    "event": "emergency_activated",
                    "type": emergency_type.value,
                    "severity": severity.value,
                    "context": context,
                    "triggering_entity": triggering_entity,
                }
            ]

            _LOGGER.error(
                "🚨 EMERGENCY ACTIVATED: %s - %s",
                emergency_type.value,
                context,
            )

            # Fire event
            self.hass.bus.fire(
                EVENT_EMERGENCY_ACTIVATED,
                {
                    "emergency_type": emergency_type.value,
                    "severity": severity.value,
                    "context": context,
                    "timestamp": self._emergency_start_time.isoformat(),
                },
            )

            # Execute automated actions (async, don't wait)
            self.hass.async_create_task(
                self._execute_automated_actions(emergency_type, context)
            )

            return {
                "success": True,
                "emergency_type": emergency_type.value,
                "severity": severity.value,
                "context": context,
                "timestamp": self._emergency_start_time.isoformat(),
            }

        except Exception as err:
            _LOGGER.error("Error triggering emergency: %s", err, exc_info=True)
            return {
                "success": False,
                "error": str(err),
            }

    async def _execute_automated_actions(
        self,
        emergency_type: EmergencyType,
        context: str,
    ) -> None:
        """Execute automated emergency actions.

        Executes within 5 seconds as per requirements.

        Args:
            emergency_type: Type of emergency
            context: Emergency context
        """
        start_time = datetime.now()
        self._actions_executed = []

        try:
            actions_config = self._config["actions"]

            # Action 1: Turn on all lights (visibility, safety)
            if actions_config.get("turn_on_lights", True):
                await self._execute_action(
                    "turn_on_all_lights",
                    self._turn_on_all_lights,
                )

            # Action 2: Unlock doors (emergency exit)
            if actions_config.get("unlock_doors", True):
                await self._execute_action(
                    "unlock_doors",
                    self._unlock_doors,
                )

            # Action 3: Disable routine automations (prevent interference)
            if actions_config.get("disable_automations", True):
                await self._execute_action(
                    "disable_automations",
                    self._disable_routine_automations,
                )

            # Action 4: Shut off water main (flood only)
            if (
                emergency_type == EmergencyType.FLOOD
                and actions_config.get("shut_off_water", False)
            ):
                await self._execute_action(
                    "shut_off_water",
                    self._shut_off_water_main,
                )

            # Action 5: Send emergency notifications
            if actions_config.get("notify_contacts", True):
                await self._execute_action(
                    "send_notifications",
                    lambda: self._send_emergency_notifications(
                        emergency_type, context
                    ),
                )

            # Log execution time
            execution_time = (datetime.now() - start_time).total_seconds()
            _LOGGER.info(
                "Emergency actions executed in %.2f seconds", execution_time
            )

            # Verify 5-second requirement
            if execution_time > 5.0:
                _LOGGER.warning(
                    "⚠️ Emergency actions took longer than 5 seconds: %.2f",
                    execution_time,
                )

        except Exception as err:
            _LOGGER.error("Error executing emergency actions: %s", err, exc_info=True)
            self._log_event(
                "action_error",
                {"error": str(err)},
            )

    async def _execute_action(
        self,
        action_name: str,
        action_func,
    ) -> None:
        """Execute a single emergency action with error handling.

        Args:
            action_name: Name of action
            action_func: Function to execute
        """
        start_time = datetime.now()
        status = ActionStatus.PENDING

        try:
            _LOGGER.debug("Executing emergency action: %s", action_name)
            status = ActionStatus.EXECUTING

            # Execute action
            await action_func()

            status = ActionStatus.COMPLETED
            execution_time = (datetime.now() - start_time).total_seconds()

            _LOGGER.info(
                "✓ Emergency action completed: %s (%.2fs)",
                action_name,
                execution_time,
            )

            # Log to emergency log
            self._log_event(
                "action_executed",
                {
                    "action": action_name,
                    "status": "completed",
                    "execution_time": execution_time,
                },
            )

            # Fire event
            self.hass.bus.fire(
                EVENT_EMERGENCY_ACTION_EXECUTED,
                {
                    "action": action_name,
                    "status": "completed",
                    "execution_time": execution_time,
                },
            )

        except Exception as err:
            status = ActionStatus.FAILED
            _LOGGER.error(
                "✗ Emergency action failed: %s - %s",
                action_name,
                err,
                exc_info=True,
            )

            self._log_event(
                "action_failed",
                {
                    "action": action_name,
                    "error": str(err),
                },
            )

        finally:
            self._actions_executed.append({
                "action": action_name,
                "status": status.value,
                "timestamp": datetime.now().isoformat(),
            })

    async def _turn_on_all_lights(self) -> None:
        """Turn on all lights for visibility and safety."""
        try:
            # Get all light entities
            light_entities = self.hass.states.async_entity_ids("light")

            if not light_entities:
                _LOGGER.warning("No lights found to turn on")
                return

            # Turn on all lights
            await self.hass.services.async_call(
                "light",
                "turn_on",
                {"entity_id": light_entities},
                blocking=True,
            )

            _LOGGER.info("Turned on %d lights", len(light_entities))

        except Exception as err:
            _LOGGER.error("Failed to turn on lights: %s", err)
            raise

    async def _unlock_doors(self) -> None:
        """Unlock all doors for emergency exit."""
        try:
            # Get all lock entities
            lock_entities = self.hass.states.async_entity_ids("lock")

            if not lock_entities:
                _LOGGER.warning("No locks found to unlock")
                return

            # Unlock all locks
            await self.hass.services.async_call(
                "lock",
                "unlock",
                {"entity_id": lock_entities},
                blocking=True,
            )

            _LOGGER.info("Unlocked %d doors", len(lock_entities))

        except Exception as err:
            _LOGGER.error("Failed to unlock doors: %s", err)
            raise

    async def _disable_routine_automations(self) -> None:
        """Disable routine automations to prevent interference."""
        try:
            # Get all automation entities
            automation_entities = self.hass.states.async_entity_ids("automation")

            if not automation_entities:
                _LOGGER.warning("No automations found")
                return

            # Filter out emergency-related automations (keep those active)
            routine_automations = [
                entity_id
                for entity_id in automation_entities
                if "emergency" not in entity_id.lower()
                and "alarm" not in entity_id.lower()
            ]

            if not routine_automations:
                _LOGGER.info("No routine automations to disable")
                return

            # Disable routine automations
            await self.hass.services.async_call(
                "automation",
                "turn_off",
                {"entity_id": routine_automations},
                blocking=True,
            )

            _LOGGER.info("Disabled %d routine automations", len(routine_automations))

        except Exception as err:
            _LOGGER.error("Failed to disable automations: %s", err)
            raise

    async def _shut_off_water_main(self) -> None:
        """Shut off water main valve (flood emergencies)."""
        try:
            # Find water main valve
            valve_entities = [
                entity_id
                for entity_id in self.hass.states.async_entity_ids()
                if "water" in entity_id.lower()
                and ("main" in entity_id.lower() or "valve" in entity_id.lower())
                and (entity_id.startswith("switch.") or entity_id.startswith("valve."))
            ]

            if not valve_entities:
                _LOGGER.warning("No water main valve found")
                return

            # Turn off valve(s)
            for valve_entity in valve_entities:
                domain = valve_entity.split(".")[0]
                if domain == "switch":
                    await self.hass.services.async_call(
                        "switch",
                        "turn_off",
                        {"entity_id": valve_entity},
                        blocking=True,
                    )
                elif domain == "valve":
                    await self.hass.services.async_call(
                        "valve",
                        "close",
                        {"entity_id": valve_entity},
                        blocking=True,
                    )

            _LOGGER.info("Shut off %d water valve(s)", len(valve_entities))

        except Exception as err:
            _LOGGER.error("Failed to shut off water: %s", err)
            raise

    async def _send_emergency_notifications(
        self,
        emergency_type: EmergencyType,
        context: str,
    ) -> None:
        """Send emergency notifications to configured contacts.

        Args:
            emergency_type: Type of emergency
            context: Emergency context
        """
        try:
            notification_services = self._config["notification_contacts"]

            # Build notification message
            message = (
                f"🚨 EMERGENCY ALERT 🚨\n\n"
                f"Type: {emergency_type.value.upper()}\n"
                f"Details: {context}\n"
                f"Time: {self._emergency_start_time.strftime('%I:%M %p')}\n\n"
                f"Automated emergency actions have been executed.\n"
                f"Please check on your home immediately."
            )

            # Send to all configured notification services
            for service in notification_services:
                try:
                    await self.hass.services.async_call(
                        "notify",
                        service.split(".")[1] if "." in service else service,
                        {
                            "message": message,
                            "title": "🚨 EMERGENCY: Home Alert",
                        },
                        blocking=False,
                    )
                except Exception as err:
                    _LOGGER.error(
                        "Failed to send notification to %s: %s", service, err
                    )

            _LOGGER.info("Sent emergency notifications to %d contacts", len(notification_services))

        except Exception as err:
            _LOGGER.error("Failed to send notifications: %s", err)
            raise

    async def resolve_emergency(self, resolved_by: str = "user") -> dict[str, Any]:
        """Resolve emergency and return to normal operation.

        Args:
            resolved_by: Who resolved the emergency

        Returns:
            Resolution result
        """
        try:
            if not self._is_emergency:
                return {
                    "success": False,
                    "message": "No active emergency to resolve",
                }

            end_time = dt_util.now()
            duration = (end_time - self._emergency_start_time).total_seconds()

            # Log resolution
            self._log_event(
                "emergency_resolved",
                {
                    "resolved_by": resolved_by,
                    "duration_seconds": duration,
                },
            )

            _LOGGER.info(
                "Emergency resolved by %s after %.1f seconds",
                resolved_by,
                duration,
            )

            # Fire event
            self.hass.bus.fire(
                EVENT_EMERGENCY_DEACTIVATED,
                {
                    "emergency_type": self._active_emergency["type"].value,
                    "duration_seconds": duration,
                    "resolved_by": resolved_by,
                    "timestamp": end_time.isoformat(),
                },
            )

            # Store emergency details for later retrieval
            emergency_summary = {
                "type": self._active_emergency["type"].value,
                "severity": self._active_emergency["severity"].value,
                "context": self._active_emergency["context"],
                "start_time": self._emergency_start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_seconds": duration,
                "actions_executed": self._actions_executed,
                "log": self._emergency_log,
            }

            # Reset state
            self._is_emergency = False
            self._active_emergency = None

            return {
                "success": True,
                "message": "Emergency resolved successfully",
                "summary": emergency_summary,
            }

        except Exception as err:
            _LOGGER.error("Error resolving emergency: %s", err, exc_info=True)
            return {
                "success": False,
                "error": str(err),
            }

    def get_status(self) -> dict[str, Any]:
        """Get current emergency status.

        Returns:
            Emergency status
        """
        if not self._is_emergency:
            return {
                "is_emergency": False,
                "message": "No active emergency",
            }

        duration = (dt_util.now() - self._emergency_start_time).total_seconds()

        return {
            "is_emergency": True,
            "emergency_type": self._active_emergency["type"].value,
            "severity": self._active_emergency["severity"].value,
            "context": self._active_emergency["context"],
            "duration_seconds": duration,
            "start_time": self._emergency_start_time.isoformat(),
            "actions_executed": len(self._actions_executed),
        }

    def get_emergency_log(self) -> dict[str, Any]:
        """Get detailed emergency log for insurance/review.

        Returns:
            Emergency log data
        """
        if not self._is_emergency and not self._emergency_log:
            return {
                "success": False,
                "message": "No emergency log available",
            }

        return {
            "success": True,
            "is_active": self._is_emergency,
            "emergency_type": (
                self._active_emergency["type"].value if self._active_emergency else None
            ),
            "log_entries": self._emergency_log,
            "actions_executed": self._actions_executed,
            "start_time": (
                self._emergency_start_time.isoformat()
                if self._emergency_start_time
                else None
            ),
        }

    def _log_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Add event to emergency log.

        Args:
            event_type: Type of event
            data: Event data
        """
        log_entry = {
            "timestamp": dt_util.now().isoformat(),
            "event": event_type,
            **data,
        }
        self._emergency_log.append(log_entry)
