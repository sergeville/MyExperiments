"""Energy Consumption Analyzer for Alfred Digital Butler."""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant, State, callback
from homeassistant.helpers.event import async_track_state_change_event
from homeassistant.util import dt as dt_util

from .pattern_storage import PatternStorage
from .historical_data import HistoricalDataAccess
from .baseline_calculator import BaselineCalculator

_LOGGER = logging.getLogger(__name__)


@dataclass
class EnergySensorStatus:
    """Status of an energy sensor."""

    entity_id: str
    name: str
    current_state: float
    unit: str
    device_class: str
    state_class: str
    last_updated: datetime
    is_available: bool
    sensor_type: str  # 'energy', 'power', 'cost'


@dataclass
class EnergyData:
    """Energy consumption data for analysis."""

    entity_id: str
    timestamps: list[datetime]
    values: list[float]  # kWh or other energy unit
    unit: str
    period: timedelta
    aggregation: str  # 'raw', 'hourly', 'daily', 'weekly', 'monthly'


@dataclass
class ConsumptionPatterns:
    """Detected consumption patterns."""

    entity_id: str
    daily_pattern: dict[int, float]  # hour -> avg kWh
    weekly_pattern: dict[int, float]  # day_of_week -> avg kWh
    monthly_trend: str  # 'increasing', 'decreasing', 'stable'
    cyclical: bool
    confidence: float
    peak_hours: list[int]
    off_peak_hours: list[int]
    detected_at: datetime


@dataclass
class PeakPeriod:
    """Peak consumption period."""

    entity_id: str
    start_time: datetime
    end_time: datetime
    avg_consumption: float
    peak_consumption: float
    frequency: str  # 'daily', 'weekly', 'monthly'
    confidence: float


@dataclass
class ConsumptionSpike:
    """Unusual consumption spike."""

    entity_id: str
    timestamp: datetime
    value: float
    baseline: float
    deviation_percent: float
    likely_cause: str | None


class EnergyConsumptionAnalyzer:
    """
    Analyzes home energy consumption patterns and provides insights.

    Capabilities:
    - Discovers and monitors energy sensors
    - Analyzes consumption patterns (daily/weekly/monthly)
    - Detects peak usage periods and spikes
    - Calculates baseline consumption
    - Generates actionable insights
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
        historical_data: HistoricalDataAccess,
        baseline_calculator: BaselineCalculator,
    ) -> None:
        """
        Initialize the Energy Consumption Analyzer.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
            historical_data: Historical data access instance
            baseline_calculator: Baseline calculator instance
        """
        self.hass = hass
        self._pattern_storage = pattern_storage
        self._historical_data = historical_data
        self._baseline_calculator = baseline_calculator

        # Cached sensor lists
        self._energy_sensors: set[str] = set()
        self._power_sensors: set[str] = set()
        self._cost_sensors: set[str] = set()
        self._last_discovery: datetime | None = None
        self._discovery_cache_duration = timedelta(hours=1)

        # State change listeners
        self._listeners: list[callable] = []

    # ========================================================================
    # SETUP & INITIALIZATION
    # ========================================================================

    async def async_setup(self) -> None:
        """Set up the energy consumption analyzer."""
        _LOGGER.info("Setting up Energy Consumption Analyzer")

        # Initial discovery
        await self.discover_energy_sensors()

        # Setup state change listeners for discovered sensors
        await self._setup_listeners()

        _LOGGER.info("Energy Consumption Analyzer setup complete")

    async def async_start(self) -> None:
        """Start energy consumption analyzer."""
        _LOGGER.info("Starting Energy Consumption Analyzer")

        # Schedule delayed re-discovery to catch sensors that load after Alfred
        async def delayed_rediscovery():
            await asyncio.sleep(30)  # Wait 30 seconds for other integrations
            _LOGGER.info("Performing delayed sensor re-discovery...")
            await self.discover_energy_sensors(force_refresh=True)
            await self.monitor_all_sensors()

        asyncio.create_task(delayed_rediscovery())

        # Initial monitoring
        await self.monitor_all_sensors()

    # ========================================================================
    # SENSOR DISCOVERY
    # ========================================================================

    async def discover_energy_sensors(
        self, force_refresh: bool = False
    ) -> dict[str, list[str]]:
        """
        Discover all energy-related sensors in Home Assistant.

        Discovers three types of sensors:
        1. Energy sensors (kWh, Wh, etc.) - device_class = 'energy'
        2. Power sensors (W, kW) - device_class = 'power'
        3. Cost sensors ($, USD) - device_class = 'monetary'

        Args:
            force_refresh: Force cache refresh

        Returns:
            Dictionary with 'energy', 'power', and 'cost' sensor lists
        """
        now = dt_util.now()

        # Check cache
        if (
            not force_refresh
            and self._last_discovery
            and now - self._last_discovery < self._discovery_cache_duration
        ):
            return {
                "energy": list(self._energy_sensors),
                "power": list(self._power_sensors),
                "cost": list(self._cost_sensors),
            }

        _LOGGER.debug("Discovering energy sensors...")

        energy_sensors = set()
        power_sensors = set()
        cost_sensors = set()

        # Strategy 1: Filter sensor domain with energy device class
        all_sensors = list(self.hass.states.async_all("sensor"))
        _LOGGER.debug(f"Total sensors in HA: {len(all_sensors)}")

        for state in all_sensors:
            device_class = state.attributes.get("device_class")
            state_class = state.attributes.get("state_class")

            # Debug log for sonoff sensors
            if "sonoff" in state.entity_id.lower() or "energy" in state.entity_id.lower() or "power" in state.entity_id.lower():
                _LOGGER.debug(f"Checking {state.entity_id}: device_class={device_class}, state_class={state_class}")

            # Energy sensors (kWh, Wh, etc.)
            if device_class == "energy" and state_class in [
                "total",
                "total_increasing",
            ]:
                _LOGGER.info(f"Found energy sensor: {state.entity_id}")
                energy_sensors.add(state.entity_id)

            # Power sensors (W, kW) - for converting to energy
            elif device_class == "power" and state_class == "measurement":
                _LOGGER.info(f"Found power sensor: {state.entity_id}")
                power_sensors.add(state.entity_id)

            # Cost sensors (monetary)
            elif device_class == "monetary" and state_class in [
                "total",
                "total_increasing",
            ]:
                cost_sensors.add(state.entity_id)

        # Strategy 2: Check for energy-related names (backup strategy)
        for state in self.hass.states.async_all("sensor"):
            entity_lower = state.entity_id.lower()

            if any(
                keyword in entity_lower
                for keyword in ["energy", "kwh", "consumption", "usage"]
            ):
                # Validate it has proper attributes
                if self._is_valid_energy_sensor(state.entity_id):
                    energy_sensors.add(state.entity_id)

        # Update cache
        self._energy_sensors = energy_sensors
        self._power_sensors = power_sensors
        self._cost_sensors = cost_sensors
        self._last_discovery = now

        _LOGGER.info(
            "Energy sensor discovery complete: %d energy, %d power, %d cost sensors",
            len(energy_sensors),
            len(power_sensors),
            len(cost_sensors),
        )

        return {
            "energy": list(energy_sensors),
            "power": list(power_sensors),
            "cost": list(cost_sensors),
        }

    def _is_valid_energy_sensor(self, entity_id: str) -> bool:
        """
        Validate if entity is a valid energy sensor.

        Args:
            entity_id: Entity ID to validate

        Returns:
            True if valid energy sensor
        """
        state = self.hass.states.get(entity_id)
        if not state:
            return False

        # Check for required attributes
        device_class = state.attributes.get("device_class")
        state_class = state.attributes.get("state_class")
        unit = state.attributes.get("unit_of_measurement")

        # Must have energy device class
        if device_class != "energy":
            return False

        # Must have appropriate state class
        if state_class not in ["total", "total_increasing"]:
            return False

        # Must have energy unit
        if unit and unit.lower() not in [
            "kwh",
            "wh",
            "mwh",
            "gwh",
            "j",
            "kj",
            "mj",
            "gj",
        ]:
            return False

        return True

    # ========================================================================
    # SENSOR MONITORING
    # ========================================================================

    async def monitor_energy_sensor(self, entity_id: str) -> EnergySensorStatus | None:
        """
        Monitor a specific energy sensor and return its status.

        Args:
            entity_id: Entity ID to monitor

        Returns:
            EnergySensorStatus or None if sensor unavailable
        """
        state = self.hass.states.get(entity_id)
        if not state:
            _LOGGER.warning("Energy sensor %s not found", entity_id)
            return None

        # Check availability
        is_available = state.state not in ["unavailable", "unknown"]
        if not is_available:
            _LOGGER.debug("Energy sensor %s is unavailable", entity_id)
            return None

        # Get current value
        try:
            current_value = float(state.state)
        except (ValueError, TypeError):
            _LOGGER.warning(
                "Energy sensor %s has invalid state: %s", entity_id, state.state
            )
            return None

        # Get attributes
        device_class = state.attributes.get("device_class", "unknown")
        state_class = state.attributes.get("state_class", "unknown")
        unit = state.attributes.get("unit_of_measurement", "")
        name = state.attributes.get("friendly_name", entity_id)

        # Determine sensor type
        sensor_type = "unknown"
        if device_class == "energy":
            sensor_type = "energy"
        elif device_class == "power":
            sensor_type = "power"
        elif device_class == "monetary":
            sensor_type = "cost"

        status = EnergySensorStatus(
            entity_id=entity_id,
            name=name,
            current_state=current_value,
            unit=unit,
            device_class=device_class,
            state_class=state_class,
            last_updated=state.last_updated,
            is_available=is_available,
            sensor_type=sensor_type,
        )

        _LOGGER.debug(
            "Energy sensor %s: %.2f %s (type: %s)",
            entity_id,
            current_value,
            unit,
            sensor_type,
        )

        return status

    async def monitor_all_sensors(self) -> dict[str, EnergySensorStatus]:
        """
        Monitor all discovered energy sensors.

        Returns:
            Dictionary mapping entity_id to EnergySensorStatus
        """
        sensors = await self.discover_energy_sensors()
        all_sensors = (
            sensors["energy"] + sensors["power"] + sensors["cost"]
        )

        results = {}
        for entity_id in all_sensors:
            status = await self.monitor_energy_sensor(entity_id)
            if status:
                results[entity_id] = status

        _LOGGER.info("Monitored %d energy sensors", len(results))

        return results

    # ========================================================================
    # STATE CHANGE LISTENERS
    # ========================================================================

    async def _setup_listeners(self) -> None:
        """Setup state change listeners for energy sensors."""
        sensors = await self.discover_energy_sensors()
        all_sensors = (
            sensors["energy"] + sensors["power"] + sensors["cost"]
        )

        if not all_sensors:
            _LOGGER.warning("No energy sensors found to monitor")
            return

        @callback
        def energy_sensor_changed(event):
            """Handle energy sensor state change."""
            entity_id = event.data.get("entity_id")
            new_state = event.data.get("new_state")

            if not new_state or new_state.state in ["unavailable", "unknown"]:
                return

            # Log significant changes
            _LOGGER.debug(
                "Energy sensor %s changed to %s %s",
                entity_id,
                new_state.state,
                new_state.attributes.get("unit_of_measurement", ""),
            )

            # Future: Trigger real-time analysis if needed

        # Setup listener for all energy sensors
        listener = async_track_state_change_event(
            self.hass, all_sensors, energy_sensor_changed
        )
        self._listeners.append(listener)

        _LOGGER.info("Setup state change listeners for %d energy sensors", len(all_sensors))

    async def async_stop(self) -> None:
        """Stop energy consumption analyzer and remove listeners."""
        for listener in self._listeners:
            listener()
        self._listeners.clear()

        _LOGGER.info("Energy Consumption Analyzer stopped")

    # ========================================================================
    # DATA COLLECTION
    # ========================================================================

    async def collect_energy_data(
        self,
        entity_id: str,
        period: timedelta | None = None,
        aggregation: str = "hour",
    ) -> EnergyData | None:
        """
        Collect energy consumption data for an entity.

        Args:
            entity_id: Energy sensor entity ID
            period: Time period to collect (default: last 30 days)
            aggregation: Aggregation level - 'hour', 'day', 'week', 'month'

        Returns:
            EnergyData object or None if data unavailable
        """
        # Default period: last 30 days
        if period is None:
            period = timedelta(days=30)

        now = dt_util.now()
        start_time = now - period

        _LOGGER.debug(
            "Collecting energy data for %s (period: %s, aggregation: %s)",
            entity_id,
            period,
            aggregation,
        )

        try:
            # Get statistics from HA recorder
            stats_dict = await self._historical_data.get_statistics(
                statistic_ids=[entity_id],
                start_time=start_time,
                end_time=now,
                period=aggregation,
                types={"sum", "state"},  # For energy sensors
            )

            if not stats_dict or entity_id not in stats_dict:
                _LOGGER.warning("No statistics found for %s", entity_id)
                return None

            stats = stats_dict[entity_id]
            if not stats:
                _LOGGER.warning("Empty statistics for %s", entity_id)
                return None

            # Extract timestamps and values
            timestamps = []
            values = []

            for stat in stats:
                timestamps.append(stat["start"])
                # Use 'sum' for cumulative energy sensors
                value = stat.get("sum") or stat.get("state") or 0.0
                values.append(value)

            # Get unit from sensor state
            state = self.hass.states.get(entity_id)
            unit = state.attributes.get("unit_of_measurement", "kWh") if state else "kWh"

            energy_data = EnergyData(
                entity_id=entity_id,
                timestamps=timestamps,
                values=values,
                unit=unit,
                period=period,
                aggregation=aggregation,
            )

            _LOGGER.info(
                "Collected %d %s data points for %s",
                len(values),
                aggregation,
                entity_id,
            )

            return energy_data

        except Exception as err:
            _LOGGER.error(
                "Error collecting energy data for %s: %s",
                entity_id,
                err,
                exc_info=True,
            )
            return None

    async def collect_multiple_sensors_data(
        self,
        entity_ids: list[str],
        period: timedelta | None = None,
        aggregation: str = "hour",
    ) -> dict[str, EnergyData]:
        """
        Collect energy data for multiple sensors.

        Args:
            entity_ids: List of energy sensor entity IDs
            period: Time period to collect (default: last 30 days)
            aggregation: Aggregation level - 'hour', 'day', 'week', 'month'

        Returns:
            Dictionary mapping entity_id to EnergyData
        """
        results = {}

        for entity_id in entity_ids:
            data = await self.collect_energy_data(entity_id, period, aggregation)
            if data:
                results[entity_id] = data

        _LOGGER.info(
            "Collected data for %d of %d sensors",
            len(results),
            len(entity_ids),
        )

        return results

    # ========================================================================
    # DATA AGGREGATION
    # ========================================================================

    async def aggregate_consumption(
        self,
        entity_ids: list[str] | None = None,
        aggregation: str = "daily",
        period_days: int = 30,
    ) -> dict[str, float]:
        """
        Aggregate energy consumption across sensors and time periods.

        Args:
            entity_ids: List of sensors to aggregate (None = all energy sensors)
            aggregation: 'hourly', 'daily', 'weekly', 'monthly'
            period_days: Number of days to look back

        Returns:
            Dictionary with aggregated consumption data:
            {
                'total_consumption': float,  # Total kWh
                'avg_per_day': float,
                'avg_per_hour': float,
                'sensor_breakdown': {entity_id: consumption}
            }
        """
        # Use all energy sensors if not specified
        if entity_ids is None:
            sensors = await self.discover_energy_sensors()
            entity_ids = sensors["energy"]

        if not entity_ids:
            _LOGGER.warning("No energy sensors to aggregate")
            return {
                "total_consumption": 0.0,
                "avg_per_day": 0.0,
                "avg_per_hour": 0.0,
                "sensor_breakdown": {},
            }

        period = timedelta(days=period_days)

        # Collect data for all sensors
        sensor_data = await self.collect_multiple_sensors_data(
            entity_ids,
            period=period,
            aggregation=aggregation,
        )

        # Calculate aggregations
        total_consumption = 0.0
        sensor_breakdown = {}

        for entity_id, data in sensor_data.items():
            if not data.values:
                continue

            # Calculate consumption for this sensor
            # For cumulative sensors, consumption = last - first value
            if data.values:
                consumption = data.values[-1] - data.values[0]
                if consumption > 0:  # Handle resets
                    sensor_breakdown[entity_id] = consumption
                    total_consumption += consumption

        # Calculate averages
        avg_per_day = total_consumption / period_days if period_days > 0 else 0.0
        avg_per_hour = avg_per_day / 24.0

        result = {
            "total_consumption": round(total_consumption, 2),
            "avg_per_day": round(avg_per_day, 2),
            "avg_per_hour": round(avg_per_hour, 2),
            "sensor_breakdown": {
                k: round(v, 2) for k, v in sensor_breakdown.items()
            },
            "period_days": period_days,
            "sensor_count": len(sensor_breakdown),
        }

        _LOGGER.info(
            "Aggregated consumption: %.2f kWh total (%.2f kWh/day avg)",
            total_consumption,
            avg_per_day,
        )

        return result

    async def calculate_consumption_delta(
        self,
        entity_id: str,
        start_time: datetime,
        end_time: datetime,
    ) -> float | None:
        """
        Calculate energy consumption delta between two timestamps.

        Args:
            entity_id: Energy sensor entity ID
            start_time: Start timestamp
            end_time: End timestamp

        Returns:
            Energy consumed (kWh) or None if unavailable
        """
        try:
            # Get statistics for the period
            stats_dict = await self._historical_data.get_statistics(
                statistic_ids=[entity_id],
                start_time=start_time,
                end_time=end_time,
                period="hour",
                types={"sum", "state"},
            )

            if not stats_dict or entity_id not in stats_dict:
                return None

            stats = stats_dict[entity_id]
            if len(stats) < 2:
                return None

            # Calculate delta (last - first)
            first_value = stats[0].get("sum") or stats[0].get("state") or 0.0
            last_value = stats[-1].get("sum") or stats[-1].get("state") or 0.0

            delta = last_value - first_value

            # Handle meter resets (negative delta)
            if delta < 0:
                _LOGGER.warning(
                    "Negative consumption delta for %s (possible meter reset)",
                    entity_id,
                )
                return None

            return round(delta, 3)

        except Exception as err:
            _LOGGER.error(
                "Error calculating consumption delta for %s: %s",
                entity_id,
                err,
            )
            return None

    # ========================================================================
    # PATTERN ANALYSIS
    # ========================================================================

    async def analyze_consumption_patterns(
        self,
        entity_id: str,
        lookback_days: int = 30,
    ) -> ConsumptionPatterns | None:
        """
        Detect consumption patterns using statistical analysis.

        Algorithm:
        1. Retrieve hourly statistics for lookback period
        2. Aggregate by hour-of-day (24 bins)
        3. Calculate mean/std for each hour
        4. Identify peak hours (> mean + 1*std)
        5. Identify off-peak hours (< mean - 0.5*std)
        6. Detect weekly patterns (day-of-week aggregation)
        7. Perform trend analysis (linear regression)
        8. Calculate cyclical pattern score
        9. Return patterns with confidence scores

        Args:
            entity_id: Energy sensor entity ID
            lookback_days: Number of days to analyze (default: 30)

        Returns:
            ConsumptionPatterns or None if insufficient data
        """
        _LOGGER.info(
            "Analyzing consumption patterns for %s (%d days)",
            entity_id,
            lookback_days,
        )

        # Step 1: Get hourly statistics
        energy_data = await self.collect_energy_data(
            entity_id,
            period=timedelta(days=lookback_days),
            aggregation="hour",
        )

        if not energy_data or len(energy_data.values) < 24:
            _LOGGER.warning(
                "Insufficient data for pattern analysis: %s",
                entity_id,
            )
            return None

        # Step 2-4: Hourly pattern analysis
        hourly_bins = [[] for _ in range(24)]
        daily_bins = [[] for _ in range(7)]

        # Calculate consumption deltas (hourly consumption, not cumulative)
        hourly_consumption = []
        for i in range(1, len(energy_data.values)):
            delta = energy_data.values[i] - energy_data.values[i - 1]
            if delta >= 0:  # Handle meter resets
                hourly_consumption.append(delta)

                # Bin by hour and day
                hour = energy_data.timestamps[i].hour
                day = energy_data.timestamps[i].weekday()
                hourly_bins[hour].append(delta)
                daily_bins[day].append(delta)

        if not hourly_consumption:
            _LOGGER.warning("No valid consumption data for %s", entity_id)
            return None

        # Calculate hourly averages
        hourly_avg = {}
        for hour in range(24):
            if hourly_bins[hour]:
                hourly_avg[hour] = sum(hourly_bins[hour]) / len(hourly_bins[hour])
            else:
                hourly_avg[hour] = 0.0

        # Calculate overall statistics
        overall_mean = sum(hourly_avg.values()) / len(hourly_avg) if hourly_avg else 0.0

        # Calculate standard deviation
        if len(hourly_avg) > 1:
            variance = sum((v - overall_mean) ** 2 for v in hourly_avg.values()) / len(hourly_avg)
            overall_std = variance ** 0.5
        else:
            overall_std = 0.0

        # Identify peak and off-peak hours
        peak_hours = [
            h for h, avg in hourly_avg.items()
            if avg > overall_mean + overall_std
        ]
        off_peak_hours = [
            h for h, avg in hourly_avg.items()
            if avg < overall_mean - 0.5 * overall_std
        ]

        # Step 5-6: Weekly pattern
        weekly_avg = {}
        for day in range(7):
            if daily_bins[day]:
                weekly_avg[day] = sum(daily_bins[day]) / len(daily_bins[day])
            else:
                weekly_avg[day] = 0.0

        # Step 7: Trend analysis (linear regression)
        if len(hourly_consumption) >= 2:
            # Simple linear regression: y = mx + b
            n = len(hourly_consumption)
            x = list(range(n))
            y = hourly_consumption

            x_mean = sum(x) / n
            y_mean = sum(y) / n

            # Calculate slope
            numerator = sum((x[i] - x_mean) * (y[i] - y_mean) for i in range(n))
            denominator = sum((x[i] - x_mean) ** 2 for i in range(n))

            if denominator != 0:
                slope = numerator / denominator
            else:
                slope = 0.0

            # Determine trend
            threshold = overall_mean * 0.01  # 1% threshold
            if slope > threshold:
                trend = "increasing"
            elif slope < -threshold:
                trend = "decreasing"
            else:
                trend = "stable"
        else:
            trend = "unknown"

        # Step 8: Cyclical detection (simple autocorrelation check)
        cyclical = self._detect_cyclical_pattern(hourly_consumption)

        # Step 9: Confidence calculation
        # Confidence based on data coverage and consistency
        expected_hours = lookback_days * 24
        actual_hours = len(hourly_consumption)
        coverage = actual_hours / expected_hours if expected_hours > 0 else 0.0

        # Confidence is higher with more data and lower variance
        confidence = min(1.0, coverage * 0.8 + 0.2)

        patterns = ConsumptionPatterns(
            entity_id=entity_id,
            daily_pattern=hourly_avg,
            weekly_pattern=weekly_avg,
            monthly_trend=trend,
            cyclical=cyclical,
            confidence=round(confidence, 2),
            peak_hours=sorted(peak_hours),
            off_peak_hours=sorted(off_peak_hours),
            detected_at=dt_util.now(),
        )

        _LOGGER.info(
            "Pattern analysis complete for %s: trend=%s, peak_hours=%s, confidence=%.2f",
            entity_id,
            trend,
            peak_hours,
            confidence,
        )

        return patterns

    def _detect_cyclical_pattern(self, values: list[float]) -> bool:
        """
        Detect cyclical patterns using simple autocorrelation.

        Args:
            values: Time series values

        Returns:
            True if cyclical pattern detected
        """
        if len(values) < 48:  # Need at least 2 days
            return False

        # Check for 24-hour cycle (daily pattern)
        try:
            lag = 24
            if len(values) > lag * 2:
                # Calculate autocorrelation at lag 24
                mean = sum(values) / len(values)

                # Calculate variance
                variance = sum((v - mean) ** 2 for v in values) / len(values)
                if variance == 0:
                    return False

                # Calculate autocorrelation
                n = len(values) - lag
                autocorr = sum(
                    (values[i] - mean) * (values[i + lag] - mean)
                    for i in range(n)
                ) / (n * variance)

                # Significant autocorrelation indicates cyclical pattern
                return autocorr > 0.3  # Threshold for "cyclical"
        except Exception as err:
            _LOGGER.debug("Error in cyclical detection: %s", err)
            return False

        return False

    async def detect_peak_periods(
        self,
        entity_id: str,
        lookback_days: int = 30,
    ) -> list[PeakPeriod]:
        """
        Detect recurring peak consumption periods.

        Algorithm:
        1. Get daily statistics for lookback period
        2. For each hour of day, calculate avg consumption
        3. Identify hours consistently above baseline
        4. Group consecutive hours into peak periods
        5. Calculate frequency (daily/weekly)
        6. Return peak periods with metadata

        Args:
            entity_id: Energy sensor entity ID
            lookback_days: Number of days to analyze

        Returns:
            List of PeakPeriod objects
        """
        _LOGGER.info("Detecting peak periods for %s", entity_id)

        # Get patterns first
        patterns = await self.analyze_consumption_patterns(entity_id, lookback_days)
        if not patterns:
            return []

        peak_periods = []

        # Group consecutive peak hours into periods
        if patterns.peak_hours:
            current_period_start = None
            current_period_hours = []

            sorted_hours = sorted(patterns.peak_hours)

            for i, hour in enumerate(sorted_hours):
                if current_period_start is None:
                    current_period_start = hour
                    current_period_hours = [hour]
                elif hour == current_period_hours[-1] + 1 or (
                    hour == 0 and current_period_hours[-1] == 23
                ):
                    # Consecutive hour
                    current_period_hours.append(hour)
                else:
                    # Gap found, create period
                    if current_period_hours:
                        period = self._create_peak_period(
                            entity_id,
                            current_period_start,
                            current_period_hours,
                            patterns,
                        )
                        if period:
                            peak_periods.append(period)

                    # Start new period
                    current_period_start = hour
                    current_period_hours = [hour]

            # Add last period
            if current_period_hours:
                period = self._create_peak_period(
                    entity_id,
                    current_period_start,
                    current_period_hours,
                    patterns,
                )
                if period:
                    peak_periods.append(period)

        _LOGGER.info("Detected %d peak periods for %s", len(peak_periods), entity_id)
        return peak_periods

    def _create_peak_period(
        self,
        entity_id: str,
        start_hour: int,
        hours: list[int],
        patterns: ConsumptionPatterns,
    ) -> PeakPeriod | None:
        """Create a PeakPeriod from consecutive hours."""
        if not hours:
            return None

        end_hour = hours[-1]

        # Calculate average and peak consumption for this period
        consumption_values = [
            patterns.daily_pattern.get(h, 0.0) for h in hours
        ]

        if not consumption_values:
            return None

        avg_consumption = sum(consumption_values) / len(consumption_values)
        peak_consumption = max(consumption_values)

        # Create datetime objects for start/end (use today as reference)
        now = dt_util.now()
        start_time = now.replace(hour=start_hour, minute=0, second=0, microsecond=0)
        end_time = now.replace(hour=end_hour, minute=59, second=59, microsecond=0)

        # Frequency is daily since we're analyzing by hour-of-day
        frequency = "daily"

        return PeakPeriod(
            entity_id=entity_id,
            start_time=start_time,
            end_time=end_time,
            avg_consumption=round(avg_consumption, 3),
            peak_consumption=round(peak_consumption, 3),
            frequency=frequency,
            confidence=patterns.confidence,
        )

    async def detect_consumption_spikes(
        self,
        entity_id: str,
        threshold_multiplier: float = 1.5,
        lookback_days: int = 7,
    ) -> list[ConsumptionSpike]:
        """
        Detect unusual consumption spikes.

        Algorithm:
        1. Calculate baseline consumption (30-day avg)
        2. Get hourly consumption for lookback period
        3. Identify values > baseline * threshold_multiplier
        4. Filter out known peak periods
        5. Correlate with device state changes (if available)
        6. Return spikes with likely causes

        Args:
            entity_id: Energy sensor entity ID
            threshold_multiplier: Multiplier for spike detection (default: 1.5)
            lookback_days: Days to check for spikes (default: 7)

        Returns:
            List of ConsumptionSpike objects
        """
        _LOGGER.info(
            "Detecting consumption spikes for %s (threshold: %.1fx)",
            entity_id,
            threshold_multiplier,
        )

        # Step 1: Calculate baseline (use 30 days for better baseline)
        baseline_data = await self.collect_energy_data(
            entity_id,
            period=timedelta(days=30),
            aggregation="hour",
        )

        if not baseline_data or len(baseline_data.values) < 24:
            _LOGGER.warning("Insufficient baseline data for %s", entity_id)
            return []

        # Calculate hourly baseline consumption
        baseline_consumption = []
        for i in range(1, len(baseline_data.values)):
            delta = baseline_data.values[i] - baseline_data.values[i - 1]
            if delta >= 0:
                baseline_consumption.append(delta)

        if not baseline_consumption:
            return []

        baseline_avg = sum(baseline_consumption) / len(baseline_consumption)
        threshold = baseline_avg * threshold_multiplier

        # Step 2: Get recent data for spike detection
        recent_data = await self.collect_energy_data(
            entity_id,
            period=timedelta(days=lookback_days),
            aggregation="hour",
        )

        if not recent_data:
            return []

        # Step 3: Identify spikes
        spikes = []
        for i in range(1, len(recent_data.values)):
            delta = recent_data.values[i] - recent_data.values[i - 1]

            if delta >= 0 and delta > threshold:
                # Calculate deviation
                deviation_percent = ((delta - baseline_avg) / baseline_avg * 100) if baseline_avg > 0 else 0.0

                spike = ConsumptionSpike(
                    entity_id=entity_id,
                    timestamp=recent_data.timestamps[i],
                    value=round(delta, 3),
                    baseline=round(baseline_avg, 3),
                    deviation_percent=round(deviation_percent, 1),
                    likely_cause=None,  # TODO: Correlate with device states
                )
                spikes.append(spike)

        _LOGGER.info("Detected %d consumption spikes for %s", len(spikes), entity_id)
        return spikes

    # ========================================================================
    # BASELINE CONSUMPTION CALCULATION
    # ========================================================================

    async def calculate_baseline_consumption(
        self,
        entity_id: str,
        period: str = "daily",
        observation_days: int = 30,
    ) -> dict[str, Any] | None:
        """
        Calculate baseline energy consumption for an entity.

        Leverages Epic 3's baseline calculation approach but tailored for
        energy consumption patterns.

        Args:
            entity_id: Energy sensor entity ID
            period: Baseline period - 'hourly', 'daily', 'weekly', 'monthly'
            observation_days: Number of days to observe (default: 30)

        Returns:
            Dictionary with baseline statistics:
            {
                'entity_id': str,
                'period': str,
                'baseline_value': float,  # Average consumption
                'std_dev': float,
                'min_value': float,
                'max_value': float,
                'confidence_score': float,
                'sample_count': int,
                'observation_days': int,
                'calculated_at': datetime,
            }
        """
        _LOGGER.info(
            "Calculating %s baseline consumption for %s (%d days)",
            period,
            entity_id,
            observation_days,
        )

        # Map period to aggregation
        aggregation_map = {
            "hourly": "hour",
            "daily": "day",
            "weekly": "week",
            "monthly": "month",
        }
        aggregation = aggregation_map.get(period, "day")

        # Collect energy data
        energy_data = await self.collect_energy_data(
            entity_id,
            period=timedelta(days=observation_days),
            aggregation=aggregation,
        )

        if not energy_data or len(energy_data.values) < 2:
            _LOGGER.warning(
                "Insufficient data for baseline calculation: %s",
                entity_id,
            )
            return None

        # Calculate consumption deltas (not cumulative values)
        consumption_values = []
        for i in range(1, len(energy_data.values)):
            delta = energy_data.values[i] - energy_data.values[i - 1]
            if delta >= 0:  # Handle meter resets
                consumption_values.append(delta)

        if len(consumption_values) < 2:
            _LOGGER.warning("Not enough consumption values for %s", entity_id)
            return None

        # Remove outliers (values > 3 std deviations from mean)
        cleaned_values = self._remove_outliers(consumption_values)

        if len(cleaned_values) < 2:
            _LOGGER.warning("Not enough valid consumption values after outlier removal")
            return None

        # Calculate statistics
        baseline_value = sum(cleaned_values) / len(cleaned_values)
        min_value = min(cleaned_values)
        max_value = max(cleaned_values)

        # Calculate standard deviation
        if len(cleaned_values) > 1:
            variance = sum(
                (v - baseline_value) ** 2 for v in cleaned_values
            ) / len(cleaned_values)
            std_dev = variance ** 0.5
        else:
            std_dev = 0.0

        # Calculate confidence score
        # Higher sample count and lower variance = higher confidence
        sample_count = len(cleaned_values)
        min_samples = 7  # At least 7 data points

        if sample_count < min_samples:
            confidence = sample_count / min_samples * 0.5
        else:
            # Confidence based on sample count and consistency
            sample_factor = min(1.0, sample_count / (observation_days * 0.8))

            # Coefficient of variation (lower is better)
            cv = (std_dev / baseline_value) if baseline_value > 0 else 1.0
            consistency_factor = max(0.0, 1.0 - min(cv, 1.0))

            confidence = (sample_factor * 0.7 + consistency_factor * 0.3)

        baseline = {
            "entity_id": entity_id,
            "period": period,
            "baseline_value": round(baseline_value, 4),
            "std_dev": round(std_dev, 4),
            "min_value": round(min_value, 4),
            "max_value": round(max_value, 4),
            "confidence_score": round(confidence, 2),
            "sample_count": sample_count,
            "observation_days": observation_days,
            "calculated_at": dt_util.now(),
        }

        _LOGGER.info(
            "Baseline calculated for %s: %.4f ±%.4f %s (confidence: %.2f)",
            entity_id,
            baseline_value,
            std_dev,
            energy_data.unit,
            confidence,
        )

        return baseline

    def _remove_outliers(
        self,
        values: list[float],
        threshold_std_dev: float = 3.0,
    ) -> list[float]:
        """
        Remove outlier values using standard deviation method.

        Args:
            values: List of values
            threshold_std_dev: Number of std deviations for outlier threshold

        Returns:
            List with outliers removed
        """
        if len(values) < 3:
            return values

        # Calculate mean and std dev
        mean = sum(values) / len(values)

        variance = sum((v - mean) ** 2 for v in values) / len(values)
        std_dev = variance ** 0.5

        if std_dev == 0:
            return values

        # Filter values within threshold
        threshold = threshold_std_dev * std_dev
        cleaned = [
            v for v in values
            if abs(v - mean) <= threshold
        ]

        removed = len(values) - len(cleaned)
        if removed > 0:
            _LOGGER.debug(
                "Removed %d outliers (%.1f%% of data)",
                removed,
                (removed / len(values) * 100),
            )

        return cleaned if cleaned else values  # Return original if all removed

    async def calculate_baseline_for_all_sensors(
        self,
        period: str = "daily",
        observation_days: int = 30,
    ) -> dict[str, dict[str, Any]]:
        """
        Calculate baselines for all discovered energy sensors.

        Args:
            period: Baseline period - 'hourly', 'daily', 'weekly', 'monthly'
            observation_days: Number of days to observe

        Returns:
            Dictionary mapping entity_id to baseline dictionary
        """
        sensors = await self.discover_energy_sensors()
        energy_sensors = sensors["energy"]

        if not energy_sensors:
            _LOGGER.warning("No energy sensors found for baseline calculation")
            return {}

        baselines = {}

        for entity_id in energy_sensors:
            baseline = await self.calculate_baseline_consumption(
                entity_id,
                period=period,
                observation_days=observation_days,
            )

            if baseline:
                baselines[entity_id] = baseline

        _LOGGER.info(
            "Calculated baselines for %d of %d energy sensors",
            len(baselines),
            len(energy_sensors),
        )

        return baselines

    async def compare_to_baseline(
        self,
        entity_id: str,
        current_consumption: float,
        period: str = "daily",
    ) -> dict[str, Any] | None:
        """
        Compare current consumption to baseline.

        Args:
            entity_id: Energy sensor entity ID
            current_consumption: Current consumption value to compare
            period: Baseline period to compare against

        Returns:
            Dictionary with comparison results:
            {
                'entity_id': str,
                'current_consumption': float,
                'baseline_consumption': float,
                'deviation': float,  # Absolute difference
                'deviation_percent': float,  # Percentage difference
                'deviation_std': float,  # Number of std deviations
                'status': str,  # 'normal', 'above_baseline', 'below_baseline'
                'significant': bool,  # Is deviation significant (>1 std dev)
            }
        """
        # Get baseline
        baseline = await self.calculate_baseline_consumption(entity_id, period)

        if not baseline:
            _LOGGER.warning("No baseline available for %s", entity_id)
            return None

        baseline_value = baseline["baseline_value"]
        std_dev = baseline["std_dev"]

        # Calculate deviations
        deviation = current_consumption - baseline_value
        deviation_percent = (
            (deviation / baseline_value * 100) if baseline_value > 0 else 0.0
        )
        deviation_std = (deviation / std_dev) if std_dev > 0 else 0.0

        # Determine status
        if abs(deviation_std) > 1.0:
            status = "above_baseline" if deviation > 0 else "below_baseline"
            significant = True
        else:
            status = "normal"
            significant = False

        comparison = {
            "entity_id": entity_id,
            "current_consumption": round(current_consumption, 4),
            "baseline_consumption": round(baseline_value, 4),
            "deviation": round(deviation, 4),
            "deviation_percent": round(deviation_percent, 1),
            "deviation_std": round(deviation_std, 2),
            "status": status,
            "significant": significant,
        }

        _LOGGER.debug(
            "Baseline comparison for %s: %.2f vs %.2f (%.1f%%, %s)",
            entity_id,
            current_consumption,
            baseline_value,
            deviation_percent,
            status,
        )

        return comparison

    # ========================================================================
    # UTILITY METHODS
    # ========================================================================

    async def get_sensor_count(self) -> dict[str, int]:
        """
        Get count of discovered sensors by type.

        Returns:
            Dictionary with counts for each sensor type
        """
        sensors = await self.discover_energy_sensors()
        return {
            "energy": len(sensors["energy"]),
            "power": len(sensors["power"]),
            "cost": len(sensors["cost"]),
            "total": len(sensors["energy"]) + len(sensors["power"]) + len(sensors["cost"]),
        }

    async def get_energy_sensors(self, sensor_type: str = "energy") -> list[str]:
        """
        Get list of energy sensors by type.

        Args:
            sensor_type: 'energy', 'power', or 'cost'

        Returns:
            List of entity IDs
        """
        sensors = await self.discover_energy_sensors()
        return sensors.get(sensor_type, [])

    def is_energy_sensor(self, entity_id: str) -> bool:
        """
        Check if entity is a monitored energy sensor.

        Args:
            entity_id: Entity ID to check

        Returns:
            True if entity is monitored energy sensor
        """
        return (
            entity_id in self._energy_sensors
            or entity_id in self._power_sensors
            or entity_id in self._cost_sensors
        )
