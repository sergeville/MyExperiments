"""Environmental hazard detection through multi-sensor correlation.

Epic 5: Security & Environmental Safety
Story 5.4: Multi-Sensor Environmental Hazard Correlation

Detects environmental hazards by correlating data from multiple sensors.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any, TYPE_CHECKING
from enum import Enum

from homeassistant.core import HomeAssistant, Event, callback
from homeassistant.const import EVENT_STATE_CHANGED
from homeassistant.util import dt as dt_util

from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class RiskLevel(Enum):
    """Risk level classification."""

    NORMAL = "normal"
    ADVISORY = "advisory"
    CAUTION = "caution"
    WARNING = "warning"
    URGENT = "urgent"


class HazardType(Enum):
    """Types of environmental hazards."""

    FLOOD_RISK = "flood_risk"
    PIPE_FREEZE = "pipe_freeze"
    WATER_DAMAGE = "water_damage"
    HVAC_FAILURE = "hvac_failure"
    AIR_QUALITY = "air_quality"


class EnvironmentalHazardDetector:
    """Detect environmental hazards through multi-sensor correlation.

    Monitors multiple sensors and correlates their data to detect:
    - Flood risk
    - Pipe freeze risk
    - Water damage
    - HVAC failures
    - Air quality issues
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize hazard detector.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage
        self._unsub = None

        # Initialize individual detectors
        self._flood_detector = FloodRiskDetector(hass, pattern_storage)
        self._freeze_detector = PipeFreezeDetector(hass, pattern_storage)
        self._water_damage_detector = WaterDamageDetector(hass, pattern_storage)
        self._hvac_detector = HVACFailureDetector(hass, pattern_storage)
        self._air_quality_detector = AirQualityDetector(hass, pattern_storage)

    async def async_setup(self) -> None:
        """Set up the hazard detector."""
        _LOGGER.info("Setting up environmental hazard detector")

        # Subscribe to state changes
        self._unsub = self.hass.bus.async_listen(
            EVENT_STATE_CHANGED,
            self._handle_state_change,
        )

        _LOGGER.info("Environmental hazard detector initialized")

    async def async_close(self) -> None:
        """Close the hazard detector."""
        if self._unsub:
            self._unsub()
        _LOGGER.info("Environmental hazard detector closed")

    @callback
    def _handle_state_change(self, event: Event) -> None:
        """Handle state change events.

        Args:
            event: State change event
        """
        entity_id = event.data.get("entity_id")
        new_state = event.data.get("new_state")
        old_state = event.data.get("old_state")

        if not entity_id or not new_state:
            return

        # Trigger correlation analysis for relevant sensors
        self.hass.async_create_task(
            self._analyze_correlations(entity_id, new_state, old_state)
        )

    async def _analyze_correlations(
        self,
        entity_id: str,
        new_state: Any,
        old_state: Any,
    ) -> None:
        """Analyze sensor correlations for hazards.

        Args:
            entity_id: Entity ID that changed
            new_state: New state
            old_state: Old state
        """
        try:
            # Check each hazard type
            hazards = []

            # Flood risk
            flood_result = await self._flood_detector.check_flood_risk()
            if flood_result["risk_level"] != RiskLevel.NORMAL:
                hazards.append(flood_result)

            # Pipe freeze
            freeze_result = await self._freeze_detector.check_freeze_risk()
            if freeze_result["risk_level"] != RiskLevel.NORMAL:
                hazards.append(freeze_result)

            # Water damage
            water_result = await self._water_damage_detector.check_water_damage()
            if water_result["risk_level"] != RiskLevel.NORMAL:
                hazards.append(water_result)

            # HVAC failure
            hvac_result = await self._hvac_detector.check_hvac_failure()
            if hvac_result["risk_level"] != RiskLevel.NORMAL:
                hazards.append(hvac_result)

            # Air quality
            air_result = await self._air_quality_detector.check_air_quality()
            if air_result["risk_level"] != RiskLevel.NORMAL:
                hazards.append(air_result)

            # Store and alert on detected hazards
            for hazard in hazards:
                await self._store_hazard_detection(hazard)
                self._log_hazard_alert(hazard)

        except Exception as err:
            _LOGGER.error("Error analyzing correlations: %s", err, exc_info=True)

    async def _store_hazard_detection(self, hazard: dict[str, Any]) -> None:
        """Store hazard detection to database.

        Args:
            hazard: Hazard detection data
        """
        try:
            await self._storage._db.execute(
                """
                INSERT INTO hazard_detections
                (hazard_type, risk_level, confidence, sensors_involved,
                 explanation, suggested_actions, detected_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    hazard["hazard_type"],
                    hazard["risk_level"].value,
                    hazard.get("confidence", 0.0),
                    str(hazard.get("sensors", [])),
                    hazard.get("explanation", ""),
                    str(hazard.get("actions", [])),
                    dt_util.now().isoformat(),
                ),
            )
            await self._storage._db.commit()

        except Exception as err:
            _LOGGER.error("Failed to store hazard detection: %s", err, exc_info=True)

    def _log_hazard_alert(self, hazard: dict[str, Any]) -> None:
        """Log hazard alert.

        Args:
            hazard: Hazard data
        """
        risk_level = hazard["risk_level"]
        hazard_type = hazard["hazard_type"]
        explanation = hazard.get("explanation", "Unknown")

        if risk_level == RiskLevel.URGENT:
            _LOGGER.error(
                "🚨 URGENT HAZARD: %s - %s",
                hazard_type,
                explanation,
            )
        elif risk_level == RiskLevel.WARNING:
            _LOGGER.warning(
                "⚠️  WARNING: %s - %s",
                hazard_type,
                explanation,
            )
        elif risk_level == RiskLevel.CAUTION:
            _LOGGER.warning(
                "⚡ CAUTION: %s - %s",
                hazard_type,
                explanation,
            )
        else:
            _LOGGER.info(
                "ℹ️  ADVISORY: %s - %s",
                hazard_type,
                explanation,
            )


class FloodRiskDetector:
    """Detect flood risk through sump pump + humidity + weather correlation."""

    def __init__(self, hass: HomeAssistant, storage: PatternStorage) -> None:
        """Initialize flood risk detector."""
        self.hass = hass
        self._storage = storage

    async def check_flood_risk(self) -> dict[str, Any]:
        """Check for flood risk conditions.

        Returns:
            Flood risk assessment
        """
        try:
            # Find relevant sensors
            sump_pump = self._find_sump_pump()
            basement_humidity = self._find_basement_humidity()
            weather_forecast = self._get_weather_forecast()

            # Default: no risk
            if not sump_pump and not basement_humidity:
                return {
                    "hazard_type": HazardType.FLOOD_RISK.value,
                    "risk_level": RiskLevel.NORMAL,
                    "confidence": 0.0,
                }

            risk_factors = []
            confidence = 0.0

            # Check sump pump activity
            if sump_pump:
                state = self.hass.states.get(sump_pump)
                if state and state.state == "on":
                    risk_factors.append("Sump pump actively running")
                    confidence += 0.3

                    # Check run frequency (high frequency = high risk)
                    run_frequency = await self._get_pump_run_frequency(sump_pump)
                    if run_frequency > 6:  # More than 6 times per hour
                        risk_factors.append(f"Sump pump running frequently ({run_frequency}/hr)")
                        confidence += 0.3

            # Check humidity levels
            if basement_humidity:
                state = self.hass.states.get(basement_humidity)
                if state:
                    try:
                        humidity = float(state.state)
                        if humidity > 70:
                            risk_factors.append(f"High basement humidity ({humidity}%)")
                            confidence += 0.2
                        if humidity > 80:
                            risk_factors.append(f"Critical basement humidity ({humidity}%)")
                            confidence += 0.2
                    except (ValueError, TypeError):
                        pass

            # Check weather forecast
            if weather_forecast and "heavy_rain" in weather_forecast:
                risk_factors.append("Heavy rain forecasted")
                confidence += 0.2

            # Determine risk level
            risk_level = self._calculate_risk_level(confidence)

            # Generate actions
            actions = []
            if risk_level in [RiskLevel.WARNING, RiskLevel.URGENT]:
                actions = [
                    "Monitor sump pump operation closely",
                    "Check basement for standing water",
                    "Ensure backup pump is functional",
                    "Move valuable items off basement floor",
                    "Have emergency contact numbers ready",
                ]
            elif risk_level == RiskLevel.CAUTION:
                actions = [
                    "Monitor sump pump activity",
                    "Check basement regularly",
                ]

            return {
                "hazard_type": HazardType.FLOOD_RISK.value,
                "risk_level": risk_level,
                "confidence": confidence,
                "sensors": [s for s in [sump_pump, basement_humidity] if s],
                "explanation": " | ".join(risk_factors) if risk_factors else "No flood risk",
                "actions": actions,
            }

        except Exception as err:
            _LOGGER.error("Error checking flood risk: %s", err, exc_info=True)
            return {
                "hazard_type": HazardType.FLOOD_RISK.value,
                "risk_level": RiskLevel.NORMAL,
                "confidence": 0.0,
            }

    def _find_sump_pump(self) -> str | None:
        """Find sump pump entity."""
        for entity_id in self.hass.states.async_entity_ids():
            if "sump" in entity_id.lower() and "pump" in entity_id.lower():
                return entity_id
        return None

    def _find_basement_humidity(self) -> str | None:
        """Find basement humidity sensor."""
        for entity_id in self.hass.states.async_entity_ids():
            if "basement" in entity_id.lower() and "humidity" in entity_id.lower():
                return entity_id
        return None

    def _get_weather_forecast(self) -> dict[str, Any] | None:
        """Get weather forecast data."""
        # Placeholder - would integrate with weather entity
        return None

    async def _get_pump_run_frequency(self, entity_id: str) -> int:
        """Get sump pump run frequency (runs per hour).

        Args:
            entity_id: Sump pump entity

        Returns:
            Number of runs in last hour
        """
        try:
            # Query state changes in last hour
            # This is a simplified version - would need actual history integration
            return 0
        except Exception:
            return 0

    def _calculate_risk_level(self, confidence: float) -> RiskLevel:
        """Calculate risk level from confidence score.

        Args:
            confidence: Confidence score (0.0 to 1.0)

        Returns:
            Risk level
        """
        if confidence >= 0.8:
            return RiskLevel.URGENT
        elif confidence >= 0.6:
            return RiskLevel.WARNING
        elif confidence >= 0.4:
            return RiskLevel.CAUTION
        elif confidence >= 0.2:
            return RiskLevel.ADVISORY
        else:
            return RiskLevel.NORMAL


class PipeFreezeDetector:
    """Detect pipe freeze risk through temperature monitoring."""

    def __init__(self, hass: HomeAssistant, storage: PatternStorage) -> None:
        """Initialize pipe freeze detector."""
        self.hass = hass
        self._storage = storage

    async def check_freeze_risk(self) -> dict[str, Any]:
        """Check for pipe freeze risk.

        Returns:
            Freeze risk assessment
        """
        try:
            outdoor_temp = self._get_outdoor_temperature()
            indoor_temp = self._get_indoor_temperature()
            basement_temp = self._get_basement_temperature()

            if outdoor_temp is None:
                return {
                    "hazard_type": HazardType.PIPE_FREEZE.value,
                    "risk_level": RiskLevel.NORMAL,
                    "confidence": 0.0,
                }

            risk_factors = []
            confidence = 0.0

            # Check outdoor temperature
            if outdoor_temp < 32:  # Below freezing
                risk_factors.append(f"Outdoor temp at freezing ({outdoor_temp}°F)")
                confidence += 0.3

            if outdoor_temp < 20:  # Well below freezing
                risk_factors.append(f"Outdoor temp critically low ({outdoor_temp}°F)")
                confidence += 0.3

            # Check basement/crawl space temperature
            if basement_temp is not None and basement_temp < 40:
                risk_factors.append(f"Basement temp low ({basement_temp}°F)")
                confidence += 0.4

            # Check temperature trend (falling rapidly)
            temp_trend = await self._get_temperature_trend(outdoor_temp)
            if temp_trend == "falling_rapidly":
                risk_factors.append("Temperature dropping rapidly")
                confidence += 0.2

            risk_level = self._calculate_risk_level(confidence)

            actions = []
            if risk_level in [RiskLevel.WARNING, RiskLevel.URGENT]:
                actions = [
                    "Open cabinet doors under sinks",
                    "Let faucets drip slightly",
                    "Increase heat in vulnerable areas",
                    "Insulate exposed pipes",
                    "Monitor basement temperature",
                ]
            elif risk_level == RiskLevel.CAUTION:
                actions = [
                    "Monitor outdoor temperature",
                    "Check basement/crawl space temp",
                ]

            return {
                "hazard_type": HazardType.PIPE_FREEZE.value,
                "risk_level": risk_level,
                "confidence": confidence,
                "sensors": ["outdoor_temp", "basement_temp"],
                "explanation": " | ".join(risk_factors) if risk_factors else "No freeze risk",
                "actions": actions,
            }

        except Exception as err:
            _LOGGER.error("Error checking freeze risk: %s", err, exc_info=True)
            return {
                "hazard_type": HazardType.PIPE_FREEZE.value,
                "risk_level": RiskLevel.NORMAL,
                "confidence": 0.0,
            }

    def _get_outdoor_temperature(self) -> float | None:
        """Get outdoor temperature."""
        for entity_id in self.hass.states.async_entity_ids():
            if "outdoor" in entity_id.lower() and "temp" in entity_id.lower():
                state = self.hass.states.get(entity_id)
                if state:
                    try:
                        return float(state.state)
                    except (ValueError, TypeError):
                        pass
        return None

    def _get_indoor_temperature(self) -> float | None:
        """Get indoor temperature."""
        # Find thermostat or indoor temp sensor
        return None

    def _get_basement_temperature(self) -> float | None:
        """Get basement temperature."""
        for entity_id in self.hass.states.async_entity_ids():
            if "basement" in entity_id.lower() and "temp" in entity_id.lower():
                state = self.hass.states.get(entity_id)
                if state:
                    try:
                        return float(state.state)
                    except (ValueError, TypeError):
                        pass
        return None

    async def _get_temperature_trend(self, current_temp: float) -> str:
        """Get temperature trend.

        Args:
            current_temp: Current temperature

        Returns:
            Trend: "falling_rapidly", "falling", "stable", "rising"
        """
        # Placeholder - would check historical data
        return "stable"

    def _calculate_risk_level(self, confidence: float) -> RiskLevel:
        """Calculate risk level."""
        if confidence >= 0.8:
            return RiskLevel.URGENT
        elif confidence >= 0.6:
            return RiskLevel.WARNING
        elif confidence >= 0.4:
            return RiskLevel.CAUTION
        elif confidence >= 0.2:
            return RiskLevel.ADVISORY
        else:
            return RiskLevel.NORMAL


class WaterDamageDetector:
    """Detect water damage through leak sensors + humidity + usage patterns."""

    def __init__(self, hass: HomeAssistant, storage: PatternStorage) -> None:
        """Initialize water damage detector."""
        self.hass = hass
        self._storage = storage

    async def check_water_damage(self) -> dict[str, Any]:
        """Check for water damage risk.

        Returns:
            Water damage assessment
        """
        try:
            leak_sensors = self._find_leak_sensors()
            humidity_sensors = self._find_humidity_sensors()

            risk_factors = []
            confidence = 0.0
            sensors_involved = []

            # Check leak sensors
            for sensor in leak_sensors:
                state = self.hass.states.get(sensor)
                if state and state.state in ["on", "wet", "detected"]:
                    risk_factors.append(f"Leak detected: {sensor}")
                    confidence += 0.6
                    sensors_involved.append(sensor)

            # Check humidity spikes
            for sensor in humidity_sensors:
                state = self.hass.states.get(sensor)
                if state:
                    try:
                        humidity = float(state.state)
                        if humidity > 75:
                            risk_factors.append(f"High humidity: {sensor} ({humidity}%)")
                            confidence += 0.2
                            sensors_involved.append(sensor)
                    except (ValueError, TypeError):
                        pass

            risk_level = self._calculate_risk_level(confidence)

            actions = []
            if risk_level in [RiskLevel.WARNING, RiskLevel.URGENT]:
                actions = [
                    "Shut off water main if necessary",
                    "Inspect for visible leaks",
                    "Use wet/dry vacuum for standing water",
                    "Run dehumidifiers",
                    "Contact plumber if leak source unknown",
                    "Document damage for insurance",
                ]
            elif risk_level == RiskLevel.CAUTION:
                actions = [
                    "Investigate humidity source",
                    "Check for condensation issues",
                ]

            return {
                "hazard_type": HazardType.WATER_DAMAGE.value,
                "risk_level": risk_level,
                "confidence": confidence,
                "sensors": sensors_involved,
                "explanation": " | ".join(risk_factors) if risk_factors else "No water damage detected",
                "actions": actions,
            }

        except Exception as err:
            _LOGGER.error("Error checking water damage: %s", err, exc_info=True)
            return {
                "hazard_type": HazardType.WATER_DAMAGE.value,
                "risk_level": RiskLevel.NORMAL,
                "confidence": 0.0,
            }

    def _find_leak_sensors(self) -> list[str]:
        """Find leak sensor entities."""
        sensors = []
        for entity_id in self.hass.states.async_entity_ids():
            if "leak" in entity_id.lower() or "water" in entity_id.lower():
                if "binary_sensor" in entity_id:
                    sensors.append(entity_id)
        return sensors

    def _find_humidity_sensors(self) -> list[str]:
        """Find humidity sensor entities."""
        sensors = []
        for entity_id in self.hass.states.async_entity_ids():
            if "humidity" in entity_id.lower():
                sensors.append(entity_id)
        return sensors

    def _calculate_risk_level(self, confidence: float) -> RiskLevel:
        """Calculate risk level."""
        if confidence >= 0.8:
            return RiskLevel.URGENT
        elif confidence >= 0.6:
            return RiskLevel.WARNING
        elif confidence >= 0.4:
            return RiskLevel.CAUTION
        elif confidence >= 0.2:
            return RiskLevel.ADVISORY
        else:
            return RiskLevel.NORMAL


class HVACFailureDetector:
    """Detect HVAC failure through setpoint vs actual temperature over time."""

    def __init__(self, hass: HomeAssistant, storage: PatternStorage) -> None:
        """Initialize HVAC failure detector."""
        self.hass = hass
        self._storage = storage

    async def check_hvac_failure(self) -> dict[str, Any]:
        """Check for HVAC failure.

        Returns:
            HVAC failure assessment
        """
        try:
            thermostats = self._find_thermostats()

            if not thermostats:
                return {
                    "hazard_type": HazardType.HVAC_FAILURE.value,
                    "risk_level": RiskLevel.NORMAL,
                    "confidence": 0.0,
                }

            risk_factors = []
            confidence = 0.0
            sensors_involved = []

            for thermostat in thermostats:
                state = self.hass.states.get(thermostat)
                if not state or not state.attributes:
                    continue

                setpoint = state.attributes.get("temperature")
                current_temp = state.attributes.get("current_temperature")

                if setpoint is None or current_temp is None:
                    continue

                temp_diff = abs(setpoint - current_temp)

                # Check if temp is far from setpoint
                if temp_diff > 5:
                    risk_factors.append(
                        f"{thermostat}: {temp_diff}°F from setpoint"
                    )
                    confidence += 0.3
                    sensors_involved.append(thermostat)

                # Check if HVAC is running but not effective
                hvac_action = state.attributes.get("hvac_action")
                if hvac_action in ["heating", "cooling"] and temp_diff > 3:
                    risk_factors.append(f"{thermostat}: HVAC running but ineffective")
                    confidence += 0.4
                    sensors_involved.append(thermostat)

            risk_level = self._calculate_risk_level(confidence)

            actions = []
            if risk_level in [RiskLevel.WARNING, RiskLevel.URGENT]:
                actions = [
                    "Check HVAC system operation",
                    "Inspect air filters",
                    "Verify thermostat batteries",
                    "Check circuit breakers",
                    "Contact HVAC technician if issue persists",
                ]
            elif risk_level == RiskLevel.CAUTION:
                actions = [
                    "Monitor temperature trend",
                    "Check air filter condition",
                ]

            return {
                "hazard_type": HazardType.HVAC_FAILURE.value,
                "risk_level": risk_level,
                "confidence": confidence,
                "sensors": sensors_involved,
                "explanation": " | ".join(risk_factors) if risk_factors else "HVAC operating normally",
                "actions": actions,
            }

        except Exception as err:
            _LOGGER.error("Error checking HVAC failure: %s", err, exc_info=True)
            return {
                "hazard_type": HazardType.HVAC_FAILURE.value,
                "risk_level": RiskLevel.NORMAL,
                "confidence": 0.0,
            }

    def _find_thermostats(self) -> list[str]:
        """Find thermostat entities."""
        thermostats = []
        for entity_id in self.hass.states.async_entity_ids():
            if entity_id.startswith("climate."):
                thermostats.append(entity_id)
        return thermostats

    def _calculate_risk_level(self, confidence: float) -> RiskLevel:
        """Calculate risk level."""
        if confidence >= 0.8:
            return RiskLevel.URGENT
        elif confidence >= 0.6:
            return RiskLevel.WARNING
        elif confidence >= 0.4:
            return RiskLevel.CAUTION
        elif confidence >= 0.2:
            return RiskLevel.ADVISORY
        else:
            return RiskLevel.NORMAL


class AirQualityDetector:
    """Detect air quality issues through CO2, VOC, particulates + ventilation."""

    def __init__(self, hass: HomeAssistant, storage: PatternStorage) -> None:
        """Initialize air quality detector."""
        self.hass = hass
        self._storage = storage

    async def check_air_quality(self) -> dict[str, Any]:
        """Check air quality.

        Returns:
            Air quality assessment
        """
        try:
            co2_sensors = self._find_co2_sensors()
            voc_sensors = self._find_voc_sensors()
            pm_sensors = self._find_particulate_sensors()

            risk_factors = []
            confidence = 0.0
            sensors_involved = []

            # Check CO2 levels
            for sensor in co2_sensors:
                state = self.hass.states.get(sensor)
                if state:
                    try:
                        co2 = float(state.state)
                        if co2 > 1000:
                            risk_factors.append(f"Elevated CO2: {sensor} ({co2} ppm)")
                            confidence += 0.3
                            sensors_involved.append(sensor)
                        if co2 > 2000:
                            risk_factors.append(f"High CO2: {sensor} ({co2} ppm)")
                            confidence += 0.3
                            sensors_involved.append(sensor)
                    except (ValueError, TypeError):
                        pass

            # Check VOC levels
            for sensor in voc_sensors:
                state = self.hass.states.get(sensor)
                if state:
                    try:
                        voc = float(state.state)
                        if voc > 300:
                            risk_factors.append(f"High VOC: {sensor} ({voc} ppb)")
                            confidence += 0.2
                            sensors_involved.append(sensor)
                    except (ValueError, TypeError):
                        pass

            # Check particulate matter
            for sensor in pm_sensors:
                state = self.hass.states.get(sensor)
                if state:
                    try:
                        pm = float(state.state)
                        if pm > 35:
                            risk_factors.append(f"High PM2.5: {sensor} ({pm} µg/m³)")
                            confidence += 0.3
                            sensors_involved.append(sensor)
                    except (ValueError, TypeError):
                        pass

            risk_level = self._calculate_risk_level(confidence)

            actions = []
            if risk_level in [RiskLevel.WARNING, RiskLevel.URGENT]:
                actions = [
                    "Open windows for ventilation",
                    "Run air purifier if available",
                    "Check for pollution sources",
                    "Avoid strenuous activity indoors",
                    "Consider leaving area if severe",
                ]
            elif risk_level == RiskLevel.CAUTION:
                actions = [
                    "Increase ventilation",
                    "Monitor air quality trends",
                ]

            return {
                "hazard_type": HazardType.AIR_QUALITY.value,
                "risk_level": risk_level,
                "confidence": confidence,
                "sensors": sensors_involved,
                "explanation": " | ".join(risk_factors) if risk_factors else "Air quality good",
                "actions": actions,
            }

        except Exception as err:
            _LOGGER.error("Error checking air quality: %s", err, exc_info=True)
            return {
                "hazard_type": HazardType.AIR_QUALITY.value,
                "risk_level": RiskLevel.NORMAL,
                "confidence": 0.0,
            }

    def _find_co2_sensors(self) -> list[str]:
        """Find CO2 sensor entities."""
        sensors = []
        for entity_id in self.hass.states.async_entity_ids():
            if "co2" in entity_id.lower():
                sensors.append(entity_id)
        return sensors

    def _find_voc_sensors(self) -> list[str]:
        """Find VOC sensor entities."""
        sensors = []
        for entity_id in self.hass.states.async_entity_ids():
            if "voc" in entity_id.lower() or "tvoc" in entity_id.lower():
                sensors.append(entity_id)
        return sensors

    def _find_particulate_sensors(self) -> list[str]:
        """Find particulate matter sensor entities."""
        sensors = []
        for entity_id in self.hass.states.async_entity_ids():
            if "pm25" in entity_id.lower() or "pm2_5" in entity_id.lower():
                sensors.append(entity_id)
        return sensors

    def _calculate_risk_level(self, confidence: float) -> RiskLevel:
        """Calculate risk level."""
        if confidence >= 0.8:
            return RiskLevel.URGENT
        elif confidence >= 0.6:
            return RiskLevel.WARNING
        elif confidence >= 0.4:
            return RiskLevel.CAUTION
        elif confidence >= 0.2:
            return RiskLevel.ADVISORY
        else:
            return RiskLevel.NORMAL
