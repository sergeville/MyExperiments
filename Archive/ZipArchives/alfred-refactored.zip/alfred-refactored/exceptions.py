"""Custom exceptions for Alfred Digital Butler.

This module defines a hierarchy of exceptions for better error handling
and more informative error messages throughout the integration.
"""
from __future__ import annotations


class AlfredError(Exception):
    """Base exception for all Alfred errors.
    
    All custom exceptions in Alfred should inherit from this class
    to allow catching all Alfred-related errors with a single except clause.
    """
    
    def __init__(self, message: str, details: dict | None = None):
        """Initialize the exception.
        
        Args:
            message: Human-readable error message
            details: Optional dictionary with additional error context
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}


# ============================================================================
# LLM Provider Errors
# ============================================================================

class LLMError(AlfredError):
    """Base exception for LLM-related errors."""
    pass


class LLMConnectionError(LLMError):
    """Failed to connect to LLM provider.
    
    Raised when the LLM provider (Gemini, OpenAI, Ollama) is unreachable
    or the connection times out.
    """
    pass


class LLMResponseError(LLMError):
    """Invalid or unexpected response from LLM.
    
    Raised when the LLM returns an empty response, malformed JSON,
    or content that fails validation.
    """
    pass


class LLMConfigurationError(LLMError):
    """LLM provider is not properly configured.
    
    Raised when API keys are missing, invalid, or the model
    is not available.
    """
    pass


class LLMRateLimitError(LLMError):
    """LLM provider rate limit exceeded.
    
    Raised when the LLM provider returns a rate limit error.
    """
    
    def __init__(self, message: str, retry_after: int | None = None):
        """Initialize the exception.
        
        Args:
            message: Error message
            retry_after: Seconds to wait before retrying (if provided by API)
        """
        super().__init__(message, {"retry_after": retry_after})
        self.retry_after = retry_after


# ============================================================================
# Storage Errors
# ============================================================================

class StorageError(AlfredError):
    """Base exception for storage/database errors."""
    pass


class DatabaseConnectionError(StorageError):
    """Failed to connect to the database.
    
    Raised when SQLite database file cannot be opened or created.
    """
    pass


class DatabaseMigrationError(StorageError):
    """Database schema migration failed.
    
    Raised when upgrading the database schema to a new version fails.
    """
    
    def __init__(self, message: str, from_version: int, to_version: int):
        """Initialize the exception.
        
        Args:
            message: Error message
            from_version: Schema version before migration
            to_version: Target schema version
        """
        super().__init__(
            message,
            {"from_version": from_version, "to_version": to_version}
        )
        self.from_version = from_version
        self.to_version = to_version


class DatabaseQueryError(StorageError):
    """Database query execution failed.
    
    Raised when a SQL query fails to execute.
    """
    pass


# ============================================================================
# Intelligence Engine Errors
# ============================================================================

class IntelligenceError(AlfredError):
    """Base exception for intelligence engine errors."""
    pass


class PatternAnalysisError(IntelligenceError):
    """Pattern analysis failed.
    
    Raised when pattern recognition or analysis encounters an error.
    """
    pass


class DeviceNotFoundError(IntelligenceError):
    """Device/entity not found in Home Assistant.
    
    Raised when attempting to analyze or control a non-existent entity.
    """
    
    def __init__(self, entity_id: str):
        """Initialize the exception.
        
        Args:
            entity_id: The entity ID that was not found
        """
        super().__init__(
            f"Entity not found: {entity_id}",
            {"entity_id": entity_id}
        )
        self.entity_id = entity_id


class InsufficientDataError(IntelligenceError):
    """Not enough historical data for analysis.
    
    Raised when pattern analysis requires more data than is available.
    """
    
    def __init__(self, message: str, required_days: int, available_days: int):
        """Initialize the exception.
        
        Args:
            message: Error message
            required_days: Days of data required
            available_days: Days of data available
        """
        super().__init__(
            message,
            {"required_days": required_days, "available_days": available_days}
        )
        self.required_days = required_days
        self.available_days = available_days


# ============================================================================
# Emergency Errors
# ============================================================================

class EmergencyError(AlfredError):
    """Base exception for emergency coordinator errors."""
    pass


class EmergencyAlreadyActiveError(EmergencyError):
    """Attempted to trigger emergency when one is already active.
    
    Raised when trying to start a new emergency while another is in progress.
    """
    pass


class EmergencyNotActiveError(EmergencyError):
    """Attempted to resolve emergency when none is active.
    
    Raised when trying to resolve an emergency that doesn't exist.
    """
    pass


class EmergencyActionFailedError(EmergencyError):
    """Emergency response action failed to execute.
    
    Raised when an automated emergency action (e.g., unlock doors) fails.
    """
    
    def __init__(self, message: str, action: str, entity_id: str | None = None):
        """Initialize the exception.
        
        Args:
            message: Error message
            action: The action that failed (e.g., 'unlock_doors')
            entity_id: The entity involved, if applicable
        """
        super().__init__(
            message,
            {"action": action, "entity_id": entity_id}
        )
        self.action = action
        self.entity_id = entity_id


# ============================================================================
# Configuration Errors
# ============================================================================

class ConfigurationError(AlfredError):
    """Base exception for configuration errors."""
    pass


class InvalidAPIKeyError(ConfigurationError):
    """API key is invalid or expired.
    
    Raised during config flow when API key validation fails.
    """
    
    def __init__(self, provider: str):
        """Initialize the exception.
        
        Args:
            provider: The LLM provider (gemini, openai, ollama)
        """
        super().__init__(
            f"Invalid API key for {provider}",
            {"provider": provider}
        )
        self.provider = provider


class MissingConfigurationError(ConfigurationError):
    """Required configuration is missing.
    
    Raised when a required configuration option is not set.
    """
    
    def __init__(self, config_key: str):
        """Initialize the exception.
        
        Args:
            config_key: The missing configuration key
        """
        super().__init__(
            f"Missing required configuration: {config_key}",
            {"config_key": config_key}
        )
        self.config_key = config_key


# ============================================================================
# Service Errors
# ============================================================================

class ServiceError(AlfredError):
    """Base exception for service call errors."""
    pass


class ServiceRateLimitError(ServiceError):
    """Service rate limit exceeded.
    
    Raised when a user exceeds the allowed number of service calls.
    """
    
    def __init__(self, user_id: str, limit: int):
        """Initialize the exception.
        
        Args:
            user_id: The user who exceeded the limit
            limit: The rate limit that was exceeded
        """
        super().__init__(
            f"Rate limit exceeded. Maximum {limit} calls per minute.",
            {"user_id": user_id, "limit": limit}
        )
        self.user_id = user_id
        self.limit = limit


class ComponentNotInitializedError(ServiceError):
    """Required component is not initialized.
    
    Raised when a service requires a component that hasn't been set up.
    """
    
    def __init__(self, component_name: str):
        """Initialize the exception.
        
        Args:
            component_name: Name of the uninitialized component
        """
        super().__init__(
            f"{component_name} not initialized",
            {"component_name": component_name}
        )
        self.component_name = component_name
