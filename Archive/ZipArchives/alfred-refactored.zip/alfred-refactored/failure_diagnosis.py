"""AI-powered failure diagnosis engine for Alfred Digital Butler - Epic 3 Story 3.4."""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.config_entries import ConfigEntry
from homeassistant.util import dt as dt_util

from .const import (
    CONF_AI_PROVIDER,
    CONF_API_KEY,
    CONF_MODEL,
    AI_PROVIDER_GEMINI,
    AI_PROVIDER_OPENAI,
    AI_PROVIDER_OLLAMA,
    DEFAULT_MODEL_GEMINI,
    DEFAULT_MODEL_OPENAI,
)
from .degradation_detector import DegradationReport
from .diagnosis_context_builder import DiagnosisContextBuilder
from .performance_metrics import PerformanceMetricsCollector
from .baseline_calculator import BaselineCalculator
from .runtime_tracker import RuntimeTracker
from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)

# Diagnosis timeout
DIAGNOSIS_TIMEOUT = 30.0  # 30 seconds max


class DiagnosisError(Exception):
    """Exception raised when diagnosis fails."""
    pass


@dataclass
class DiagnosisResult:
    """AI-generated diagnosis result."""

    entity_id: str
    diagnosis_date: datetime
    primary_cause: str
    confidence_percentage: int
    supporting_evidence: list[str]
    alternative_hypotheses: list[dict[str, Any]]
    severity_assessment: str  # immediate, urgent, monitor
    recommendations: dict[str, Any]
    estimated_timeline: str | None
    estimated_cost: dict[str, str] | None

    # Metadata
    degradation_report_id: int | None
    llm_provider: str
    llm_model: str
    tokens_used: int | None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage."""
        data = asdict(self)
        data["diagnosis_date"] = self.diagnosis_date.isoformat()
        return data


class LLMDiagnosticClient:
    """Abstraction layer for LLM providers."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """
        Initialize LLM diagnostic client.

        Args:
            hass: Home Assistant instance
            entry: Config entry with AI provider configuration
        """
        self.hass = hass
        self.entry = entry
        self._client = None
        self._provider = entry.data.get(CONF_AI_PROVIDER)
        self._model = entry.data.get(CONF_MODEL)
        self._api_key = entry.data.get(CONF_API_KEY)

    async def async_setup(self) -> None:
        """Initialize LLM client based on provider."""
        _LOGGER.info("Setting up LLM diagnostic client for %s", self._provider)

        if self._provider == AI_PROVIDER_GEMINI:
            import google.generativeai as genai

            genai.configure(api_key=self._api_key)
            model_name = self._model or DEFAULT_MODEL_GEMINI

            # Remove 'models/' prefix if present
            if model_name.startswith('models/'):
                model_name = model_name.replace('models/', '')

            self._client = genai.GenerativeModel(
                model_name=model_name,
                system_instruction=self._get_diagnostic_system_prompt(),
                generation_config={
                    "temperature": 0.3,  # Lower temperature for more consistent technical analysis
                    "top_p": 0.95,
                    "max_output_tokens": 2048,
                }
            )
            _LOGGER.info("LLM diagnostic client initialized with Gemini: %s", model_name)

        elif self._provider == AI_PROVIDER_OPENAI:
            from openai import AsyncOpenAI

            self._client = AsyncOpenAI(api_key=self._api_key)
            self._model = self._model or DEFAULT_MODEL_OPENAI
            _LOGGER.info("LLM diagnostic client initialized with OpenAI: %s", self._model)

        elif self._provider == AI_PROVIDER_OLLAMA:
            # For Ollama, we use HTTP client
            self._ollama_url = "http://host.docker.internal:11434"
            self._model = self._model or "llama3.2:3b"
            _LOGGER.info(
                "LLM diagnostic client initialized with Ollama: %s at %s",
                self._model,
                self._ollama_url
            )

    async def diagnose(self, context: dict[str, Any]) -> dict[str, Any]:
        """
        Generate diagnosis using LLM.

        Args:
            context: Comprehensive context dictionary from DiagnosisContextBuilder

        Returns:
            Structured diagnosis result dictionary

        Raises:
            DiagnosisError: If diagnosis fails
        """
        prompt = self._build_diagnosis_prompt(context)

        try:
            if self._provider == AI_PROVIDER_GEMINI:
                response = await self._diagnose_with_gemini(prompt)
            elif self._provider == AI_PROVIDER_OPENAI:
                response = await self._diagnose_with_openai(prompt)
            elif self._provider == AI_PROVIDER_OLLAMA:
                response = await self._diagnose_with_ollama(prompt)
            else:
                raise DiagnosisError(f"Unsupported AI provider: {self._provider}")

            return self._parse_diagnosis_response(response)

        except Exception as err:
            _LOGGER.error("LLM diagnosis failed: %s", err, exc_info=True)
            raise DiagnosisError(f"LLM diagnosis failed: {err}") from err

    async def _diagnose_with_gemini(self, prompt: str) -> str:
        """
        Generate diagnosis using Google Gemini.

        Args:
            prompt: Diagnosis prompt

        Returns:
            Raw LLM response text
        """
        try:
            response = await asyncio.wait_for(
                asyncio.to_thread(self._client.generate_content, prompt),
                timeout=DIAGNOSIS_TIMEOUT
            )

            return response.text

        except asyncio.TimeoutError as err:
            raise DiagnosisError("Gemini diagnosis timed out after 30 seconds") from err
        except Exception as err:
            raise DiagnosisError(f"Gemini API error: {err}") from err

    async def _diagnose_with_openai(self, prompt: str) -> str:
        """
        Generate diagnosis using OpenAI.

        Args:
            prompt: Diagnosis prompt

        Returns:
            Raw LLM response text
        """
        try:
            response = await asyncio.wait_for(
                self._client.chat.completions.create(
                    model=self._model,
                    messages=[
                        {
                            "role": "system",
                            "content": self._get_diagnostic_system_prompt()
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=0.3,
                    max_tokens=2048,
                ),
                timeout=DIAGNOSIS_TIMEOUT
            )

            return response.choices[0].message.content

        except asyncio.TimeoutError as err:
            raise DiagnosisError("OpenAI diagnosis timed out after 30 seconds") from err
        except Exception as err:
            raise DiagnosisError(f"OpenAI API error: {err}") from err

    async def _diagnose_with_ollama(self, prompt: str) -> str:
        """
        Generate diagnosis using Ollama.

        Args:
            prompt: Diagnosis prompt

        Returns:
            Raw LLM response text
        """
        try:
            import aiohttp

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self._ollama_url}/api/generate",
                    json={
                        "model": self._model,
                        "prompt": f"{self._get_diagnostic_system_prompt()}\n\n{prompt}",
                        "stream": False,
                        "options": {
                            "temperature": 0.3,
                            "num_predict": 2048,
                        }
                    },
                    timeout=aiohttp.ClientTimeout(total=DIAGNOSIS_TIMEOUT)
                ) as response:
                    result = await response.json()
                    return result["response"]

        except asyncio.TimeoutError as err:
            raise DiagnosisError("Ollama diagnosis timed out after 30 seconds") from err
        except Exception as err:
            raise DiagnosisError(f"Ollama API error: {err}") from err

    def _get_diagnostic_system_prompt(self) -> str:
        """
        Get system prompt for technical diagnosis.

        Returns:
            System prompt string
        """
        return """You are a technical diagnostic expert specializing in home automation devices and IoT systems. Your role is to analyze device performance data, identify root causes of failures, and provide actionable recommendations.

DIAGNOSTIC APPROACH:
1. Analyze all provided performance data and symptoms
2. Consider multiple hypotheses ranked by likelihood
3. Support each hypothesis with specific evidence from the data
4. Provide confidence scores based on data quality and symptom clarity
5. Recommend specific actions: DIY fixes, professional service, or replacement

OUTPUT FORMAT:
Return ONLY valid JSON with this exact structure (no markdown, no extra text):
{
  "primary_cause": "Most likely root cause description",
  "confidence_percentage": 85,
  "supporting_evidence": [
    "Evidence point 1 from data",
    "Evidence point 2 from data"
  ],
  "alternative_hypotheses": [
    {
      "cause": "Alternative explanation",
      "confidence": 40,
      "evidence": ["Supporting data"]
    }
  ],
  "severity_assessment": "immediate|urgent|monitor",
  "recommendations": {
    "diy_steps": ["Step 1", "Step 2"],
    "professional_service": "Description if needed",
    "replacement_consideration": "When to consider replacement"
  },
  "estimated_timeline": "How soon to address (e.g., '24-48 hours', '1-2 weeks')",
  "estimated_cost": {
    "diy": "Cost range for DIY approach",
    "professional": "Cost range for professional service",
    "replacement": "Cost range for replacement"
  }
}

CONFIDENCE SCORING GUIDELINES:
- 90-100%: Clear pattern, strong data support, common failure mode
- 70-89%: Good evidence, logical conclusion, some uncertainty
- 50-69%: Plausible hypothesis, limited evidence
- Below 50%: Speculative, insufficient data

SEVERITY ASSESSMENT:
- immediate: Device failed or will fail within 24 hours
- urgent: Significant degradation, address within 1 week
- monitor: Minor issue, watch for further degradation

TONE: Professional, technical, concise. Focus on actionable insights."""

    def _build_diagnosis_prompt(self, context: dict[str, Any]) -> str:
        """
        Build comprehensive diagnosis prompt from context.

        Args:
            context: Context dictionary from DiagnosisContextBuilder

        Returns:
            Formatted diagnosis prompt
        """
        device = context.get("device", {})
        symptoms = context.get("current_symptoms", {})
        baseline = context.get("baseline", {})
        runtime = context.get("runtime", {})
        history = context.get("performance_history", [])
        environment = context.get("environment", {})
        power = context.get("power_quality", {})

        prompt = f"""DEVICE FAILURE DIAGNOSIS REQUEST

DEVICE INFORMATION:
- Name: {device.get('friendly_name', 'Unknown')}
- Type: {device.get('domain', 'unknown')} ({device.get('device_class', 'unknown')})
- Manufacturer: {device.get('manufacturer', 'unknown')}
- Model: {device.get('model', 'unknown')}
- Location: {environment.get('area', 'unknown')}

CURRENT SYMPTOMS:
- Metric: {symptoms.get('metric_name', 'unknown')}
- Issue: {symptoms.get('degradation_type', 'unknown')}
- Severity: {symptoms.get('severity', 'unknown')}
- Current Value: {symptoms.get('current_value', 0):.2f}
- Baseline Value: {symptoms.get('baseline_value', 0):.2f}
- Deviation: {symptoms.get('deviation_percentage', 0):.1%}
- Statistical Confidence: Z-score {symptoms.get('z_score', 0):.2f}
- Duration: {symptoms.get('days_degraded', 0)} days degraded
- Trend: {symptoms.get('trend_type', 'unknown')}
- Degradation Rate: {symptoms.get('degradation_rate', 0):.3f} units/day

BASELINE PERFORMANCE:
{self._format_baseline_data(baseline)}

RUNTIME STATISTICS:
{self._format_runtime_data(runtime)}

PERFORMANCE HISTORY (Last 14 Days):
{self._format_history_data(history)}

{self._format_power_data(power)}

ENVIRONMENTAL CONTEXT:
{self._format_environment_data(environment)}

TASK:
Analyze this device failure and provide a comprehensive technical diagnosis following the JSON format specified in your system instructions. Consider device type, symptoms, performance trends, and environmental factors. Provide actionable recommendations."""

        return prompt

    def _format_baseline_data(self, baseline: dict[str, Any]) -> str:
        """Format baseline data for prompt."""
        if not baseline or baseline.get("status") == "no_baseline":
            return "- No baseline data available"

        lines = []
        for metric_name, data in baseline.items():
            if isinstance(data, dict):
                lines.append(
                    f"- {metric_name}: {data.get('value', 0):.2f} "
                    f"(±{data.get('std_dev', 0):.2f}, "
                    f"{data.get('sample_count', 0)} samples over "
                    f"{data.get('observation_days', 0)} days)"
                )
        return "\n".join(lines) if lines else "- No baseline metrics"

    def _format_runtime_data(self, runtime: dict[str, Any]) -> str:
        """Format runtime data for prompt."""
        if not runtime or runtime.get("status") == "no_runtime_tracking":
            return "- No runtime tracking data available"

        return f"""- Total Runtime: {runtime.get('total_runtime_hours', 0):.1f} hours
- Runtime Since Baseline: {runtime.get('runtime_since_baseline', 0):.1f} hours
- On/Off Cycles: {runtime.get('on_cycles_count', 0)} cycles
- Average Cycle Duration: {runtime.get('average_cycle_duration', 0):.2f} hours
- Cycles Per Day: {runtime.get('cycles_per_day', 0):.1f}
- Current State: {runtime.get('current_state', 'unknown')}"""

    def _format_history_data(self, history: list[dict[str, Any]]) -> str:
        """Format performance history for prompt."""
        if not history:
            return "- No historical data available"

        lines = ["Date | Value | Std Dev"]
        lines.append("-" * 40)

        for record in history[:7]:  # Show last 7 days
            date = record.get('date', 'unknown')
            if isinstance(date, str):
                # Parse ISO date and format as YYYY-MM-DD
                try:
                    date_obj = datetime.fromisoformat(date.replace('Z', '+00:00'))
                    date = date_obj.strftime('%Y-%m-%d')
                except:
                    pass

            value = record.get('value', 0)
            std_dev = record.get('std_dev', 0)
            lines.append(f"{date} | {value:.2f} | ±{std_dev:.2f}")

        return "\n".join(lines)

    def _format_power_data(self, power: dict[str, Any]) -> str:
        """Format power quality data for prompt."""
        if not power or power.get("error"):
            return ""

        lines = ["POWER QUALITY DATA:"]
        if "current_power" in power:
            lines.append(f"- Current Power: {power['current_power']:.2f}W")
        if "current_voltage" in power:
            lines.append(f"- Voltage: {power['current_voltage']:.1f}V")
        if "current_amperage" in power:
            lines.append(f"- Current: {power['current_amperage']:.3f}A")
        if "total_energy" in power:
            lines.append(f"- Total Energy: {power['total_energy']:.2f}kWh")

        return "\n".join(lines) if len(lines) > 1 else ""

    def _format_environment_data(self, environment: dict[str, Any]) -> str:
        """Format environmental context for prompt."""
        if not environment:
            return "- No environmental data available"

        lines = []
        if "area" in environment:
            lines.append(f"- Area: {environment['area']}")
        if "time_of_day" in environment:
            lines.append(f"- Time of Day: {environment['time_of_day']}")
        if "day_of_week" in environment:
            lines.append(
                f"- Day: {environment['day_of_week']} "
                f"({'Weekend' if environment.get('is_weekend') else 'Weekday'})"
            )
        if "area_device_count" in environment:
            lines.append(f"- Devices in Area: {environment['area_device_count']}")

        return "\n".join(lines) if lines else "- No environmental context"

    def _parse_diagnosis_response(self, response: str) -> dict[str, Any]:
        """
        Parse LLM response into structured diagnosis.

        Args:
            response: Raw LLM response

        Returns:
            Parsed diagnosis dictionary

        Raises:
            DiagnosisError: If response cannot be parsed
        """
        try:
            # Remove markdown code blocks if present
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.startswith("```"):
                response = response[3:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()

            # Parse JSON
            diagnosis = json.loads(response)

            # Validate required fields
            required_fields = [
                "primary_cause",
                "confidence_percentage",
                "supporting_evidence",
                "severity_assessment",
                "recommendations",
            ]

            for field in required_fields:
                if field not in diagnosis:
                    raise DiagnosisError(f"Missing required field: {field}")

            # Validate severity assessment
            valid_severities = ["immediate", "urgent", "monitor"]
            if diagnosis["severity_assessment"] not in valid_severities:
                _LOGGER.warning(
                    "Invalid severity '%s', defaulting to 'monitor'",
                    diagnosis["severity_assessment"]
                )
                diagnosis["severity_assessment"] = "monitor"

            # Ensure confidence is an integer
            diagnosis["confidence_percentage"] = int(diagnosis["confidence_percentage"])

            return diagnosis

        except json.JSONDecodeError as err:
            _LOGGER.error("Failed to parse JSON response: %s", response)
            raise DiagnosisError(f"Invalid JSON response: {err}") from err
        except Exception as err:
            _LOGGER.error("Error parsing diagnosis response: %s", err)
            raise DiagnosisError(f"Response parsing error: {err}") from err


class FailureDiagnosisEngine:
    """AI-powered device failure diagnosis engine."""

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        metrics_collector: PerformanceMetricsCollector,
        baseline_calculator: BaselineCalculator,
        runtime_tracker: RuntimeTracker,
        pattern_storage: PatternStorage,
    ) -> None:
        """
        Initialize diagnosis engine.

        Args:
            hass: Home Assistant instance
            entry: Config entry
            metrics_collector: Performance metrics collector
            baseline_calculator: Baseline calculator
            runtime_tracker: Runtime tracker
            pattern_storage: Pattern storage for database access
        """
        self.hass = hass
        self.entry = entry
        self._metrics = metrics_collector
        self._baseline = baseline_calculator
        self._runtime = runtime_tracker
        self._storage = pattern_storage

        self._context_builder: DiagnosisContextBuilder | None = None
        self._llm_client: LLMDiagnosticClient | None = None

    async def async_setup(self) -> None:
        """Set up diagnosis engine."""
        _LOGGER.info("Setting up Alfred Failure Diagnosis Engine")

        # Initialize context builder
        self._context_builder = DiagnosisContextBuilder(
            self.hass,
            self._metrics,
            self._baseline,
            self._runtime,
            self._storage,
        )

        # Initialize LLM client
        self._llm_client = LLMDiagnosticClient(self.hass, self.entry)
        await self._llm_client.async_setup()

        _LOGGER.info("Failure diagnosis engine initialized successfully")

    async def diagnose_device_failure(
        self,
        entity_id: str,
        degradation_report: DegradationReport,
    ) -> DiagnosisResult:
        """
        Diagnose device failure using AI analysis.

        Args:
            entity_id: Entity ID to diagnose
            degradation_report: Degradation report from detector

        Returns:
            DiagnosisResult with comprehensive analysis

        Raises:
            DiagnosisError: If diagnosis fails
        """
        try:
            _LOGGER.info(
                "Starting AI diagnosis for %s (%s)",
                entity_id,
                degradation_report.degradation_type
            )

            # 1. Build comprehensive context
            context = await self._context_builder.build_diagnosis_context(
                entity_id,
                degradation_report,
            )

            # 2. Generate diagnosis using LLM
            diagnosis_data = await self._llm_client.diagnose(context)

            # 3. Create diagnosis result
            diagnosis = DiagnosisResult(
                entity_id=entity_id,
                diagnosis_date=dt_util.now(),
                primary_cause=diagnosis_data["primary_cause"],
                confidence_percentage=diagnosis_data["confidence_percentage"],
                supporting_evidence=diagnosis_data["supporting_evidence"],
                alternative_hypotheses=diagnosis_data.get("alternative_hypotheses", []),
                severity_assessment=diagnosis_data["severity_assessment"],
                recommendations=diagnosis_data["recommendations"],
                estimated_timeline=diagnosis_data.get("estimated_timeline"),
                estimated_cost=diagnosis_data.get("estimated_cost"),
                degradation_report_id=None,  # TODO: Link to degradation report
                llm_provider=self._llm_client._provider,
                llm_model=self._llm_client._model,
                tokens_used=None,  # TODO: Track token usage
            )

            # 4. Save diagnosis to database
            diagnosis_id = await self._storage.save_diagnosis(
                entity_id=diagnosis.entity_id,
                diagnosis_date=diagnosis.diagnosis_date,
                primary_cause=diagnosis.primary_cause,
                confidence_percentage=diagnosis.confidence_percentage,
                supporting_evidence=diagnosis.supporting_evidence,
                alternative_hypotheses=diagnosis.alternative_hypotheses,
                severity_assessment=diagnosis.severity_assessment,
                recommendations=diagnosis.recommendations,
                estimated_timeline=diagnosis.estimated_timeline,
                estimated_cost=diagnosis.estimated_cost,
                degradation_report_id=diagnosis.degradation_report_id,
                llm_provider=diagnosis.llm_provider,
                llm_model=diagnosis.llm_model,
                tokens_used=diagnosis.tokens_used,
            )

            _LOGGER.info(
                "Diagnosis #%d complete for %s: %s (confidence: %d%%)",
                diagnosis_id,
                entity_id,
                diagnosis.primary_cause,
                diagnosis.confidence_percentage
            )

            return diagnosis

        except Exception as err:
            _LOGGER.error(
                "Failed to diagnose %s: %s",
                entity_id,
                err,
                exc_info=True
            )
            raise DiagnosisError(f"Diagnosis failed: {err}") from err
