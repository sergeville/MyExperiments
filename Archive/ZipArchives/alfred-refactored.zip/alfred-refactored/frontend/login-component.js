import {
  LitElement,
  html,
  css,
} from "https://unpkg.com/lit-element@2.4.0/lit-element.js?module";

/**
 * LoginComponent - User authentication component
 * 
 * Features:
 * - Email/username and password input
 * - Form validation
 * - Error handling
 * - Loading states
 * - Integration with data service
 */
class LoginComponent extends LitElement {
  static get properties() {
    return {
      hass: { type: Object },
      _email: { type: String },
      _password: { type: String },
      _errors: { type: Object },
      _isLoading: { type: Boolean },
      _dataService: { type: Object },
      _redirectUri: { type: String },
    };
  }

  constructor() {
    super();
    this._email = "";
    this._password = "";
    this._errors = {};
    this._isLoading = false;
    this._dataService = null;
    this._redirectUri = null;
  }

  connectedCallback() {
    super.connectedCallback();
    const urlParams = new URLSearchParams(window.location.search);
    this._redirectUri = urlParams.get("redirect_uri");
  }

  firstUpdated() {
    // Initialize data service if not provided
    if (!this._dataService) {
      this._dataService = this._createDataService();
    }
  }

  /**
   * Create data service instance
   * This can be mocked for testing
   */
  _createDataService() {
    return {
      async authenticate(email, password) {
        // This will be replaced with actual authentication service
        // For now, return a promise that can be mocked in tests
        return new Promise((resolve, reject) => {
          // Simulate API call
          setTimeout(() => {
            if (email && password) {
              resolve({
                success: true,
                token: "mock-token",
                user: { email, name: "User" },
              });
            } else {
              reject({
                success: false,
                error: "Invalid credentials",
              });
            }
          }, 1000);
        });
      },
    };
  }

  /**
   * Validate email format
   */
  _validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Validate form inputs
   */
  _validateForm() {
    const errors = {};

    // Email validation
    if (!this._email.trim()) {
      errors.email = "Email is required";
    } else if (!this._validateEmail(this._email)) {
      errors.email = "Please enter a valid email address";
    }

    // Password validation
    if (!this._password) {
      errors.password = "Password is required";
    } else if (this._password.length < 6) {
      errors.password = "Password must be at least 6 characters";
    }

    this._errors = errors;
    return Object.keys(errors).length === 0;
  }

  /**
   * Handle email input change
   */
  _handleEmailChange(e) {
    this._email = e.target.value;
    // Clear email error when user starts typing
    if (this._errors.email) {
      this._errors = { ...this._errors, email: null };
      delete this._errors.email;
    }
  }

  /**
   * Handle password input change
   */
  _handlePasswordChange(e) {
    this._password = e.target.value;
    // Clear password error when user starts typing
    if (this._errors.password) {
      this._errors = { ...this._errors, password: null };
      delete this._errors.password;
    }
  }

  /**
   * Handle form submission
   */
  async _handleSubmit(e) {
    e.preventDefault();

    // Validate form
    if (!this._validateForm()) {
      return;
    }

    // Set loading state
    this._isLoading = true;
    this._errors = {};

    try {
      // Call authentication service
      const result = await this._dataService.authenticate(
        this._email,
        this._password
      );

      if (result.success) {
        if (this._redirectUri) {
          window.location.href = this._redirectUri;
        } else {
          // Dispatch success event
          this.dispatchEvent(
            new CustomEvent("login-success", {
              detail: {
                user: result.user,
                token: result.token,
              },
              bubbles: true,
              composed: true,
            })
          );
        }

        // Clear form
        this._email = "";
        this._password = "";
      } else {
        this._errors = {
          general: result.error || "Authentication failed",
        };
      }
    } catch (error) {
      // Handle authentication error
      this._errors = {
        general: error.error || error.message || "An error occurred during login",
      };
    } finally {
      this._isLoading = false;
    }
  }

  /**
   * Handle Enter key press
   */
  _handleKeyPress(e) {
    if (e.key === "Enter" && !this._isLoading) {
      this._handleSubmit(e);
    }
  }

  static get styles() {
    return css`
      :host {
        display: block;
        max-width: 400px;
        margin: 0 auto;
        padding: 2rem;
      }

      .login-container {
        background: var(--card-background-color, #1e1e1e);
        border-radius: 8px;
        padding: 2rem;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      }

      .login-title {
        color: var(--primary-text-color, #fff);
        font-size: 1.5rem;
        font-weight: 600;
        margin: 0 0 0.5rem 0;
        text-align: center;
      }

      .login-subtitle {
        color: var(--secondary-text-color, #aaa);
        font-size: 0.9rem;
        margin: 0 0 2rem 0;
        text-align: center;
      }

      .form-group {
        margin-bottom: 1.5rem;
      }

      .form-label {
        display: block;
        color: var(--primary-text-color, #fff);
        font-size: 0.9rem;
        font-weight: 500;
        margin-bottom: 0.5rem;
      }

      .form-input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid var(--divider-color, #444);
        border-radius: 4px;
        background: var(--input-background-color, #2a2a2a);
        color: var(--primary-text-color, #fff);
        font-size: 1rem;
        box-sizing: border-box;
        transition: border-color 0.2s;
      }

      .form-input:focus {
        outline: none;
        border-color: var(--primary-color, #03a9f4);
      }

      .form-input.error {
        border-color: var(--error-color, #f44336);
      }

      .error-message {
        color: var(--error-color, #f44336);
        font-size: 0.85rem;
        margin-top: 0.25rem;
        display: block;
      }

      .general-error {
        background: rgba(244, 67, 54, 0.1);
        border: 1px solid var(--error-color, #f44336);
        border-radius: 4px;
        padding: 0.75rem;
        margin-bottom: 1rem;
        color: var(--error-color, #f44336);
        font-size: 0.9rem;
      }

      .submit-button {
        width: 100%;
        padding: 0.75rem;
        background: var(--primary-color, #03a9f4);
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s, opacity 0.2s;
        margin-top: 1rem;
      }

      .submit-button:hover:not(:disabled) {
        background: var(--primary-color-dark, #0288d1);
      }

      .submit-button:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }

      .loading-spinner {
        display: inline-block;
        width: 16px;
        height: 16px;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 0.8s linear infinite;
        margin-right: 0.5rem;
        vertical-align: middle;
      }

      @keyframes spin {
        to {
          transform: rotate(360deg);
        }
      }
    `;
  }

  render() {
    return html`
      <div class="login-container">
        <h2 class="login-title">Sign In</h2>
        <p class="login-subtitle">Enter your credentials to continue</p>

        <form @submit=${this._handleSubmit}>
          ${this._errors.general
            ? html`<div class="general-error">${this._errors.general}</div>`
            : ""}

          <div class="form-group">
            <label class="form-label" for="email">Email</label>
            <input
              id="email"
              type="email"
              class="form-input ${this._errors.email ? "error" : ""}"
              .value=${this._email}
              @input=${this._handleEmailChange}
              @keypress=${this._handleKeyPress}
              placeholder="your.email@example.com"
              ?disabled=${this._isLoading}
              autocomplete="email"
            />
            ${this._errors.email
              ? html`<span class="error-message">${this._errors.email}</span>`
              : ""}
          </div>

          <div class="form-group">
            <label class="form-label" for="password">Password</label>
            <input
              id="password"
              type="password"
              class="form-input ${this._errors.password ? "error" : ""}"
              .value=${this._password}
              @input=${this._handlePasswordChange}
              @keypress=${this._handleKeyPress}
              placeholder="Enter your password"
              ?disabled=${this._isLoading}
              autocomplete="current-password"
            />
            ${this._errors.password
              ? html`<span class="error-message">${this._errors.password}</span>`
              : ""}
          </div>

          <button
            type="submit"
            class="submit-button"
            ?disabled=${this._isLoading || !this._email || !this._password}
          >
            ${this._isLoading
              ? html`<span class="loading-spinner"></span>`
              : ""}
            ${this._isLoading ? "Signing in..." : "Sign In"}
          </button>
        </form>
      </div>
    `;
  }
}

customElements.define("login-component", LoginComponent);

