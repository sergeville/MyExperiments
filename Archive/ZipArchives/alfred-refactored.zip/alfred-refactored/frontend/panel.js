import {
  LitElement,
  html,
  css,
} from "https://unpkg.com/lit-element@2.4.0/lit-element.js?module";

class AlfredPanel extends LitElement {
  static get properties() {
    return {
      hass: { type: Object },
      narrow: { type: Boolean },
      _messages: { type: Array },
      _inputValue: { type: String },
      _isListening: { type: Boolean },
      _alfredState: { type: String }, // 'idle', 'attentive', 'thinking', 'speaking'
      _mode: { type: String }, // 'text' or 'voice'
      _greeting: { type: String },
      _currentView: { type: String }, // 'duties', 'chat', 'systems', 'analytics', 'alerts', 'settings'
      _lastUpdated: { type: String },
      _permissionLevel: { type: Number },
      _nextMaintenance: { type: String },
      _dashboardStats: { type: Object },
      _analyticsData: { type: Object },
      _analyticsLoading: { type: Boolean },
      _notifications: { type: Array },
      _showNotifications: { type: Boolean },
      _unreadNotifications: { type: Number },
    };
  }

  constructor() {
    super();
    this._messages = [];
    this._inputValue = "";
    this._isListening = false;
    this._alfredState = "idle";
    this._mode = "text";
    this._greeting = "";
    this._currentView = "duties"; // Default: Show dashboard (Daily Duties) when accessing /alfred
    this._ttsEnabled = true; // Enable TTS by default
    this._permissionLevel = 0;
    this._nextMaintenance = "Tomorrow @ 3:00 AM";
    this._dashboardStats = {
      totalTasks: 8,
      activeTasks: 6,
      completedToday: 2,
      actionsToday: 0,
      decisionsToday: 0,
      learningPatterns: 12,
      safetyChecks: 24,
      uptime: "2 days"
    };
    this._analyticsData = null;
    this._analyticsLoading = false;
    this._notifications = [];
    this._showNotifications = false;
    this._unreadNotifications = 0;
    this._sessionId = "panel-" + Math.random().toString(36).substr(2, 9); // Unique session ID for memory
    this._lastUpdated = this._getCurrentTime();
    this._initializeTTS();
    this._loadDashboardData();
    this._checkNotifications();
  }

  _initializeTTS() {
    // Initialize Web Speech API
    if ('speechSynthesis' in window) {
      this._speechSynthesis = window.speechSynthesis;

      // Wait for voices to load
      const setVoice = () => {
        const voices = this._speechSynthesis.getVoices();
        // Try to find a British English male voice
        this._voice = voices.find(v =>
          v.lang === 'en-GB' && v.name.includes('Male')
        ) || voices.find(v =>
          v.lang === 'en-GB'
        ) || voices.find(v =>
          v.lang.startsWith('en-')
        );

        if (this._voice) {
          console.log('Alfred voice selected:', this._voice.name);
        }
      };

      // Voices might not be loaded immediately
      if (this._speechSynthesis.getVoices().length > 0) {
        setVoice();
      }
      this._speechSynthesis.onvoiceschanged = setVoice;
    } else {
      console.warn('Web Speech API not supported');
      this._ttsEnabled = false;
    }
  }

  _speak(text) {
    if (!this._ttsEnabled || !this._speechSynthesis) return;

    // Cancel any ongoing speech
    this._speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    if (this._voice) {
      utterance.voice = this._voice;
    }
    utterance.lang = 'en-GB';
    utterance.rate = 0.95; // Slightly slower for distinguished butler effect
    utterance.pitch = 0.9; // Slightly lower pitch

    utterance.onstart = () => {
      this._alfredState = "speaking";
    };

    utterance.onend = () => {
      this._alfredState = "idle";
    };

    this._speechSynthesis.speak(utterance);
  }

  static get styles() {
    return css`
      :host {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        color: #e8e8e8;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }

      .container {
        display: flex;
        flex-direction: column;
        height: 100%;
        max-width: 1200px;
        margin: 0 auto;
        width: 100%;
        padding: 20px;
        box-sizing: border-box;
      }

      /* Dashboard Layout with Sidebar */
      .dashboard-layout {
        display: flex;
        height: 100vh;
        width: 100%;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      }

      /* Sidebar */
      .sidebar {
        width: 250px;
        background: rgba(0, 0, 0, 0.3);
        border-right: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        flex-direction: column;
        padding: 20px;
        box-sizing: border-box;
      }

      .sidebar-header {
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .sidebar-title {
        font-size: 1.8em;
        font-weight: 600;
        color: #ffd700;
        margin-bottom: 5px;
      }

      .sidebar-subtitle {
        font-size: 0.9em;
        color: #a0a0a0;
      }

      .sidebar-nav {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 5px;
      }

      .nav-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 15px;
        background: transparent;
        border: none;
        border-radius: 8px;
        color: #a0a0a0;
        font-size: 1em;
        cursor: pointer;
        transition: all 0.3s ease;
        text-align: left;
        font-family: inherit;
      }

      .nav-item:hover {
        background: rgba(255, 255, 255, 0.05);
        color: #e8e8e8;
      }

      .nav-item.active {
        background: rgba(100, 149, 237, 0.2);
        color: #6495ed;
        border-left: 3px solid #6495ed;
      }

      .nav-icon {
        font-size: 1.3em;
        width: 24px;
        text-align: center;
      }

      .nav-text {
        flex: 1;
      }

      .sidebar-footer {
        display: flex;
        align-items: center;
        gap: 12px;
        padding-top: 20px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      }

      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #6495ed 0%, #4169e1 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 1.2em;
      }

      .user-info {
        flex: 1;
      }

      .user-name {
        color: #e8e8e8;
        font-weight: 500;
        font-size: 0.95em;
      }

      .user-status {
        color: #4ade80;
        font-size: 0.85em;
        margin-top: 2px;
      }

      /* Main Content */
      .main-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
        padding: 30px 40px;
        box-sizing: border-box;
      }

      .dashboard-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        flex-wrap: wrap;
        gap: 20px;
      }

      .header-left {
        flex: 1;
      }

      .header-right {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .last-updated {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        color: #a0a0a0;
        font-size: 0.9em;
      }

      .last-updated-label {
        margin-bottom: 4px;
      }

      .last-updated-time {
        color: #e8e8e8;
        font-weight: 500;
      }

      .header {
        text-align: center;
        padding: 20px;
        border-bottom: 2px solid rgba(255, 215, 0, 0.2);
      }

      .alfred-title {
        font-size: 2.5em;
        font-weight: 300;
        margin: 0;
        color: #ffd700;
        letter-spacing: 2px;
      }

      .alfred-subtitle {
        font-size: 1em;
        color: #a0a0a0;
        margin: 10px 0 0 0;
        font-style: italic;
      }

      .mode-selector {
        display: flex;
        justify-content: center;
        gap: 20px;
        margin: 20px 0;
      }

      .mode-button {
        padding: 15px 30px;
        background: rgba(255, 255, 255, 0.1);
        border: 2px solid rgba(255, 215, 0, 0.3);
        border-radius: 10px;
        color: #e8e8e8;
        font-size: 1.1em;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .mode-button:hover {
        background: rgba(255, 255, 255, 0.2);
        border-color: rgba(255, 215, 0, 0.6);
        transform: translateY(-2px);
      }

      .mode-button.active {
        background: rgba(255, 215, 0, 0.2);
        border-color: #ffd700;
      }

      .alfred-avatar {
        width: 120px;
        height: 120px;
        margin: 20px auto;
        border-radius: 50%;
        background: linear-gradient(135deg, #2a2a3e 0%, #3a3a5e 100%);
        border: 3px solid #ffd700;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3em;
        transition: all 0.3s ease;
        box-shadow: 0 0 20px rgba(255, 215, 0, 0.3);
      }

      .alfred-avatar.idle {
        opacity: 0.7;
      }

      .alfred-avatar.attentive {
        opacity: 1;
        transform: scale(1.05);
        box-shadow: 0 0 30px rgba(255, 215, 0, 0.6);
        animation: pulse 2s ease-in-out infinite;
      }

      .alfred-avatar.thinking {
        animation: gentle-bob 1.5s ease-in-out infinite;
      }

      .alfred-avatar.speaking {
        animation: butler-bow 0.8s ease-in-out infinite;
        box-shadow: 0 0 40px rgba(255, 215, 0, 0.8);
      }

      .alfred-avatar svg {
        width: 90%;
        height: 90%;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
      }

      @keyframes pulse {
        0%, 100% { transform: scale(1.05); }
        50% { transform: scale(1.08); }
      }

      @keyframes gentle-bob {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-5px); }
      }

      @keyframes butler-bow {
        0%, 100% { transform: rotate(0deg) translateY(0px); }
        25% { transform: rotate(-3deg) translateY(-3px); }
        75% { transform: rotate(3deg) translateY(-3px); }
      }

      @keyframes wave {
        0%, 100% { height: 20px; }
        50% { height: 60px; }
      }

      .waveform {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        height: 60px;
        margin: 20px 0;
      }

      .waveform-bar {
        width: 4px;
        background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        border-radius: 2px;
        animation: wave 0.8s ease-in-out infinite;
      }

      .waveform-bar:nth-child(1) { animation-delay: 0s; }
      .waveform-bar:nth-child(2) { animation-delay: 0.1s; }
      .waveform-bar:nth-child(3) { animation-delay: 0.2s; }
      .waveform-bar:nth-child(4) { animation-delay: 0.3s; }
      .waveform-bar:nth-child(5) { animation-delay: 0.4s; }
      .waveform-bar:nth-child(6) { animation-delay: 0.3s; }
      .waveform-bar:nth-child(7) { animation-delay: 0.2s; }
      .waveform-bar:nth-child(8) { animation-delay: 0.1s; }
      .waveform-bar:nth-child(9) { animation-delay: 0s; }

      .greeting-message {
        text-align: center;
        font-size: 1.2em;
        color: #ffd700;
        min-height: 30px;
        margin: 10px 0;
        font-style: italic;
        opacity: 0;
        transition: opacity 0.3s ease;
      }

      .greeting-message.visible {
        opacity: 1;
      }

      .messages-container {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 15px;
      }

      .message {
        display: flex;
        gap: 10px;
        animation: slideIn 0.3s ease;
      }

      @keyframes slideIn {
        from {
          opacity: 0;
          transform: translateX(400px);
        }
        to {
          opacity: 1;
          transform: translateX(0);
        }
      }

      @keyframes slideOut {
        from {
          opacity: 1;
          transform: translateX(0);
        }
        to {
          opacity: 0;
          transform: translateX(400px);
        }
      }

      .message.user {
        justify-content: flex-end;
      }

      .message-bubble {
        max-width: 70%;
        padding: 15px 20px;
        border-radius: 15px;
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
      }

      .message.alfred .message-bubble {
        background: rgba(255, 215, 0, 0.15);
        border: 1px solid rgba(255, 215, 0, 0.3);
      }

      .message.user .message-bubble {
        background: rgba(100, 149, 237, 0.2);
        border: 1px solid rgba(100, 149, 237, 0.4);
      }

      .message-sender {
        font-weight: 600;
        margin-bottom: 5px;
        font-size: 0.9em;
        color: #ffd700;
      }

      .message.user .message-sender {
        color: #6495ed;
      }

      .message-text {
        line-height: 1.5;
        white-space: pre-wrap;
      }

      .input-container {
        padding: 20px;
        border-top: 2px solid rgba(255, 215, 0, 0.2);
        background: rgba(0, 0, 0, 0.2);
      }

      .input-wrapper {
        display: flex;
        gap: 10px;
        align-items: center;
      }

      .text-input {
        flex: 1;
        padding: 15px 20px;
        background: rgba(255, 255, 255, 0.1);
        border: 2px solid rgba(255, 215, 0, 0.3);
        border-radius: 10px;
        color: #e8e8e8;
        font-size: 1em;
        font-family: inherit;
        transition: all 0.3s ease;
      }

      .text-input:focus {
        outline: none;
        border-color: #ffd700;
        background: rgba(255, 255, 255, 0.15);
        box-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
      }

      .send-button {
        padding: 15px 30px;
        background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
        border: none;
        border-radius: 10px;
        color: #1a1a2e;
        font-size: 1em;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      .send-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);
      }

      .send-button:active {
        transform: translateY(0);
      }

      .send-button:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .voice-controls {
        text-align: center;
        padding: 20px;
      }

      .voice-button {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
        border: 3px solid #fff;
        color: white;
        font-size: 2em;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
      }

      .voice-button:hover {
        transform: scale(1.1);
        box-shadow: 0 7px 20px rgba(255, 107, 107, 0.6);
      }

      .voice-button.listening {
        animation: pulse 1.5s ease-in-out infinite;
        background: linear-gradient(135deg, #4ecdc4 0%, #44a08d 100%);
      }

      .suggestions-container {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 10px;
        justify-content: center;
      }

      .suggestion-chip {
        padding: 8px 16px;
        background: rgba(255, 215, 0, 0.1);
        border: 1px solid rgba(255, 215, 0, 0.3);
        border-radius: 20px;
        font-size: 0.9em;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      .suggestion-chip:hover {
        background: rgba(255, 215, 0, 0.2);
        border-color: rgba(255, 215, 0, 0.6);
        transform: translateY(-2px);
      }

      /* Navigation Tabs */
      .nav-tabs {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin: 20px 0;
        border-bottom: 2px solid rgba(255, 215, 0, 0.2);
        padding-bottom: 10px;
      }

      .nav-tab {
        padding: 10px 20px;
        background: transparent;
        border: none;
        border-bottom: 3px solid transparent;
        color: #a0a0a0;
        font-size: 1.1em;
        cursor: pointer;
        transition: all 0.3s ease;
      }

      .nav-tab:hover {
        color: #ffd700;
      }

      .nav-tab.active {
        color: #ffd700;
        border-bottom-color: #ffd700;
      }

      .nav-tab.nav-back {
        margin-right: auto;
        color: #ffffff;
        opacity: 0.7;
        font-size: 1em;
        padding: 10px 15px;
      }

      .nav-tab.nav-back:hover {
        opacity: 1;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 5px;
      }

      /* Mobile Responsive Styles */
      @media (max-width: 768px) {
        .dashboard-layout {
          flex-direction: column;
        }

        .sidebar {
          width: 100%;
          height: auto;
          border-right: none;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-nav {
          flex-direction: row;
          overflow-x: auto;
          gap: 10px;
        }

        .nav-item {
          white-space: nowrap;
          min-width: 100px;
        }

        .main-content {
          padding: 20px;
        }

        .dashboard-header {
          flex-direction: column;
        }

        .duties-grid {
          grid-template-columns: 1fr;
        }
        .nav-tabs {
          position: sticky;
          top: 0;
          z-index: 100;
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
          padding: 10px 5px;
          margin: 0 -20px 20px -20px;
          gap: 5px;
          flex-wrap: wrap;
        }

        .nav-tab {
          padding: 8px 12px;
          font-size: 0.9em;
          flex: 1;
          min-width: 70px;
        }

        .nav-tab.nav-back {
          flex: 0 0 auto;
          min-width: 60px;
          padding: 8px 10px;
        }

        .container {
          padding: 10px;
        }
      }

      /* Very small mobile screens */
      @media (max-width: 480px) {
        .nav-tabs {
          gap: 3px;
          padding: 8px 3px;
        }

        .nav-tab {
          padding: 6px 8px;
          font-size: 0.8em;
          min-width: 60px;
        }

        .nav-tab.nav-back {
          min-width: 50px;
          padding: 6px 8px;
        }
      }

      /* Dashboard Styles */
      .dashboard-container {
        flex: 1;
        background: transparent;
      }

      .dashboard-title {
        font-size: 2.5em;
        font-weight: 600;
        color: #e8e8e8;
        margin: 0 0 10px 0;
      }

      .dashboard-subtitle {
        font-size: 1.1em;
        color: #a0a0a0;
        margin: 0;
      }

      .status-indicator {
        background: linear-gradient(135deg, #2d8659 0%, #1e5d3f 100%);
        border: 2px solid #4ade80;
        border-radius: 15px;
        padding: 20px;
        margin: 20px auto;
        max-width: 500px;
        text-align: center;
        box-shadow: 0 0 20px rgba(74, 222, 128, 0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
      }

      .status-icon {
        font-size: 2em;
      }

      .status-text {
        font-size: 1.3em;
        font-weight: 600;
        color: #4ade80;
      }

      .status-indicator.clickable {
        cursor: pointer;
        transition: all 0.3s ease;
        border: none;
        font-family: inherit;
      }

      .status-indicator.clickable:hover {
        transform: translateY(-2px);
        box-shadow: 0 0 30px rgba(74, 222, 128, 0.5);
        background: linear-gradient(135deg, #34a068 0%, #258a4f 100%);
        border: 2px solid #5eff90;
      }

      .status-indicator.clickable:active {
        transform: translateY(0px);
      }

      .status-info {
        text-align: center;
        color: #a0a0a0;
        margin: 10px 0;
        font-size: 0.95em;
      }

      /* Dashboard Metrics */
      .dashboard-metrics {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 15px;
        margin: 30px 0;
      }

      .metric-card {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 215, 0, 0.2);
        border-radius: 12px;
        padding: 15px;
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
      }

      .metric-card:hover {
        background: rgba(255, 255, 255, 0.08);
        border-color: rgba(255, 215, 0, 0.4);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
      }

      .metric-icon {
        font-size: 2em;
        opacity: 0.8;
      }

      .metric-content {
        flex: 1;
      }

      .metric-value {
        font-size: 1.8em;
        font-weight: 700;
        color: #ffd700;
        line-height: 1.2;
      }

      .metric-label {
        font-size: 0.85em;
        color: #a0a0a0;
        margin-top: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      /* Dashboard Info Bar */
      .dashboard-info-bar {
        display: flex;
        justify-content: center;
        gap: 30px;
        margin: 20px 0;
        padding: 15px;
        background: rgba(255, 255, 255, 0.03);
        border-radius: 10px;
        border: 1px solid rgba(255, 215, 0, 0.1);
        flex-wrap: wrap;
      }

      .info-item {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #e8e8e8;
        font-size: 0.95em;
      }

      .info-label {
        color: #a0a0a0;
        font-weight: 500;
      }

      .info-value {
        color: #ffd700;
        font-weight: 600;
      }

      .duties-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 25px;
      }

      @media (min-width: 1400px) {
        .duties-grid {
          grid-template-columns: repeat(2, 1fr);
        }
      }

      .duty-card {
        background: rgba(255, 255, 255, 0.03);
        border: none;
        border-left: 4px solid;
        border-radius: 8px;
        padding: 25px;
        transition: all 0.3s ease;
        cursor: pointer;
        position: relative;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      }

      .duty-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        background: rgba(255, 255, 255, 0.05);
      }

      .duty-card.maintenance {
        border-left: 4px solid #4ade80;
      }

      .duty-card.inspections {
        border-left: 4px solid #22d3ee;
      }

      .duty-card.operations {
        border-left: 4px solid #fbbf24;
      }

      .duty-card.learning {
        border-left: 4px solid #fbbf24;
      }

      .duty-card.safety {
        border-left: 4px solid #ef4444;
      }

      .duty-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
      }

      .duty-icon {
        font-size: 1.8em;
      }

      .duty-title {
        font-size: 1.2em;
        font-weight: 600;
        color: #e8e8e8;
        letter-spacing: 0.5px;
      }

      .duty-duties {
        list-style: none;
        padding: 0;
        margin: 0;
      }

      .duty-duties li {
        padding: 10px 0;
        color: #a0a0a0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        font-size: 0.95em;
        line-height: 1.5;
      }

      .duty-duties li:last-child {
        border-bottom: none;
      }

      .duty-duties li::before {
        content: "";
        display: none;
      }
    `;
  }

  _getCurrentTime() {
    const now = new Date();
    const options = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    };
    return now.toLocaleDateString('en-US', options);
  }

  async _loadDashboardData() {
    // Load dashboard data from Home Assistant
    try {
      // Try to get permission level from a sensor or config
      // For now, default to 0
      this._permissionLevel = 0;
      
      // Calculate next maintenance time
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(3, 0, 0, 0);
      
      if (tomorrow < now) {
        tomorrow.setDate(tomorrow.getDate() + 1);
      }
      
      const hours = tomorrow.getHours();
      const minutes = tomorrow.getMinutes();
      this._nextMaintenance = `Tomorrow @ ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      
      // Update last updated time
      this._lastUpdated = this._getCurrentTime();

      // Try to load real data from Home Assistant if available
      if (this.hass && this.hass.callWS) {
        try {
          // Could fetch real stats here in the future
          // const stats = await this.hass.callWS({ type: "alfred/get_stats" });
        } catch (error) {
          // Silently fail - use default values
          console.debug('Alfred panel: Could not load stats from HA:', error);
        }
      }
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    }
  }

  async _loadAnalyticsData() {
    // Load analytics data from Alfred's intelligence engine
    if (!this.hass) {
      console.warn("Cannot load analytics: hass not available");
      return;
    }

    this._analyticsLoading = true;
    this.requestUpdate();

    try {
      // Call the analytics API endpoint
      const response = await fetch('/api/alfred/analytics', {
        headers: {
          'Authorization': `Bearer ${this.hass.auth.data.access_token}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Analytics API returned ${response.status}`);
      }

      this._analyticsData = await response.json();
      this._lastUpdated = this._getCurrentTime();
      console.log('Analytics data loaded:', this._analyticsData);

      // Check for new notifications based on analytics data
      this._processNotifications(this._analyticsData);

    } catch (error) {
      console.error('Error loading analytics data:', error);
      // Set default empty data on error
      this._analyticsData = {
        patterns: { total_patterns: 0, patterns: [] },
        device_health: { total_devices_monitored: 0, active_alerts: 0, alerts: [] },
        energy: { available: false },
        battery: { available: false },
        security: { available: false },
        error: error.message,
      };
    } finally {
      this._analyticsLoading = false;
      this.requestUpdate();
    }
  }

  _checkNotifications() {
    // Auto-check for notifications every 30 seconds
    setInterval(() => {
      if (this.hass && this._analyticsData) {
        this._loadAnalyticsData();
      }
    }, 30000);
  }

  _processNotifications(data) {
    // Process analytics data and create notifications for important events
    const newNotifications = [];
    const now = new Date();

    // Check for device health alerts
    if (data.device_health && data.device_health.active_alerts > 0) {
      data.device_health.alerts.forEach(alert => {
        newNotifications.push({
          id: `alert_${alert.entity_id}_${Date.now()}`,
          type: 'alert',
          severity: alert.severity,
          title: 'Device Health Alert',
          message: `${alert.entity_id.split('.')[1]}: ${alert.degradation_type}`,
          timestamp: now,
          read: false,
        });
      });
    }

    // Check for low batteries
    if (data.battery && data.battery.low_batteries > 0) {
      data.battery.low_battery_list.forEach(battery => {
        if (battery.level < 15) {
          newNotifications.push({
            id: `battery_${battery.entity_id}_${Date.now()}`,
            type: 'warning',
            severity: 'medium',
            title: 'Low Battery',
            message: `${battery.name}: ${battery.level}% - Replace soon`,
            timestamp: now,
            read: false,
          });
        }
      });
    }

    // Check for new patterns (only show if more than 3)
    if (data.patterns && data.patterns.total_patterns > 3) {
      const hasNewPatterns = !this._lastPatternCount || data.patterns.total_patterns > this._lastPatternCount;
      if (hasNewPatterns) {
        newNotifications.push({
          id: `pattern_${Date.now()}`,
          type: 'info',
          severity: 'low',
          title: 'New Pattern Detected',
          message: `${data.patterns.total_patterns} patterns discovered`,
          timestamp: now,
          read: false,
        });
      }
      this._lastPatternCount = data.patterns.total_patterns;
    }

    // Add new notifications and show popup for new ones
    if (newNotifications.length > 0) {
      // Only add truly new notifications (check if ID exists)
      const uniqueNew = newNotifications.filter(n =>
        !this._notifications.some(existing => existing.id === n.id)
      );

      if (uniqueNew.length > 0) {
        this._notifications = [...uniqueNew, ...this._notifications].slice(0, 20); // Keep last 20
        this._unreadNotifications = this._notifications.filter(n => !n.read).length;

        // Show toast for the first new notification
        this._showToast(uniqueNew[0]);

        this.requestUpdate();
      }
    }
  }

  _showToast(notification) {
    // Create a toast popup that auto-dismisses
    const toast = document.createElement('div');
    toast.className = 'notification-toast';
    toast.style.cssText = `
      position: fixed;
      top: 80px;
      right: 20px;
      background: ${notification.severity === 'high' ? '#ef4444' : notification.severity === 'medium' ? '#f59e0b' : '#3b82f6'};
      color: white;
      padding: 16px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 10000;
      min-width: 300px;
      animation: slideIn 0.3s ease-out;
    `;

    toast.innerHTML = `
      <div style="font-weight: 600; margin-bottom: 4px;">${notification.title}</div>
      <div style="font-size: 14px;">${notification.message}</div>
    `;

    this.shadowRoot.appendChild(toast);

    // Alfred speaks the notification
    if (this._ttsEnabled) {
      const spokenMessage = this._formatNotificationForSpeech(notification);
      this._speak(spokenMessage);
    }

    // Auto-dismiss after 5 seconds
    setTimeout(() => {
      toast.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => toast.remove(), 300);
    }, 5000);
  }

  _formatNotificationForSpeech(notification) {
    // Format notification for natural speech
    const introductions = {
      'alert': 'Pardon me, there is an alert:',
      'warning': 'I must inform you:',
      'info': 'Good news:'
    };

    const intro = introductions[notification.type] || 'Attention:';
    return `${intro} ${notification.message}`;
  }

  _speakWelcome() {
    // Alfred introduces the analytics dashboard
    const greeting = "Good day. Welcome to the Intelligence Analytics dashboard. I am monitoring your home systems and will notify you of any important updates.";
    this._speak(greeting);
  }

  _toggleNotifications() {
    this._showNotifications = !this._showNotifications;
    if (this._showNotifications) {
      // Mark all as read when opening
      this._notifications = this._notifications.map(n => ({...n, read: true}));
      this._unreadNotifications = 0;
    }
    this.requestUpdate();
  }

  _clearNotifications() {
    this._notifications = [];
    this._unreadNotifications = 0;
    this._showNotifications = false;
    this.requestUpdate();
  }

  _switchView(view) {
    this._currentView = view;

    // Load analytics data when switching to analytics view
    if (view === 'analytics' && !this._analyticsData) {
      this._loadAnalyticsData();
    }
  }

  _navigateBack() {
    // Navigate back to Home Assistant dashboard
    if (window.history.length > 1) {
      window.history.back();
    } else {
      // Fallback: go to default dashboard
      window.location.href = '/lovelace/0';
    }
  }

  connectedCallback() {
    super.connectedCallback();
    // Wait for hass to be available before subscribing
    if (this.hass && this.hass.connection) {
      this._subscribeToEvents();
    }
  }

  updated(changedProperties) {
    super.updated(changedProperties);
    // Re-subscribe when hass becomes available or changes
    if (changedProperties.has('hass') && this.hass && this.hass.connection) {
      this._subscribeToEvents();
    }
  }

  _subscribeToEvents() {
    // Subscribe to Alfred's events only if hass and connection are available
    if (!this.hass || !this.hass.connection) {
      console.warn('Alfred panel: hass or connection not available yet');
      return;
    }

    try {
      if (this.hass.connection.subscribeEvents) {
        this.hass.connection.subscribeEvents((event) => {
          this._handleAlfredSuggestion(event);
        }, "alfred_suggestion");

        this.hass.connection.subscribeEvents((event) => {
          this._handleAlfredAlert(event);
        }, "alfred_alert");

        this.hass.connection.subscribeEvents((event) => {
          this._handleUserTyping(event);
        }, "alfred_user_typing");
      }
    } catch (error) {
      console.error('Alfred panel: Error subscribing to events:', error);
    }
  }

  _handleAlfredSuggestion(event) {
    const { title, message } = event.data;
    this._addMessage("alfred", `${title}: ${message}`);
  }

  _handleAlfredAlert(event) {
    const { title, message } = event.data;
    this._addMessage("alfred", `⚠️ ${title}: ${message}`);
  }

  _handleUserTyping(event) {
    const { greeting } = event.data;
    this._greeting = greeting;
    this._alfredState = "attentive";
  }

  _handleInputFocus() {
    // User focused on input - Alfred becomes attentive
    this._alfredState = "attentive";
    this._greeting = this._getContextualGreeting();

    // Call service to notify Alfred (only if hass is available)
    if (this.hass && this.hass.callService) {
      try {
        this.hass.callService("alfred", "start_conversation", {});
      } catch (error) {
        console.error('Alfred panel: Error calling service:', error);
      }
    }
  }

  _getContextualGreeting() {
    const hour = new Date().getHours();
    let timeGreeting;

    if (hour < 12) {
      timeGreeting = "Good morning";
    } else if (hour < 17) {
      timeGreeting = "Good afternoon";
    } else {
      timeGreeting = "Good evening";
    }

    return `${timeGreeting}, sir. I'm listening.`;
  }

  _handleInputBlur() {
    // If no message typed, return to idle after a delay
    if (!this._inputValue) {
      setTimeout(() => {
        if (!this._inputValue) {
          this._alfredState = "idle";
          this._greeting = "";
        }
      }, 3000);
    }
  }

  _handleInputChange(e) {
    this._inputValue = e.target.value;
  }

  async _handleSendMessage() {
    if (!this._inputValue.trim()) return;

    const message = this._inputValue.trim();
    this._addMessage("user", message);
    this._inputValue = "";

    // Set Alfred to thinking
    this._alfredState = "thinking";
    this._greeting = "One moment, sir...";

    // Check if hass and callWS are available
    if (!this.hass || !this.hass.callWS) {
      console.error('Alfred panel: hass or callWS not available');
      this._addMessage("alfred", "My apologies, sir. I'm having trouble connecting to Home Assistant.");
      this._alfredState = "idle";
      this._greeting = "";
      return;
    }

    try {
      // Call Alfred's service using WebSocket API for return_response support
      const response = await this.hass.callWS({
        type: "call_service",
        domain: "alfred",
        service: "chat_with_memory",
        service_data: {
          message: message,
          session_id: this._sessionId,
        },
        return_response: true,
      });

      // Display the actual response from Alfred
      let alfredResponse = "";
      if (response && response.response && response.response.response) {
        alfredResponse = response.response.response;
      } else if (response && response.response) {
        alfredResponse = response.response;
      } else {
        alfredResponse = "Certainly, sir. I'm at your service.";
      }

      this._addMessage("alfred", alfredResponse);

      // Speak the response if TTS is enabled
      if (this._ttsEnabled) {
        this._speak(alfredResponse);
      }

      this._alfredState = "idle";
      this._greeting = "";
    } catch (error) {
      console.error("Error sending message to Alfred:", error);
      this._addMessage("alfred", "My apologies, sir. I encountered a difficulty.");
      this._alfredState = "idle";
      this._greeting = "";
    }
  }

  _handleKeyPress(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      this._handleSendMessage();
    }
  }

  _addMessage(sender, text) {
    this._messages = [
      ...this._messages,
      {
        sender,
        text,
        timestamp: new Date(),
      },
    ];

    // Scroll to bottom after a short delay
    setTimeout(() => {
      const container = this.shadowRoot.querySelector(".messages-container");
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
    }, 100);
  }

  _switchMode(mode) {
    this._mode = mode;
    this._greeting = "";
    this._alfredState = "idle";
  }

  _handleVoiceButton() {
    this._isListening = !this._isListening;

    if (this._isListening) {
      this._alfredState = "attentive";
      this._greeting = "Yes, sir?";
      // Would integrate with HA Assist here
    } else {
      this._alfredState = "idle";
      this._greeting = "";
    }
  }

  _handleSuggestion(text) {
    this._inputValue = text;
    this.shadowRoot.querySelector(".text-input").focus();
  }

  render() {
    // Default to dashboard (duties view) when accessing /alfred
    if (!this._currentView || this._currentView === "duties") {
      return this._renderDutiesView();
    } else if (this._currentView === "systems") {
      return this._renderSystemsView();
    } else if (this._currentView === "analytics") {
      return this._renderAnalyticsView();
    } else if (this._currentView === "alerts" ||
               this._currentView === "settings" || this._currentView === "profile") {
      // For now, redirect these to duties view (can be implemented later)
      return this._renderDutiesView();
    }
    return this._renderChatView();
  }

  _renderSystemsView() {
    return html`
      <div class="container">
        <!-- Navigation Tabs -->
        <div class="nav-tabs">
          <button
            class="nav-tab nav-back"
            @click=${() => this._navigateBack()}
            title="Back to Home Assistant"
          >
            ← Back
          </button>
          <button
            class="nav-tab"
            @click=${() => this._switchView("duties")}
          >
            📋 Daily Duties
          </button>
          <button
            class="nav-tab"
            @click=${() => this._switchView("chat")}
          >
            💬 Chat
          </button>
          <button
            class="nav-tab active"
            @click=${() => this._switchView("systems")}
          >
            ⚙️ Systems
          </button>
        </div>

        <div class="dashboard-container">
          <h1 class="dashboard-title">System Status</h1>

          <!-- Overall Status -->
          <div class="status-indicator">
            <div class="status-icon">✅</div>
            <div class="status-text">All Systems Operational</div>
          </div>

          <!-- Systems Grid -->
          <div class="duties-grid">
            <!-- Home Assistant Integration -->
            <div class="duty-card monitoring">
              <div class="duty-header">
                <div class="duty-icon">🏠</div>
                <div class="duty-title">HOME ASSISTANT</div>
              </div>
              <div class="duty-status" style="color: #4ade80;">✓ Connected</div>
              <ul class="duty-duties">
                <li>API connection: Active</li>
                <li>Event streaming: Enabled</li>
                <li>State sync: Real-time</li>
                <li>Service calls: Operational</li>
              </ul>
            </div>

            <!-- Conversation AI -->
            <div class="duty-card decision">
              <div class="duty-header">
                <div class="duty-icon">🤖</div>
                <div class="duty-title">CONVERSATION AI</div>
              </div>
              <div class="duty-status" style="color: #4ade80;">✓ Ready</div>
              <ul class="duty-duties">
                <li>LLM provider: Connected</li>
                <li>Intent detection: Active</li>
                <li>Action execution: Enabled</li>
                <li>Response generation: Operational</li>
              </ul>
            </div>

            <!-- Database -->
            <div class="duty-card learning">
              <div class="duty-header">
                <div class="duty-icon">💾</div>
                <div class="duty-title">DATABASE</div>
              </div>
              <div class="duty-status" style="color: #4ade80;">✓ Healthy</div>
              <ul class="duty-duties">
                <li>SQLite connection: Active</li>
                <li>Schema version: Latest</li>
                <li>Data integrity: Verified</li>
                <li>Backup status: Current</li>
              </ul>
            </div>

            <!-- Safety Systems -->
            <div class="duty-card maintenance">
              <div class="duty-header">
                <div class="duty-icon">🛡️</div>
                <div class="duty-title">SAFETY SYSTEMS</div>
              </div>
              <div class="duty-status" style="color: #4ade80;">✓ Armed</div>
              <ul class="duty-duties">
                <li>Permission level: ${this._permissionLevel} (OBSERVE)</li>
                <li>Risk assessment: Active</li>
                <li>Approval workflow: Standby</li>
                <li>Rollback capability: Ready</li>
              </ul>
            </div>

            <!-- Monitoring -->
            <div class="duty-card monitoring">
              <div class="duty-header">
                <div class="duty-icon">📊</div>
                <div class="duty-title">MONITORING</div>
              </div>
              <div class="duty-status" style="color: #4ade80;">✓ Active</div>
              <ul class="duty-duties">
                <li>Device tracking: All entities</li>
                <li>Pattern recognition: Learning</li>
                <li>Anomaly detection: Enabled</li>
                <li>Performance metrics: Logging</li>
              </ul>
            </div>

            <!-- Maintenance -->
            <div class="duty-card rollback">
              <div class="duty-header">
                <div class="duty-icon">🔧</div>
                <div class="duty-title">MAINTENANCE</div>
              </div>
              <div class="duty-status" style="color: #4ade80;">✓ Scheduled</div>
              <ul class="duty-duties">
                <li>Next run: ${this._nextMaintenance}</li>
                <li>Docker cleanup: Configured</li>
                <li>Log rotation: Enabled</li>
                <li>Health checks: Passing</li>
              </ul>
            </div>
          </div>

          <!-- System Info -->
          <div class="status-info" style="margin-top: 30px; padding: 20px; background: rgba(255,255,255,0.05); border-radius: 10px;">
            <div style="margin-bottom: 10px;"><strong>Version:</strong> Alfred v0.2.4</div>
            <div style="margin-bottom: 10px;"><strong>Uptime:</strong> Since last HA restart</div>
            <div style="margin-bottom: 10px;"><strong>Performance:</strong> All metrics nominal</div>
            <div><strong>Last Check:</strong> Just now</div>
          </div>
        </div>
      </div>
    `;
  }

  _renderAnalyticsView() {
    return html`
      <div class="dashboard-layout">
        <!-- Left Sidebar -->
        <div class="sidebar">
          <div class="sidebar-header">
            <div class="sidebar-title">Alfred</div>
            <div class="sidebar-subtitle">Intelligence Analytics</div>
          </div>

          <nav class="sidebar-nav">
            <button
              class="nav-item"
              @click=${() => this._switchView("duties")}
            >
              <span class="nav-icon">🏠</span>
              <span class="nav-text">Dashboard</span>
            </button>
            <button
              class="nav-item active"
              @click=${() => this._switchView("analytics")}
            >
              <span class="nav-icon">📊</span>
              <span class="nav-text">Analytics</span>
            </button>
            <button
              class="nav-item"
              @click=${() => this._switchView("chat")}
            >
              <span class="nav-icon">💬</span>
              <span class="nav-text">Chat</span>
            </button>
          </nav>

          <div class="sidebar-footer">
            <div class="user-avatar">A</div>
            <div class="user-info">
              <div class="user-name">Alfred AI</div>
              ${this._alfredState === "speaking" ? html`
                <div class="waveform">
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                </div>
              ` : html`
                <div class="user-status">Online</div>
              `}
            </div>
          </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
          <div class="dashboard-header">
            <div class="header-left">
              <h1 class="dashboard-title">Intelligence Analytics</h1>
              <p class="dashboard-subtitle">Real-time insights from Alfred's intelligence engine</p>
            </div>
            <div class="header-right">
              <button
                class="speaker-button"
                @click=${() => this._speakWelcome()}
                title="Hear Alfred speak"
                style="padding: 10px 16px; background: rgba(255,215,0,0.1); border: 1px solid rgba(255,215,0,0.3); border-radius: 8px; color: #ffd700; cursor: pointer; font-size: 20px;"
              >
                ${this._ttsEnabled ? '🔊' : '🔇'}
              </button>
              <button
                class="notification-bell"
                @click=${() => this._toggleNotifications()}
                style="position: relative; padding: 10px 16px; background: rgba(255,215,0,0.1); border: 1px solid rgba(255,215,0,0.3); border-radius: 8px; color: #ffd700; cursor: pointer; font-size: 20px;"
              >
                🔔
                ${this._unreadNotifications > 0 ? html`
                  <span style="position: absolute; top: -5px; right: -5px; background: #ef4444; color: white; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                    ${this._unreadNotifications}
                  </span>
                ` : ''}
              </button>
              <button
                class="refresh-button"
                @click=${() => this._loadAnalyticsData()}
                ?disabled=${this._analyticsLoading}
                style="padding: 10px 20px; background: rgba(255,215,0,0.2); border: 1px solid rgba(255,215,0,0.5); border-radius: 8px; color: #ffd700; cursor: pointer; font-size: 14px;"
              >
                ${this._analyticsLoading ? '⏳ Loading...' : '🔄 Refresh'}
              </button>
              <div class="last-updated">
                <span class="last-updated-label">Last updated</span>
                <span class="last-updated-time">${this._lastUpdated}</span>
              </div>
            </div>

            <!-- Notification Panel -->
            ${this._showNotifications ? html`
              <div style="position: absolute; top: 70px; right: 20px; width: 400px; max-height: 500px; background: rgba(20,20,30,0.98); border: 1px solid rgba(255,215,0,0.3); border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.5); z-index: 1000; overflow: hidden;">
                <div style="padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; justify-content: space-between; align-items: center;">
                  <div style="font-weight: 600; font-size: 16px;">Notifications</div>
                  <button
                    @click=${() => this._clearNotifications()}
                    style="background: none; border: none; color: #888; cursor: pointer; font-size: 14px;"
                  >Clear All</button>
                </div>
                <div style="max-height: 400px; overflow-y: auto;">
                  ${this._notifications.length > 0 ? this._notifications.map(notif => html`
                    <div style="padding: 12px 16px; border-bottom: 1px solid rgba(255,255,255,0.05); background: ${!notif.read ? 'rgba(255,215,0,0.05)' : 'transparent'};">
                      <div style="display: flex; align-items: start; gap: 12px;">
                        <div style="font-size: 24px;">
                          ${notif.type === 'alert' ? '⚠️' : notif.type === 'warning' ? '🔋' : '💡'}
                        </div>
                        <div style="flex: 1;">
                          <div style="font-weight: 600; margin-bottom: 4px; color: ${notif.severity === 'high' ? '#ef4444' : notif.severity === 'medium' ? '#f59e0b' : '#3b82f6'};">
                            ${notif.title}
                          </div>
                          <div style="font-size: 14px; color: #ccc; margin-bottom: 4px;">
                            ${notif.message}
                          </div>
                          <div style="font-size: 12px; color: #888;">
                            ${notif.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  `) : html`
                    <div style="padding: 40px 20px; text-align: center; color: #888;">
                      No notifications
                    </div>
                  `}
                </div>
              </div>
            ` : ''}
          </div>

          ${this._analyticsLoading && !this._analyticsData ? html`
            <div style="text-align: center; padding: 60px; color: #888;">
              <div style="font-size: 48px; margin-bottom: 20px;">⏳</div>
              <div style="font-size: 18px;">Loading analytics data...</div>
            </div>
          ` : this._analyticsData ? html`
            <div class="dashboard-container">
              <!-- Analytics Grid -->
              <div class="duties-grid">

                <!-- Pattern Discovery Card -->
                <div class="duty-card learning">
                  <div class="duty-header">
                    <div class="duty-icon">🧠</div>
                    <div class="duty-title">PATTERN DISCOVERY</div>
                  </div>
                  <div style="font-size: 32px; font-weight: bold; color: #ffd700; margin: 15px 0;">
                    ${this._analyticsData.patterns.total_patterns}
                  </div>
                  <div style="color: #888; margin-bottom: 15px;">Patterns Detected</div>
                  <ul class="duty-duties">
                    ${this._analyticsData.patterns.patterns && this._analyticsData.patterns.patterns.length > 0 ?
                      this._analyticsData.patterns.patterns.slice(0, 5).map(p => html`
                        <li>
                          ${p.entity_id.split('.')[1]}: ${p.type}
                          <span style="color: #4ade80;">(${p.confidence}%)</span>
                        </li>
                      `) : html`<li style="color: #888;">No patterns detected yet</li>`
                    }
                  </ul>
                </div>

                <!-- Device Health Card -->
                <div class="duty-card ${this._analyticsData.device_health.active_alerts > 0 ? 'safety' : 'monitoring'}">
                  <div class="duty-header">
                    <div class="duty-icon">🔧</div>
                    <div class="duty-title">DEVICE HEALTH</div>
                  </div>
                  <div style="font-size: 32px; font-weight: bold; color: ${this._analyticsData.device_health.active_alerts > 0 ? '#ef4444' : '#4ade80'}; margin: 15px 0;">
                    ${this._analyticsData.device_health.active_alerts}
                  </div>
                  <div style="color: #888; margin-bottom: 15px;">
                    Active Alerts (${this._analyticsData.device_health.total_devices_monitored} monitored)
                  </div>
                  <ul class="duty-duties">
                    ${this._analyticsData.device_health.alerts && this._analyticsData.device_health.alerts.length > 0 ?
                      this._analyticsData.device_health.alerts.map(a => html`
                        <li>
                          ${a.entity_id.split('.')[1]}: ${a.degradation_type}
                          <span style="color: ${a.severity === 'high' ? '#ef4444' : '#f59e0b'};">
                            (${a.severity})
                          </span>
                        </li>
                      `) : html`<li style="color: #4ade80;">All devices healthy ✓</li>`
                    }
                  </ul>
                </div>

                <!-- Energy Intelligence Card -->
                <div class="duty-card operations">
                  <div class="duty-header">
                    <div class="duty-icon">⚡</div>
                    <div class="duty-title">ENERGY INTELLIGENCE</div>
                  </div>
                  ${this._analyticsData.energy.available ? html`
                    <div style="font-size: 32px; font-weight: bold; color: #ffd700; margin: 15px 0;">
                      ${this._analyticsData.energy.total_insights || 0}
                    </div>
                    <div style="color: #888; margin-bottom: 15px;">Energy Insights</div>
                    <ul class="duty-duties">
                      ${this._analyticsData.energy.insights && this._analyticsData.energy.insights.length > 0 ?
                        this._analyticsData.energy.insights.map(i => html`
                          <li>
                            ${i.entity_id.split('.')[1]}: ${i.type}
                            <span style="color: #f59e0b;">(${i.severity})</span>
                          </li>
                        `) : html`<li style="color: #888;">No energy anomalies detected</li>`
                      }
                    </ul>
                  ` : html`
                    <div style="color: #888; padding: 20px; text-align: center;">
                      Energy analyzer initializing...
                    </div>
                  `}
                </div>

                <!-- Battery Status Card -->
                <div class="duty-card ${this._analyticsData.battery.available && this._analyticsData.battery.low_batteries > 0 ? 'maintenance' : 'decision'}">
                  <div class="duty-header">
                    <div class="duty-icon">🔋</div>
                    <div class="duty-title">BATTERY STATUS</div>
                  </div>
                  ${this._analyticsData.battery.available ? html`
                    <div style="font-size: 32px; font-weight: bold; color: ${this._analyticsData.battery.low_batteries > 0 ? '#ef4444' : '#4ade80'}; margin: 15px 0;">
                      ${this._analyticsData.battery.low_batteries}
                    </div>
                    <div style="color: #888; margin-bottom: 15px;">
                      Low Batteries (${this._analyticsData.battery.total_batteries} total)
                    </div>
                    <ul class="duty-duties">
                      ${this._analyticsData.battery.low_battery_list && this._analyticsData.battery.low_battery_list.length > 0 ?
                        this._analyticsData.battery.low_battery_list.map(b => html`
                          <li>
                            ${b.name}: ${b.level}%
                            <span style="color: #ef4444;">(Replace soon)</span>
                          </li>
                        `) : html`<li style="color: #4ade80;">All batteries healthy ✓</li>`
                      }
                    </ul>
                  ` : html`
                    <div style="color: #888; padding: 20px; text-align: center;">
                      Battery manager initializing...
                    </div>
                  `}
                </div>

                <!-- Security Monitor Card -->
                <div class="duty-card safety">
                  <div class="duty-header">
                    <div class="duty-icon">🛡️</div>
                    <div class="duty-title">SECURITY MONITOR</div>
                  </div>
                  ${this._analyticsData.security.available ? html`
                    <div style="font-size: 32px; font-weight: bold; color: #4ade80; margin: 15px 0;">
                      ${this._analyticsData.security.anomalies_detected || 0}
                    </div>
                    <div style="color: #888; margin-bottom: 15px;">Access Anomalies</div>
                    <ul class="duty-duties">
                      <li style="color: #4ade80;">No security anomalies ✓</li>
                      <li>Smart lock monitoring: Active</li>
                      <li>Access pattern tracking: Enabled</li>
                      <li>Guest code management: Ready</li>
                    </ul>
                  ` : html`
                    <div style="color: #888; padding: 20px; text-align: center;">
                      Security intelligence initializing...
                    </div>
                  `}
                </div>

                <!-- System Stats Card -->
                <div class="duty-card inspections">
                  <div class="duty-header">
                    <div class="duty-icon">📈</div>
                    <div class="duty-title">SYSTEM STATS</div>
                  </div>
                  <ul class="duty-duties">
                    <li>Patterns: ${this._analyticsData.patterns.total_patterns} detected</li>
                    <li>Devices: ${this._analyticsData.device_health.total_devices_monitored} monitored</li>
                    <li>Alerts: ${this._analyticsData.device_health.active_alerts} active</li>
                    <li>Batteries: ${this._analyticsData.battery.available ? this._analyticsData.battery.total_batteries : 'N/A'} tracked</li>
                    <li>Security: ${this._analyticsData.security.available ? 'Active' : 'Initializing'}</li>
                    <li>Last sync: ${this._lastUpdated}</li>
                  </ul>
                </div>

              </div>
            </div>
          ` : html`
            <div style="text-align: center; padding: 60px; color: #888;">
              <div style="font-size: 48px; margin-bottom: 20px;">📊</div>
              <div style="font-size: 18px; margin-bottom: 20px;">Analytics data not loaded</div>
              <button
                @click=${() => this._loadAnalyticsData()}
                style="padding: 12px 24px; background: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%); border: none; border-radius: 8px; color: #1a1a2e; font-weight: 600; cursor: pointer; font-size: 16px;"
              >
                Load Analytics
              </button>
            </div>
          `}

        </div>
      </div>
    `;
  }

  _renderDutiesView() {
    return html`
      <div class="dashboard-layout">
        <!-- Left Sidebar -->
        <div class="sidebar">
          <div class="sidebar-header">
            <div class="sidebar-title">Alfred</div>
            <div class="sidebar-subtitle">Home Assistant</div>
          </div>
          
          <nav class="sidebar-nav">
            <button
              class="nav-item active"
              @click=${() => this._switchView("duties")}
            >
              <span class="nav-icon">🏠</span>
              <span class="nav-text">Dashboard</span>
            </button>
            <button
              class="nav-item"
              @click=${() => this._switchView("analytics")}
            >
              <span class="nav-icon">📊</span>
              <span class="nav-text">Analytics</span>
            </button>
            <button
              class="nav-item"
              @click=${() => this._switchView("chat")}
            >
              <span class="nav-icon">💬</span>
              <span class="nav-text">Chat</span>
            </button>
          </nav>

          <div class="sidebar-footer">
            <div class="user-avatar">A</div>
            <div class="user-info">
              <div class="user-name">Alfred AI</div>
              ${this._alfredState === "speaking" ? html`
                <div class="waveform">
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                  <div class="waveform-bar"></div>
                </div>
              ` : html`
                <div class="user-status">Online</div>
              `}
            </div>
          </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
          <div class="dashboard-header">
            <div class="header-left">
              <h1 class="dashboard-title">Alfred's Daily Duties</h1>
              <p class="dashboard-subtitle">Your comprehensive building management overview.</p>
            </div>
            <div class="header-right">
              <div class="last-updated">
                <span class="last-updated-label">Last updated</span>
                <span class="last-updated-time">${this._lastUpdated}</span>
              </div>
            </div>
          </div>

          <div class="dashboard-container">


            <!-- Duties Grid -->
            <div class="duties-grid">
              <!-- Maintenance -->
              <div class="duty-card maintenance">
                <div class="duty-header">
                  <div class="duty-icon">🛠️</div>
                  <div class="duty-title">MAINTENANCE</div>
                </div>
                <ul class="duty-duties">
                  <li>Check and clean air quality sensors</li>
                  <li>Review pump operations</li>
                  <li>Inspect HVAC filters</li>
                  <li>Test emergency lighting</li>
                  <li>Lubricate door mechanisms</li>
                </ul>
              </div>

              <!-- Inspections -->
              <div class="duty-card inspections">
                <div class="duty-header">
                  <div class="duty-icon">💬</div>
                  <div class="duty-title">INSPECTIONS</div>
                </div>
                <ul class="duty-duties">
                  <li>Water system function check</li>
                  <li>HVAC system performance</li>
                  <li>Electrical systems review</li>
                  <li>Security camera functionality</li>
                  <li>Fire alarm systems</li>
                </ul>
              </div>

              <!-- Operations Insights -->
              <div class="duty-card operations">
                <div class="duty-header">
                  <div class="duty-icon">🧠</div>
                  <div class="duty-title">OPERATIONS INSIGHTS</div>
                </div>
                <ul class="duty-duties">
                  <li>Visitor flow</li>
                  <li>Energy consumption</li>
                  <li>Climate control efficiency</li>
                  <li>Resource utilization</li>
                  <li>System performance trends</li>
                </ul>
              </div>

              <!-- Learning -->
              <div class="duty-card learning">
                <div class="duty-header">
                  <div class="duty-icon">📚</div>
                  <div class="duty-title">LEARNING</div>
                </div>
                <ul class="duty-duties">
                  <li>Review new features</li>
                  <li>Update maintenance logs</li>
                  <li>Study building systems</li>
                  <li>Analyze efficiency data</li>
                  <li>Research best practices</li>
                </ul>
              </div>

              <!-- Safety -->
              <div class="duty-card safety">
                <div class="duty-header">
                  <div class="duty-icon">🛡️</div>
                  <div class="duty-title">SAFETY</div>
                </div>
                <ul class="duty-duties">
                  <li>Review emergency procedures</li>
                  <li>Inspect fire extinguishers</li>
                  <li>Check emergency exits</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  _renderChatView() {
    return html`
      <div class="container">
        <!-- Navigation Tabs -->
        <div class="nav-tabs">
          <button
            class="nav-tab nav-back"
            @click=${() => this._navigateBack()}
            title="Back to Home Assistant"
          >
            ← Back
          </button>
          <button
            class="nav-tab"
            @click=${() => this._switchView("duties")}
          >
            📋 Daily Duties
          </button>
          <button
            class="nav-tab active"
            @click=${() => this._switchView("chat")}
          >
            💬 Chat
          </button>
          <button
            class="nav-tab"
            @click=${() => this._switchView("systems")}
          >
            ⚙️ Systems
          </button>
        </div>

        <!-- Header -->
        <div class="header">
          <h1 class="alfred-title">🎩 Alfred</h1>
          <p class="alfred-subtitle">Your Digital Butler</p>

          <!-- Mode Selector -->
          <div class="mode-selector">
            <button
              class="mode-button ${this._mode === "text" ? "active" : ""}"
              @click=${() => this._switchMode("text")}
            >
              💬 Type
            </button>
            <button
              class="mode-button ${this._mode === "voice" ? "active" : ""}"
              @click=${() => this._switchMode("voice")}
            >
              🎤 Voice
            </button>
          </div>

          <!-- Alfred Avatar -->
          <div class="alfred-avatar ${this._alfredState}">
            <svg viewBox="0 0 100 150" xmlns="http://www.w3.org/2000/svg">
              <!-- Butler's Head -->
              <ellipse cx="50" cy="30" rx="18" ry="22" fill="#f5e6d3" stroke="#333" stroke-width="1"/>

              <!-- Bowler Hat -->
              <ellipse cx="50" cy="16" rx="22" ry="8" fill="#1a1a1a" stroke="#000" stroke-width="1"/>
              <rect x="32" y="14" width="36" height="8" rx="2" fill="#1a1a1a" stroke="#000" stroke-width="1"/>
              <ellipse cx="50" cy="8" rx="14" ry="10" fill="#2a2a2a" stroke="#000" stroke-width="0.5"/>

              <!-- Eyes -->
              <circle cx="44" cy="32" r="2" fill="#333"/>
              <circle cx="56" cy="32" r="2" fill="#333"/>

              <!-- Mustache -->
              <path d="M 42 40 Q 38 42 35 40 M 58 40 Q 62 42 65 40" stroke="#333" stroke-width="1.5" fill="none" stroke-linecap="round"/>

              <!-- Bow Tie -->
              <path d="M 44 48 L 40 52 L 44 56 L 50 52 Z M 56 48 L 60 52 L 56 56 L 50 52 Z" fill="#8b0000" stroke="#600" stroke-width="0.5"/>
              <circle cx="50" cy="52" r="2" fill="#600"/>

              <!-- Body (Suit) -->
              <path d="M 35 56 L 35 100 Q 35 110 40 115 L 45 130 L 50 128 L 55 130 L 60 115 Q 65 110 65 100 L 65 56 Z" fill="#1a1a1a" stroke="#000" stroke-width="1"/>

              <!-- Vest -->
              <path d="M 42 60 L 42 95 Q 42 100 45 105 L 50 110 L 55 105 Q 58 100 58 95 L 58 60 Z" fill="#2a2a2a" stroke="#000" stroke-width="0.5"/>

              <!-- Vest Buttons -->
              <circle cx="50" cy="70" r="1.5" fill="#ffd700"/>
              <circle cx="50" cy="80" r="1.5" fill="#ffd700"/>
              <circle cx="50" cy="90" r="1.5" fill="#ffd700"/>

              <!-- Arms -->
              <path d="M 35 60 Q 25 70 22 90 L 20 100" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>
              <path d="M 65 60 Q 75 70 78 90 L 80 100" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>

              <!-- White Gloves -->
              <circle cx="20" cy="100" r="4" fill="#f5f5f5" stroke="#ddd" stroke-width="0.5"/>
              <circle cx="80" cy="100" r="4" fill="#f5f5f5" stroke="#ddd" stroke-width="0.5"/>

              <!-- Legs -->
              <rect x="42" y="128" width="6" height="20" fill="#1a1a1a" stroke="#000" stroke-width="0.5"/>
              <rect x="52" y="128" width="6" height="20" fill="#1a1a1a" stroke="#000" stroke-width="0.5"/>

              <!-- Shoes -->
              <ellipse cx="45" cy="148" rx="5" ry="3" fill="#000"/>
              <ellipse cx="55" cy="148" rx="5" ry="3" fill="#000"/>
            </svg>
          </div>

          <!-- Greeting Message -->
          <div class="greeting-message ${this._greeting ? "visible" : ""}">
            ${this._greeting}
          </div>
        </div>

        <!-- Messages -->
        <div class="messages-container">
          ${this._messages.map(
            (msg) => html`
              <div class="message ${msg.sender}">
                <div class="message-bubble">
                  <div class="message-sender">
                    ${msg.sender === "alfred" ? "Alfred" : "You"}
                  </div>
                  <div class="message-text">${msg.text}</div>
                </div>
              </div>
            `
          )}
        </div>

        <!-- Input Area -->
        ${this._mode === "text"
          ? html`
              <div class="input-container">
                <div class="suggestions-container">
                  <div class="suggestion-chip" @click=${() => this._handleSuggestion("What's the status of my home?")}>
                    Status check
                  </div>
                  <div class="suggestion-chip" @click=${() => this._handleSuggestion("Are there any alerts?")}>
                    Check alerts
                  </div>
                  <div class="suggestion-chip" @click=${() => this._handleSuggestion("Turn on the lights")}>
                    Control lights
                  </div>
                </div>
                <div class="input-wrapper">
                  <input
                    type="text"
                    class="text-input"
                    placeholder="Type your message to Alfred..."
                    .value=${this._inputValue}
                    @input=${this._handleInputChange}
                    @keypress=${this._handleKeyPress}
                    @focus=${this._handleInputFocus}
                    @blur=${this._handleInputBlur}
                  />
                  <button
                    class="send-button"
                    @click=${this._handleSendMessage}
                    ?disabled=${!this._inputValue.trim()}
                  >
                    Send
                  </button>
                </div>
              </div>
            `
          : html`
              <div class="voice-controls">
                <button
                  class="voice-button ${this._isListening ? "listening" : ""}"
                  @click=${this._handleVoiceButton}
                >
                  🎤
                </button>
                <p style="margin-top: 15px; color: #a0a0a0;">
                  ${this._isListening
                    ? "Listening... Speak now"
                    : "Click to speak with Alfred"}
                </p>
              </div>
            `}
      </div>
    `;
  }
}

customElements.define("alfred-panel", AlfredPanel);
