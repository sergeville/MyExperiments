"""Historical data access layer for Alfred Digital Butler."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant, State
from homeassistant.util import dt as dt_util
from homeassistant.components import recorder
from homeassistant.components.recorder import history, statistics

_LOGGER = logging.getLogger(__name__)


class HistoricalDataAccess:
    """Access layer for Home Assistant historical state data."""

    def __init__(self, hass: HomeAssistant) -> None:
        """Initialize historical data access."""
        self.hass = hass
        self._recorder_available = False

    async def async_setup(self) -> None:
        """Set up the historical data access layer."""
        _LOGGER.info("Setting up Alfred Historical Data Access")

        # Check if recorder component is available
        self._recorder_available = await self._check_recorder_availability()

        if not self._recorder_available:
            _LOGGER.warning(
                "Home Assistant recorder component not available. "
                "Historical pattern recognition will be limited to real-time data only."
            )
        else:
            _LOGGER.info("Recorder component available - historical data access enabled")

    async def _check_recorder_availability(self) -> bool:
        """Check if the recorder component is available and configured."""
        try:
            # Check if recorder instance exists in hass.data
            recorder_instance = self.hass.data.get("recorder_instance")
            if recorder_instance is None:
                _LOGGER.debug("Recorder instance not found in hass.data")
                return False

            # Verify recorder is running
            if not recorder_instance.enabled:
                _LOGGER.debug("Recorder is disabled")
                return False

            _LOGGER.debug("Recorder component is available and enabled")
            return True

        except Exception as err:
            _LOGGER.error("Error checking recorder availability: %s", err)
            return False

    async def get_entity_history(
        self,
        entity_id: str,
        start_time: datetime,
        end_time: datetime | None = None,
        minimal_response: bool = False,
    ) -> list[State]:
        """
        Get historical states for a specific entity.

        Args:
            entity_id: Entity ID to query (e.g., "light.living_room")
            start_time: Start of time range (timezone-aware datetime)
            end_time: End of time range (defaults to now)
            minimal_response: If True, return minimal state data (faster)

        Returns:
            List of State objects ordered by time (oldest first)

        Raises:
            ValueError: If recorder is not available or parameters invalid
        """
        if not self._recorder_available:
            raise ValueError(
                "Historical data access requires Home Assistant recorder component. "
                "Please enable recorder in your Home Assistant configuration."
            )

        # Validate parameters
        if not entity_id:
            raise ValueError("entity_id is required")

        # Ensure start_time is timezone-aware
        if start_time.tzinfo is None:
            start_time = dt_util.as_local(start_time)

        # Default end_time to now
        if end_time is None:
            end_time = dt_util.now()
        elif end_time.tzinfo is None:
            end_time = dt_util.as_local(end_time)

        # Validate time range
        if start_time >= end_time:
            raise ValueError("start_time must be before end_time")

        _LOGGER.debug(
            "Querying history for %s from %s to %s",
            entity_id,
            start_time.isoformat(),
            end_time.isoformat(),
        )

        try:
            # Execute query in executor to avoid blocking event loop
            states_dict = await self.hass.async_add_executor_job(
                self._get_significant_states,
                start_time,
                end_time,
                [entity_id],
                minimal_response,
            )

            # Extract states for this entity
            entity_states = states_dict.get(entity_id, [])

            _LOGGER.debug(
                "Retrieved %d historical states for %s",
                len(entity_states),
                entity_id,
            )

            return entity_states

        except Exception as err:
            _LOGGER.error(
                "Error retrieving history for %s: %s",
                entity_id,
                err,
                exc_info=True,
            )
            raise

    async def get_multiple_entities_history(
        self,
        entity_ids: list[str],
        start_time: datetime,
        end_time: datetime | None = None,
        minimal_response: bool = False,
    ) -> dict[str, list[State]]:
        """
        Get historical states for multiple entities.

        Args:
            entity_ids: List of entity IDs to query
            start_time: Start of time range (timezone-aware datetime)
            end_time: End of time range (defaults to now)
            minimal_response: If True, return minimal state data (faster)

        Returns:
            Dictionary mapping entity_id to list of State objects

        Raises:
            ValueError: If recorder is not available or parameters invalid
        """
        if not self._recorder_available:
            raise ValueError("Historical data access requires recorder component")

        if not entity_ids:
            raise ValueError("entity_ids list cannot be empty")

        # Ensure start_time is timezone-aware
        if start_time.tzinfo is None:
            start_time = dt_util.as_local(start_time)

        # Default end_time to now
        if end_time is None:
            end_time = dt_util.now()
        elif end_time.tzinfo is None:
            end_time = dt_util.as_local(end_time)

        # Validate time range
        if start_time >= end_time:
            raise ValueError("start_time must be before end_time")

        _LOGGER.debug(
            "Querying history for %d entities from %s to %s",
            len(entity_ids),
            start_time.isoformat(),
            end_time.isoformat(),
        )

        try:
            # Execute query in executor to avoid blocking event loop
            states_dict = await self.hass.async_add_executor_job(
                self._get_significant_states,
                start_time,
                end_time,
                entity_ids,
                minimal_response,
            )

            total_states = sum(len(states) for states in states_dict.values())
            _LOGGER.debug(
                "Retrieved %d total historical states for %d entities",
                total_states,
                len(entity_ids),
            )

            return states_dict

        except Exception as err:
            _LOGGER.error(
                "Error retrieving history for multiple entities: %s",
                err,
                exc_info=True,
            )
            raise

    async def get_domain_history(
        self,
        domain: str,
        start_time: datetime,
        end_time: datetime | None = None,
        minimal_response: bool = False,
    ) -> dict[str, list[State]]:
        """
        Get historical states for all entities in a domain.

        Args:
            domain: Domain to query (e.g., "light", "switch", "sensor")
            start_time: Start of time range
            end_time: End of time range (defaults to now)
            minimal_response: If True, return minimal state data (faster)

        Returns:
            Dictionary mapping entity_id to list of State objects

        Raises:
            ValueError: If recorder is not available or parameters invalid
        """
        # Get all current entities in domain
        all_entities = self.hass.states.async_all(domain)
        entity_ids = [state.entity_id for state in all_entities]

        if not entity_ids:
            _LOGGER.warning("No entities found for domain: %s", domain)
            return {}

        _LOGGER.debug("Querying history for domain '%s' (%d entities)", domain, len(entity_ids))

        return await self.get_multiple_entities_history(
            entity_ids,
            start_time,
            end_time,
            minimal_response,
        )

    def _get_significant_states(
        self,
        start_time: datetime,
        end_time: datetime,
        entity_ids: list[str],
        minimal_response: bool,
    ) -> dict[str, list[State]]:
        """
        Get significant states (runs in executor thread).

        This method runs in a thread pool executor to avoid blocking
        the event loop during database queries.

        Args:
            start_time: Start of time range
            end_time: End of time range
            entity_ids: List of entity IDs to query
            minimal_response: If True, return minimal state data

        Returns:
            Dictionary mapping entity_id to list of State objects
        """
        return history.get_significant_states(
            self.hass,
            start_time,
            end_time,
            entity_ids=entity_ids,
            filters=None,
            include_start_time_state=True,
            significant_changes_only=True,
            minimal_response=minimal_response,
            no_attributes=minimal_response,
        )

    async def get_last_state_changes(
        self,
        entity_id: str,
        limit: int = 100,
    ) -> list[State]:
        """
        Get the most recent state changes for an entity.

        Args:
            entity_id: Entity ID to query
            limit: Maximum number of states to return (default: 100)

        Returns:
            List of State objects (most recent first)

        Raises:
            ValueError: If recorder is not available
        """
        if not self._recorder_available:
            raise ValueError("Historical data access requires recorder component")

        # Query last 30 days (should be enough for most retention settings)
        start_time = dt_util.now() - timedelta(days=30)
        end_time = dt_util.now()

        try:
            states = await self.get_entity_history(
                entity_id,
                start_time,
                end_time,
                minimal_response=False,
            )

            # Return most recent states (reverse order, limit)
            recent_states = list(reversed(states[-limit:]))

            _LOGGER.debug(
                "Retrieved %d recent state changes for %s",
                len(recent_states),
                entity_id,
            )

            return recent_states

        except Exception as err:
            _LOGGER.error(
                "Error retrieving recent states for %s: %s",
                entity_id,
                err,
            )
            raise

    async def get_state_changes_during_period(
        self,
        entity_id: str,
        start_time: datetime,
        end_time: datetime | None = None,
    ) -> int:
        """
        Count the number of state changes during a time period.

        Args:
            entity_id: Entity ID to query
            start_time: Start of time range
            end_time: End of time range (defaults to now)

        Returns:
            Number of state changes during the period

        Raises:
            ValueError: If recorder is not available
        """
        states = await self.get_entity_history(
            entity_id,
            start_time,
            end_time,
            minimal_response=True,
        )

        return len(states)

    def is_available(self) -> bool:
        """Check if historical data access is available."""
        return self._recorder_available

    async def get_recorder_retention_days(self) -> int | None:
        """
        Get the recorder retention period in days.

        Returns:
            Number of days of history available, or None if unknown
        """
        try:
            recorder_instance = self.hass.data.get("recorder_instance")
            if recorder_instance is None:
                return None

            # Get retention period from recorder config
            # Default is 10 days if not configured
            retention_days = getattr(recorder_instance, "keep_days", 10)

            _LOGGER.debug("Recorder retention: %d days", retention_days)
            return retention_days

        except Exception as err:
            _LOGGER.error("Error getting recorder retention: %s", err)
            return None

    # ========================================================================
    # STATISTICS API ACCESS (For Energy & Long-Term Data)
    # ========================================================================

    async def get_statistics(
        self,
        statistic_ids: list[str],
        start_time: datetime,
        end_time: datetime | None = None,
        period: str = "hour",
        types: set[str] | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Get long-term statistics for energy sensors and other statistical entities.

        This method accesses HA's statistics table which stores hourly aggregates
        that are never purged (unlike short-term states).

        Args:
            statistic_ids: List of statistic IDs to query (usually entity_ids)
            start_time: Start of time range (timezone-aware datetime)
            end_time: End of time range (defaults to now)
            period: Aggregation period - 'hour', 'day', 'week', 'month'
                    (default: 'hour')
            types: Set of statistic types to include:
                   {'sum', 'mean', 'min', 'max', 'state'}
                   If None, returns all available types

        Returns:
            Dictionary mapping statistic_id to list of statistics
            Each statistic is a dict with keys:
            - 'start': Start timestamp of period
            - 'end': End timestamp of period
            - 'mean': Average value (for measurement sensors)
            - 'min': Minimum value (for measurement sensors)
            - 'max': Maximum value (for measurement sensors)
            - 'sum': Cumulative sum (for energy/total sensors)
            - 'state': Final state value (for energy/total sensors)

        Raises:
            ValueError: If recorder is not available or parameters invalid

        Example:
            stats = await get_statistics(
                ["sensor.home_energy"],
                start_time=now - timedelta(days=7),
                period="day"
            )
            # Returns daily energy consumption for the last 7 days
        """
        if not self._recorder_available:
            raise ValueError(
                "Statistics access requires Home Assistant recorder component. "
                "Please enable recorder in your Home Assistant configuration."
            )

        # Validate parameters
        if not statistic_ids:
            raise ValueError("statistic_ids list cannot be empty")

        # Ensure start_time is timezone-aware
        if start_time.tzinfo is None:
            start_time = dt_util.as_local(start_time)

        # Default end_time to now
        if end_time is None:
            end_time = dt_util.now()
        elif end_time.tzinfo is None:
            end_time = dt_util.as_local(end_time)

        # Validate time range
        if start_time >= end_time:
            raise ValueError("start_time must be before end_time")

        # Validate period
        valid_periods = {"hour", "day", "week", "month", "5minute"}
        if period not in valid_periods:
            raise ValueError(f"period must be one of {valid_periods}")

        _LOGGER.debug(
            "Querying statistics for %d entities from %s to %s (period: %s)",
            len(statistic_ids),
            start_time.isoformat(),
            end_time.isoformat(),
            period,
        )

        try:
            # Execute query in executor to avoid blocking event loop
            stats = await self.hass.async_add_executor_job(
                self._get_statistics_during_period,
                start_time,
                end_time,
                statistic_ids,
                period,
                types,
            )

            total_records = sum(len(records) for records in stats.values())
            _LOGGER.debug(
                "Retrieved %d total statistics records for %d entities",
                total_records,
                len(statistic_ids),
            )

            return stats

        except Exception as err:
            _LOGGER.error(
                "Error retrieving statistics: %s",
                err,
                exc_info=True,
            )
            raise

    def _get_statistics_during_period(
        self,
        start_time: datetime,
        end_time: datetime,
        statistic_ids: list[str],
        period: str,
        types: set[str] | None,
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Get statistics (runs in executor thread).

        This method runs in a thread pool executor to avoid blocking
        the event loop during database queries.

        Args:
            start_time: Start of time range
            end_time: End of time range
            statistic_ids: List of statistic IDs to query
            period: Aggregation period
            types: Set of statistic types to include

        Returns:
            Dictionary mapping statistic_id to list of statistics
        """
        return statistics.statistics_during_period(
            self.hass,
            start_time,
            end_time,
            statistic_ids,
            period,
            units=None,
            types=types,
        )

    async def get_latest_statistics(
        self,
        statistic_ids: list[str],
        types: set[str] | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        """
        Get the most recent statistics for given statistic IDs.

        Args:
            statistic_ids: List of statistic IDs to query
            types: Set of statistic types to include (default: all)

        Returns:
            Dictionary mapping statistic_id to list with single latest stat

        Raises:
            ValueError: If recorder is not available
        """
        if not self._recorder_available:
            raise ValueError("Statistics access requires recorder component")

        if not statistic_ids:
            raise ValueError("statistic_ids list cannot be empty")

        _LOGGER.debug(
            "Querying latest statistics for %d entities",
            len(statistic_ids),
        )

        try:
            # Execute query in executor
            stats = await self.hass.async_add_executor_job(
                statistics.get_latest_short_term_statistics,
                self.hass,
                statistic_ids,
                types,
                None,  # metadata
            )

            _LOGGER.debug(
                "Retrieved latest statistics for %d entities",
                len(stats),
            )

            return stats

        except Exception as err:
            _LOGGER.error("Error retrieving latest statistics: %s", err)
            raise

    async def get_statistics_metadata(
        self,
        statistic_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """
        Get metadata about statistics.

        Args:
            statistic_ids: List of statistic IDs (None = all)

        Returns:
            List of metadata dictionaries with keys:
            - 'statistic_id': Entity ID
            - 'source': Data source ('recorder' or integration name)
            - 'unit_of_measurement': Unit
            - 'has_mean': Whether mean is calculated
            - 'has_sum': Whether sum is calculated
            - 'name': Friendly name

        Raises:
            ValueError: If recorder is not available
        """
        if not self._recorder_available:
            raise ValueError("Statistics access requires recorder component")

        try:
            metadata = await self.hass.async_add_executor_job(
                statistics.list_statistic_ids,
                self.hass,
                statistic_ids,
            )

            _LOGGER.debug("Retrieved metadata for %d statistics", len(metadata))

            return metadata

        except Exception as err:
            _LOGGER.error("Error retrieving statistics metadata: %s", err)
            raise
