"""Intelligence engine for Alfred Digital Butler."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant, Event, callback
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EVENT_STATE_CHANGED
from homeassistant.helpers.event import async_track_state_change_event
from homeassistant.helpers import (
    entity_registry as er,
    device_registry as dr,
    area_registry as ar,
)
from homeassistant.helpers.entity_registry import EVENT_ENTITY_REGISTRY_UPDATED

from .const import (
    DOMAIN,
    EVENT_ALFRED_ALERT,
    EVENT_ALFRED_SUGGESTION,
)
from .historical_data import HistoricalDataAccess
from .pattern_storage import PatternStorage
from .pattern_analyzer import PatternAnalyzer
from .performance_metrics import PerformanceMetricsCollector
from .baseline_calculator import BaselineCalculator
from .runtime_tracker import RuntimeTracker
from .degradation_detector import DegradationDetector
from .failure_diagnosis import FailureDiagnosisEngine
from .battery_manager import BatteryManager
from .energy_analyzer import EnergyConsumptionAnalyzer

_LOGGER = logging.getLogger(__name__)


class AlfredIntelligenceEngine:
    """Intelligence engine for pattern recognition and proactive suggestions."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """Initialize the intelligence engine."""
        self.hass = hass
        self.entry = entry
        self._patterns: dict[str, Any] = {}
        self._device_baselines: dict[str, Any] = {}
        self._listeners = []
        self._historical_data = HistoricalDataAccess(hass)
        self._pattern_storage = PatternStorage(hass)
        self._pattern_analyzer: PatternAnalyzer | None = None
        self._metrics_collector: PerformanceMetricsCollector | None = None
        self._baseline_calculator: BaselineCalculator | None = None
        self._runtime_tracker: RuntimeTracker | None = None
        self._degradation_detector: DegradationDetector | None = None
        self._diagnosis_engine: FailureDiagnosisEngine | None = None
        self._battery_manager: BatteryManager | None = None
        self._energy_analyzer: EnergyConsumptionAnalyzer | None = None
        self._detected_devices: dict[str, datetime] = {}  # Track recently detected devices

    async def async_setup(self) -> None:
        """Set up the intelligence engine."""
        _LOGGER.info("Setting up Alfred Intelligence Engine")

        # Set up historical data access
        await self._historical_data.async_setup()

        # Set up pattern storage database
        await self._pattern_storage.async_setup()

        # Initialize pattern analyzer
        self._pattern_analyzer = PatternAnalyzer(
            self.hass,
            self._historical_data,
            self._pattern_storage,
        )

        # Initialize performance metrics collector
        self._metrics_collector = PerformanceMetricsCollector(self.hass)
        await self._metrics_collector.async_setup()

        # Initialize baseline calculator
        self._baseline_calculator = BaselineCalculator(
            self.hass,
            self._historical_data,
            self._metrics_collector,
            self._pattern_storage,
        )
        await self._baseline_calculator.async_setup()

        # Initialize runtime tracker
        self._runtime_tracker = RuntimeTracker(
            self.hass,
            self._pattern_storage,
        )
        await self._runtime_tracker.async_setup()

        # Initialize degradation detector
        self._degradation_detector = DegradationDetector(
            self.hass,
            self._metrics_collector,
            self._baseline_calculator,
            self._pattern_storage,
        )
        await self._degradation_detector.async_setup()

        # Initialize diagnosis engine (Epic 3.4)
        self._diagnosis_engine = FailureDiagnosisEngine(
            self.hass,
            self.entry,
            self._metrics_collector,
            self._baseline_calculator,
            self._runtime_tracker,
            self._pattern_storage,
        )
        await self._diagnosis_engine.async_setup()

        # Initialize battery manager (Epic 3.6)
        self._battery_manager = BatteryManager(
            self.hass,
            self._pattern_storage,
        )
        await self._battery_manager.async_setup()

        # Initialize energy consumption analyzer (Epic 4.1)
        self._energy_analyzer = EnergyConsumptionAnalyzer(
            self.hass,
            self._pattern_storage,
            self._historical_data,
            self._baseline_calculator,
        )
        await self._energy_analyzer.async_setup()

        # Initialize environmental hazard detector (Epic 5.4)
        from .environmental_hazard_detector import EnvironmentalHazardDetector

        self._hazard_detector = EnvironmentalHazardDetector(
            self.hass,
            self._pattern_storage,
        )
        await self._hazard_detector.async_setup()

        # Initialize pipe freeze predictor (Epic 5.5)
        from .pipe_freeze_predictor import PipeFreezePredictor

        self._freeze_predictor = PipeFreezePredictor(
            self.hass,
            self._pattern_storage,
        )

        # Initialize security report generator (Epic 5.6)
        from .security_report_generator import SecurityReportGenerator

        self._security_report_generator = SecurityReportGenerator(
            self.hass,
            self._pattern_storage,
        )
        await self._security_report_generator.async_setup()

        # Initialize smart lock intelligence (Epic 5.3)
        from .smart_lock_intelligence import SmartLockIntelligence

        self._smart_lock_intelligence = SmartLockIntelligence(
            self.hass,
            self._pattern_storage,
        )
        await self._smart_lock_intelligence.async_setup()

        # Load historical patterns if available
        await self._load_patterns()

        # Set up event listeners
        self._setup_listeners()

    async def async_start(self) -> None:
        """Start the intelligence engine."""
        _LOGGER.info("Starting Alfred Intelligence Engine")

        # Start battery manager
        await self._battery_manager.async_start()

        # Start energy analyzer
        await self._energy_analyzer.async_start()

        # Run initial home analysis
        await self._analyze_home_state()

        # Schedule periodic analysis
        await self._schedule_periodic_tasks()

    async def async_stop(self) -> None:
        """Stop the intelligence engine."""
        _LOGGER.info("Stopping Alfred Intelligence Engine")

        # Close environmental hazard detector
        if hasattr(self, "_hazard_detector"):
            await self._hazard_detector.async_close()

        # Close security report generator
        if hasattr(self, "_security_report_generator"):
            await self._security_report_generator.async_close()

        # Close smart lock intelligence
        if hasattr(self, "_smart_lock_intelligence"):
            await self._smart_lock_intelligence.async_close()

        # Remove all listeners
        for remove_listener in self._listeners:
            remove_listener()
        self._listeners.clear()

        # Close pattern storage database
        await self._pattern_storage.async_close()

    def _setup_listeners(self) -> None:
        """Set up event listeners for intelligence gathering."""

        # Listen for new entity registrations
        @callback
        def handle_entity_registry_updated(event: Event) -> None:
            """Handle entity registry updates."""
            action = event.data.get("action")
            entity_id = event.data.get("entity_id")

            if action == "create" and entity_id:
                _LOGGER.debug("Entity registry updated - new entity: %s", entity_id)
                self.hass.async_create_task(self._on_new_device(entity_id))

        # Listen for state changes to detect patterns
        @callback
        def handle_state_change(event: Event) -> None:
            """Handle state changes for pattern detection."""
            entity_id = event.data.get("entity_id")
            old_state = event.data.get("old_state")
            new_state = event.data.get("new_state")

            if entity_id and old_state and new_state:
                self.hass.async_create_task(
                    self._on_state_change(entity_id, old_state, new_state)
                )

        # Track entity registry updates for new devices
        remove_registry = self.hass.bus.async_listen(
            EVENT_ENTITY_REGISTRY_UPDATED, handle_entity_registry_updated
        )
        self._listeners.append(remove_registry)

        # Track all state changes using event bus
        remove_state = self.hass.bus.async_listen(EVENT_STATE_CHANGED, handle_state_change)
        self._listeners.append(remove_state)

    async def _on_new_device(self, entity_id: str) -> None:
        """Handle when a new device is added."""
        _LOGGER.info("Alfred detected new device: %s", entity_id)

        # Check if we've already processed this device recently (avoid duplicates)
        now = datetime.now()
        if entity_id in self._detected_devices:
            last_detected = self._detected_devices[entity_id]
            if now - last_detected < timedelta(hours=24):
                _LOGGER.debug("Device %s already processed recently, skipping", entity_id)
                return

        # Clean up old detected devices (>7 days)
        self._detected_devices = {
            eid: dt
            for eid, dt in self._detected_devices.items()
            if now - dt < timedelta(days=7)
        }

        # Get device state
        state = self.hass.states.get(entity_id)
        if not state:
            _LOGGER.debug("No state available for %s yet", entity_id)
            return

        # Get entity registry entry for additional context
        entity_registry = er.async_get(self.hass)
        entity_entry = entity_registry.async_get(entity_id)

        # Get device and area information
        device_entry = None
        area_name = None

        if entity_entry and entity_entry.device_id:
            device_registry = dr.async_get(self.hass)
            device_entry = device_registry.async_get(entity_entry.device_id)

            if device_entry and device_entry.area_id:
                area_registry = ar.async_get(self.hass)
                area_entry = area_registry.async_get_area(device_entry.area_id)
                if area_entry:
                    area_name = area_entry.name

        # Build device context for suggestion generation
        device_context = {
            "entity_id": entity_id,
            "state": state,
            "entity_entry": entity_entry,
            "device_entry": device_entry,
            "area_name": area_name,
        }

        # Determine device type and suggest automation
        suggestion = await self._generate_new_device_suggestion(device_context)

        if suggestion:
            # Track this device
            self._detected_devices[entity_id] = now

            # Fire suggestion event
            self.hass.bus.async_fire(
                EVENT_ALFRED_SUGGESTION,
                {
                    "title": "New Device Detected",
                    "message": suggestion["message"],
                    "entity_id": entity_id,
                    "suggestion_type": "new_device",
                    "actions": suggestion.get("actions", []),
                },
            )

            # Also send notification
            await self._send_notification(
                "Alfred: New Device",
                suggestion["message"],
                {"entity_id": entity_id},
            )

    async def _generate_new_device_suggestion(
        self, device_context: dict[str, Any]
    ) -> dict[str, Any] | None:
        """
        Generate automation suggestion for new device.

        Args:
            device_context: Dictionary containing:
                - entity_id: Entity ID
                - state: Current state object
                - entity_entry: Entity registry entry (optional)
                - device_entry: Device registry entry (optional)
                - area_name: Area name (optional)

        Returns:
            Dictionary with message and actions, or None if no suggestion
        """
        entity_id = device_context["entity_id"]
        state = device_context["state"]
        area_name = device_context.get("area_name")

        domain = entity_id.split(".")[0]
        name = state.name
        device_class = state.attributes.get("device_class")

        # Build location context
        location = f" in the {area_name}" if area_name else ""

        # Filter out test/temporary devices
        if any(
            keyword in name.lower()
            for keyword in ["test", "temp", "temporary", "demo", "example"]
        ):
            _LOGGER.debug("Skipping test/temporary device: %s", name)
            return None

        # Light suggestions
        if domain == "light":
            if any(
                keyword in name.lower()
                for keyword in ["outdoor", "patio", "front", "back", "garden", "yard"]
            ):
                return {
                    "message": f"Good day. I've noticed a new outdoor light: {name}{location}. Shall I create an automation to turn it on at sunset and off at sunrise?",
                    "actions": [
                        {"action": "create_sunset_automation", "label": "Yes, Please"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }
            else:
                return {
                    "message": f"A new light has been detected: {name}{location}. Would you like me to add it to your lighting dashboard?",
                    "actions": [
                        {"action": "add_to_dashboard", "label": "Add to Dashboard"},
                        {"action": "dismiss", "label": "No, Thank You"},
                    ],
                }

        # Switch suggestions
        elif domain == "switch":
            return {
                "message": f"New switch detected: {name}{location}. I'll monitor its usage to learn your preferences and suggest automations.",
                "actions": [{"action": "acknowledge", "label": "Very Well"}],
            }

        # Binary sensor suggestions (motion, door, window, etc.)
        elif domain == "binary_sensor":
            if device_class == "motion":
                return {
                    "message": f"A motion sensor has been added: {name}{location}. Would you like suggestions for lighting or security automations?",
                    "actions": [
                        {"action": "suggest_motion_automations", "label": "Show Ideas"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }
            elif device_class in ["door", "window", "opening"]:
                return {
                    "message": f"New {device_class} sensor detected: {name}{location}. Shall I monitor it for security alerts and notifications?",
                    "actions": [
                        {"action": "enable_security_monitoring", "label": "Yes, Please"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }
            elif device_class == "occupancy":
                return {
                    "message": f"Occupancy sensor added: {name}{location}. I can create automations for lights or climate control based on presence.",
                    "actions": [
                        {"action": "suggest_occupancy_automations", "label": "Show Options"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }

        # Sensor suggestions
        elif domain == "sensor":
            if device_class == "battery":
                return {
                    "message": f"Battery sensor detected: {name}. I shall monitor it and alert you when replacement is needed.",
                    "actions": [{"action": "acknowledge", "label": "Thank You"}],
                }
            elif device_class == "temperature":
                return {
                    "message": f"Temperature sensor added: {name}{location}. I'll track the baseline and alert you to unusual temperature changes.",
                    "actions": [{"action": "acknowledge", "label": "Very Good"}],
                }
            elif device_class in ["humidity", "moisture"]:
                return {
                    "message": f"{device_class.capitalize()} sensor detected: {name}{location}. Would you like alerts for unusual levels?",
                    "actions": [
                        {"action": "enable_humidity_alerts", "label": "Yes, Please"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }
            elif device_class == "power":
                return {
                    "message": f"Power sensor added: {name}{location}. I can track energy usage and suggest optimization opportunities.",
                    "actions": [
                        {"action": "enable_power_tracking", "label": "Enable Tracking"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }

        # Climate suggestions
        elif domain == "climate":
            return {
                "message": f"Climate control device detected: {name}{location}. I can learn your temperature preferences and create smart schedules.",
                "actions": [
                    {"action": "suggest_climate_automations", "label": "Show Ideas"},
                    {"action": "dismiss", "label": "Not Now"},
                ],
            }

        # Cover suggestions (blinds, shades, garage doors)
        elif domain == "cover":
            if "garage" in name.lower():
                return {
                    "message": f"Garage door detected: {name}. Shall I alert you if it remains open for an extended period?",
                    "actions": [
                        {"action": "enable_garage_alerts", "label": "Yes, Please"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }
            else:
                return {
                    "message": f"New cover detected: {name}{location}. I can create automations based on sun position or time of day.",
                    "actions": [
                        {"action": "suggest_cover_automations", "label": "Show Options"},
                        {"action": "dismiss", "label": "Not Now"},
                    ],
                }

        # Media player suggestions
        elif domain == "media_player":
            return {
                "message": f"Media player detected: {name}{location}. I'll monitor it to learn your entertainment patterns.",
                "actions": [{"action": "acknowledge", "label": "Very Well"}],
            }

        # Camera suggestions
        elif domain == "camera":
            return {
                "message": f"Camera added: {name}{location}. Would you like motion detection alerts or recording suggestions?",
                "actions": [
                    {"action": "suggest_camera_automations", "label": "Show Options"},
                    {"action": "dismiss", "label": "Not Now"},
                ],
            }

        # Lock suggestions
        elif domain == "lock":
            return {
                "message": f"Smart lock detected: {name}{location}. I can create security automations and monitor access patterns.",
                "actions": [
                    {"action": "enable_lock_monitoring", "label": "Enable Monitoring"},
                    {"action": "dismiss", "label": "Not Now"},
                ],
            }

        # Fan suggestions
        elif domain == "fan":
            return {
                "message": f"Fan detected: {name}{location}. Shall I create automations based on temperature or schedule?",
                "actions": [
                    {"action": "suggest_fan_automations", "label": "Show Ideas"},
                    {"action": "dismiss", "label": "Not Now"},
                ],
            }

        # Default for other device types
        return {
            "message": f"New device detected: {name}{location}. I'll monitor its usage to learn patterns and suggest automations.",
            "actions": [{"action": "acknowledge", "label": "Very Good"}],
        }

    async def _on_state_change(self, entity_id: str, old_state, new_state) -> None:
        """Handle state changes for pattern detection."""

        # Check for low battery
        if new_state.attributes.get("battery_level"):
            battery_level = new_state.attributes["battery_level"]
            if battery_level < 20 and (
                not old_state.attributes.get("battery_level")
                or old_state.attributes["battery_level"] >= 20
            ):
                await self._alert_low_battery(entity_id, battery_level)

        # Record pattern for learning
        await self._record_pattern(entity_id, old_state.state, new_state.state)

    async def _alert_low_battery(self, entity_id: str, battery_level: int) -> None:
        """Alert user about low battery."""
        state = self.hass.states.get(entity_id)
        if not state:
            return

        message = f"The {state.name} battery is at {battery_level}%. A replacement is advised."

        self.hass.bus.async_fire(
            EVENT_ALFRED_ALERT,
            {
                "title": "Battery Alert",
                "message": message,
                "entity_id": entity_id,
                "alert_type": "low_battery",
                "battery_level": battery_level,
            },
        )

        await self._send_notification(
            "Alfred: Battery Alert",
            message,
            {"entity_id": entity_id, "battery_level": battery_level},
        )

    async def _record_pattern(
        self, entity_id: str, old_state: str, new_state: str
    ) -> None:
        """Record state change pattern for learning."""
        # Initialize pattern storage for entity
        if entity_id not in self._patterns:
            self._patterns[entity_id] = []

        # Record the pattern
        self._patterns[entity_id].append({
            "timestamp": datetime.now(),
            "old_state": old_state,
            "new_state": new_state,
        })

        # Keep only last 100 patterns per entity
        if len(self._patterns[entity_id]) > 100:
            self._patterns[entity_id] = self._patterns[entity_id][-100:]

    async def _analyze_home_state(self) -> None:
        """Analyze current home state for insights."""
        _LOGGER.debug("Alfred analyzing home state")

        # Check for common issues
        await self._check_doors_windows()
        await self._check_climate_optimization()

    async def _check_doors_windows(self) -> None:
        """Check if doors/windows are in unusual state."""
        # Example: Garage door open for extended period
        for state in self.hass.states.async_all("cover"):
            if "garage" in state.name.lower() and state.state == "open":
                # Check if it's been open for more than 2 hours
                last_changed = state.last_changed
                if datetime.now() - last_changed > timedelta(hours=2):
                    message = f"I notice the {state.name} has been open for {int((datetime.now() - last_changed).total_seconds() / 3600)} hours. Shall I close it?"

                    self.hass.bus.async_fire(
                        EVENT_ALFRED_SUGGESTION,
                        {
                            "title": "Garage Door Alert",
                            "message": message,
                            "entity_id": state.entity_id,
                            "suggestion_type": "security",
                        },
                    )

    async def _check_climate_optimization(self) -> None:
        """Check for climate optimization opportunities."""
        # Check if alarm is armed and thermostat can be optimized
        alarm_states = [s for s in self.hass.states.async_all("alarm_control_panel")]
        climate_states = [s for s in self.hass.states.async_all("climate")]

        for alarm in alarm_states:
            if alarm.state == "armed_away":
                for climate in climate_states:
                    current_temp = climate.attributes.get("temperature")
                    if current_temp and current_temp > 21:  # 21°C threshold (metric system)
                        message = f"I see the house is empty and the {climate.name} is set to {current_temp}°C. Shall I adjust to 20°C for energy savings?"

                        self.hass.bus.async_fire(
                            EVENT_ALFRED_SUGGESTION,
                            {
                                "title": "Energy Optimization",
                                "message": message,
                                "entity_id": climate.entity_id,
                                "suggestion_type": "energy",
                            },
                        )

    async def _schedule_periodic_tasks(self) -> None:
        """Schedule periodic analysis tasks."""
        import async_timeout
        from homeassistant.helpers.event import async_track_time_interval

        # Run pattern analysis every 6 hours
        async def periodic_pattern_analysis(_):
            """Run pattern analysis periodically."""
            try:
                _LOGGER.info("Starting periodic pattern and correlation analysis")

                if not self._pattern_analyzer:
                    _LOGGER.warning("Pattern analyzer not initialized")
                    return

                async with async_timeout.timeout(300):  # 5 minute timeout
                    # Analyze common device domains for patterns
                    domains = ["light", "switch", "fan", "climate"]
                    patterns = await self._pattern_analyzer.analyze_all_entities(domains)

                    _LOGGER.info(
                        "Pattern analysis complete: %d entities with patterns",
                        len(patterns)
                    )

                    # Detect correlations between entities
                    correlations = await self._pattern_analyzer.detect_correlations(days=14)

                    _LOGGER.info(
                        "Correlation analysis complete: %d correlations detected",
                        len(correlations)
                    )

                    # Generate notifications for newly discovered patterns
                    await self._notify_new_patterns(patterns)

                    # Generate notifications for correlations
                    await self._notify_new_correlations(correlations)

            except Exception as err:
                _LOGGER.error("Error in periodic pattern analysis: %s", err)

        # Run home state analysis every 30 minutes
        async def periodic_home_analysis(_):
            """Run home state analysis periodically."""
            try:
                await self._analyze_home_state()
            except Exception as err:
                _LOGGER.error("Error in periodic home analysis: %s", err)

        # Schedule pattern analysis every 6 hours
        remove_pattern = async_track_time_interval(
            self.hass,
            periodic_pattern_analysis,
            timedelta(hours=6),
        )
        self._listeners.append(remove_pattern)

        # Schedule home analysis every 30 minutes
        remove_home = async_track_time_interval(
            self.hass,
            periodic_home_analysis,
            timedelta(minutes=30),
        )
        self._listeners.append(remove_home)

        # Run battery monitoring every 6 hours
        async def periodic_battery_monitoring(_):
            """Run battery monitoring periodically."""
            try:
                _LOGGER.info("Starting periodic battery monitoring")

                if not self._battery_manager:
                    _LOGGER.warning("Battery manager not initialized")
                    return

                async with async_timeout.timeout(300):  # 5 minute timeout
                    # Monitor all batteries
                    batteries = await self._battery_manager.monitor_all_batteries()

                    _LOGGER.info(
                        "Battery monitoring complete: %d batteries monitored",
                        len(batteries)
                    )

            except Exception as err:
                _LOGGER.error("Error in periodic battery monitoring: %s", err)

        # Schedule battery monitoring every 6 hours
        remove_battery = async_track_time_interval(
            self.hass,
            periodic_battery_monitoring,
            timedelta(hours=6),
        )
        self._listeners.append(remove_battery)

        # Run baseline calculation every 24 hours
        async def periodic_baseline_calculation(_):
            """Run baseline calculation periodically."""
            try:
                _LOGGER.info("Starting periodic baseline calculation")

                if not self._baseline_calculator:
                    _LOGGER.warning("Baseline calculator not initialized")
                    return

                async with async_timeout.timeout(600):  # 10 minute timeout
                    # Calculate baselines for all trackable entities
                    stats = await self._baseline_calculator.calculate_all_trackable_baselines(
                        observation_days=30
                    )

                    _LOGGER.info(
                        "Baseline calculation complete: %d entities, %d baselines established",
                        stats.get("entities_with_baselines", 0),
                        stats.get("baselines_calculated", 0),
                    )

                    # Fire event for new baselines
                    if stats.get("baselines_calculated", 0) > 0:
                        self.hass.bus.async_fire(
                            EVENT_ALFRED_SUGGESTION,
                            {
                                "type": "baselines_updated",
                                "entities_processed": stats.get("entities_processed", 0),
                                "baselines_calculated": stats.get("baselines_calculated", 0),
                                "entities_with_baselines": stats.get("entities_with_baselines", 0),
                            },
                        )

            except Exception as err:
                _LOGGER.error("Error in periodic baseline calculation: %s", err, exc_info=True)

        # Schedule baseline calculation every 24 hours
        remove_baseline = async_track_time_interval(
            self.hass,
            periodic_baseline_calculation,
            timedelta(hours=24),
        )
        self._listeners.append(remove_baseline)

        # Run runtime tracking updates every 60 seconds
        async def periodic_runtime_update(_):
            """Update runtime stats for all tracked devices."""
            try:
                if not self._runtime_tracker:
                    return

                # Runtime tracker handles updates internally
                # This is a placeholder for any additional runtime-related tasks
                # The actual runtime updates happen in RuntimeTracker's periodic task

            except Exception as err:
                _LOGGER.error("Error in periodic runtime update: %s", err)

        # Schedule runtime updates every 60 seconds
        remove_runtime = async_track_time_interval(
            self.hass,
            periodic_runtime_update,
            timedelta(seconds=60),
        )
        self._listeners.append(remove_runtime)

        # Run degradation detection every 6 hours
        async def periodic_degradation_analysis(_):
            """Analyze all devices for performance degradation."""
            try:
                if not self._degradation_detector:
                    return

                _LOGGER.info("Running periodic degradation analysis")

                stats = await self._degradation_detector.analyze_all_devices()

                _LOGGER.info(
                    "Degradation analysis complete: %d devices analyzed, %d degraded, %d alerts generated, %d restored",
                    stats.get("devices_analyzed", 0),
                    stats.get("degradation_detected", 0),
                    stats.get("alerts_generated", 0),
                    stats.get("devices_restored", 0),
                )

                # Fire event if degradation was detected
                if stats.get("alerts_generated", 0) > 0:
                    self.hass.bus.async_fire(
                        EVENT_ALFRED_ALERT,
                        {
                            "type": "degradation_detected",
                            "devices_affected": stats.get("alerts_generated", 0),
                            "devices_analyzed": stats.get("devices_analyzed", 0),
                        },
                    )

            except Exception as err:
                _LOGGER.error("Error in periodic degradation analysis: %s", err, exc_info=True)

        # Schedule degradation analysis every 6 hours
        remove_degradation = async_track_time_interval(
            self.hass,
            periodic_degradation_analysis,
            timedelta(hours=6),
        )
        self._listeners.append(remove_degradation)

        # Run periodic diagnosis for sustained degradation every 6 hours
        async def periodic_diagnosis_check(_):
            """Check for devices with sustained degradation and run diagnosis."""
            try:
                if not self._diagnosis_engine or not self._pattern_storage:
                    return

                _LOGGER.info("Running periodic diagnosis check")

                # Get active alerts
                alerts = await self._pattern_storage.get_active_alerts()

                diagnosed_count = 0
                for alert in alerts:
                    entity_id = alert["entity_id"]

                    # Only diagnose if:
                    # 1. Alert is older than 1 day
                    # 2. Severity is moderate or severe
                    # 3. No recent diagnosis exists

                    import homeassistant.util.dt as dt_util
                    alert_age = (dt_util.now() - alert["first_detected"]).days

                    if alert_age >= 1 and alert["severity"] in ["moderate", "severe"]:
                        # Check if diagnosis already exists
                        history = await self._pattern_storage.get_diagnosis_history(
                            entity_id,
                            limit=1
                        )

                        if not history or history[0]["diagnosis_date"] < alert["first_detected"]:
                            _LOGGER.info(
                                "Running periodic diagnosis for %s (alert age: %d days, severity: %s)",
                                entity_id,
                                alert_age,
                                alert["severity"]
                            )

                            # Get recent observations to build degradation report
                            if self._degradation_detector:
                                observations = await self._degradation_detector.get_recent_observations(
                                    entity_id,
                                    days=7
                                )

                                if observations:
                                    # Create degradation report from observations
                                    from .degradation_detector import DegradationReport
                                    latest = observations[0]

                                    degradation_report = DegradationReport(
                                        entity_id=entity_id,
                                        metric_name=latest["metric_name"],
                                        degradation_type=latest["degradation_type"],
                                        severity=latest["severity"],
                                        current_value=latest["current_value"],
                                        baseline_value=latest["baseline_value"],
                                        deviation_percentage=latest["deviation_percentage"],
                                        z_score=latest["z_score"],
                                        statistical_significance=True,
                                        trend_type=latest.get("trend_type"),
                                        degradation_rate=latest.get("degradation_rate"),
                                        days_degraded=len(observations),
                                        confidence=0.85,
                                        recommendation="Periodic diagnosis",
                                        timestamp=dt_util.now(),
                                    )

                                    # Run diagnosis
                                    try:
                                        await self._diagnosis_engine.diagnose_device_failure(
                                            entity_id,
                                            degradation_report,
                                        )
                                        diagnosed_count += 1

                                    except Exception as err:
                                        _LOGGER.error(
                                            "Periodic diagnosis failed for %s: %s",
                                            entity_id,
                                            err
                                        )

                _LOGGER.info(
                    "Periodic diagnosis complete: %d devices diagnosed",
                    diagnosed_count
                )

            except Exception as err:
                _LOGGER.error("Error in periodic diagnosis check: %s", err, exc_info=True)

        # Schedule periodic diagnosis every 6 hours
        remove_periodic_diagnosis = async_track_time_interval(
            self.hass,
            periodic_diagnosis_check,
            timedelta(hours=6),
        )
        self._listeners.append(remove_periodic_diagnosis)

        # Run energy consumption analysis every 24 hours
        async def periodic_energy_analysis(_):
            """Analyze energy consumption patterns periodically."""
            try:
                if not self._energy_analyzer:
                    return

                _LOGGER.info("Running periodic energy consumption analysis")

                # Discover and analyze all energy sensors
                sensors = await self._energy_analyzer.discover_energy_sensors()

                if not sensors:
                    _LOGGER.info("No energy sensors found for analysis")
                    return

                analyzed_count = 0
                patterns_detected = 0
                insights_generated = 0

                # Analyze top 5 energy sensors (to avoid overload)
                for sensor_id in sensors[:5]:
                    try:
                        # Analyze consumption patterns
                        patterns = await self._energy_analyzer.analyze_consumption_patterns(
                            sensor_id,
                            lookback_days=30
                        )

                        if patterns:
                            patterns_detected += 1

                        # Detect unusual consumption
                        spikes = await self._energy_analyzer.detect_consumption_spikes(
                            sensor_id,
                            lookback_days=7
                        )

                        if spikes and len(spikes) > 0:
                            insights_generated += 1
                            # Generate insight notification for unusual consumption
                            _LOGGER.info(
                                "Unusual energy consumption detected for %s: %d spikes in last 7 days",
                                sensor_id,
                                len(spikes)
                            )

                        analyzed_count += 1

                    except Exception as err:
                        _LOGGER.debug("Error analyzing energy sensor %s: %s", sensor_id, err)

                _LOGGER.info(
                    "Energy analysis complete: %d sensors analyzed, %d patterns detected, %d insights generated",
                    analyzed_count,
                    patterns_detected,
                    insights_generated
                )

                # Fire event if insights were generated
                if insights_generated > 0:
                    self.hass.bus.async_fire(
                        EVENT_ALFRED_SUGGESTION,
                        {
                            "type": "energy_insights",
                            "sensors_analyzed": analyzed_count,
                            "patterns_detected": patterns_detected,
                            "insights_generated": insights_generated,
                        },
                    )

            except Exception as err:
                _LOGGER.error("Error in periodic energy analysis: %s", err, exc_info=True)

        # Schedule energy analysis every 24 hours
        remove_energy = async_track_time_interval(
            self.hass,
            periodic_energy_analysis,
            timedelta(hours=24),
        )
        self._listeners.append(remove_energy)

        # Schedule pipe freeze prediction (every 6 hours during cold months)
        async def periodic_freeze_prediction(_):
            """Run periodic pipe freeze prediction."""
            try:
                if hasattr(self, "_freeze_predictor"):
                    prediction = await self._freeze_predictor.predict_freeze_risk(forecast_days=3)
                    if prediction.get("severity") in ["high", "critical"]:
                        _LOGGER.warning(
                            "Pipe freeze risk detected: %s - %s",
                            prediction.get("severity"),
                            prediction.get("message"),
                        )
            except Exception as err:
                _LOGGER.error("Error in periodic freeze prediction: %s", err, exc_info=True)

        remove_freeze = async_track_time_interval(
            self.hass,
            periodic_freeze_prediction,
            timedelta(hours=6),
        )
        self._listeners.append(remove_freeze)

        _LOGGER.info("Periodic tasks scheduled: pattern analysis (6h), home analysis (30m), baseline calculation (24h), runtime updates (60s), degradation analysis (6h), diagnosis check (6h), energy analysis (24h), freeze prediction (6h)")

        # Run initial pattern analysis after 5 minutes
        async def initial_pattern_analysis(_):
            """Run initial pattern analysis on startup."""
            await periodic_pattern_analysis(None)

        remove_initial = async_track_time_interval(
            self.hass,
            initial_pattern_analysis,
            timedelta(minutes=5),
        )
        self._listeners.append(remove_initial)

    async def _send_notification(
        self, title: str, message: str, data: dict[str, Any] | None = None
    ) -> None:
        """Send notification to user."""
        await self.hass.services.async_call(
            "persistent_notification",
            "create",
            {
                "title": title,
                "message": message,
                "notification_id": f"alfred_{datetime.now().timestamp()}",
            },
        )

    async def _notify_new_patterns(self, patterns: dict[str, list[dict[str, Any]]]) -> None:
        """
        Generate notifications for newly discovered patterns.

        Args:
            patterns: Dictionary mapping entity_id to list of patterns
        """
        for entity_id, entity_patterns in patterns.items():
            # Get entity state for friendly name
            state = self.hass.states.get(entity_id)
            if not state:
                continue

            name = state.name

            # Group patterns by type
            time_on_patterns = [p for p in entity_patterns if p["type"] == "time_based_on"]
            time_off_patterns = [p for p in entity_patterns if p["type"] == "time_based_off"]
            duration_patterns = [p for p in entity_patterns if p["type"] == "duration"]
            weekday_patterns = [p for p in entity_patterns if p["type"] in ["weekday_dominant", "weekend_dominant"]]

            # Generate notifications for high-confidence patterns
            for pattern in time_on_patterns:
                if pattern["confidence"] >= 0.80:  # 80%+ confidence
                    hour = pattern["hour"]
                    minute = pattern["minute"]
                    confidence = pattern["confidence"] * 100

                    if pattern.get("weekday_specific") and pattern.get("weekdays"):
                        # Determine if weekdays or weekends
                        weekday_count = sum(1 for w in pattern["weekdays"] if w < 5)
                        weekend_count = len(pattern["weekdays"]) - weekday_count

                        if weekday_count > weekend_count:
                            day_desc = "on weekdays"
                        else:
                            day_desc = "on weekends"
                    else:
                        day_desc = "daily"

                    message = (
                        f"I've observed a pattern: {name} turns on {day_desc} around {hour:02d}:{minute:02d}. "
                        f"This pattern has {confidence:.0f}% consistency. Shall I create an automation for this?"
                    )

                    # Fire suggestion event (DISABLED - notifications removed per user request)
                    # self.hass.bus.async_fire(
                    #     EVENT_ALFRED_SUGGESTION,
                    #     {
                    #         "title": "Pattern Detected",
                    #         "message": message,
                    #         "entity_id": entity_id,
                    #         "suggestion_type": "time_pattern",
                    #         "pattern": pattern,
                    #         "actions": [
                    #             {"action": "create_pattern_automation", "label": "Create Automation"},
                    #             {"action": "dismiss", "label": "Not Now"},
                    #         ],
                    #     },
                    # )

                    # Send notification (DISABLED - notifications removed per user request)
                    # await self._send_notification(
                    #     "Alfred: Pattern Detected",
                    #     message,
                    #     {"entity_id": entity_id, "pattern": pattern},
                    # )

                    _LOGGER.info(
                        "Pattern detected (notification disabled) for %s: %s at %02d:%02d (%.0f%% confidence)",
                        entity_id,
                        day_desc,
                        hour,
                        minute,
                        confidence,
                    )

            # Notify about duration patterns (DISABLED - notifications removed per user request)
            for pattern in duration_patterns:
                if pattern["confidence"] >= 0.80:
                    duration_min = pattern["avg_duration_seconds"] / 60
                    confidence = pattern["confidence"] * 100

                    message = (
                        f"I've noticed {name} typically runs for {duration_min:.0f} minutes. "
                        f"This pattern is {confidence:.0f}% consistent. Would you like a reminder if it exceeds this duration?"
                    )

                    # self.hass.bus.async_fire(
                    #     EVENT_ALFRED_SUGGESTION,
                    #     {
                    #         "title": "Duration Pattern",
                    #         "message": message,
                    #         "entity_id": entity_id,
                    #         "suggestion_type": "duration_pattern",
                    #         "pattern": pattern,
                    #         "actions": [
                    #             {"action": "enable_duration_alert", "label": "Yes, Please"},
                    #             {"action": "dismiss", "label": "Not Now"},
                    #         ],
                    #     },
                    # )

                    _LOGGER.info(
                        "Duration pattern detected (notification disabled) for %s: %.0f minutes (%.0f%% confidence)",
                        entity_id,
                        duration_min,
                        confidence,
                    )

    async def _notify_new_correlations(self, correlations: list[dict[str, Any]]) -> None:
        """
        Generate notifications for newly discovered correlations.

        Args:
            correlations: List of correlation dictionaries
        """
        # Only notify for high-strength correlations (80%+)
        for correlation in correlations:
            if correlation["strength"] < 0.80:
                continue

            # Get entity names
            state_a = self.hass.states.get(correlation["entity_a"])
            state_b = self.hass.states.get(correlation["entity_b"])

            if not state_a or not state_b:
                continue

            name_a = state_a.name
            name_b = state_b.name
            strength = correlation["strength"] * 100
            corr_type = correlation["type"]

            # Generate message based on correlation type
            if corr_type == "sequential":
                offset = correlation.get("avg_time_offset_seconds", 0)
                message = (
                    f"I've detected a pattern: When {name_a} activates, {name_b} turns on "
                    f"{offset} seconds later. This occurs {strength:.0f}% of the time. "
                    f"Shall I create an automation for this?"
                )
            elif corr_type == "simultaneous":
                message = (
                    f"I've observed that {name_a} and {name_b} activate together "
                    f"{strength:.0f}% of the time. Would you like me to link them in an automation?"
                )
            elif corr_type == "inverse":
                message = (
                    f"When {name_a} turns on, {name_b} turns off {strength:.0f}% of the time. "
                    f"This appears to be an intentional pattern. Shall I automate it?"
                )
            else:
                continue

            # Fire suggestion event (DISABLED - notifications removed per user request)
            # self.hass.bus.async_fire(
            #     EVENT_ALFRED_SUGGESTION,
            #     {
            #         "title": "Device Correlation Detected",
            #         "message": message,
            #         "entity_id_a": correlation["entity_a"],
            #         "entity_id_b": correlation["entity_b"],
            #         "suggestion_type": "correlation",
            #         "correlation": correlation,
            #         "actions": [
            #             {"action": "create_correlation_automation", "label": "Create Automation"},
            #             {"action": "dismiss", "label": "Not Now"},
            #         ],
            #     },
            # )

            # Send notification (DISABLED - notifications removed per user request)
            # await self._send_notification(
            #     "Alfred: Device Correlation",
            #     message,
            #     {"correlation": correlation},
            # )

            _LOGGER.info(
                "Correlation detected (notification disabled): %s %s %s (%.0f%% strength)",
                correlation["entity_a"],
                "→" if corr_type == "sequential" else "↔" if corr_type == "simultaneous" else "→!",
                correlation["entity_b"],
                strength,
            )

    async def _load_patterns(self) -> None:
        """Load historical patterns from storage."""
        try:
            # Get database stats
            stats = await self._pattern_storage.get_database_stats()
            _LOGGER.info(
                "Pattern storage initialized: %d patterns, %d baselines, %d correlations",
                stats.get("patterns_count", 0),
                stats.get("baselines_count", 0),
                stats.get("correlations_count", 0),
            )
        except Exception as err:
            _LOGGER.error("Error loading patterns: %s", err)

    async def _save_patterns(self) -> None:
        """Save patterns to storage."""
        # Patterns are now saved immediately to SQLite database
        # This method kept for compatibility
        _LOGGER.debug("Patterns automatically saved to database")

    async def get_entity_usage_history(
        self,
        entity_id: str,
        days: int = 7,
    ) -> list:
        """
        Get usage history for an entity over the specified number of days.

        This is a helper method that demonstrates using the historical data access layer.

        Args:
            entity_id: Entity ID to query (e.g., "light.living_room")
            days: Number of days to look back (default: 7)

        Returns:
            List of state changes, or empty list if historical data unavailable

        Example:
            history = await engine.get_entity_usage_history("light.living_room", days=7)
            on_count = len([s for s in history if s.state == "on"])
        """
        if not self._historical_data.is_available():
            _LOGGER.warning(
                "Cannot get usage history for %s - recorder not available",
                entity_id,
            )
            return []

        try:
            start_time = datetime.now() - timedelta(days=days)
            states = await self._historical_data.get_entity_history(
                entity_id,
                start_time,
                minimal_response=False,
            )

            _LOGGER.info(
                "Retrieved %d state changes for %s over last %d days",
                len(states),
                entity_id,
                days,
            )

            return states

        except Exception as err:
            _LOGGER.error(
                "Error getting usage history for %s: %s",
                entity_id,
                err,
            )
            return []
