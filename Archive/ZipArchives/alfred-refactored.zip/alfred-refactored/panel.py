"""Alfred Digital Butler custom panel."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components import frontend, panel_custom
from homeassistant.core import HomeAssistant

_LOGGER = logging.getLogger(__name__)

ALFRED_PANEL_URL = "/api/panel_custom/alfred"


async def async_register_panel(hass: HomeAssistant) -> None:
    """Register the Alfred custom panel."""

    # Register the panel
    await panel_custom.async_register_panel(
        hass,
        frontend_url_path="alfred",
        webcomponent_name="alfred-panel",
        sidebar_title="Alfred",
        sidebar_icon="mdi:bell",  # Bell shape resembles bowler hat
        module_url="/api/alfred/panel.js",
        embed_iframe=False,
        require_admin=False,
        config={},
    )

    _LOGGER.info("Alfred panel registered")


async def async_unregister_panel(hass: HomeAssistant) -> None:
    """Unregister the Alfred custom panel."""
    try:
        await hass.async_add_executor_job(
            hass.components.frontend.async_remove_panel, "alfred"
        )
    except Exception as e:
        _LOGGER.warning(f"Error unregistering panel: {e}")
    _LOGGER.info("Alfred panel unregistered")
