"""Pattern analysis engine for Alfred Digital Butler."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any
from collections import defaultdict
import statistics

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .historical_data import HistoricalDataAccess
from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class PatternAnalyzer:
    """Analyze entity state changes to detect time-based patterns."""

    def __init__(
        self,
        hass: HomeAssistant,
        historical_data: HistoricalDataAccess,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize the pattern analyzer."""
        self.hass = hass
        self._historical_data = historical_data
        self._pattern_storage = pattern_storage
        self._min_days_for_pattern = 7  # Minimum observation period
        self._min_confidence = 0.70  # 70% confidence threshold
        self._time_tolerance_minutes = 15  # ±15 minute window

    async def analyze_entity_patterns(
        self, entity_id: str, days: int = 14
    ) -> list[dict[str, Any]]:
        """
        Analyze historical data for an entity to detect time-based patterns.

        Args:
            entity_id: Entity to analyze
            days: Number of days of history to analyze (default: 14)

        Returns:
            List of detected patterns with confidence scores
        """
        if days < self._min_days_for_pattern:
            _LOGGER.warning(
                "Cannot analyze patterns for %s: need at least %d days, got %d",
                entity_id,
                self._min_days_for_pattern,
                days,
            )
            return []

        # Get historical data
        start_time = dt_util.now() - timedelta(days=days)
        states = await self._historical_data.get_entity_history(
            entity_id, start_time, minimal_response=False
        )

        if not states:
            _LOGGER.debug("No historical data for %s", entity_id)
            return []

        _LOGGER.info(
            "Analyzing %d state changes for %s over %d days",
            len(states),
            entity_id,
            days,
        )

        # Detect different pattern types
        patterns = []

        # Time-of-day patterns (ON/OFF at specific times)
        time_patterns = await self._detect_time_patterns(entity_id, states, days)
        patterns.extend(time_patterns)

        # Weekday vs weekend patterns
        weekday_patterns = await self._detect_weekday_weekend_patterns(
            entity_id, states, days
        )
        patterns.extend(weekday_patterns)

        # Duration patterns (how long device stays on)
        duration_patterns = await self._detect_duration_patterns(entity_id, states)
        patterns.extend(duration_patterns)

        # Filter by confidence threshold
        reliable_patterns = [
            p for p in patterns if p["confidence"] >= self._min_confidence
        ]

        _LOGGER.info(
            "Found %d patterns for %s (%d above %.0f%% confidence)",
            len(patterns),
            entity_id,
            len(reliable_patterns),
            self._min_confidence * 100,
        )

        # Save patterns to database
        for pattern in reliable_patterns:
            await self._save_pattern(entity_id, pattern)

        return reliable_patterns

    async def _detect_time_patterns(
        self, entity_id: str, states: list, days: int
    ) -> list[dict[str, Any]]:
        """
        Detect time-of-day patterns (device turns on/off at specific times).

        Args:
            entity_id: Entity being analyzed
            states: List of historical states
            days: Number of days analyzed

        Returns:
            List of time-based patterns
        """
        patterns = []

        # Group state changes by hour
        on_events_by_hour = defaultdict(list)
        off_events_by_hour = defaultdict(list)

        previous_state = None
        for state in states:
            # Detect transitions
            if previous_state:
                # ON transition
                if previous_state.state in ["off", "unavailable"] and state.state == "on":
                    hour = state.last_changed.hour
                    minute = state.last_changed.minute
                    weekday = state.last_changed.weekday()
                    on_events_by_hour[hour].append({
                        "time": state.last_changed,
                        "minute": minute,
                        "weekday": weekday,
                    })

                # OFF transition
                elif previous_state.state == "on" and state.state in ["off", "unavailable"]:
                    hour = state.last_changed.hour
                    minute = state.last_changed.minute
                    weekday = state.last_changed.weekday()
                    off_events_by_hour[hour].append({
                        "time": state.last_changed,
                        "minute": minute,
                        "weekday": weekday,
                    })

            previous_state = state

        # Analyze ON patterns
        for hour, events in on_events_by_hour.items():
            if len(events) >= self._min_days_for_pattern:
                # Calculate average minute within the hour
                avg_minute = statistics.mean([e["minute"] for e in events])

                # Calculate confidence (how often it occurs)
                # Total opportunities = days analyzed
                confidence = len(events) / days

                if confidence >= self._min_confidence:
                    # Check if it's specific to certain weekdays
                    weekdays = [e["weekday"] for e in events]
                    is_weekday_specific = self._is_weekday_pattern(weekdays)

                    pattern = {
                        "type": "time_based_on",
                        "hour": hour,
                        "minute": int(avg_minute),
                        "confidence": confidence,
                        "occurrences": len(events),
                        "days_analyzed": days,
                        "weekday_specific": is_weekday_specific,
                        "weekdays": weekdays if is_weekday_specific else None,
                    }
                    patterns.append(pattern)

                    _LOGGER.debug(
                        "Found ON pattern for %s: %02d:%02d (%.0f%% confidence, %d occurrences)",
                        entity_id,
                        hour,
                        int(avg_minute),
                        confidence * 100,
                        len(events),
                    )

        # Analyze OFF patterns
        for hour, events in off_events_by_hour.items():
            if len(events) >= self._min_days_for_pattern:
                avg_minute = statistics.mean([e["minute"] for e in events])
                confidence = len(events) / days

                if confidence >= self._min_confidence:
                    weekdays = [e["weekday"] for e in events]
                    is_weekday_specific = self._is_weekday_pattern(weekdays)

                    pattern = {
                        "type": "time_based_off",
                        "hour": hour,
                        "minute": int(avg_minute),
                        "confidence": confidence,
                        "occurrences": len(events),
                        "days_analyzed": days,
                        "weekday_specific": is_weekday_specific,
                        "weekdays": weekdays if is_weekday_specific else None,
                    }
                    patterns.append(pattern)

                    _LOGGER.debug(
                        "Found OFF pattern for %s: %02d:%02d (%.0f%% confidence, %d occurrences)",
                        entity_id,
                        hour,
                        int(avg_minute),
                        confidence * 100,
                        len(events),
                    )

        return patterns

    async def _detect_weekday_weekend_patterns(
        self, entity_id: str, states: list, days: int
    ) -> list[dict[str, Any]]:
        """
        Detect weekday vs weekend usage patterns.

        Args:
            entity_id: Entity being analyzed
            states: List of historical states
            days: Number of days analyzed

        Returns:
            List of weekday/weekend patterns
        """
        patterns = []

        weekday_on_count = 0
        weekend_on_count = 0
        weekday_total = 0
        weekend_total = 0

        # Group by weekday vs weekend
        previous_date = None
        for state in states:
            current_date = state.last_changed.date()

            # Count unique days
            if previous_date != current_date:
                if state.last_changed.weekday() < 5:  # Monday-Friday
                    weekday_total += 1
                else:  # Saturday-Sunday
                    weekend_total += 1
                previous_date = current_date

            # Count ON states
            if state.state == "on":
                if state.last_changed.weekday() < 5:
                    weekday_on_count += 1
                else:
                    weekend_on_count += 1

        # Calculate weekday vs weekend usage difference
        if weekday_total > 0 and weekend_total > 0:
            weekday_usage = weekday_on_count / weekday_total
            weekend_usage = weekend_on_count / weekend_total

            # Significant difference threshold: 50% or more
            if abs(weekday_usage - weekend_usage) > 0.5:
                if weekday_usage > weekend_usage:
                    pattern_type = "weekday_dominant"
                    confidence = weekday_usage / (weekday_usage + weekend_usage)
                else:
                    pattern_type = "weekend_dominant"
                    confidence = weekend_usage / (weekday_usage + weekend_usage)

                pattern = {
                    "type": pattern_type,
                    "weekday_usage": weekday_usage,
                    "weekend_usage": weekend_usage,
                    "confidence": confidence,
                    "weekday_on_count": weekday_on_count,
                    "weekend_on_count": weekend_on_count,
                }
                patterns.append(pattern)

                _LOGGER.debug(
                    "Found %s pattern for %s: weekday=%.1f%%, weekend=%.1f%% (%.0f%% confidence)",
                    pattern_type,
                    entity_id,
                    weekday_usage * 100,
                    weekend_usage * 100,
                    confidence * 100,
                )

        return patterns

    async def _detect_duration_patterns(
        self, entity_id: str, states: list
    ) -> list[dict[str, Any]]:
        """
        Detect how long device typically stays on.

        Args:
            entity_id: Entity being analyzed
            states: List of historical states

        Returns:
            List of duration patterns
        """
        patterns = []
        durations = []

        on_time = None
        for state in states:
            if state.state == "on" and on_time is None:
                on_time = state.last_changed
            elif state.state in ["off", "unavailable"] and on_time:
                duration = (state.last_changed - on_time).total_seconds()
                durations.append(duration)
                on_time = None

        if len(durations) >= self._min_days_for_pattern:
            avg_duration = statistics.mean(durations)
            std_dev = statistics.stdev(durations) if len(durations) > 1 else 0

            # High consistency if std_dev is less than 30% of mean
            consistency = 1.0 - min(std_dev / avg_duration, 1.0) if avg_duration > 0 else 0

            if consistency >= 0.5:  # At least 50% consistent
                pattern = {
                    "type": "duration",
                    "avg_duration_seconds": int(avg_duration),
                    "std_dev_seconds": int(std_dev),
                    "confidence": consistency,
                    "sample_count": len(durations),
                }
                patterns.append(pattern)

                _LOGGER.debug(
                    "Found duration pattern for %s: %.0f min (±%.0f min, %.0f%% consistency)",
                    entity_id,
                    avg_duration / 60,
                    std_dev / 60,
                    consistency * 100,
                )

        return patterns

    def _is_weekday_pattern(self, weekdays: list[int]) -> bool:
        """
        Determine if pattern is specific to weekdays or weekends.

        Args:
            weekdays: List of weekday integers (0=Monday, 6=Sunday)

        Returns:
            True if pattern is weekday/weekend specific
        """
        weekday_count = sum(1 for w in weekdays if w < 5)
        weekend_count = sum(1 for w in weekdays if w >= 5)

        total = len(weekdays)
        if total == 0:
            return False

        # If 80%+ are weekdays or weekends, it's specific
        weekday_ratio = weekday_count / total
        weekend_ratio = weekend_count / total

        return weekday_ratio >= 0.8 or weekend_ratio >= 0.8

    async def _save_pattern(self, entity_id: str, pattern: dict[str, Any]) -> None:
        """
        Save detected pattern to database.

        Args:
            entity_id: Entity the pattern belongs to
            pattern: Pattern dictionary
        """
        try:
            # Build pattern data JSON
            pattern_data = {
                k: v for k, v in pattern.items() if k not in ["type", "confidence"]
            }

            await self._pattern_storage.save_pattern(
                entity_id=entity_id,
                pattern_type=pattern["type"],
                pattern_data=pattern_data,
                confidence=pattern["confidence"],
            )

            _LOGGER.debug(
                "Saved %s pattern for %s (%.0f%% confidence)",
                pattern["type"],
                entity_id,
                pattern["confidence"] * 100,
            )

        except Exception as err:
            _LOGGER.error("Error saving pattern for %s: %s", entity_id, err)

    async def analyze_all_entities(self, domains: list[str] | None = None) -> dict[str, list]:
        """
        Analyze patterns for all entities (or specific domains).

        Args:
            domains: Optional list of domains to analyze (e.g., ['light', 'switch'])

        Returns:
            Dictionary mapping entity_id to list of patterns
        """
        all_patterns = {}

        # Get all entities
        if domains:
            entities = []
            for domain in domains:
                entities.extend(self.hass.states.async_all(domain))
        else:
            # Default domains for pattern analysis
            default_domains = ["light", "switch", "fan", "climate", "media_player"]
            entities = []
            for domain in default_domains:
                entities.extend(self.hass.states.async_all(domain))

        _LOGGER.info("Analyzing patterns for %d entities", len(entities))

        for state in entities:
            entity_id = state.entity_id

            # Skip disabled entities
            if state.state == "unavailable":
                continue

            try:
                patterns = await self.analyze_entity_patterns(entity_id, days=14)
                if patterns:
                    all_patterns[entity_id] = patterns

            except Exception as err:
                _LOGGER.error("Error analyzing patterns for %s: %s", entity_id, err)

        _LOGGER.info(
            "Pattern analysis complete: %d entities with patterns", len(all_patterns)
        )

        return all_patterns

    async def detect_correlations(
        self, entity_pairs: list[tuple[str, str]] | None = None, days: int = 14
    ) -> list[dict[str, Any]]:
        """
        Detect correlations between entity pairs.

        Args:
            entity_pairs: Optional list of (entity_a, entity_b) tuples to analyze
                         If None, will analyze common entity pairs
            days: Number of days of history to analyze (default: 14)

        Returns:
            List of detected correlations with strength scores
        """
        if days < self._min_days_for_pattern:
            _LOGGER.warning(
                "Cannot detect correlations: need at least %d days, got %d",
                self._min_days_for_pattern,
                days,
            )
            return []

        correlations = []

        # If no pairs specified, generate common pairs
        if not entity_pairs:
            entity_pairs = await self._generate_entity_pairs()

        _LOGGER.info(
            "Analyzing correlations for %d entity pairs over %d days",
            len(entity_pairs),
            days,
        )

        for entity_a, entity_b in entity_pairs:
            try:
                pair_correlations = await self._analyze_entity_pair(
                    entity_a, entity_b, days
                )
                correlations.extend(pair_correlations)

            except Exception as err:
                _LOGGER.error(
                    "Error analyzing correlation between %s and %s: %s",
                    entity_a,
                    entity_b,
                    err,
                )

        # Filter by minimum confidence
        reliable_correlations = [
            c for c in correlations if c["strength"] >= self._min_confidence
        ]

        _LOGGER.info(
            "Found %d correlations (%d above %.0f%% strength)",
            len(correlations),
            len(reliable_correlations),
            self._min_confidence * 100,
        )

        # Save correlations to database
        for correlation in reliable_correlations:
            await self._save_correlation(correlation)

        return reliable_correlations

    async def _generate_entity_pairs(self) -> list[tuple[str, str]]:
        """
        Generate common entity pairs to analyze for correlations.

        Returns:
            List of (entity_a, entity_b) tuples
        """
        pairs = []

        # Get all lights and binary_sensors (motion, door, etc.)
        lights = [s.entity_id for s in self.hass.states.async_all("light")]
        binary_sensors = [s.entity_id for s in self.hass.states.async_all("binary_sensor")]
        switches = [s.entity_id for s in self.hass.states.async_all("switch")]

        # Common correlation patterns:
        # 1. Binary sensors (motion, door) → Lights
        for sensor in binary_sensors:
            for light in lights:
                pairs.append((sensor, light))

        # 2. Binary sensors → Switches
        for sensor in binary_sensors:
            for switch in switches:
                pairs.append((sensor, switch))

        # 3. Light → Light (room lighting patterns)
        for i, light_a in enumerate(lights):
            for light_b in lights[i + 1:]:
                pairs.append((light_a, light_b))

        _LOGGER.debug("Generated %d entity pairs for correlation analysis", len(pairs))

        return pairs

    async def _analyze_entity_pair(
        self, entity_a: str, entity_b: str, days: int
    ) -> list[dict[str, Any]]:
        """
        Analyze a specific entity pair for correlations.

        Args:
            entity_a: First entity ID
            entity_b: Second entity ID
            days: Number of days to analyze

        Returns:
            List of detected correlations
        """
        correlations = []

        # Get historical data for both entities
        start_time = dt_util.now() - timedelta(days=days)

        states_a = await self._historical_data.get_entity_history(
            entity_a, start_time, minimal_response=False
        )
        states_b = await self._historical_data.get_entity_history(
            entity_b, start_time, minimal_response=False
        )

        if not states_a or not states_b:
            return []

        # Detect sequential patterns (A → B)
        sequential = await self._detect_sequential_correlation(
            entity_a, entity_b, states_a, states_b, days
        )
        if sequential:
            correlations.append(sequential)

        # Detect simultaneous patterns (A ↔ B)
        simultaneous = await self._detect_simultaneous_correlation(
            entity_a, entity_b, states_a, states_b, days
        )
        if simultaneous:
            correlations.append(simultaneous)

        # Detect inverse patterns (A → !B)
        inverse = await self._detect_inverse_correlation(
            entity_a, entity_b, states_a, states_b, days
        )
        if inverse:
            correlations.append(inverse)

        return correlations

    async def _detect_sequential_correlation(
        self,
        entity_a: str,
        entity_b: str,
        states_a: list,
        states_b: list,
        days: int,
    ) -> dict[str, Any] | None:
        """
        Detect if entity B turns on shortly after entity A (A → B).

        Args:
            entity_a: First entity ID
            entity_b: Second entity ID
            states_a: Historical states for entity A
            states_b: Historical states for entity B
            days: Number of days analyzed

        Returns:
            Correlation dict if detected, None otherwise
        """
        # Time window to check for sequential activation (5 minutes)
        time_window = timedelta(minutes=5)

        # Track when A turns on
        a_on_events = []
        previous_state = None
        for state in states_a:
            if previous_state and previous_state.state in ["off", "unavailable"]:
                if state.state == "on":
                    a_on_events.append(state.last_changed)
            previous_state = state

        if len(a_on_events) < 10:  # Minimum 10 occurrences
            return None

        # Check how many times B turns on within time window after A
        b_follows_a = 0
        time_offsets = []

        for a_time in a_on_events:
            # Find closest B ON event after A within time window
            for state_b in states_b:
                if state_b.state == "on":
                    time_diff = (state_b.last_changed - a_time).total_seconds()
                    if 0 < time_diff <= time_window.total_seconds():
                        b_follows_a += 1
                        time_offsets.append(time_diff)
                        break  # Count only first occurrence

        if b_follows_a < 10:  # Minimum 10 occurrences
            return None

        # Calculate correlation strength
        strength = b_follows_a / len(a_on_events)

        if strength >= self._min_confidence:
            avg_offset = statistics.mean(time_offsets) if time_offsets else 0

            return {
                "type": "sequential",
                "entity_a": entity_a,
                "entity_b": entity_b,
                "strength": strength,
                "occurrences": b_follows_a,
                "total_opportunities": len(a_on_events),
                "avg_time_offset_seconds": int(avg_offset),
                "description": f"{entity_b} turns on {int(avg_offset)}s after {entity_a}",
            }

        return None

    async def _detect_simultaneous_correlation(
        self,
        entity_a: str,
        entity_b: str,
        states_a: list,
        states_b: list,
        days: int,
    ) -> dict[str, Any] | None:
        """
        Detect if entities turn on/off at the same time (A ↔ B).

        Args:
            entity_a: First entity ID
            entity_b: Second entity ID
            states_a: Historical states for entity A
            states_b: Historical states for entity B
            days: Number of days analyzed

        Returns:
            Correlation dict if detected, None otherwise
        """
        # Time window for "simultaneous" (30 seconds)
        time_window = timedelta(seconds=30)

        # Track ON events for both
        a_on_events = [
            s.last_changed
            for s in states_a
            if s.state == "on"
        ]
        b_on_events = [
            s.last_changed
            for s in states_b
            if s.state == "on"
        ]

        if len(a_on_events) < 10 or len(b_on_events) < 10:
            return None

        # Count simultaneous activations
        simultaneous_count = 0
        for a_time in a_on_events:
            for b_time in b_on_events:
                if abs((a_time - b_time).total_seconds()) <= time_window.total_seconds():
                    simultaneous_count += 1
                    break

        if simultaneous_count < 10:
            return None

        # Calculate strength
        strength = simultaneous_count / len(a_on_events)

        if strength >= self._min_confidence:
            return {
                "type": "simultaneous",
                "entity_a": entity_a,
                "entity_b": entity_b,
                "strength": strength,
                "occurrences": simultaneous_count,
                "total_opportunities": len(a_on_events),
                "avg_time_offset_seconds": 0,
                "description": f"{entity_a} and {entity_b} turn on together",
            }

        return None

    async def _detect_inverse_correlation(
        self,
        entity_a: str,
        entity_b: str,
        states_a: list,
        states_b: list,
        days: int,
    ) -> dict[str, Any] | None:
        """
        Detect if B turns off when A turns on (A → !B).

        Args:
            entity_a: First entity ID
            entity_b: Second entity ID
            states_a: Historical states for entity A
            states_b: Historical states for entity B
            days: Number of days analyzed

        Returns:
            Correlation dict if detected, None otherwise
        """
        time_window = timedelta(minutes=5)

        # Track when A turns on
        a_on_events = [
            s.last_changed
            for s in states_a
            if s.state == "on"
        ]

        if len(a_on_events) < 10:
            return None

        # Check how many times B turns off within time window after A turns on
        b_turns_off_count = 0

        for a_time in a_on_events:
            for state_b in states_b:
                if state_b.state in ["off", "unavailable"]:
                    time_diff = (state_b.last_changed - a_time).total_seconds()
                    if 0 < time_diff <= time_window.total_seconds():
                        b_turns_off_count += 1
                        break

        if b_turns_off_count < 10:
            return None

        strength = b_turns_off_count / len(a_on_events)

        if strength >= self._min_confidence:
            return {
                "type": "inverse",
                "entity_a": entity_a,
                "entity_b": entity_b,
                "strength": strength,
                "occurrences": b_turns_off_count,
                "total_opportunities": len(a_on_events),
                "avg_time_offset_seconds": 0,
                "description": f"{entity_b} turns off when {entity_a} turns on",
            }

        return None

    async def _save_correlation(self, correlation: dict[str, Any]) -> None:
        """
        Save detected correlation to database.

        Args:
            correlation: Correlation dictionary
        """
        try:
            await self._pattern_storage.save_correlation(
                entity_id_a=correlation["entity_a"],
                entity_id_b=correlation["entity_b"],
                correlation_type=correlation["type"],
                correlation_strength=correlation["strength"],
                time_offset_seconds=correlation.get("avg_time_offset_seconds", 0),
            )

            _LOGGER.debug(
                "Saved %s correlation: %s → %s (%.0f%% strength)",
                correlation["type"],
                correlation["entity_a"],
                correlation["entity_b"],
                correlation["strength"] * 100,
            )

        except Exception as err:
            _LOGGER.error(
                "Error saving correlation %s → %s: %s",
                correlation["entity_a"],
                correlation["entity_b"],
                err,
            )
