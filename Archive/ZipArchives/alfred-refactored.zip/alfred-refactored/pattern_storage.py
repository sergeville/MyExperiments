"""Pattern storage system for Alfred Digital Butler."""
from __future__ import annotations

import aiosqlite
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

_LOGGER = logging.getLogger(__name__)

SCHEMA_VERSION = 12  # Epic 5.3: Added smart lock intelligence tables


class PatternStorage:
    """SQLite storage for patterns, baselines, and correlations."""

    def __init__(self, hass: HomeAssistant) -> None:
        """Initialize pattern storage."""
        self.hass = hass
        self._db_path: Path | None = None
        self._db: aiosqlite.Connection | None = None

    async def async_setup(self) -> None:
        """Set up the pattern storage database."""
        _LOGGER.info("Setting up Alfred Pattern Storage")

        # Get storage path
        storage_dir = Path(self.hass.config.path(".storage"))
        storage_dir.mkdir(parents=True, exist_ok=True)
        self._db_path = storage_dir / "alfred_patterns.db"

        _LOGGER.info("Pattern database path: %s", self._db_path)

        try:
            # Open database connection
            self._db = await aiosqlite.connect(str(self._db_path))

            # Enable WAL mode for better concurrency
            await self._db.execute("PRAGMA journal_mode=WAL")
            await self._db.execute("PRAGMA busy_timeout=5000")

            # Check and create schema
            await self._ensure_schema()

            _LOGGER.info("Pattern storage initialized successfully")

        except Exception as err:
            _LOGGER.error("Failed to initialize pattern storage: %s", err, exc_info=True)
            if self._db:
                await self._db.close()
                self._db = None
            raise

    async def async_close(self) -> None:
        """Close the database connection."""
        if self._db:
            await self._db.close()
            self._db = None
            _LOGGER.info("Pattern storage closed")

    async def _ensure_schema(self) -> None:
        """Ensure database schema exists and is up to date."""
        try:
            # Check if schema_version table exists
            cursor = await self._db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'"
            )
            schema_table_exists = await cursor.fetchone() is not None
            await cursor.close()

            if not schema_table_exists:
                # First-time setup
                _LOGGER.info("Creating initial database schema")
                await self._create_initial_schema()
            else:
                # Check version and migrate if needed
                cursor = await self._db.execute("SELECT MAX(version) FROM schema_version")
                current_version = (await cursor.fetchone())[0]
                await cursor.close()

                if current_version < SCHEMA_VERSION:
                    _LOGGER.info(
                        "Migrating database from version %d to %d",
                        current_version,
                        SCHEMA_VERSION,
                    )
                    await self._migrate_schema(current_version, SCHEMA_VERSION)
                else:
                    _LOGGER.debug("Database schema is up to date (version %d)", current_version)

        except Exception as err:
            _LOGGER.error("Error ensuring schema: %s", err, exc_info=True)
            raise

    async def _create_initial_schema(self) -> None:
        """Create the initial database schema."""
        # Create patterns table
        await self._db.execute("""
            CREATE TABLE patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id TEXT NOT NULL,
                pattern_type TEXT NOT NULL,
                pattern_data TEXT NOT NULL,
                confidence REAL NOT NULL,
                occurrences INTEGER DEFAULT 1,
                first_seen TIMESTAMP NOT NULL,
                last_seen TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(entity_id, pattern_type, pattern_data)
            )
        """)

        # Create indexes for patterns
        await self._db.execute("CREATE INDEX idx_patterns_entity_id ON patterns(entity_id)")
        await self._db.execute("CREATE INDEX idx_patterns_type ON patterns(pattern_type)")
        await self._db.execute("CREATE INDEX idx_patterns_confidence ON patterns(confidence)")
        await self._db.execute("CREATE INDEX idx_patterns_last_seen ON patterns(last_seen)")

        # Create baselines table
        await self._db.execute("""
            CREATE TABLE baselines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                metric_value REAL NOT NULL,
                metric_unit TEXT,
                std_dev REAL,
                sample_count INTEGER DEFAULT 1,
                established_date TIMESTAMP NOT NULL,
                last_updated TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(entity_id, metric_name)
            )
        """)

        # Create indexes for baselines
        await self._db.execute("CREATE INDEX idx_baselines_entity_id ON baselines(entity_id)")
        await self._db.execute("CREATE INDEX idx_baselines_metric ON baselines(metric_name)")

        # Create correlations table
        await self._db.execute("""
            CREATE TABLE correlations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id_a TEXT NOT NULL,
                entity_id_b TEXT NOT NULL,
                correlation_type TEXT NOT NULL,
                correlation_strength REAL NOT NULL,
                time_offset_seconds INTEGER,
                occurrences INTEGER DEFAULT 1,
                first_detected TIMESTAMP NOT NULL,
                last_detected TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CHECK(entity_id_a < entity_id_b),
                UNIQUE(entity_id_a, entity_id_b, correlation_type)
            )
        """)

        # Create indexes for correlations
        await self._db.execute("CREATE INDEX idx_correlations_entity_a ON correlations(entity_id_a)")
        await self._db.execute("CREATE INDEX idx_correlations_entity_b ON correlations(entity_id_b)")
        await self._db.execute("CREATE INDEX idx_correlations_strength ON correlations(correlation_strength)")

        # Create schema_version table
        await self._db.execute("""
            CREATE TABLE schema_version (
                version INTEGER PRIMARY KEY,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                description TEXT
            )
        """)

        # Insert initial version
        await self._db.execute(
            "INSERT INTO schema_version (version, description) VALUES (?, ?)",
            (SCHEMA_VERSION, "Initial schema: patterns, baselines, correlations"),
        )

        await self._db.commit()
        _LOGGER.info("Initial database schema created (version %d)", SCHEMA_VERSION)

    async def _migrate_schema(self, from_version: int, to_version: int) -> None:
        """Migrate database schema from one version to another."""
        _LOGGER.info("Migrating database schema from version %d to %d", from_version, to_version)

        try:
            if from_version < 2 and to_version >= 2:
                # Epic 3: Add performance baseline fields
                _LOGGER.info("Applying Epic 3 schema migration: performance baseline fields")

                await self._db.execute("ALTER TABLE baselines ADD COLUMN min_value REAL")
                await self._db.execute("ALTER TABLE baselines ADD COLUMN max_value REAL")
                await self._db.execute("ALTER TABLE baselines ADD COLUMN confidence_score REAL DEFAULT 0.0")
                await self._db.execute("ALTER TABLE baselines ADD COLUMN observation_period_days INTEGER DEFAULT 30")
                await self._db.execute("ALTER TABLE baselines ADD COLUMN condition_type TEXT DEFAULT 'default'")

                # Create indexes for new fields
                await self._db.execute(
                    "CREATE INDEX IF NOT EXISTS idx_baselines_condition ON baselines(entity_id, condition_type)"
                )
                await self._db.execute(
                    "CREATE INDEX IF NOT EXISTS idx_baselines_confidence ON baselines(confidence_score)"
                )

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (2, "Epic 3: Added performance baseline fields (min_value, max_value, confidence_score, observation_period_days, condition_type)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 2")

            if from_version < 3 and to_version >= 3:
                # Epic 3.2: Add runtime tracking tables
                _LOGGER.info("Applying Epic 3.2 schema migration: runtime tracking tables")

                # Table 1: device_runtime_tracking
                await self._db.execute("""
                    CREATE TABLE device_runtime_tracking (
                        entity_id TEXT PRIMARY KEY,
                        total_runtime_hours REAL NOT NULL DEFAULT 0.0,
                        runtime_since_baseline REAL NOT NULL DEFAULT 0.0,
                        on_cycles_count INTEGER NOT NULL DEFAULT 0,
                        current_state TEXT NOT NULL DEFAULT 'unknown',
                        last_on_time TIMESTAMP,
                        last_off_time TIMESTAMP,
                        avg_cycle_duration_seconds REAL,
                        max_cycle_duration_seconds REAL,
                        min_cycle_duration_seconds REAL,
                        power_on_threshold REAL DEFAULT 0.5,
                        first_tracked TIMESTAMP NOT NULL,
                        last_updated TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(current_state IN ('on', 'off', 'unknown')),
                        CHECK(total_runtime_hours >= 0),
                        CHECK(on_cycles_count >= 0)
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_runtime_entity_state
                    ON device_runtime_tracking(entity_id, current_state)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_runtime_last_updated
                    ON device_runtime_tracking(last_updated)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_runtime_hours
                    ON device_runtime_tracking(total_runtime_hours DESC)
                """)

                # Table 2: power_consumption_log
                await self._db.execute("""
                    CREATE TABLE power_consumption_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        voltage REAL,
                        current REAL,
                        power REAL,
                        energy_wh REAL,
                        power_quality_score REAL,
                        voltage_stability REAL,
                        current_peak REAL,
                        source TEXT DEFAULT 'esphome',
                        aggregation_period TEXT,
                        CHECK(power_quality_score IS NULL OR
                              (power_quality_score >= 0 AND power_quality_score <= 100))
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_power_log_entity_time
                    ON power_consumption_log(entity_id, timestamp DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_power_log_timestamp
                    ON power_consumption_log(timestamp DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_power_log_quality
                    ON power_consumption_log(entity_id, power_quality_score)
                    WHERE power_quality_score IS NOT NULL
                """)

                await self._db.execute("""
                    CREATE INDEX idx_power_log_entity_period
                    ON power_consumption_log(entity_id, aggregation_period, timestamp DESC)
                """)

                # Table 3: device_cycles
                await self._db.execute("""
                    CREATE TABLE device_cycles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        cycle_start TIMESTAMP NOT NULL,
                        cycle_end TIMESTAMP,
                        runtime_duration_seconds REAL,
                        avg_power REAL,
                        max_power REAL,
                        min_power REAL,
                        energy_wh REAL,
                        startup_current_peak REAL,
                        startup_duration_ms REAL,
                        voltage_sag_count INTEGER DEFAULT 0,
                        current_spike_count INTEGER DEFAULT 0,
                        avg_power_quality_score REAL,
                        is_abnormal BOOLEAN DEFAULT 0,
                        abnormal_reason TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(cycle_end IS NULL OR cycle_end >= cycle_start),
                        CHECK(runtime_duration_seconds IS NULL OR runtime_duration_seconds >= 0)
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_cycles_entity_start
                    ON device_cycles(entity_id, cycle_start DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_cycles_duration
                    ON device_cycles(entity_id, runtime_duration_seconds)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_cycles_abnormal
                    ON device_cycles(entity_id, is_abnormal)
                    WHERE is_abnormal = 1
                """)

                await self._db.execute("""
                    CREATE INDEX idx_cycles_current_running
                    ON device_cycles(entity_id, cycle_end)
                    WHERE cycle_end IS NULL
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (3, "Epic 3.2: Added runtime tracking tables (device_runtime_tracking, power_consumption_log, device_cycles)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 3")

            if from_version < 4 and to_version >= 4:
                # Epic 3.3: Add degradation tracking tables
                _LOGGER.info("Applying Epic 3.3 schema migration: degradation tracking")

                # Table: degradation_observations
                await self._db.execute("""
                    CREATE TABLE degradation_observations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        observation_date DATE NOT NULL,
                        degradation_type TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        z_score REAL NOT NULL,
                        deviation_percentage REAL NOT NULL,
                        current_value REAL NOT NULL,
                        baseline_value REAL NOT NULL,
                        metric_name TEXT NOT NULL,
                        confirmed BOOLEAN DEFAULT 0,
                        trend_type TEXT,
                        degradation_rate REAL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(severity IN ('minor', 'moderate', 'severe'))
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_degrade_obs_entity_date
                    ON degradation_observations(entity_id, observation_date DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_degrade_obs_confirmed
                    ON degradation_observations(entity_id, confirmed)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_degrade_obs_type
                    ON degradation_observations(entity_id, degradation_type)
                """)

                # Table: degradation_alerts
                await self._db.execute("""
                    CREATE TABLE degradation_alerts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        alert_type TEXT NOT NULL,
                        degradation_type TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        message TEXT NOT NULL,
                        recommendation TEXT,
                        first_detected DATE NOT NULL,
                        last_updated TIMESTAMP NOT NULL,
                        acknowledged BOOLEAN DEFAULT 0,
                        acknowledged_at TIMESTAMP,
                        resolved BOOLEAN DEFAULT 0,
                        resolved_at TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(alert_type IN ('initial', 'escalation', 'resolution')),
                        CHECK(severity IN ('minor', 'moderate', 'severe'))
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_degrade_alert_entity
                    ON degradation_alerts(entity_id, resolved)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_degrade_alert_active
                    ON degradation_alerts(resolved, acknowledged)
                    WHERE resolved = 0
                """)

                await self._db.execute("""
                    CREATE INDEX idx_degrade_alert_severity
                    ON degradation_alerts(entity_id, severity)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (4, "Epic 3.3: Added degradation tracking tables (degradation_observations, degradation_alerts)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 4")

            if from_version < 5 and to_version >= 5:
                # Epic 3.4: Add AI diagnosis storage tables
                _LOGGER.info("Applying Epic 3.4 schema migration: AI diagnosis storage")

                # Table: diagnosis_history
                await self._db.execute("""
                    CREATE TABLE diagnosis_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        degradation_report_id INTEGER,
                        diagnosis_date TIMESTAMP NOT NULL,

                        -- Diagnosis Results
                        primary_cause TEXT NOT NULL,
                        confidence_percentage INTEGER NOT NULL,
                        supporting_evidence TEXT NOT NULL,
                        alternative_hypotheses TEXT,
                        severity_assessment TEXT NOT NULL,
                        recommendations TEXT NOT NULL,
                        estimated_timeline TEXT,
                        estimated_cost TEXT,

                        -- Validation Tracking
                        validation_status TEXT DEFAULT 'pending',
                        validated_at TIMESTAMP,
                        actual_cause TEXT,
                        validation_notes TEXT,

                        -- Metadata
                        llm_provider TEXT,
                        llm_model TEXT,
                        tokens_used INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

                        CHECK(confidence_percentage >= 0 AND confidence_percentage <= 100),
                        CHECK(severity_assessment IN ('immediate', 'urgent', 'monitor')),
                        CHECK(validation_status IN ('pending', 'confirmed', 'incorrect', 'partially_correct'))
                    )
                """)

                # Indexes for diagnosis_history
                await self._db.execute("""
                    CREATE INDEX idx_diagnosis_entity
                    ON diagnosis_history(entity_id, diagnosis_date DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_diagnosis_date
                    ON diagnosis_history(diagnosis_date DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_diagnosis_validation
                    ON diagnosis_history(validation_status)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_diagnosis_severity
                    ON diagnosis_history(entity_id, severity_assessment)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_diagnosis_confidence
                    ON diagnosis_history(confidence_percentage DESC)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (5, "Epic 3.4: Added AI diagnosis storage table (diagnosis_history)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 5")

            if from_version < 6 and to_version >= 6:
                # Epic 3.6: Add battery management tables
                _LOGGER.info("Applying Epic 3.6 schema migration: battery management")

                # Table: battery_tracking
                await self._db.execute("""
                    CREATE TABLE battery_tracking (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL UNIQUE,
                        friendly_name TEXT,
                        current_level REAL,
                        last_updated TIMESTAMP,
                        drain_rate_per_day REAL,
                        drain_rate_confidence REAL,
                        drain_rate_quality TEXT,
                        drain_rate_calculated_at TIMESTAMP,
                        predicted_replacement_date TIMESTAMP,
                        days_remaining INTEGER,
                        prediction_confidence REAL,
                        prediction_confidence_interval_days INTEGER,
                        battery_type TEXT,
                        battery_type_override TEXT,
                        battery_type_confidence TEXT,
                        last_alerted_threshold INTEGER,
                        last_alerted_at TIMESTAMP,
                        alert_count INTEGER DEFAULT 0,
                        abnormal_drain_detected BOOLEAN DEFAULT FALSE,
                        abnormal_drain_percentage REAL,
                        abnormal_drain_since TIMESTAMP,
                        baseline_drain_rate REAL,
                        last_replacement_date TIMESTAMP,
                        days_since_replacement INTEGER,
                        first_discovered TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Create indexes
                await self._db.execute("""
                    CREATE INDEX idx_battery_entity
                    ON battery_tracking(entity_id)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_battery_level
                    ON battery_tracking(current_level)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_battery_replacement_date
                    ON battery_tracking(predicted_replacement_date)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_battery_abnormal
                    ON battery_tracking(abnormal_drain_detected)
                """)

                # Table: battery_replacement_history
                await self._db.execute("""
                    CREATE TABLE battery_replacement_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        friendly_name TEXT,
                        replacement_date TIMESTAMP NOT NULL,
                        battery_type TEXT,
                        battery_type_verified BOOLEAN DEFAULT FALSE,
                        battery_cost REAL,
                        currency TEXT DEFAULT 'USD',
                        quantity INTEGER DEFAULT 1,
                        replacement_source TEXT,
                        replaced_by TEXT,
                        notes TEXT,
                        previous_prediction_date TIMESTAMP,
                        prediction_accuracy_days INTEGER,
                        drain_rate_accuracy REAL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Create indexes
                await self._db.execute("""
                    CREATE INDEX idx_replacement_entity
                    ON battery_replacement_history(entity_id)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_replacement_date
                    ON battery_replacement_history(replacement_date)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (6, "Epic 3.6: Added battery management tables (battery_tracking, battery_replacement_history)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 6")

            if from_version < 7 and to_version >= 7:
                # Epic 4.1: Add energy consumption tracking tables
                _LOGGER.info("Applying Epic 4.1 schema migration: energy consumption tracking")

                # Table: energy_patterns
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS energy_patterns (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        pattern_type TEXT NOT NULL,
                        pattern_data TEXT NOT NULL,
                        confidence REAL NOT NULL,
                        detected_at TIMESTAMP NOT NULL,
                        valid_until TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_pattern_entity
                    ON energy_patterns(entity_id, pattern_type)
                """)

                # Table: energy_baselines
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS energy_baselines (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        period TEXT NOT NULL,
                        baseline_value REAL NOT NULL,
                        std_dev REAL NOT NULL,
                        min_value REAL NOT NULL,
                        max_value REAL NOT NULL,
                        confidence_score REAL NOT NULL,
                        sample_count INTEGER NOT NULL,
                        observation_days INTEGER NOT NULL,
                        calculated_at TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(entity_id, period)
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_baseline_entity
                    ON energy_baselines(entity_id, period)
                """)

                # Table: energy_peaks
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS energy_peaks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        start_time TIMESTAMP NOT NULL,
                        end_time TIMESTAMP NOT NULL,
                        avg_consumption REAL NOT NULL,
                        peak_consumption REAL NOT NULL,
                        frequency TEXT NOT NULL,
                        confidence REAL NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_peak_entity_time
                    ON energy_peaks(entity_id, start_time)
                """)

                # Table: energy_spikes
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS energy_spikes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        value REAL NOT NULL,
                        baseline REAL NOT NULL,
                        deviation_percent REAL NOT NULL,
                        likely_cause TEXT,
                        acknowledged BOOLEAN DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_spike_entity_time
                    ON energy_spikes(entity_id, timestamp)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_spike_acknowledged
                    ON energy_spikes(acknowledged, created_at)
                """)

                # Table: energy_insights
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS energy_insights (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT,
                        insight_type TEXT NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        actionable BOOLEAN NOT NULL,
                        recommendations TEXT,
                        acknowledged BOOLEAN DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        expires_at TIMESTAMP
                    )
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_insight_entity
                    ON energy_insights(entity_id, created_at)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_energy_insight_type
                    ON energy_insights(insight_type, acknowledged)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (7, "Epic 4.1: Added energy consumption tracking tables (energy_patterns, energy_baselines, energy_peaks, energy_spikes, energy_insights)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 7")

            if from_version < 8 and to_version >= 8:
                # Epic 5.1: Add security baseline and access tracking tables
                _LOGGER.info("Applying Epic 5.1 schema migration: security baselines and access tracking")

                # Table: security_baselines
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS security_baselines (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entity_id TEXT NOT NULL,
                        user_hash TEXT,
                        baseline_type TEXT NOT NULL,
                        day_of_week INTEGER,
                        hour_of_day INTEGER,
                        access_frequency REAL,
                        typical_sequence TEXT,
                        pattern_data TEXT NOT NULL,
                        confidence REAL NOT NULL,
                        sample_count INTEGER NOT NULL,
                        established_date DATE NOT NULL,
                        last_updated TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(baseline_type IN ('temporal', 'spatial', 'behavioral')),
                        CHECK(day_of_week IS NULL OR (day_of_week >= 0 AND day_of_week <= 6)),
                        CHECK(hour_of_day IS NULL OR (hour_of_day >= 0 AND hour_of_day <= 23)),
                        CHECK(confidence >= 0.0 AND confidence <= 1.0),
                        UNIQUE(entity_id, baseline_type, user_hash, day_of_week, hour_of_day)
                    )
                """)

                # Indexes for security_baselines
                await self._db.execute("""
                    CREATE INDEX idx_security_baseline_entity
                    ON security_baselines(entity_id, baseline_type)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_security_baseline_confidence
                    ON security_baselines(confidence DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_security_baseline_updated
                    ON security_baselines(last_updated DESC)
                """)

                # Table: access_events
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS access_events (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        event_id TEXT NOT NULL UNIQUE,
                        entity_id TEXT NOT NULL,
                        user_hash TEXT,
                        access_method TEXT,
                        event_type TEXT NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        duration_inside INTEGER,
                        anomaly_detected BOOLEAN DEFAULT FALSE,
                        risk_level TEXT,
                        context_data TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(event_type IN ('lock', 'unlock', 'open', 'close', 'motion', 'occupancy')),
                        CHECK(risk_level IS NULL OR risk_level IN ('low', 'medium', 'high'))
                    )
                """)

                # Indexes for access_events
                await self._db.execute("""
                    CREATE INDEX idx_access_event_entity_time
                    ON access_events(entity_id, timestamp DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_access_event_user
                    ON access_events(user_hash, timestamp DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_access_event_anomaly
                    ON access_events(anomaly_detected, risk_level)
                    WHERE anomaly_detected = TRUE
                """)

                await self._db.execute("""
                    CREATE INDEX idx_access_event_timestamp
                    ON access_events(timestamp DESC)
                """)

                # Table: security_sequences
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS security_sequences (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        sequence_hash TEXT NOT NULL UNIQUE,
                        entity_sequence TEXT NOT NULL,
                        user_hash TEXT,
                        sequence_type TEXT NOT NULL,
                        frequency_count INTEGER NOT NULL DEFAULT 1,
                        avg_duration_seconds REAL,
                        confidence REAL NOT NULL,
                        first_observed TIMESTAMP NOT NULL,
                        last_observed TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(sequence_type IN ('entry', 'exit', 'routine')),
                        CHECK(confidence >= 0.0 AND confidence <= 1.0)
                    )
                """)

                # Indexes for security_sequences
                await self._db.execute("""
                    CREATE INDEX idx_security_sequence_user
                    ON security_sequences(user_hash, frequency_count DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_security_sequence_confidence
                    ON security_sequences(confidence DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_security_sequence_observed
                    ON security_sequences(last_observed DESC)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (8, "Epic 5.1: Added security baseline and access tracking tables (security_baselines, access_events, security_sequences)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 8")

            if from_version < 9 and to_version >= 9:
                # Epic 5.3: Add guest code management table
                _LOGGER.info("Applying Epic 5.3 schema migration: guest code management")

                # Table: guest_codes
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS guest_codes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        code_slot TEXT NOT NULL UNIQUE,
                        code_name TEXT NOT NULL,
                        entity_id TEXT NOT NULL,
                        user_hash TEXT,
                        code_value TEXT,
                        expiration_date TIMESTAMP,
                        max_uses INTEGER,
                        current_uses INTEGER DEFAULT 0,
                        is_active BOOLEAN DEFAULT TRUE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by TEXT,
                        notes TEXT,
                        CHECK(max_uses IS NULL OR max_uses > 0),
                        CHECK(current_uses >= 0)
                    )
                """)

                # Indexes for guest_codes
                await self._db.execute("""
                    CREATE INDEX idx_guest_code_slot
                    ON guest_codes(code_slot, is_active)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_guest_code_entity
                    ON guest_codes(entity_id, is_active)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_guest_code_expiration
                    ON guest_codes(expiration_date)
                    WHERE is_active = TRUE
                """)

                await self._db.execute("""
                    CREATE INDEX idx_guest_code_usage
                    ON guest_codes(current_uses, max_uses)
                    WHERE is_active = TRUE
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (9, "Epic 5.3: Added guest code management table (guest_codes)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 9")

            if from_version < 10 and to_version >= 10:
                # Epic 5.4: Add environmental hazard detection table
                _LOGGER.info("Applying Epic 5.4 schema migration: environmental hazard detection table")

                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS hazard_detections (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        hazard_type TEXT NOT NULL,
                        risk_level TEXT NOT NULL,
                        confidence REAL NOT NULL,
                        sensors_involved TEXT NOT NULL,
                        explanation TEXT,
                        suggested_actions TEXT,
                        detected_at TIMESTAMP NOT NULL,
                        resolved_at TIMESTAMP,
                        acknowledged BOOLEAN DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(risk_level IN ('normal', 'advisory', 'caution', 'warning', 'urgent')),
                        CHECK(confidence >= 0.0 AND confidence <= 1.0)
                    )
                """)

                # Indexes for hazard_detections
                await self._db.execute("""
                    CREATE INDEX idx_hazard_type_risk
                    ON hazard_detections(hazard_type, risk_level)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_hazard_detected_at
                    ON hazard_detections(detected_at DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_hazard_resolved
                    ON hazard_detections(resolved_at, acknowledged)
                    WHERE resolved_at IS NULL
                """)

                await self._db.execute("""
                    CREATE INDEX idx_hazard_confidence
                    ON hazard_detections(confidence DESC, risk_level)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (10, "Epic 5.4: Added environmental hazard detection table (hazard_detections)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 10")

            if from_version < 11 and to_version >= 11:
                # Epic 5.5: Add pipe freeze prediction table
                _LOGGER.info("Applying Epic 5.5 schema migration: pipe freeze prediction table")

                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS freeze_predictions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        severity TEXT NOT NULL,
                        hours_until_risk INTEGER,
                        confidence REAL NOT NULL,
                        current_temp REAL,
                        forecast_summary TEXT,
                        preventive_actions TEXT,
                        building_factors TEXT,
                        post_freeze_detected BOOLEAN DEFAULT FALSE,
                        predicted_at TIMESTAMP NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(severity IN ('none', 'low', 'moderate', 'high', 'critical')),
                        CHECK(confidence >= 0.0 AND confidence <= 1.0)
                    )
                """)

                # Indexes for freeze_predictions
                await self._db.execute("""
                    CREATE INDEX idx_freeze_severity_predicted
                    ON freeze_predictions(severity, predicted_at DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_freeze_hours_risk
                    ON freeze_predictions(hours_until_risk, severity)
                    WHERE hours_until_risk IS NOT NULL
                """)

                await self._db.execute("""
                    CREATE INDEX idx_freeze_predicted_at
                    ON freeze_predictions(predicted_at DESC)
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (11, "Epic 5.5: Added pipe freeze prediction table (freeze_predictions)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 11")

            if from_version < 12 and to_version >= 12:
                # Epic 5.3: Add smart lock intelligence tables
                _LOGGER.info("Applying Epic 5.3 schema migration: smart lock intelligence tables")

                # Drop old guest_codes table if it exists (from earlier incompatible schema)
                await self._db.execute("DROP TABLE IF EXISTS guest_codes")

                # Drop old lock_access_history indexes if they exist
                await self._db.execute("DROP INDEX IF EXISTS idx_lock_access_entity_timestamp")
                await self._db.execute("DROP INDEX IF EXISTS idx_lock_access_user_code")
                await self._db.execute("DROP INDEX IF EXISTS idx_lock_access_anomalies")
                await self._db.execute("DROP INDEX IF EXISTS idx_lock_access_timestamp")

                # Table 1: lock_access_history
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS lock_access_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        lock_entity_id TEXT NOT NULL,
                        event_type TEXT NOT NULL,
                        user_code TEXT,
                        user_name TEXT,
                        access_method TEXT,
                        timestamp TIMESTAMP NOT NULL,
                        previous_state TEXT,
                        new_state TEXT,
                        duration_seconds INTEGER,
                        anomaly_detected BOOLEAN DEFAULT FALSE,
                        anomaly_type TEXT,
                        anomaly_details TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        CHECK(event_type IN ('locked', 'unlocked', 'code_entered', 'failed_attempt')),
                        CHECK(access_method IN ('code', 'fingerprint', 'key', 'app', 'auto', 'unknown'))
                    )
                """)

                # Indexes for lock_access_history
                await self._db.execute("""
                    CREATE INDEX idx_lock_access_entity_timestamp
                    ON lock_access_history(lock_entity_id, timestamp DESC)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_lock_access_user_code
                    ON lock_access_history(user_code, timestamp DESC)
                    WHERE user_code IS NOT NULL
                """)

                await self._db.execute("""
                    CREATE INDEX idx_lock_access_anomalies
                    ON lock_access_history(lock_entity_id, anomaly_detected)
                    WHERE anomaly_detected = TRUE
                """)

                await self._db.execute("""
                    CREATE INDEX idx_lock_access_timestamp
                    ON lock_access_history(timestamp DESC)
                """)

                # Table 2: guest_codes
                await self._db.execute("""
                    CREATE TABLE IF NOT EXISTS guest_codes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        lock_entity_id TEXT NOT NULL,
                        code_slot INTEGER NOT NULL,
                        code_name TEXT NOT NULL,
                        user_code TEXT NOT NULL,
                        start_date TIMESTAMP,
                        end_date TIMESTAMP,
                        is_one_time BOOLEAN DEFAULT FALSE,
                        used_count INTEGER DEFAULT 0,
                        is_active BOOLEAN DEFAULT TRUE,
                        notes TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE(lock_entity_id, code_slot)
                    )
                """)

                # Indexes for guest_codes
                await self._db.execute("""
                    CREATE INDEX idx_guest_codes_entity_active
                    ON guest_codes(lock_entity_id, is_active)
                """)

                await self._db.execute("""
                    CREATE INDEX idx_guest_codes_expiration
                    ON guest_codes(end_date, is_active)
                    WHERE end_date IS NOT NULL
                """)

                await self._db.execute("""
                    CREATE INDEX idx_guest_codes_one_time
                    ON guest_codes(is_one_time, used_count, is_active)
                    WHERE is_one_time = TRUE
                """)

                # Update schema version
                await self._db.execute(
                    "INSERT INTO schema_version (version, description) VALUES (?, ?)",
                    (12, "Epic 5.3: Added smart lock intelligence tables (lock_access_history, guest_codes)"),
                )

                await self._db.commit()
                _LOGGER.info("Successfully migrated to schema version 12")

        except Exception as err:
            _LOGGER.error("Error during schema migration: %s", err, exc_info=True)
            raise

    # ==================== Pattern Operations ====================

    async def save_pattern(
        self,
        entity_id: str,
        pattern_type: str,
        pattern_data: dict[str, Any],
        confidence: float,
    ) -> int:
        """
        Save or update a pattern.

        Args:
            entity_id: Entity ID
            pattern_type: Type of pattern
            pattern_data: Pattern data as dict (will be JSON serialized)
            confidence: Confidence score (0.0 to 1.0)

        Returns:
            Pattern ID
        """
        if not self._db:
            raise RuntimeError("Database not initialized")

        pattern_data_json = json.dumps(pattern_data, sort_keys=True)
        now = dt_util.now().isoformat()

        try:
            # Try to insert or update
            cursor = await self._db.execute(
                """
                INSERT INTO patterns (entity_id, pattern_type, pattern_data, confidence, first_seen, last_seen, occurrences)
                VALUES (?, ?, ?, ?, ?, ?, 1)
                ON CONFLICT(entity_id, pattern_type, pattern_data) DO UPDATE SET
                    confidence = ?,
                    last_seen = ?,
                    occurrences = occurrences + 1,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (entity_id, pattern_type, pattern_data_json, confidence, now, now, confidence, now),
            )

            pattern_id = cursor.lastrowid
            await self._db.commit()
            await cursor.close()

            _LOGGER.debug(
                "Saved pattern for %s (type=%s, confidence=%.2f)",
                entity_id,
                pattern_type,
                confidence,
            )

            return pattern_id

        except Exception as err:
            _LOGGER.error("Error saving pattern: %s", err, exc_info=True)
            raise

    async def get_patterns_for_entity(
        self,
        entity_id: str,
        min_confidence: float = 0.0,
    ) -> list[dict[str, Any]]:
        """
        Get all patterns for an entity.

        Args:
            entity_id: Entity ID
            min_confidence: Minimum confidence threshold

        Returns:
            List of pattern dictionaries
        """
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id, pattern_type, pattern_data, confidence,
                       occurrences, first_seen, last_seen
                FROM patterns
                WHERE entity_id = ? AND confidence >= ?
                ORDER BY confidence DESC, last_seen DESC
                """,
                (entity_id, min_confidence),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            patterns = []
            for row in rows:
                patterns.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "pattern_type": row[2],
                    "pattern_data": json.loads(row[3]),
                    "confidence": row[4],
                    "occurrences": row[5],
                    "first_seen": row[6],
                    "last_seen": row[7],
                })

            return patterns

        except Exception as err:
            _LOGGER.error("Error getting patterns for entity: %s", err)
            return []

    async def get_all_patterns(
        self,
        min_confidence: float = 0.5,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """
        Get all patterns above confidence threshold.

        Args:
            min_confidence: Minimum confidence threshold
            limit: Maximum number of patterns to return

        Returns:
            List of pattern dictionaries
        """
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id, pattern_type, pattern_data, confidence,
                       occurrences, first_seen, last_seen
                FROM patterns
                WHERE confidence >= ?
                ORDER BY confidence DESC, last_seen DESC
                LIMIT ?
                """,
                (min_confidence, limit),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            patterns = []
            for row in rows:
                patterns.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "pattern_type": row[2],
                    "pattern_data": json.loads(row[3]),
                    "confidence": row[4],
                    "occurrences": row[5],
                    "first_seen": row[6],
                    "last_seen": row[7],
                })

            return patterns

        except Exception as err:
            _LOGGER.error("Error getting all patterns: %s", err)
            return []

    async def delete_pattern(self, pattern_id: int) -> bool:
        """Delete a specific pattern by ID."""
        if not self._db:
            return False

        try:
            await self._db.execute("DELETE FROM patterns WHERE id = ?", (pattern_id,))
            await self._db.commit()
            return True
        except Exception as err:
            _LOGGER.error("Error deleting pattern: %s", err)
            return False

    async def delete_stale_patterns(self, days: int = 90) -> int:
        """
        Delete patterns not seen in specified days.

        Args:
            days: Number of days (default: 90)

        Returns:
            Number of patterns deleted
        """
        if not self._db:
            return 0

        try:
            cutoff_date = (dt_util.now() - timedelta(days=days)).isoformat()

            cursor = await self._db.execute(
                "DELETE FROM patterns WHERE last_seen < ?",
                (cutoff_date,),
            )

            deleted = cursor.rowcount
            await self._db.commit()
            await cursor.close()

            if deleted > 0:
                _LOGGER.info("Deleted %d stale patterns (>%d days old)", deleted, days)

            return deleted

        except Exception as err:
            _LOGGER.error("Error deleting stale patterns: %s", err)
            return 0

    # ==================== Baseline Operations ====================

    async def save_baseline(
        self,
        entity_id: str,
        metric_name: str,
        metric_value: float,
        metric_unit: str | None = None,
        std_dev: float | None = None,
        sample_count: int = 1,
        min_value: float | None = None,
        max_value: float | None = None,
        confidence_score: float = 0.0,
        observation_period_days: int = 30,
        condition_type: str = "default",
    ) -> int:
        """Save or update a baseline metric."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        now = dt_util.now().isoformat()

        try:
            cursor = await self._db.execute(
                """
                INSERT INTO baselines (entity_id, metric_name, metric_value, metric_unit,
                                     std_dev, sample_count, established_date, last_updated,
                                     min_value, max_value, confidence_score, observation_period_days, condition_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(entity_id, metric_name) DO UPDATE SET
                    metric_value = ?,
                    metric_unit = ?,
                    std_dev = ?,
                    sample_count = sample_count + ?,
                    last_updated = ?,
                    min_value = ?,
                    max_value = ?,
                    confidence_score = ?,
                    observation_period_days = ?,
                    condition_type = ?
                """,
                (entity_id, metric_name, metric_value, metric_unit, std_dev, sample_count, now, now,
                 min_value, max_value, confidence_score, observation_period_days, condition_type,
                 metric_value, metric_unit, std_dev, sample_count, now,
                 min_value, max_value, confidence_score, observation_period_days, condition_type),
            )

            baseline_id = cursor.lastrowid
            await self._db.commit()
            await cursor.close()

            _LOGGER.debug(
                "Saved baseline for %s (%s=%.2f%s)",
                entity_id,
                metric_name,
                metric_value,
                metric_unit or "",
            )

            return baseline_id

        except Exception as err:
            _LOGGER.error("Error saving baseline: %s", err, exc_info=True)
            raise

    async def get_baseline(
        self,
        entity_id: str,
        metric_name: str,
    ) -> dict[str, Any] | None:
        """Get a specific baseline metric."""
        if not self._db:
            return None

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id, metric_name, metric_value, metric_unit,
                       std_dev, sample_count, established_date, last_updated
                FROM baselines
                WHERE entity_id = ? AND metric_name = ?
                """,
                (entity_id, metric_name),
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row:
                return None

            return {
                "id": row[0],
                "entity_id": row[1],
                "metric_name": row[2],
                "metric_value": row[3],
                "metric_unit": row[4],
                "std_dev": row[5],
                "sample_count": row[6],
                "established_date": row[7],
                "last_updated": row[8],
            }

        except Exception as err:
            _LOGGER.error("Error getting baseline: %s", err)
            return None

    async def get_baselines_for_entity(self, entity_id: str) -> list[dict[str, Any]]:
        """Get all baselines for an entity."""
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id, metric_name, metric_value, metric_unit,
                       std_dev, sample_count, established_date, last_updated
                FROM baselines
                WHERE entity_id = ?
                ORDER BY metric_name
                """,
                (entity_id,),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            baselines = []
            for row in rows:
                baselines.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "metric_name": row[2],
                    "metric_value": row[3],
                    "metric_unit": row[4],
                    "std_dev": row[5],
                    "sample_count": row[6],
                    "established_date": row[7],
                    "last_updated": row[8],
                })

            return baselines

        except Exception as err:
            _LOGGER.error("Error getting baselines for entity: %s", err)
            return []

    async def delete_baseline(self, entity_id: str, metric_name: str) -> bool:
        """Delete a specific baseline."""
        if not self._db:
            return False

        try:
            await self._db.execute(
                "DELETE FROM baselines WHERE entity_id = ? AND metric_name = ?",
                (entity_id, metric_name),
            )
            await self._db.commit()
            return True
        except Exception as err:
            _LOGGER.error("Error deleting baseline: %s", err)
            return False

    async def get_baseline_history(
        self,
        entity_id: str,
        metric_name: str,
        days: int = 7,
    ) -> list[dict[str, Any]]:
        """
        Get historical baseline/metric values for trend analysis.

        Args:
            entity_id: Entity ID to query
            metric_name: Metric name (e.g., 'power', 'voltage', 'current')
            days: Number of days of history to retrieve

        Returns:
            List of historical values with timestamps, ordered oldest to newest
        """
        if not self._db:
            return []

        try:
            cutoff_date = (dt_util.now() - timedelta(days=days)).isoformat()

            # Map metric names to power_consumption_log columns
            metric_column_map = {
                "power": "power",
                "voltage": "voltage",
                "current": "current",
                "energy": "energy_wh",
                "power_quality": "power_quality_score",
            }

            column = metric_column_map.get(metric_name)
            if not column:
                # Metric not supported yet, return empty
                _LOGGER.debug(
                    "Metric '%s' not yet supported for historical queries",
                    metric_name
                )
                return []

            # Query power consumption log
            cursor = await self._db.execute(
                f"""
                SELECT timestamp, {column}
                FROM power_consumption_log
                WHERE entity_id = ?
                  AND timestamp >= ?
                  AND {column} IS NOT NULL
                ORDER BY timestamp ASC
                """,
                (entity_id, cutoff_date),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            history = []
            for row in rows:
                history.append({
                    "timestamp": row[0],
                    "value": row[1],
                })

            _LOGGER.debug(
                "Retrieved %d historical values for %s.%s",
                len(history),
                entity_id,
                metric_name,
            )

            return history

        except Exception as err:
            _LOGGER.error(
                "Error getting baseline history for %s.%s: %s",
                entity_id,
                metric_name,
                err,
            )
            return []

    # ==================== Correlation Operations ====================

    async def save_correlation(
        self,
        entity_id_a: str,
        entity_id_b: str,
        correlation_type: str,
        correlation_strength: float,
        time_offset_seconds: int | None = None,
    ) -> int:
        """Save or update a correlation."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        # Ensure ordering (entity_id_a < entity_id_b)
        if entity_id_a > entity_id_b:
            entity_id_a, entity_id_b = entity_id_b, entity_id_a

        now = dt_util.now().isoformat()

        try:
            cursor = await self._db.execute(
                """
                INSERT INTO correlations (entity_id_a, entity_id_b, correlation_type,
                                        correlation_strength, time_offset_seconds,
                                        first_detected, last_detected, occurrences)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                ON CONFLICT(entity_id_a, entity_id_b, correlation_type) DO UPDATE SET
                    correlation_strength = ?,
                    time_offset_seconds = ?,
                    last_detected = ?,
                    occurrences = occurrences + 1
                """,
                (entity_id_a, entity_id_b, correlation_type, correlation_strength,
                 time_offset_seconds, now, now, correlation_strength, time_offset_seconds, now),
            )

            correlation_id = cursor.lastrowid
            await self._db.commit()
            await cursor.close()

            _LOGGER.debug(
                "Saved correlation: %s <-> %s (type=%s, strength=%.2f)",
                entity_id_a,
                entity_id_b,
                correlation_type,
                correlation_strength,
            )

            return correlation_id

        except Exception as err:
            _LOGGER.error("Error saving correlation: %s", err, exc_info=True)
            raise

    async def get_correlations_for_entity(
        self,
        entity_id: str,
        min_strength: float = 0.5,
    ) -> list[dict[str, Any]]:
        """Get all correlations involving an entity."""
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id_a, entity_id_b, correlation_type,
                       correlation_strength, time_offset_seconds,
                       occurrences, first_detected, last_detected
                FROM correlations
                WHERE (entity_id_a = ? OR entity_id_b = ?)
                  AND correlation_strength >= ?
                ORDER BY correlation_strength DESC
                """,
                (entity_id, entity_id, min_strength),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            correlations = []
            for row in rows:
                correlations.append({
                    "id": row[0],
                    "entity_id_a": row[1],
                    "entity_id_b": row[2],
                    "correlation_type": row[3],
                    "correlation_strength": row[4],
                    "time_offset_seconds": row[5],
                    "occurrences": row[6],
                    "first_detected": row[7],
                    "last_detected": row[8],
                })

            return correlations

        except Exception as err:
            _LOGGER.error("Error getting correlations: %s", err)
            return []

    async def get_strong_correlations(
        self,
        min_strength: float = 0.8,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Get strong correlations above threshold."""
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id_a, entity_id_b, correlation_type,
                       correlation_strength, time_offset_seconds,
                       occurrences, first_detected, last_detected
                FROM correlations
                WHERE correlation_strength >= ?
                ORDER BY correlation_strength DESC
                LIMIT ?
                """,
                (min_strength, limit),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            correlations = []
            for row in rows:
                correlations.append({
                    "id": row[0],
                    "entity_id_a": row[1],
                    "entity_id_b": row[2],
                    "correlation_type": row[3],
                    "correlation_strength": row[4],
                    "time_offset_seconds": row[5],
                    "occurrences": row[6],
                    "first_detected": row[7],
                    "last_detected": row[8],
                })

            return correlations

        except Exception as err:
            _LOGGER.error("Error getting strong correlations: %s", err)
            return []

    async def delete_correlation(self, correlation_id: int) -> bool:
        """Delete a specific correlation."""
        if not self._db:
            return False

        try:
            await self._db.execute("DELETE FROM correlations WHERE id = ?", (correlation_id,))
            await self._db.commit()
            return True
        except Exception as err:
            _LOGGER.error("Error deleting correlation: %s", err)
            return False

    # ==================== Utility Methods ====================

    async def get_database_stats(self) -> dict[str, int]:
        """Get database statistics."""
        if not self._db:
            return {}

        try:
            stats = {}

            # Count patterns
            cursor = await self._db.execute("SELECT COUNT(*) FROM patterns")
            stats["patterns_count"] = (await cursor.fetchone())[0]
            await cursor.close()

            # Count baselines
            cursor = await self._db.execute("SELECT COUNT(*) FROM baselines")
            stats["baselines_count"] = (await cursor.fetchone())[0]
            await cursor.close()

            # Count correlations
            cursor = await self._db.execute("SELECT COUNT(*) FROM correlations")
            stats["correlations_count"] = (await cursor.fetchone())[0]
            await cursor.close()

            # Database file size (in bytes)
            if self._db_path and self._db_path.exists():
                stats["database_size_bytes"] = self._db_path.stat().st_size

            return stats

        except Exception as err:
            _LOGGER.error("Error getting database stats: %s", err)
            return {}

    # ==================== Runtime Tracking Operations (Epic 3.2) ====================

    async def create_runtime_tracking(
        self,
        entity_id: str,
        power_on_threshold: float,
        first_tracked: datetime,
    ) -> None:
        """Create a new runtime tracking entry."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        now = first_tracked.isoformat()

        await self._db.execute(
            """
            INSERT INTO device_runtime_tracking
            (entity_id, power_on_threshold, first_tracked, last_updated)
            VALUES (?, ?, ?, ?)
            """,
            (entity_id, power_on_threshold, now, now),
        )

        await self._db.commit()
        _LOGGER.debug("Created runtime tracking for %s", entity_id)

    async def update_runtime_tracking(
        self,
        entity_id: str,
        total_runtime_hours: float,
        runtime_since_baseline: float,
        on_cycles_count: int,
        current_state: str,
        last_on_time: datetime | None,
        last_off_time: datetime | None,
        last_updated: datetime,
    ) -> None:
        """Update runtime tracking data."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        await self._db.execute(
            """
            UPDATE device_runtime_tracking
            SET total_runtime_hours = ?,
                runtime_since_baseline = ?,
                on_cycles_count = ?,
                current_state = ?,
                last_on_time = ?,
                last_off_time = ?,
                last_updated = ?
            WHERE entity_id = ?
            """,
            (
                total_runtime_hours,
                runtime_since_baseline,
                on_cycles_count,
                current_state,
                last_on_time.isoformat() if last_on_time else None,
                last_off_time.isoformat() if last_off_time else None,
                last_updated.isoformat(),
                entity_id,
            ),
        )

        await self._db.commit()

    async def get_runtime_tracking(self, entity_id: str) -> dict[str, Any] | None:
        """Get runtime tracking data for an entity."""
        if not self._db:
            return None

        try:
            cursor = await self._db.execute(
                """
                SELECT entity_id, total_runtime_hours, runtime_since_baseline,
                       on_cycles_count, current_state, last_on_time, last_off_time,
                       power_on_threshold, first_tracked, last_updated
                FROM device_runtime_tracking
                WHERE entity_id = ?
                """,
                (entity_id,),
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row:
                return None

            return {
                "entity_id": row[0],
                "total_runtime_hours": row[1],
                "runtime_since_baseline": row[2],
                "on_cycles_count": row[3],
                "current_state": row[4],
                "last_on_time": row[5],
                "last_off_time": row[6],
                "power_on_threshold": row[7],
                "first_tracked": row[8],
                "last_updated": row[9],
            }

        except Exception as err:
            _LOGGER.error("Error getting runtime tracking: %s", err)
            return None

    async def get_all_runtime_tracking(self) -> list[dict[str, Any]]:
        """Get all runtime tracking data."""
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT entity_id, total_runtime_hours, runtime_since_baseline,
                       on_cycles_count, current_state, last_on_time, last_off_time,
                       power_on_threshold
                FROM device_runtime_tracking
                ORDER BY entity_id
                """
            )

            rows = await cursor.fetchall()
            await cursor.close()

            tracking_data = []
            for row in rows:
                tracking_data.append({
                    "entity_id": row[0],
                    "total_runtime_hours": row[1],
                    "runtime_since_baseline": row[2],
                    "on_cycles_count": row[3],
                    "current_state": row[4],
                    "last_on_time": row[5],
                    "last_off_time": row[6],
                    "power_on_threshold": row[7],
                })

            return tracking_data

        except Exception as err:
            _LOGGER.error("Error getting all runtime tracking: %s", err)
            return []

    async def start_device_cycle(
        self,
        entity_id: str,
        cycle_start: datetime,
    ) -> int:
        """Start a new device cycle."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        cursor = await self._db.execute(
            """
            INSERT INTO device_cycles
            (entity_id, cycle_start)
            VALUES (?, ?)
            """,
            (entity_id, cycle_start.isoformat()),
        )

        await self._db.commit()
        cycle_id = cursor.lastrowid
        await cursor.close()

        _LOGGER.debug("Started cycle %d for %s", cycle_id, entity_id)
        return cycle_id

    async def end_device_cycle(
        self,
        entity_id: str,
        cycle_end: datetime,
        runtime_duration_seconds: float,
    ) -> None:
        """End the current device cycle."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        # Find the most recent open cycle
        cursor = await self._db.execute(
            """
            SELECT id FROM device_cycles
            WHERE entity_id = ? AND cycle_end IS NULL
            ORDER BY cycle_start DESC
            LIMIT 1
            """,
            (entity_id,),
        )

        row = await cursor.fetchone()
        await cursor.close()

        if not row:
            _LOGGER.warning("No open cycle found for %s", entity_id)
            return

        cycle_id = row[0]

        # Update the cycle
        await self._db.execute(
            """
            UPDATE device_cycles
            SET cycle_end = ?,
                runtime_duration_seconds = ?
            WHERE id = ?
            """,
            (cycle_end.isoformat(), runtime_duration_seconds, cycle_id),
        )

        await self._db.commit()
        _LOGGER.debug("Ended cycle %d for %s (%.1fs)", cycle_id, entity_id, runtime_duration_seconds)

    async def get_cycle_statistics(self, entity_id: str) -> dict[str, Any] | None:
        """Get cycle statistics for an entity."""
        if not self._db:
            return None

        try:
            cursor = await self._db.execute(
                """
                SELECT
                    COUNT(*) as total_cycles,
                    AVG(runtime_duration_seconds) as avg_duration,
                    MAX(runtime_duration_seconds) as max_duration,
                    MIN(runtime_duration_seconds) as min_duration
                FROM device_cycles
                WHERE entity_id = ?
                AND cycle_end IS NOT NULL
                """,
                (entity_id,),
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row or row[0] == 0:
                return None

            return {
                "total_cycles": row[0],
                "avg_duration_seconds": row[1],
                "max_duration_seconds": row[2],
                "min_duration_seconds": row[3],
            }

        except Exception as err:
            _LOGGER.error("Error getting cycle statistics: %s", err)
            return None

    async def log_power_consumption(
        self,
        entity_id: str,
        timestamp: datetime,
        voltage: float | None = None,
        current: float | None = None,
        power: float | None = None,
        energy_wh: float | None = None,
        power_quality_score: float | None = None,
    ) -> None:
        """
        Log power consumption data to database.

        Args:
            entity_id: Entity ID
            timestamp: Timestamp of measurement
            voltage: Voltage reading (V)
            current: Current reading (A)
            power: Power reading (W)
            energy_wh: Energy reading (Wh)
            power_quality_score: Quality score (0-100)
        """
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            await self._db.execute(
                """
                INSERT INTO power_consumption_log (
                    entity_id, timestamp, voltage, current, power,
                    energy_wh, power_quality_score
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entity_id,
                    timestamp.isoformat(),
                    voltage,
                    current,
                    power,
                    energy_wh,
                    power_quality_score,
                ),
            )

            await self._db.commit()

        except Exception as err:
            _LOGGER.error(
                "Error logging power consumption for %s: %s", entity_id, err
            )

    # ==================== Degradation Tracking Operations (Epic 3.3) ====================

    async def save_degradation_observation(
        self,
        entity_id: str,
        observation_date: datetime,
        degradation_type: str,
        severity: str,
        z_score: float,
        deviation_percentage: float,
        current_value: float,
        baseline_value: float,
        metric_name: str,
        trend_type: str | None = None,
        degradation_rate: float | None = None,
    ) -> int:
        """
        Save a degradation observation to the database.

        Args:
            entity_id: Entity ID
            observation_date: Date of observation
            degradation_type: Type of degradation (e.g., 'higher_power')
            severity: Severity level ('minor', 'moderate', 'severe')
            z_score: Z-score of the degradation
            deviation_percentage: Percentage deviation from baseline
            current_value: Current metric value
            baseline_value: Baseline metric value
            metric_name: Name of the metric
            trend_type: Type of trend (optional)
            degradation_rate: Rate of degradation (optional)

        Returns:
            Observation ID
        """
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            cursor = await self._db.execute(
                """
                INSERT INTO degradation_observations (
                    entity_id, observation_date, degradation_type, severity,
                    z_score, deviation_percentage, current_value, baseline_value,
                    metric_name, trend_type, degradation_rate
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entity_id,
                    observation_date.date().isoformat(),
                    degradation_type,
                    severity,
                    z_score,
                    deviation_percentage,
                    current_value,
                    baseline_value,
                    metric_name,
                    trend_type,
                    degradation_rate,
                ),
            )

            await self._db.commit()
            observation_id = cursor.lastrowid
            await cursor.close()

            _LOGGER.debug(
                "Saved degradation observation for %s (type=%s, severity=%s)",
                entity_id,
                degradation_type,
                severity,
            )

            return observation_id

        except Exception as err:
            _LOGGER.error("Error saving degradation observation: %s", err, exc_info=True)
            raise

    async def get_recent_observations(
        self,
        entity_id: str,
        degradation_type: str,
        days: int = 5,
    ) -> list[dict[str, Any]]:
        """
        Get recent degradation observations for confirmation logic.

        Args:
            entity_id: Entity ID
            degradation_type: Type of degradation to filter by
            days: Number of days to look back

        Returns:
            List of observations
        """
        if not self._db:
            return []

        try:
            cutoff_date = (dt_util.now() - timedelta(days=days)).date().isoformat()

            cursor = await self._db.execute(
                """
                SELECT id, entity_id, observation_date, degradation_type,
                       severity, z_score, deviation_percentage, current_value,
                       baseline_value, metric_name, confirmed, trend_type,
                       degradation_rate, created_at
                FROM degradation_observations
                WHERE entity_id = ?
                  AND degradation_type = ?
                  AND observation_date >= ?
                ORDER BY observation_date DESC
                """,
                (entity_id, degradation_type, cutoff_date),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            observations = []
            for row in rows:
                observations.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "observation_date": row[2],
                    "degradation_type": row[3],
                    "severity": row[4],
                    "z_score": row[5],
                    "deviation_percentage": row[6],
                    "current_value": row[7],
                    "baseline_value": row[8],
                    "metric_name": row[9],
                    "confirmed": bool(row[10]),
                    "trend_type": row[11],
                    "degradation_rate": row[12],
                    "created_at": row[13],
                })

            return observations

        except Exception as err:
            _LOGGER.error("Error getting recent observations: %s", err)
            return []

    async def mark_observation_confirmed(
        self,
        observation_id: int,
    ) -> None:
        """Mark a degradation observation as confirmed."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            await self._db.execute(
                "UPDATE degradation_observations SET confirmed = 1 WHERE id = ?",
                (observation_id,),
            )
            await self._db.commit()

        except Exception as err:
            _LOGGER.error("Error marking observation as confirmed: %s", err)
            raise

    async def save_degradation_alert(
        self,
        entity_id: str,
        alert_type: str,
        degradation_type: str,
        severity: str,
        message: str,
        recommendation: str | None,
        first_detected: datetime,
    ) -> int:
        """
        Save a degradation alert.

        Args:
            entity_id: Entity ID
            alert_type: Type of alert ('initial', 'escalation', 'resolution')
            degradation_type: Type of degradation
            severity: Severity level
            message: Alert message
            recommendation: Recommendation text (optional)
            first_detected: Date first detected

        Returns:
            Alert ID
        """
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            now = dt_util.now().isoformat()

            cursor = await self._db.execute(
                """
                INSERT INTO degradation_alerts (
                    entity_id, alert_type, degradation_type, severity,
                    message, recommendation, first_detected, last_updated
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entity_id,
                    alert_type,
                    degradation_type,
                    severity,
                    message,
                    recommendation,
                    first_detected.date().isoformat(),
                    now,
                ),
            )

            await self._db.commit()
            alert_id = cursor.lastrowid
            await cursor.close()

            _LOGGER.info(
                "Saved degradation alert for %s (type=%s, severity=%s)",
                entity_id,
                alert_type,
                severity,
            )

            return alert_id

        except Exception as err:
            _LOGGER.error("Error saving degradation alert: %s", err, exc_info=True)
            raise

    async def get_active_alerts(
        self,
        entity_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Get active (unresolved) degradation alerts.

        Args:
            entity_id: Optional entity ID to filter by

        Returns:
            List of active alerts
        """
        if not self._db:
            return []

        try:
            if entity_id:
                cursor = await self._db.execute(
                    """
                    SELECT id, entity_id, alert_type, degradation_type, severity,
                           message, recommendation, first_detected, last_updated,
                           acknowledged, acknowledged_at
                    FROM degradation_alerts
                    WHERE entity_id = ? AND resolved = 0
                    ORDER BY severity DESC, last_updated DESC
                    """,
                    (entity_id,),
                )
            else:
                cursor = await self._db.execute(
                    """
                    SELECT id, entity_id, alert_type, degradation_type, severity,
                           message, recommendation, first_detected, last_updated,
                           acknowledged, acknowledged_at
                    FROM degradation_alerts
                    WHERE resolved = 0
                    ORDER BY severity DESC, last_updated DESC
                    """
                )

            rows = await cursor.fetchall()
            await cursor.close()

            alerts = []
            for row in rows:
                alerts.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "alert_type": row[2],
                    "degradation_type": row[3],
                    "severity": row[4],
                    "message": row[5],
                    "recommendation": row[6],
                    "first_detected": row[7],
                    "last_updated": row[8],
                    "acknowledged": bool(row[9]),
                    "acknowledged_at": row[10],
                })

            return alerts

        except Exception as err:
            _LOGGER.error("Error getting active alerts: %s", err)
            return []

    async def mark_alert_resolved(
        self,
        alert_id: int,
    ) -> None:
        """Mark a degradation alert as resolved."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            now = dt_util.now().isoformat()

            await self._db.execute(
                """
                UPDATE degradation_alerts
                SET resolved = 1, resolved_at = ?
                WHERE id = ?
                """,
                (now, alert_id),
            )

            await self._db.commit()

            _LOGGER.info("Marked alert #%d as resolved", alert_id)

        except Exception as err:
            _LOGGER.error("Error marking alert as resolved: %s", err)
            raise

    async def mark_alert_acknowledged(
        self,
        alert_id: int,
    ) -> None:
        """Mark a degradation alert as acknowledged."""
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            now = dt_util.now().isoformat()

            await self._db.execute(
                """
                UPDATE degradation_alerts
                SET acknowledged = 1, acknowledged_at = ?
                WHERE id = ?
                """,
                (now, alert_id),
            )

            await self._db.commit()

            _LOGGER.info("Marked alert #%d as acknowledged", alert_id)

        except Exception as err:
            _LOGGER.error("Error marking alert as acknowledged: %s", err)
            raise

    # ==================== Diagnosis Operations (Epic 3.4) ====================

    async def save_diagnosis(
        self,
        entity_id: str,
        diagnosis_date: datetime,
        primary_cause: str,
        confidence_percentage: int,
        supporting_evidence: list[str],
        alternative_hypotheses: list[dict[str, Any]],
        severity_assessment: str,
        recommendations: dict[str, Any],
        estimated_timeline: str | None = None,
        estimated_cost: dict[str, str] | None = None,
        degradation_report_id: int | None = None,
        llm_provider: str | None = None,
        llm_model: str | None = None,
        tokens_used: int | None = None,
    ) -> int:
        """
        Save diagnosis result to database.

        Args:
            entity_id: Entity ID
            diagnosis_date: When diagnosis was performed
            primary_cause: Primary root cause
            confidence_percentage: Confidence (0-100)
            supporting_evidence: List of evidence strings
            alternative_hypotheses: List of alternative causes
            severity_assessment: immediate, urgent, or monitor
            recommendations: Recommendations dict
            estimated_timeline: Timeline estimate
            estimated_cost: Cost estimates dict
            degradation_report_id: Optional link to degradation report
            llm_provider: AI provider used
            llm_model: Model used
            tokens_used: Token count

        Returns:
            Diagnosis ID
        """
        if not self._db:
            raise RuntimeError("Database not initialized")

        try:
            cursor = await self._db.execute(
                """
                INSERT INTO diagnosis_history (
                    entity_id, degradation_report_id, diagnosis_date,
                    primary_cause, confidence_percentage, supporting_evidence,
                    alternative_hypotheses, severity_assessment, recommendations,
                    estimated_timeline, estimated_cost,
                    llm_provider, llm_model, tokens_used
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entity_id,
                    degradation_report_id,
                    diagnosis_date.isoformat(),
                    primary_cause,
                    confidence_percentage,
                    json.dumps(supporting_evidence),
                    json.dumps(alternative_hypotheses) if alternative_hypotheses else None,
                    severity_assessment,
                    json.dumps(recommendations),
                    estimated_timeline,
                    json.dumps(estimated_cost) if estimated_cost else None,
                    llm_provider,
                    llm_model,
                    tokens_used,
                ),
            )

            diagnosis_id = cursor.lastrowid
            await self._db.commit()
            await cursor.close()

            _LOGGER.info(
                "Saved diagnosis #%d for %s (confidence: %d%%, severity: %s)",
                diagnosis_id,
                entity_id,
                confidence_percentage,
                severity_assessment
            )

            return diagnosis_id

        except Exception as err:
            _LOGGER.error("Error saving diagnosis: %s", err, exc_info=True)
            raise

    async def get_diagnosis_history(
        self,
        entity_id: str,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """
        Get diagnosis history for an entity.

        Args:
            entity_id: Entity ID
            limit: Maximum number of results

        Returns:
            List of diagnosis records
        """
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id, diagnosis_date, primary_cause,
                       confidence_percentage, supporting_evidence,
                       alternative_hypotheses, severity_assessment,
                       recommendations, estimated_timeline, estimated_cost,
                       validation_status, validated_at, actual_cause,
                       validation_notes, llm_provider, llm_model, tokens_used,
                       created_at
                FROM diagnosis_history
                WHERE entity_id = ?
                ORDER BY diagnosis_date DESC
                LIMIT ?
                """,
                (entity_id, limit),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            diagnoses = []
            for row in rows:
                diagnoses.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "diagnosis_date": row[2],
                    "primary_cause": row[3],
                    "confidence_percentage": row[4],
                    "supporting_evidence": json.loads(row[5]) if row[5] else [],
                    "alternative_hypotheses": json.loads(row[6]) if row[6] else [],
                    "severity_assessment": row[7],
                    "recommendations": json.loads(row[8]) if row[8] else {},
                    "estimated_timeline": row[9],
                    "estimated_cost": json.loads(row[10]) if row[10] else None,
                    "validation_status": row[11],
                    "validated_at": row[12],
                    "actual_cause": row[13],
                    "validation_notes": row[14],
                    "llm_provider": row[15],
                    "llm_model": row[16],
                    "tokens_used": row[17],
                    "created_at": row[18],
                })

            return diagnoses

        except Exception as err:
            _LOGGER.error("Error getting diagnosis history: %s", err)
            return []

    async def get_diagnosis_by_id(
        self,
        diagnosis_id: int,
    ) -> dict[str, Any] | None:
        """
        Get a specific diagnosis by ID.

        Args:
            diagnosis_id: Diagnosis ID

        Returns:
            Diagnosis record or None
        """
        if not self._db:
            return None

        try:
            cursor = await self._db.execute(
                """
                SELECT id, entity_id, diagnosis_date, primary_cause,
                       confidence_percentage, supporting_evidence,
                       alternative_hypotheses, severity_assessment,
                       recommendations, estimated_timeline, estimated_cost,
                       validation_status, validated_at, actual_cause,
                       validation_notes, llm_provider, llm_model, tokens_used,
                       created_at
                FROM diagnosis_history
                WHERE id = ?
                """,
                (diagnosis_id,),
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row:
                return None

            return {
                "id": row[0],
                "entity_id": row[1],
                "diagnosis_date": row[2],
                "primary_cause": row[3],
                "confidence_percentage": row[4],
                "supporting_evidence": json.loads(row[5]) if row[5] else [],
                "alternative_hypotheses": json.loads(row[6]) if row[6] else [],
                "severity_assessment": row[7],
                "recommendations": json.loads(row[8]) if row[8] else {},
                "estimated_timeline": row[9],
                "estimated_cost": json.loads(row[10]) if row[10] else None,
                "validation_status": row[11],
                "validated_at": row[12],
                "actual_cause": row[13],
                "validation_notes": row[14],
                "llm_provider": row[15],
                "llm_model": row[16],
                "tokens_used": row[17],
                "created_at": row[18],
            }

        except Exception as err:
            _LOGGER.error("Error getting diagnosis: %s", err)
            return None

    async def validate_diagnosis(
        self,
        diagnosis_id: int,
        status: str,
        actual_cause: str | None = None,
        notes: str | None = None,
    ) -> None:
        """
        Validate a diagnosis result.

        Args:
            diagnosis_id: Diagnosis ID
            status: pending, confirmed, incorrect, partially_correct
            actual_cause: What the actual cause was
            notes: Validation notes
        """
        if not self._db:
            raise RuntimeError("Database not initialized")

        # Validate status
        valid_statuses = ["pending", "confirmed", "incorrect", "partially_correct"]
        if status not in valid_statuses:
            raise ValueError(f"Invalid validation status: {status}")

        try:
            now = dt_util.now().isoformat()

            await self._db.execute(
                """
                UPDATE diagnosis_history
                SET validation_status = ?,
                    validated_at = ?,
                    actual_cause = ?,
                    validation_notes = ?
                WHERE id = ?
                """,
                (status, now, actual_cause, notes, diagnosis_id),
            )

            await self._db.commit()

            _LOGGER.info(
                "Validated diagnosis #%d: %s",
                diagnosis_id,
                status
            )

        except Exception as err:
            _LOGGER.error("Error validating diagnosis: %s", err)
            raise

    async def get_diagnosis_stats(self) -> dict[str, Any]:
        """
        Get diagnosis statistics for accuracy tracking.

        Returns:
            Statistics dictionary
        """
        if not self._db:
            return {}

        try:
            # Total diagnoses
            cursor = await self._db.execute(
                "SELECT COUNT(*) FROM diagnosis_history"
            )
            total = (await cursor.fetchone())[0]
            await cursor.close()

            # By validation status
            cursor = await self._db.execute(
                """
                SELECT validation_status, COUNT(*)
                FROM diagnosis_history
                GROUP BY validation_status
                """
            )
            status_rows = await cursor.fetchall()
            await cursor.close()

            status_counts = {row[0]: row[1] for row in status_rows}

            # Accuracy (confirmed / validated)
            validated = sum(
                count for status, count in status_counts.items()
                if status in ["confirmed", "incorrect", "partially_correct"]
            )
            confirmed = status_counts.get("confirmed", 0)
            accuracy = (confirmed / validated * 100) if validated > 0 else 0

            # Average confidence
            cursor = await self._db.execute(
                "SELECT AVG(confidence_percentage) FROM diagnosis_history"
            )
            avg_confidence = (await cursor.fetchone())[0] or 0
            await cursor.close()

            # By provider
            cursor = await self._db.execute(
                """
                SELECT llm_provider, COUNT(*)
                FROM diagnosis_history
                GROUP BY llm_provider
                """
            )
            provider_rows = await cursor.fetchall()
            await cursor.close()

            provider_counts = {row[0]: row[1] for row in provider_rows}

            return {
                "total_diagnoses": total,
                "validation_status_counts": status_counts,
                "validated_count": validated,
                "confirmed_count": confirmed,
                "accuracy_percentage": round(accuracy, 2),
                "average_confidence": round(avg_confidence, 2),
                "by_provider": provider_counts,
            }

        except Exception as err:
            _LOGGER.error("Error getting diagnosis stats: %s", err)
            return {}

    # ==================== Battery Management Operations ====================

    async def get_battery_tracking(self, entity_id: str) -> dict[str, Any] | None:
        """
        Get battery tracking data for an entity.

        Args:
            entity_id: Entity ID

        Returns:
            Battery tracking data or None if not found
        """
        if not self._db:
            return None

        try:
            cursor = await self._db.execute(
                """
                SELECT
                    entity_id, friendly_name, current_level, last_updated,
                    drain_rate_per_day, drain_rate_confidence, drain_rate_quality,
                    drain_rate_calculated_at, predicted_replacement_date, days_remaining,
                    prediction_confidence, prediction_confidence_interval_days,
                    battery_type, battery_type_override, battery_type_confidence,
                    last_alerted_threshold, last_alerted_at, alert_count,
                    abnormal_drain_detected, abnormal_drain_percentage,
                    abnormal_drain_since, baseline_drain_rate,
                    last_replacement_date, days_since_replacement
                FROM battery_tracking
                WHERE entity_id = ?
                """,
                (entity_id,)
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row:
                return None

            return {
                "entity_id": row[0],
                "friendly_name": row[1],
                "current_level": row[2],
                "last_updated": row[3],
                "drain_rate_per_day": row[4],
                "drain_rate_confidence": row[5],
                "drain_rate_quality": row[6],
                "drain_rate_calculated_at": row[7],
                "predicted_replacement_date": row[8],
                "days_remaining": row[9],
                "prediction_confidence": row[10],
                "prediction_confidence_interval_days": row[11],
                "battery_type": row[12],
                "battery_type_override": row[13],
                "battery_type_confidence": row[14],
                "last_alerted_threshold": row[15],
                "last_alerted_at": row[16],
                "alert_count": row[17],
                "abnormal_drain_detected": row[18],
                "abnormal_drain_percentage": row[19],
                "abnormal_drain_since": row[20],
                "baseline_drain_rate": row[21],
                "last_replacement_date": row[22],
                "days_since_replacement": row[23],
            }

        except Exception as err:
            _LOGGER.error("Error getting battery tracking for %s: %s", entity_id, err)
            return None

    async def save_battery_tracking(
        self,
        entity_id: str,
        data: dict[str, Any]
    ) -> None:
        """
        Save or update battery tracking data.

        Args:
            entity_id: Entity ID
            data: Dictionary of fields to update
        """
        if not self._db:
            return

        try:
            # Check if exists
            existing = await self.get_battery_tracking(entity_id)

            if existing:
                # Update existing record
                set_clauses = []
                values = []

                for key, value in data.items():
                    set_clauses.append(f"{key} = ?")
                    values.append(value)

                # Always update updated_at
                set_clauses.append("updated_at = ?")
                values.append(dt_util.now())

                values.append(entity_id)

                await self._db.execute(
                    f"""
                    UPDATE battery_tracking
                    SET {', '.join(set_clauses)}
                    WHERE entity_id = ?
                    """,
                    values
                )
            else:
                # Insert new record
                data["entity_id"] = entity_id
                data["created_at"] = dt_util.now()
                data["updated_at"] = dt_util.now()

                fields = list(data.keys())
                placeholders = ', '.join('?' * len(fields))

                await self._db.execute(
                    f"""
                    INSERT INTO battery_tracking ({', '.join(fields)})
                    VALUES ({placeholders})
                    """,
                    list(data.values())
                )

            await self._db.commit()

        except Exception as err:
            _LOGGER.error("Error saving battery tracking for %s: %s", entity_id, err)

    async def save_battery_replacement(
        self,
        entity_id: str,
        replacement_date: datetime,
        battery_type: str | None = None,
        cost: float | None = None,
        notes: str | None = None
    ) -> int | None:
        """
        Save battery replacement history record.

        Args:
            entity_id: Entity ID
            replacement_date: Date of replacement
            battery_type: Battery type (e.g., "AA", "CR2032")
            cost: Cost of battery
            notes: Optional notes

        Returns:
            Replacement record ID
        """
        if not self._db:
            return None

        try:
            # Get friendly name
            tracking = await self.get_battery_tracking(entity_id)
            friendly_name = tracking.get("friendly_name") if tracking else entity_id

            # Get previous prediction for accuracy tracking
            previous_prediction = tracking.get("predicted_replacement_date") if tracking else None

            # Calculate prediction accuracy
            accuracy_days = None
            if previous_prediction:
                accuracy_days = (replacement_date - previous_prediction).days

            cursor = await self._db.execute(
                """
                INSERT INTO battery_replacement_history
                (entity_id, friendly_name, replacement_date, battery_type,
                 battery_cost, notes, previous_prediction_date,
                 prediction_accuracy_days, replacement_source)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'user_reported')
                """,
                (
                    entity_id,
                    friendly_name,
                    replacement_date,
                    battery_type,
                    cost,
                    notes,
                    previous_prediction,
                    accuracy_days
                )
            )

            replacement_id = cursor.lastrowid
            await cursor.close()
            await self._db.commit()

            # Update tracking record
            await self.save_battery_tracking(
                entity_id,
                {
                    "last_replacement_date": replacement_date,
                    "days_since_replacement": 0,
                    "current_level": 100.0,  # Assume fresh battery
                    "last_alerted_threshold": None,  # Reset alerts
                }
            )

            return replacement_id

        except Exception as err:
            _LOGGER.error("Error saving battery replacement: %s", err)
            return None

    async def get_battery_level_history(
        self,
        entity_id: str,
        since_date: datetime
    ) -> list[dict[str, Any]]:
        """
        Get historical battery level data for drain rate calculation using Home Assistant's history.

        Args:
            entity_id: Entity ID
            since_date: Get data since this date

        Returns:
            List of {timestamp, level} dicts, sorted by timestamp
        """
        try:
            # Use Home Assistant's history component to get historical states
            from homeassistant.components import history
            from homeassistant.components.recorder import get_instance

            # Ensure recorder is available
            recorder = get_instance(self.hass)
            if not recorder:
                _LOGGER.debug("Recorder not available for battery history")
                return []

            # Get historical states from HA's history
            end_time = dt_util.now()
            states = await get_instance(self.hass).async_add_executor_job(
                history.state_changes_during_period,
                self.hass,
                since_date,
                end_time,
                entity_id,
                True,  # include_start_time_state
                True,  # significant_changes_only
                1000,  # minimal_response (limit results)
            )

            if not states or entity_id not in states:
                _LOGGER.debug("No historical states found for %s", entity_id)
                return []

            history_data = []
            for state in states[entity_id]:
                try:
                    # Get the battery level from state
                    if state.state in (None, "unknown", "unavailable"):
                        continue

                    level = float(state.state)

                    # Normalize to percentage (0-100)
                    if 0 <= level <= 1:
                        level = level * 100
                    elif level < 0 or level > 100:
                        continue

                    history_data.append({
                        "timestamp": state.last_updated.isoformat(),
                        "level": level
                    })
                except (ValueError, TypeError):
                    continue

            return history_data

        except Exception as err:
            _LOGGER.error("Error getting battery level history for %s: %s", entity_id, err)
            return []

    async def get_battery_replacement_history(
        self,
        entity_id: str,
        limit: int = 10
    ) -> list[dict[str, Any]]:
        """
        Get battery replacement history for an entity.

        Args:
            entity_id: Entity ID
            limit: Maximum number of records to return

        Returns:
            List of replacement records, sorted by date (most recent first)
        """
        if not self._db:
            return []

        try:
            cursor = await self._db.execute(
                """
                SELECT
                    id, entity_id, friendly_name, replacement_date,
                    battery_type, battery_cost, notes,
                    previous_prediction_date, prediction_accuracy_days,
                    replacement_source, created_at
                FROM battery_replacement_history
                WHERE entity_id = ?
                ORDER BY replacement_date DESC
                LIMIT ?
                """,
                (entity_id, limit)
            )

            rows = await cursor.fetchall()
            await cursor.close()

            history = []
            for row in rows:
                history.append({
                    "id": row[0],
                    "entity_id": row[1],
                    "friendly_name": row[2],
                    "replacement_date": row[3],
                    "battery_type": row[4],
                    "battery_cost": row[5],
                    "notes": row[6],
                    "previous_prediction_date": row[7],
                    "prediction_accuracy_days": row[8],
                    "replacement_source": row[9],
                    "created_at": row[10],
                })

            return history

        except Exception as err:
            _LOGGER.error("Error getting battery replacement history for %s: %s", entity_id, err)
            return []
