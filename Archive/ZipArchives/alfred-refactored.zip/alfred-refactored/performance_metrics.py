"""Performance metrics collector for Alfred Digital Butler."""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict, deque
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant, State, Event
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.util import dt as dt_util
from homeassistant.const import (
    ATTR_BATTERY_LEVEL,
    ATTR_TEMPERATURE,
    ATTR_UNIT_OF_MEASUREMENT,
    STATE_UNAVAILABLE,
    STATE_UNKNOWN,
)

_LOGGER = logging.getLogger(__name__)

# Metric types that can be collected
METRIC_BATTERY = "battery_level"
METRIC_TEMPERATURE = "temperature"
METRIC_POWER = "power_consumption"
METRIC_RESPONSE_TIME = "response_time"
METRIC_BRIGHTNESS = "brightness"
METRIC_HUMIDITY = "humidity"

# Hardware power monitoring constants
POWER_BUFFER_SIZE = 600  # Keep 10 minutes at 1 Hz
POWER_FLUSH_INTERVAL = 60  # Write to database every 60 seconds
VOLTAGE_SAG_THRESHOLD = 0.85  # Alert if voltage drops below 85% of nominal
CURRENT_SPIKE_THRESHOLD = 2.0  # Alert if current exceeds 2× average


class PerformanceMetricsCollector:
    """Collector for device performance metrics."""

    def __init__(self, hass: HomeAssistant) -> None:
        """Initialize performance metrics collector."""
        self.hass = hass
        self._enabled = True

        # Hardware power monitoring buffers (entity_id -> deque of samples)
        self._power_buffers: dict[str, deque] = defaultdict(
            lambda: deque(maxlen=POWER_BUFFER_SIZE)
        )

        # Track monitored hardware sensors
        self._monitored_sensors: set[str] = set()

        # Track average values for anomaly detection
        self._baseline_voltage: dict[str, float] = {}
        self._baseline_current: dict[str, float] = {}

        # Cleanup tracker
        self._cleanup_task = None
        self._flush_task = None

    async def async_setup(self) -> None:
        """Set up the performance metrics collector."""
        _LOGGER.info("Setting up Alfred Performance Metrics Collector")
        self._enabled = True

        # Start periodic flush of power data to database
        self._flush_task = async_track_time_interval(
            self.hass,
            self._async_flush_power_data,
            timedelta(seconds=POWER_FLUSH_INTERVAL)
        )

    async def collect_entity_metrics(
        self, entity_id: str
    ) -> dict[str, Any] | None:
        """
        Collect all available performance metrics for an entity.

        Args:
            entity_id: Entity ID to collect metrics for

        Returns:
            Dictionary of metrics with values and units, or None if unavailable
            Example:
            {
                "entity_id": "sensor.living_room_temperature",
                "timestamp": "2025-11-13T18:00:00",
                "metrics": {
                    "temperature": {"value": 21.5, "unit": "°C"},
                    "battery_level": {"value": 85.0, "unit": "%"}
                }
            }
        """
        if not self._enabled:
            return None

        # Get current state
        state = self.hass.states.get(entity_id)
        if not state:
            _LOGGER.debug("Entity %s not found", entity_id)
            return None

        # Skip unavailable entities
        if state.state in (STATE_UNAVAILABLE, STATE_UNKNOWN):
            _LOGGER.debug("Entity %s is unavailable", entity_id)
            return None

        # Collect metrics based on entity type
        metrics = {}
        domain = entity_id.split(".")[0]

        try:
            # Battery level (all battery-powered devices)
            battery = await self._get_battery_level(state)
            if battery is not None:
                metrics[METRIC_BATTERY] = battery

            # Temperature (climate, sensors)
            if domain in ("climate", "sensor", "weather"):
                temperature = await self._get_temperature(state)
                if temperature is not None:
                    metrics[METRIC_TEMPERATURE] = temperature

            # Power consumption (switches, lights, climate)
            if domain in ("switch", "light", "climate", "fan"):
                power = await self._get_power_consumption(state, entity_id)
                if power is not None:
                    metrics[METRIC_POWER] = power

            # Brightness (lights)
            if domain == "light":
                brightness = await self._get_brightness(state)
                if brightness is not None:
                    metrics[METRIC_BRIGHTNESS] = brightness

            # Humidity (sensors, climate)
            if domain in ("climate", "sensor", "weather"):
                humidity = await self._get_humidity(state)
                if humidity is not None:
                    metrics[METRIC_HUMIDITY] = humidity

            # Return metrics if any were collected
            if metrics:
                return {
                    "entity_id": entity_id,
                    "timestamp": dt_util.now().isoformat(),
                    "domain": domain,
                    "metrics": metrics,
                }

            return None

        except Exception as err:
            _LOGGER.error(
                "Error collecting metrics for %s: %s", entity_id, err, exc_info=True
            )
            return None

    async def _get_battery_level(self, state: State) -> dict[str, Any] | None:
        """Extract battery level from entity state."""
        try:
            # Check attributes for battery level
            battery = state.attributes.get(ATTR_BATTERY_LEVEL)
            if battery is not None:
                return {"value": float(battery), "unit": "%"}

            # Check if the entity itself is a battery sensor
            if "battery" in state.entity_id.lower():
                try:
                    value = float(state.state)
                    unit = state.attributes.get(ATTR_UNIT_OF_MEASUREMENT, "%")
                    return {"value": value, "unit": unit}
                except (ValueError, TypeError):
                    pass

            return None

        except Exception as err:
            _LOGGER.debug("Error getting battery level: %s", err)
            return None

    async def _get_temperature(self, state: State) -> dict[str, Any] | None:
        """Extract temperature from entity state."""
        try:
            # Check attributes for temperature
            temperature = state.attributes.get(ATTR_TEMPERATURE)
            if temperature is not None:
                unit = state.attributes.get(ATTR_UNIT_OF_MEASUREMENT, "°C")
                return {"value": float(temperature), "unit": unit}

            # Check if the entity itself is a temperature sensor
            if "temperature" in state.entity_id.lower():
                try:
                    value = float(state.state)
                    unit = state.attributes.get(ATTR_UNIT_OF_MEASUREMENT, "°C")
                    return {"value": value, "unit": unit}
                except (ValueError, TypeError):
                    pass

            # Check for current_temperature (climate devices)
            current_temp = state.attributes.get("current_temperature")
            if current_temp is not None:
                unit = state.attributes.get("temperature_unit", "°C")
                return {"value": float(current_temp), "unit": unit}

            return None

        except Exception as err:
            _LOGGER.debug("Error getting temperature: %s", err)
            return None

    async def _get_power_consumption(
        self, state: State, entity_id: str
    ) -> dict[str, Any] | None:
        """Extract power consumption from entity state."""
        try:
            # Check for power attribute
            power = state.attributes.get("current_power_w")
            if power is not None:
                return {"value": float(power), "unit": "W"}

            # Check for power sensor
            power_sensor_id = f"sensor.{entity_id.split('.')[1]}_power"
            power_state = self.hass.states.get(power_sensor_id)
            if power_state and power_state.state not in (
                STATE_UNAVAILABLE,
                STATE_UNKNOWN,
            ):
                try:
                    value = float(power_state.state)
                    unit = power_state.attributes.get(ATTR_UNIT_OF_MEASUREMENT, "W")
                    return {"value": value, "unit": unit}
                except (ValueError, TypeError):
                    pass

            return None

        except Exception as err:
            _LOGGER.debug("Error getting power consumption: %s", err)
            return None

    async def _get_brightness(self, state: State) -> dict[str, Any] | None:
        """Extract brightness from light entity."""
        try:
            brightness = state.attributes.get("brightness")
            if brightness is not None:
                # Convert from 0-255 to 0-100 percentage
                percentage = (float(brightness) / 255.0) * 100.0
                return {"value": percentage, "unit": "%"}

            return None

        except Exception as err:
            _LOGGER.debug("Error getting brightness: %s", err)
            return None

    async def _get_humidity(self, state: State) -> dict[str, Any] | None:
        """Extract humidity from entity state."""
        try:
            # Check attributes for humidity
            humidity = state.attributes.get("humidity") or state.attributes.get(
                "current_humidity"
            )
            if humidity is not None:
                return {"value": float(humidity), "unit": "%"}

            # Check if the entity itself is a humidity sensor
            if "humidity" in state.entity_id.lower():
                try:
                    value = float(state.state)
                    unit = state.attributes.get(ATTR_UNIT_OF_MEASUREMENT, "%")
                    return {"value": value, "unit": unit}
                except (ValueError, TypeError):
                    pass

            return None

        except Exception as err:
            _LOGGER.debug("Error getting humidity: %s", err)
            return None

    async def collect_multiple_entities(
        self, entity_ids: list[str]
    ) -> list[dict[str, Any]]:
        """
        Collect metrics for multiple entities.

        Args:
            entity_ids: List of entity IDs to collect metrics for

        Returns:
            List of metric dictionaries (only entities with metrics)
        """
        results = []

        for entity_id in entity_ids:
            metrics = await self.collect_entity_metrics(entity_id)
            if metrics:
                results.append(metrics)

        _LOGGER.debug(
            "Collected metrics for %d/%d entities", len(results), len(entity_ids)
        )

        return results

    async def collect_domain_metrics(self, domain: str) -> list[dict[str, Any]]:
        """
        Collect metrics for all entities in a domain.

        Args:
            domain: Domain to collect metrics for (e.g., "sensor", "light")

        Returns:
            List of metric dictionaries
        """
        # Get all entity IDs for the domain
        entity_ids = []
        for entity_id in self.hass.states.async_entity_ids(domain):
            entity_ids.append(entity_id)

        _LOGGER.debug("Found %d entities in domain %s", len(entity_ids), domain)

        return await self.collect_multiple_entities(entity_ids)

    async def get_trackable_entities(self) -> list[str]:
        """
        Get list of entities suitable for performance tracking.

        Returns:
            List of entity IDs that have trackable performance metrics
        """
        trackable = []

        # Domains likely to have performance metrics
        trackable_domains = [
            "sensor",
            "climate",
            "light",
            "switch",
            "fan",
            "cover",
            "weather",
        ]

        for domain in trackable_domains:
            for entity_id in self.hass.states.async_entity_ids(domain):
                state = self.hass.states.get(entity_id)
                if state and state.state not in (STATE_UNAVAILABLE, STATE_UNKNOWN):
                    trackable.append(entity_id)

        _LOGGER.info("Found %d trackable entities", len(trackable))

        return trackable

    # ==================== Hardware Power Monitoring (Epic 3.2) ====================

    async def detect_hardware_power_sensors(self) -> list[str]:
        """
        Detect ESPHome hardware power monitoring sensors.

        Returns:
            List of entity IDs that are hardware power sensors
        """
        hardware_sensors = []

        for entity_id in self.hass.states.async_entity_ids("sensor"):
            state = self.hass.states.get(entity_id)

            if not state or state.state in (STATE_UNAVAILABLE, STATE_UNKNOWN):
                continue

            # Check for ESPHome power sensors
            # Look for attributes that indicate hardware power monitoring
            integration = state.attributes.get("integration")
            device_class = state.attributes.get("device_class")

            # ESPHome power sensors
            if integration == "esphome" and device_class == "power":
                hardware_sensors.append(entity_id)
                continue

            # Also check for voltage and current sensors (part of power monitoring)
            if integration == "esphome":
                if device_class in ("voltage", "current"):
                    hardware_sensors.append(entity_id)
                    continue

                # Check entity_id naming patterns
                if any(keyword in entity_id.lower() for keyword in [
                    "power", "voltage", "current", "energy"
                ]):
                    hardware_sensors.append(entity_id)

        _LOGGER.info("Detected %d hardware power sensors", len(hardware_sensors))
        return hardware_sensors

    async def collect_hardware_power_metrics(
        self,
        entity_id: str
    ) -> dict[str, Any] | None:
        """
        Collect detailed power metrics from hardware sensors.

        Args:
            entity_id: Entity ID of power sensor

        Returns:
            Dict with voltage, current, power, quality metrics
        """
        state = self.hass.states.get(entity_id)

        if not state or state.state in (STATE_UNAVAILABLE, STATE_UNKNOWN):
            return None

        try:
            # Get related sensors (voltage, current, power from same device)
            device_sensors = await self._get_related_power_sensors(entity_id)

            metrics = {
                "entity_id": entity_id,
                "timestamp": dt_util.now().isoformat(),
                "source": "esphome",
            }

            # Collect voltage
            if "voltage" in device_sensors:
                voltage_state = self.hass.states.get(device_sensors["voltage"])
                if voltage_state:
                    try:
                        metrics["voltage"] = float(voltage_state.state)
                    except (ValueError, TypeError):
                        pass

            # Collect current
            if "current" in device_sensors:
                current_state = self.hass.states.get(device_sensors["current"])
                if current_state:
                    try:
                        metrics["current"] = float(current_state.state)
                    except (ValueError, TypeError):
                        pass

            # Collect power
            if "power" in device_sensors:
                power_state = self.hass.states.get(device_sensors["power"])
                if power_state:
                    try:
                        metrics["power"] = float(power_state.state)
                    except (ValueError, TypeError):
                        pass

            # Collect energy (if available)
            if "energy" in device_sensors:
                energy_state = self.hass.states.get(device_sensors["energy"])
                if energy_state:
                    try:
                        metrics["energy_wh"] = float(energy_state.state)
                    except (ValueError, TypeError):
                        pass

            # Collect power quality metrics (if available from ESPHome)
            if "power_quality" in device_sensors:
                quality_state = self.hass.states.get(device_sensors["power_quality"])
                if quality_state:
                    try:
                        metrics["power_quality_score"] = float(quality_state.state)
                    except (ValueError, TypeError):
                        pass

            if "voltage_stability" in device_sensors:
                stability_state = self.hass.states.get(device_sensors["voltage_stability"])
                if stability_state:
                    try:
                        metrics["voltage_stability"] = float(stability_state.state)
                    except (ValueError, TypeError):
                        pass

            if "current_peak" in device_sensors:
                peak_state = self.hass.states.get(device_sensors["current_peak"])
                if peak_state:
                    try:
                        metrics["current_peak"] = float(peak_state.state)
                    except (ValueError, TypeError):
                        pass

            return metrics if len(metrics) > 3 else None  # Must have more than just meta fields

        except Exception as err:
            _LOGGER.error(
                "Error collecting hardware power metrics for %s: %s",
                entity_id, err, exc_info=True
            )
            return None

    async def _get_related_power_sensors(self, entity_id: str) -> dict[str, str]:
        """
        Get related power sensors from the same device.

        Args:
            entity_id: Base entity ID

        Returns:
            Dict mapping sensor type to entity_id
        """
        related = {}

        # Get device name from entity_id (e.g., "power_monitor_01" from "sensor.power_monitor_01_power")
        parts = entity_id.replace("sensor.", "").rsplit("_", 1)

        if len(parts) < 2:
            return related

        device_name = parts[0]

        # Look for related sensors with same device name
        sensor_types = {
            "voltage": ["voltage", "bus_voltage"],
            "current": ["current"],
            "power": ["power"],
            "energy": ["energy_total", "energy_today", "energy"],
            "power_quality": ["power_quality"],
            "voltage_stability": ["voltage_stability"],
            "current_peak": ["current_peak"],
        }

        for sensor_type, keywords in sensor_types.items():
            for keyword in keywords:
                potential_id = f"sensor.{device_name}_{keyword}"

                if self.hass.states.get(potential_id):
                    related[sensor_type] = potential_id
                    break

        return related

    def calculate_power_quality(
        self,
        voltage_samples: list[float],
        current_samples: list[float] | None = None
    ) -> float:
        """
        Calculate power quality score from voltage and current samples.

        Args:
            voltage_samples: List of voltage readings
            current_samples: List of current readings (optional)

        Returns:
            Power quality score (0-100)
        """
        if not voltage_samples:
            return 0.0

        try:
            import statistics

            score = 100.0

            # Voltage stability (penalize high standard deviation)
            if len(voltage_samples) > 1:
                std_dev = statistics.stdev(voltage_samples)

                # Penalize voltage instability
                # > 0.5V stdev = very poor
                # > 0.1V stdev = poor
                if std_dev > 0.5:
                    score = 0.0
                elif std_dev > 0.1:
                    score -= (std_dev - 0.1) * 200.0

            # Voltage range (penalize if outside nominal ±10%)
            avg_voltage = statistics.mean(voltage_samples)
            expected_voltage = 12.0  # Configurable per device

            voltage_deviation = abs(avg_voltage - expected_voltage) / expected_voltage

            if voltage_deviation > 0.15:  # > 15% deviation
                score -= 50.0
            elif voltage_deviation > 0.10:  # > 10% deviation
                score -= 30.0

            # Current spikes (if current data available)
            if current_samples and len(current_samples) > 1:
                max_current = max(current_samples)
                avg_current = statistics.mean(current_samples)

                if avg_current > 0:
                    spike_ratio = max_current / avg_current

                    # Penalize if spike > 3× average (indicates transients)
                    if spike_ratio > 3.0:
                        score -= 20.0
                    elif spike_ratio > 2.0:
                        score -= 10.0

            return max(0.0, min(100.0, score))

        except Exception as err:
            _LOGGER.error("Error calculating power quality: %s", err)
            return 0.0

    def detect_startup_event(
        self,
        current_samples: list[float],
        threshold_multiplier: float = 2.0
    ) -> bool:
        """
        Detect startup inrush current event.

        Args:
            current_samples: List of recent current readings
            threshold_multiplier: Multiplier for average to detect spike

        Returns:
            True if startup event detected
        """
        if len(current_samples) < 5:
            return False

        try:
            import statistics

            # Check if there's a sudden spike in current
            # Compare first few samples to later samples

            initial_samples = current_samples[:3]
            later_samples = current_samples[3:]

            if not later_samples:
                return False

            initial_avg = statistics.mean(initial_samples)
            later_avg = statistics.mean(later_samples)

            # Startup detected if initial current significantly higher than steady state
            if later_avg > 0 and initial_avg > later_avg * threshold_multiplier:
                return True

            # Also check for rapid rise
            if len(current_samples) >= 2:
                delta = current_samples[1] - current_samples[0]

                if delta > 0.5:  # Rapid increase > 0.5A
                    return True

            return False

        except Exception as err:
            _LOGGER.error("Error detecting startup event: %s", err)
            return False

    async def aggregate_power_data(
        self,
        samples: list[dict[str, Any]],
        interval: str = "1m"
    ) -> dict[str, Any]:
        """
        Aggregate power samples over an interval.

        Args:
            samples: List of power metric samples
            interval: Aggregation interval ("1s", "1m", "1h")

        Returns:
            Aggregated metrics
        """
        if not samples:
            return {}

        try:
            import statistics

            # Extract values
            voltages = [s["voltage"] for s in samples if "voltage" in s]
            currents = [s["current"] for s in samples if "current" in s]
            powers = [s["power"] for s in samples if "power" in s]

            aggregated = {
                "timestamp": samples[-1]["timestamp"],  # Latest timestamp
                "sample_count": len(samples),
                "aggregation_period": interval,
            }

            # Voltage statistics
            if voltages:
                aggregated["voltage"] = statistics.mean(voltages)
                aggregated["voltage_min"] = min(voltages)
                aggregated["voltage_max"] = max(voltages)
                aggregated["voltage_stability"] = statistics.stdev(voltages) if len(voltages) > 1 else 0.0

            # Current statistics
            if currents:
                aggregated["current"] = statistics.mean(currents)
                aggregated["current_min"] = min(currents)
                aggregated["current_max"] = max(currents)
                aggregated["current_peak"] = max(currents)

            # Power statistics
            if powers:
                aggregated["power"] = statistics.mean(powers)
                aggregated["power_min"] = min(powers)
                aggregated["power_max"] = max(powers)

            # Calculate power quality
            if voltages:
                aggregated["power_quality_score"] = self.calculate_power_quality(
                    voltages, currents if currents else None
                )

            # Detect startup if we have current data
            if currents:
                aggregated["startup_detected"] = self.detect_startup_event(currents)

            return aggregated

        except Exception as err:
            _LOGGER.error("Error aggregating power data: %s", err)
            return {}

    # ==================== Power Data Buffering & Storage ====================

    async def start_monitoring_hardware_sensor(
        self,
        entity_id: str,
        nominal_voltage: float = 12.0
    ) -> None:
        """
        Start monitoring a hardware power sensor.

        Args:
            entity_id: Entity ID of the power sensor
            nominal_voltage: Expected nominal voltage for the device
        """
        if entity_id in self._monitored_sensors:
            _LOGGER.debug("Already monitoring %s", entity_id)
            return

        self._monitored_sensors.add(entity_id)
        _LOGGER.info("Started monitoring hardware sensor: %s", entity_id)

        # Set baseline voltage for anomaly detection
        self._baseline_voltage[entity_id] = nominal_voltage

    async def stop_monitoring_hardware_sensor(self, entity_id: str) -> None:
        """Stop monitoring a hardware power sensor."""
        self._monitored_sensors.discard(entity_id)
        self._power_buffers.pop(entity_id, None)
        self._baseline_voltage.pop(entity_id, None)
        self._baseline_current.pop(entity_id, None)
        _LOGGER.info("Stopped monitoring hardware sensor: %s", entity_id)

    async def record_power_sample(
        self,
        entity_id: str,
        metrics: dict[str, Any]
    ) -> None:
        """
        Record a power sample in the buffer.

        Args:
            entity_id: Entity ID of the sensor
            metrics: Power metrics dict from collect_hardware_power_metrics
        """
        if not self._enabled or entity_id not in self._monitored_sensors:
            return

        # Add timestamp if not present
        if "timestamp" not in metrics:
            metrics["timestamp"] = dt_util.now().isoformat()

        # Add to buffer
        self._power_buffers[entity_id].append(metrics)

        # Check for anomalies
        await self._check_power_anomalies(entity_id, metrics)

        # Update baselines (rolling average)
        await self._update_baselines(entity_id, metrics)

    async def _check_power_anomalies(
        self,
        entity_id: str,
        metrics: dict[str, Any]
    ) -> None:
        """
        Check for power anomalies and fire events.

        Args:
            entity_id: Entity ID
            metrics: Current power metrics
        """
        try:
            # Check voltage sag
            if "voltage" in metrics and entity_id in self._baseline_voltage:
                nominal = self._baseline_voltage[entity_id]
                current_voltage = metrics["voltage"]

                if current_voltage < nominal * VOLTAGE_SAG_THRESHOLD:
                    # Fire voltage sag event
                    self.hass.bus.async_fire(
                        "alfred_voltage_sag_detected",
                        {
                            "entity_id": entity_id,
                            "voltage": current_voltage,
                            "nominal_voltage": nominal,
                            "sag_percentage": (1 - current_voltage / nominal) * 100,
                            "timestamp": metrics["timestamp"],
                        }
                    )
                    _LOGGER.warning(
                        "Voltage sag detected on %s: %.2fV (%.1f%% below nominal)",
                        entity_id, current_voltage,
                        (1 - current_voltage / nominal) * 100
                    )

            # Check current spike
            if "current" in metrics and entity_id in self._baseline_current:
                baseline = self._baseline_current[entity_id]
                current = metrics["current"]

                if baseline > 0 and current > baseline * CURRENT_SPIKE_THRESHOLD:
                    # Fire current spike event
                    self.hass.bus.async_fire(
                        "alfred_current_spike_detected",
                        {
                            "entity_id": entity_id,
                            "current": current,
                            "baseline_current": baseline,
                            "spike_multiplier": current / baseline,
                            "timestamp": metrics["timestamp"],
                        }
                    )
                    _LOGGER.warning(
                        "Current spike detected on %s: %.2fA (%.1f× baseline)",
                        entity_id, current, current / baseline
                    )

        except Exception as err:
            _LOGGER.error("Error checking power anomalies: %s", err)

    async def _update_baselines(
        self,
        entity_id: str,
        metrics: dict[str, Any]
    ) -> None:
        """
        Update baseline values for anomaly detection.

        Uses exponential moving average to track typical values.

        Args:
            entity_id: Entity ID
            metrics: Current power metrics
        """
        try:
            alpha = 0.1  # Smoothing factor for EMA

            # Update voltage baseline
            if "voltage" in metrics:
                current_voltage = metrics["voltage"]
                if entity_id in self._baseline_voltage:
                    old_baseline = self._baseline_voltage[entity_id]
                    self._baseline_voltage[entity_id] = (
                        alpha * current_voltage + (1 - alpha) * old_baseline
                    )
                else:
                    self._baseline_voltage[entity_id] = current_voltage

            # Update current baseline
            if "current" in metrics:
                current_current = metrics["current"]
                if current_current > 0.01:  # Only update if device is drawing power
                    if entity_id in self._baseline_current:
                        old_baseline = self._baseline_current[entity_id]
                        self._baseline_current[entity_id] = (
                            alpha * current_current + (1 - alpha) * old_baseline
                        )
                    else:
                        self._baseline_current[entity_id] = current_current

        except Exception as err:
            _LOGGER.error("Error updating baselines: %s", err)

    async def _async_flush_power_data(self, now: datetime) -> None:
        """
        Flush buffered power data to database (called every 60s).

        Args:
            now: Current datetime
        """
        if not self._enabled or not self._power_buffers:
            return

        try:
            # Import pattern_storage here to avoid circular dependency
            from .pattern_storage import PatternStorage

            pattern_storage = PatternStorage(self.hass)

            for entity_id, buffer in self._power_buffers.items():
                if not buffer:
                    continue

                # Get samples from last flush interval
                samples = list(buffer)

                if not samples:
                    continue

                # Aggregate data for 1-minute interval
                aggregated = await self.aggregate_power_data(samples, interval="1m")

                if not aggregated:
                    continue

                # Write to database (power_consumption_log table)
                await pattern_storage.log_power_consumption(
                    entity_id=entity_id,
                    timestamp=dt_util.parse_datetime(aggregated["timestamp"]),
                    voltage=aggregated.get("voltage"),
                    current=aggregated.get("current"),
                    power=aggregated.get("power"),
                    energy_wh=aggregated.get("energy_wh"),
                    power_quality_score=aggregated.get("power_quality_score"),
                )

                _LOGGER.debug(
                    "Flushed %d power samples for %s to database",
                    len(samples), entity_id
                )

                # Clear buffer after successful write
                buffer.clear()

        except Exception as err:
            _LOGGER.error("Error flushing power data to database: %s", err, exc_info=True)

    async def get_recent_power_data(
        self,
        entity_id: str,
        seconds: int = 60
    ) -> list[dict[str, Any]]:
        """
        Get recent power data from buffer.

        Args:
            entity_id: Entity ID
            seconds: Number of seconds of data to retrieve

        Returns:
            List of power samples
        """
        if entity_id not in self._power_buffers:
            return []

        buffer = self._power_buffers[entity_id]
        if not buffer:
            return []

        # Get samples from last N seconds
        cutoff_time = dt_util.now() - timedelta(seconds=seconds)

        recent_samples = []
        for sample in reversed(buffer):
            sample_time = dt_util.parse_datetime(sample["timestamp"])
            if sample_time and sample_time >= cutoff_time:
                recent_samples.append(sample)
            else:
                break

        return list(reversed(recent_samples))

    # ==================== Runtime Tracker Integration ====================

    async def get_power_state(
        self,
        entity_id: str,
        power_threshold: float = 0.5
    ) -> bool:
        """
        Get current power state (on/off) based on power consumption.

        Used by runtime_tracker to determine device state.

        Args:
            entity_id: Entity ID
            power_threshold: Minimum power to consider device "on" (watts)

        Returns:
            True if device is powered on, False otherwise
        """
        # Get most recent power data
        recent_data = await self.get_recent_power_data(entity_id, seconds=5)

        if not recent_data:
            return False

        # Check if recent average power exceeds threshold
        recent_powers = [s.get("power", 0) for s in recent_data if "power" in s]

        if not recent_powers:
            return False

        import statistics
        avg_power = statistics.mean(recent_powers)

        return avg_power >= power_threshold

    async def get_current_power_metrics(
        self,
        entity_id: str
    ) -> dict[str, Any] | None:
        """
        Get current power metrics for an entity.

        Used by runtime_tracker and intelligence engine.

        Args:
            entity_id: Entity ID

        Returns:
            Latest power metrics or None
        """
        if entity_id not in self._power_buffers:
            return None

        buffer = self._power_buffers[entity_id]
        if not buffer:
            return None

        # Return most recent sample
        return buffer[-1]

    async def async_shutdown(self) -> None:
        """Shutdown the performance metrics collector."""
        _LOGGER.info("Shutting down Performance Metrics Collector")

        # Flush any remaining data
        if self._power_buffers:
            await self._async_flush_power_data(dt_util.now())

        # Cancel periodic tasks
        if self._flush_task:
            self._flush_task()
            self._flush_task = None

        self._enabled = False
