"""Pipe freeze prediction and prevention system.

Epic 5: Security & Environmental Safety
Story 5.5: Pipe Freeze Prediction & Prevention

Provides advanced warning of pipe freeze risk with multi-day forecasting,
preventive actions, and automated responses.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any
from enum import Enum

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util
from homeassistant.const import ATTR_TEMPERATURE

from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class FreezeSeverity(Enum):
    """Freeze risk severity levels."""

    NONE = "none"
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class BuildingFactor(Enum):
    """Building construction factors affecting freeze risk."""

    WELL_INSULATED = "well_insulated"
    MODERATE_INSULATION = "moderate_insulation"
    POOR_INSULATION = "poor_insulation"
    EXPOSED_PIPES = "exposed_pipes"
    PROTECTED_PIPES = "protected_pipes"


class PipeFreezePredictor:
    """Advanced pipe freeze prediction with multi-day forecasting.

    Provides:
    - Hours until freeze risk calculation
    - Multi-day forecast analysis
    - Building-specific risk factors
    - Preventive action suggestions
    - Automated actions (if configured)
    - Post-freeze detection
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize pipe freeze predictor.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage

        # Configuration (can be made configurable later)
        self._freeze_threshold = 32.0  # Fahrenheit
        self._critical_threshold = 20.0  # Fahrenheit
        self._basement_warning_temp = 40.0  # Fahrenheit
        self._basement_critical_temp = 32.0  # Fahrenheit

        # Building factors (defaults - should be configurable)
        self._insulation_quality = BuildingFactor.MODERATE_INSULATION
        self._pipe_exposure = BuildingFactor.PROTECTED_PIPES

    async def predict_freeze_risk(
        self,
        forecast_days: int = 3,
    ) -> dict[str, Any]:
        """Predict pipe freeze risk with multi-day forecast.

        Args:
            forecast_days: Number of days to forecast (default: 3)

        Returns:
            Freeze risk prediction with hours until risk, severity, and actions
        """
        try:
            # Get current conditions
            outdoor_temp = self._get_outdoor_temperature()
            indoor_temp = self._get_indoor_temperature()
            basement_temp = self._get_basement_temperature()

            if outdoor_temp is None:
                return {
                    "risk_level": FreezeSeverity.NONE.value,
                    "hours_until_risk": None,
                    "severity": "none",
                    "confidence": 0.0,
                    "message": "Outdoor temperature sensor not available",
                }

            # Get weather forecast
            forecast = await self._get_weather_forecast(forecast_days)

            # Calculate hours until freeze risk
            hours_until_risk = self._calculate_hours_until_risk(
                outdoor_temp, forecast
            )

            # Calculate severity based on multiple factors
            severity = self._calculate_severity(
                outdoor_temp,
                indoor_temp,
                basement_temp,
                forecast,
                hours_until_risk,
            )

            # Generate preventive actions
            actions = self._generate_preventive_actions(severity, hours_until_risk)

            # Check for post-freeze conditions
            post_freeze_detected = await self._check_post_freeze_conditions(
                outdoor_temp, indoor_temp, basement_temp
            )

            # Build prediction result
            result = {
                "risk_level": severity.value,
                "hours_until_risk": hours_until_risk,
                "severity": severity.value,
                "confidence": self._calculate_confidence(forecast, hours_until_risk),
                "current_outdoor_temp": outdoor_temp,
                "current_indoor_temp": indoor_temp,
                "current_basement_temp": basement_temp,
                "forecast_days": forecast_days,
                "forecast_summary": self._summarize_forecast(forecast),
                "preventive_actions": actions,
                "post_freeze_detected": post_freeze_detected,
                "building_factors": {
                    "insulation": self._insulation_quality.value,
                    "pipe_exposure": self._pipe_exposure.value,
                },
                "message": self._generate_message(severity, hours_until_risk),
            }

            # Store prediction
            await self._store_prediction(result)

            return result

        except Exception as err:
            _LOGGER.error("Error predicting freeze risk: %s", err, exc_info=True)
            return {
                "risk_level": FreezeSeverity.NONE.value,
                "hours_until_risk": None,
                "severity": "none",
                "confidence": 0.0,
                "error": str(err),
            }

    def _calculate_hours_until_risk(
        self,
        current_temp: float,
        forecast: list[dict[str, Any]] | None,
    ) -> int | None:
        """Calculate hours until freeze risk.

        Args:
            current_temp: Current outdoor temperature
            forecast: Weather forecast data

        Returns:
            Hours until freeze risk, or None if no risk
        """
        if current_temp >= self._freeze_threshold:
            # Temperature is above freezing, check forecast
            if forecast:
                for hour_data in forecast:
                    temp = hour_data.get("temperature")
                    hours_ahead = hour_data.get("hours_ahead", 0)
                    if temp is not None and temp < self._freeze_threshold:
                        return hours_ahead
            return None  # No freeze risk in forecast

        # Already at or below freezing
        return 0

    def _calculate_severity(
        self,
        outdoor_temp: float,
        indoor_temp: float | None,
        basement_temp: float | None,
        forecast: list[dict[str, Any]] | None,
        hours_until_risk: int | None,
    ) -> FreezeSeverity:
        """Calculate freeze risk severity.

        Args:
            outdoor_temp: Current outdoor temperature
            indoor_temp: Current indoor temperature
            basement_temp: Current basement temperature
            forecast: Weather forecast
            hours_until_risk: Hours until freeze risk

        Returns:
            Freeze severity level
        """
        # Critical: Already freezing and basement is cold
        if outdoor_temp <= self._critical_threshold:
            if basement_temp is not None and basement_temp <= self._basement_critical_temp:
                return FreezeSeverity.CRITICAL
            return FreezeSeverity.HIGH

        # High: Freezing now or within 12 hours
        if outdoor_temp <= self._freeze_threshold:
            return FreezeSeverity.HIGH

        if hours_until_risk is not None and hours_until_risk <= 12:
            return FreezeSeverity.HIGH

        # Moderate: Freeze risk in 12-48 hours
        if hours_until_risk is not None and hours_until_risk <= 48:
            # Check if forecast shows sustained cold
            if forecast and self._has_sustained_cold(forecast, hours_until_risk):
                return FreezeSeverity.MODERATE
            return FreezeSeverity.LOW

        # Low: Freeze risk beyond 48 hours
        if hours_until_risk is not None:
            return FreezeSeverity.LOW

        # None: No freeze risk
        return FreezeSeverity.NONE

    def _has_sustained_cold(
        self,
        forecast: list[dict[str, Any]],
        start_hours: int,
    ) -> bool:
        """Check if forecast shows sustained cold period.

        Args:
            forecast: Weather forecast
            start_hours: Hours from now when cold starts

        Returns:
            True if sustained cold period expected
        """
        if not forecast:
            return False

        cold_hours = 0
        for hour_data in forecast:
            hours_ahead = hour_data.get("hours_ahead", 0)
            if hours_ahead < start_hours:
                continue
            temp = hour_data.get("temperature")
            if temp is not None and temp < self._freeze_threshold:
                cold_hours += 1
            else:
                break

        # Consider it sustained if cold for 6+ hours
        return cold_hours >= 6

    def _generate_preventive_actions(
        self,
        severity: FreezeSeverity,
        hours_until_risk: int | None,
    ) -> list[str]:
        """Generate preventive action suggestions.

        Args:
            severity: Freeze severity level
            hours_until_risk: Hours until freeze risk

        Returns:
            List of preventive actions
        """
        actions = []

        if severity == FreezeSeverity.CRITICAL:
            actions.extend([
                "URGENT: Pipes at immediate risk of freezing",
                "Increase heat immediately in vulnerable areas",
                "Open all cabinet doors under sinks",
                "Let faucets drip continuously",
                "Check for already frozen pipes",
                "Consider shutting off water to exposed areas",
            ])
        elif severity == FreezeSeverity.HIGH:
            actions.extend([
                "Increase heat in vulnerable areas (basement, crawl spaces)",
                "Open cabinet doors under sinks",
                "Let faucets drip slightly",
                "Insulate exposed pipes immediately",
                "Monitor basement/crawl space temperature closely",
            ])
        elif severity == FreezeSeverity.MODERATE:
            if hours_until_risk and hours_until_risk <= 24:
                actions.extend([
                    "Prepare for freeze risk within 24 hours",
                    "Increase heat in vulnerable areas",
                    "Open cabinet doors",
                    "Insulate exposed pipes",
                    "Monitor temperature trends",
                ])
            else:
                actions.extend([
                    "Freeze risk expected in 24-48 hours",
                    "Plan preventive measures",
                    "Check insulation on exposed pipes",
                    "Monitor weather forecast",
                ])
        elif severity == FreezeSeverity.LOW:
            actions.extend([
                "Freeze risk possible beyond 48 hours",
                "Monitor weather forecast",
                "Review pipe insulation",
            ])

        # Add building-specific actions
        if self._insulation_quality == BuildingFactor.POOR_INSULATION:
            actions.append("Consider improving insulation (higher risk due to poor insulation)")

        if self._pipe_exposure == BuildingFactor.EXPOSED_PIPES:
            actions.append("Exposed pipes detected - prioritize insulation")

        return actions

    async def _check_post_freeze_conditions(
        self,
        outdoor_temp: float,
        indoor_temp: float | None,
        basement_temp: float | None,
    ) -> dict[str, Any]:
        """Check if pipes may already be frozen.

        Args:
            outdoor_temp: Current outdoor temperature
            indoor_temp: Current indoor temperature
            basement_temp: Current basement temperature

        Returns:
            Post-freeze detection result
        """
        # Check if we've had freezing temps and pipes might be frozen
        if outdoor_temp > self._freeze_threshold:
            # Temperature has risen above freezing
            # Check if we had freezing conditions recently
            recent_freeze = await self._check_recent_freeze_conditions()

            if recent_freeze:
                return {
                    "detected": True,
                    "message": "Recent freezing conditions detected - check pipes for damage",
                    "recommendations": [
                        "Check all faucets for water flow",
                        "Inspect pipes for visible damage",
                        "Monitor for leaks as pipes thaw",
                        "Check water pressure",
                    ],
                }

        return {
            "detected": False,
            "message": "No post-freeze conditions detected",
        }

    async def _check_recent_freeze_conditions(self) -> bool:
        """Check if freezing conditions occurred recently.

        Returns:
            True if freezing conditions in last 24 hours
        """
        # This would check historical data
        # For now, return False (placeholder)
        return False

    async def _get_weather_forecast(
        self,
        days: int,
    ) -> list[dict[str, Any]] | None:
        """Get weather forecast for specified days.

        Args:
            days: Number of days to forecast

        Returns:
            Forecast data or None
        """
        try:
            # Find weather entity
            weather_entity = self._find_weather_entity()
            if not weather_entity:
                _LOGGER.warning("No weather entity found")
                return None

            state = self.hass.states.get(weather_entity)
            if not state or not state.attributes:
                return None

            # Get forecast from weather entity
            forecast = state.attributes.get("forecast")
            if not forecast:
                return None

            # Process forecast into hourly format
            hourly_forecast = []
            for i, day_forecast in enumerate(forecast[:days]):
                # Extract temperature and time
                temp = day_forecast.get("temperature")
                datetime_str = day_forecast.get("datetime")

                if temp is not None:
                    hours_ahead = i * 24  # Approximate
                    hourly_forecast.append({
                        "temperature": float(temp),
                        "hours_ahead": hours_ahead,
                        "datetime": datetime_str,
                    })

            return hourly_forecast

        except Exception as err:
            _LOGGER.error("Error getting weather forecast: %s", err, exc_info=True)
            return None

    def _find_weather_entity(self) -> str | None:
        """Find weather entity in Home Assistant.

        Returns:
            Weather entity ID or None
        """
        for entity_id in self.hass.states.async_entity_ids("weather"):
            return entity_id
        return None

    def _get_outdoor_temperature(self) -> float | None:
        """Get outdoor temperature."""
        # Try weather entity first
        weather_entity = self._find_weather_entity()
        if weather_entity:
            state = self.hass.states.get(weather_entity)
            if state:
                temp = state.attributes.get("temperature")
                if temp is not None:
                    try:
                        return float(temp)
                    except (ValueError, TypeError):
                        pass

        # Fallback to sensor search
        for entity_id in self.hass.states.async_entity_ids():
            if "outdoor" in entity_id.lower() and "temp" in entity_id.lower():
                state = self.hass.states.get(entity_id)
                if state:
                    try:
                        return float(state.state)
                    except (ValueError, TypeError):
                        pass
        return None

    def _get_indoor_temperature(self) -> float | None:
        """Get indoor temperature."""
        # Try thermostat first
        for entity_id in self.hass.states.async_entity_ids("climate"):
            state = self.hass.states.get(entity_id)
            if state and state.attributes:
                temp = state.attributes.get("current_temperature")
                if temp is not None:
                    try:
                        return float(temp)
                    except (ValueError, TypeError):
                        pass

        # Fallback to sensor search
        for entity_id in self.hass.states.async_entity_ids():
            if "indoor" in entity_id.lower() and "temp" in entity_id.lower():
                state = self.hass.states.get(entity_id)
                if state:
                    try:
                        return float(state.state)
                    except (ValueError, TypeError):
                        pass
        return None

    def _get_basement_temperature(self) -> float | None:
        """Get basement temperature."""
        for entity_id in self.hass.states.async_entity_ids():
            if "basement" in entity_id.lower() and "temp" in entity_id.lower():
                state = self.hass.states.get(entity_id)
                if state:
                    try:
                        return float(state.state)
                    except (ValueError, TypeError):
                        pass
        return None

    def _calculate_confidence(
        self,
        forecast: list[dict[str, Any]] | None,
        hours_until_risk: int | None,
    ) -> float:
        """Calculate prediction confidence.

        Args:
            forecast: Weather forecast data
            hours_until_risk: Hours until freeze risk

        Returns:
            Confidence score (0.0 to 1.0)
        """
        if not forecast:
            return 0.5  # Medium confidence without forecast

        if hours_until_risk is None:
            return 0.9  # High confidence if no risk

        # Confidence decreases with longer forecast periods
        if hours_until_risk <= 12:
            return 0.95  # Very high confidence for near-term
        elif hours_until_risk <= 24:
            return 0.85  # High confidence for 24-hour forecast
        elif hours_until_risk <= 48:
            return 0.75  # Good confidence for 48-hour forecast
        else:
            return 0.65  # Moderate confidence for longer forecasts

    def _summarize_forecast(
        self,
        forecast: list[dict[str, Any]] | None,
    ) -> str:
        """Summarize weather forecast.

        Args:
            forecast: Weather forecast data

        Returns:
            Forecast summary string
        """
        if not forecast:
            return "No forecast available"

        min_temp = min(
            (f.get("temperature") for f in forecast if f.get("temperature") is not None),
            default=None,
        )

        if min_temp is None:
            return "Forecast data incomplete"

        if min_temp < self._freeze_threshold:
            return f"Freezing temperatures expected (low: {min_temp}°F)"
        else:
            return f"No freezing temperatures in forecast (low: {min_temp}°F)"

    def _generate_message(
        self,
        severity: FreezeSeverity,
        hours_until_risk: int | None,
    ) -> str:
        """Generate human-readable message.

        Args:
            severity: Freeze severity level
            hours_until_risk: Hours until freeze risk

        Returns:
            Message string
        """
        if severity == FreezeSeverity.CRITICAL:
            return "🚨 CRITICAL: Pipes at immediate risk of freezing!"
        elif severity == FreezeSeverity.HIGH:
            if hours_until_risk == 0:
                return "⚠️ HIGH RISK: Freezing conditions now - take immediate action"
            else:
                return f"⚠️ HIGH RISK: Freeze risk in {hours_until_risk} hours"
        elif severity == FreezeSeverity.MODERATE:
            return f"⚡ MODERATE RISK: Freeze risk in {hours_until_risk} hours - prepare preventive measures"
        elif severity == FreezeSeverity.LOW:
            return f"ℹ️ LOW RISK: Possible freeze risk in {hours_until_risk} hours - monitor conditions"
        else:
            return "✅ No freeze risk detected"

    async def _store_prediction(self, prediction: dict[str, Any]) -> None:
        """Store prediction to database.

        Args:
            prediction: Prediction data
        """
        try:
            await self._storage._db.execute(
                """
                INSERT INTO freeze_predictions
                (severity, hours_until_risk, confidence, current_temp,
                 forecast_summary, preventive_actions, predicted_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    prediction["severity"],
                    prediction.get("hours_until_risk"),
                    prediction.get("confidence", 0.0),
                    prediction.get("current_outdoor_temp"),
                    prediction.get("forecast_summary", ""),
                    str(prediction.get("preventive_actions", [])),
                    dt_util.now().isoformat(),
                ),
            )
            await self._storage._db.commit()
        except Exception as err:
            _LOGGER.error("Failed to store freeze prediction: %s", err, exc_info=True)

    async def execute_automated_actions(
        self,
        severity: FreezeSeverity,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute automated actions if configured.

        Args:
            severity: Freeze severity level
            config: Action configuration

        Returns:
            Action execution results
        """
        if not config or not config.get("enabled", False):
            return {
                "executed": False,
                "message": "Automated actions not enabled",
            }

        results = {
            "executed": True,
            "actions": [],
            "errors": [],
        }

        try:
            # Raise thermostat if configured
            if severity in [FreezeSeverity.HIGH, FreezeSeverity.CRITICAL]:
                if config.get("raise_thermostat", False):
                    target_temp = config.get("target_temperature", 68)
                    thermostat_entity = config.get("thermostat_entity")

                    if thermostat_entity:
                        try:
                            await self.hass.services.async_call(
                                "climate",
                                "set_temperature",
                                {
                                    "entity_id": thermostat_entity,
                                    ATTR_TEMPERATURE: target_temp,
                                },
                            )
                            results["actions"].append(
                                f"Raised thermostat to {target_temp}°F"
                            )
                        except Exception as err:
                            results["errors"].append(f"Failed to raise thermostat: {err}")

            # Send notification
            if config.get("send_notification", False):
                try:
                    message = self._generate_message(severity, None)
                    await self.hass.services.async_call(
                        "notify",
                        "persistent_notification",
                        {
                            "message": message,
                            "title": "Pipe Freeze Alert",
                        },
                    )
                    results["actions"].append("Notification sent")
                except Exception as err:
                    results["errors"].append(f"Failed to send notification: {err}")

        except Exception as err:
            _LOGGER.error("Error executing automated actions: %s", err, exc_info=True)
            results["errors"].append(str(err))

        return results

