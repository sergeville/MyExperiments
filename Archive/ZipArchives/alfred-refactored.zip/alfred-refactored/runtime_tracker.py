"""Runtime tracker for Alfred Digital Butler - Epic 3 Story 3.2."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant, Event, State, callback
from homeassistant.const import (
    EVENT_STATE_CHANGED,
    STATE_UNAVAILABLE,
    STATE_UNKNOWN,
)
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.util import dt as dt_util

_LOGGER = logging.getLogger(__name__)

# Default power threshold for device "on" state (watts)
DEFAULT_POWER_THRESHOLD = 0.5

# Runtime tracking update interval
RUNTIME_UPDATE_INTERVAL = timedelta(seconds=60)

# Batch write interval for database writes
BATCH_WRITE_INTERVAL = timedelta(seconds=60)


class RuntimeTracker:
    """Track device runtime hours and on/off cycles."""

    def __init__(self, hass: HomeAssistant, pattern_storage) -> None:
        """
        Initialize runtime tracker.

        Args:
            hass: Home Assistant instance
            pattern_storage: PatternStorage instance for database access
        """
        self.hass = hass
        self._storage = pattern_storage
        self._enabled = False

        # In-memory runtime tracking (entity_id -> runtime_data)
        self._runtime_data: dict[str, dict[str, Any]] = {}

        # Track entities being monitored
        self._tracked_entities: set[str] = set()

        # Batch write buffer
        self._pending_writes: dict[str, dict[str, Any]] = {}

        # Unsubscribe callbacks
        self._unsubscribe_state_listener = None
        self._unsubscribe_runtime_updater = None
        self._unsubscribe_batch_writer = None

    async def async_setup(self) -> None:
        """Set up the runtime tracker."""
        _LOGGER.info("Setting up Alfred Runtime Tracker")

        try:
            # Load existing runtime data from database
            await self._load_runtime_data()

            # Subscribe to state changes
            self._unsubscribe_state_listener = self.hass.bus.async_listen(
                EVENT_STATE_CHANGED, self._async_handle_state_change
            )

            # Schedule periodic runtime updates (every 60s)
            self._unsubscribe_runtime_updater = async_track_time_interval(
                self.hass, self._async_update_runtime, RUNTIME_UPDATE_INTERVAL
            )

            # Schedule periodic batch writes (every 60s)
            self._unsubscribe_batch_writer = async_track_time_interval(
                self.hass, self._async_flush_batch_writes, BATCH_WRITE_INTERVAL
            )

            self._enabled = True
            _LOGGER.info("Runtime tracker initialized successfully")

        except Exception as err:
            _LOGGER.error("Failed to initialize runtime tracker: %s", err, exc_info=True)
            raise

    async def async_shutdown(self) -> None:
        """Shut down the runtime tracker."""
        _LOGGER.info("Shutting down runtime tracker")

        # Flush any pending writes
        await self._async_flush_batch_writes(None)

        # Unsubscribe from events
        if self._unsubscribe_state_listener:
            self._unsubscribe_state_listener()
        if self._unsubscribe_runtime_updater:
            self._unsubscribe_runtime_updater()
        if self._unsubscribe_batch_writer:
            self._unsubscribe_batch_writer()

        self._enabled = False
        _LOGGER.info("Runtime tracker shut down")

    async def _load_runtime_data(self) -> None:
        """Load existing runtime data from database."""
        try:
            runtime_data = await self._storage.get_all_runtime_tracking()

            for data in runtime_data:
                entity_id = data["entity_id"]
                self._runtime_data[entity_id] = {
                    "total_runtime_hours": data["total_runtime_hours"],
                    "runtime_since_baseline": data["runtime_since_baseline"],
                    "on_cycles_count": data["on_cycles_count"],
                    "current_state": data["current_state"],
                    "last_on_time": data.get("last_on_time"),
                    "last_off_time": data.get("last_off_time"),
                    "power_on_threshold": data.get("power_on_threshold", DEFAULT_POWER_THRESHOLD),
                    # In-memory tracking for current session
                    "session_start": dt_util.now() if data["current_state"] == "on" else None,
                    "last_update": dt_util.now(),
                }
                self._tracked_entities.add(entity_id)

            _LOGGER.info("Loaded runtime data for %d entities", len(self._runtime_data))

        except Exception as err:
            _LOGGER.error("Error loading runtime data: %s", err, exc_info=True)

    async def async_start_tracking(
        self,
        entity_id: str,
        power_on_threshold: float = DEFAULT_POWER_THRESHOLD
    ) -> None:
        """
        Start tracking runtime for an entity.

        Args:
            entity_id: Entity ID to track (e.g., sensor.power_monitor_01_power)
            power_on_threshold: Power threshold for "on" state (watts)
        """
        if entity_id in self._tracked_entities:
            _LOGGER.debug("Entity %s already being tracked", entity_id)
            return

        _LOGGER.info("Starting runtime tracking for %s", entity_id)

        now = dt_util.now()

        # Initialize runtime data
        self._runtime_data[entity_id] = {
            "total_runtime_hours": 0.0,
            "runtime_since_baseline": 0.0,
            "on_cycles_count": 0,
            "current_state": "unknown",
            "last_on_time": None,
            "last_off_time": None,
            "power_on_threshold": power_on_threshold,
            "session_start": None,
            "last_update": now,
        }

        # Create database entry
        await self._storage.create_runtime_tracking(
            entity_id=entity_id,
            power_on_threshold=power_on_threshold,
            first_tracked=now,
        )

        self._tracked_entities.add(entity_id)

        # Get current state
        state = self.hass.states.get(entity_id)
        if state:
            await self._async_update_device_state(entity_id, state, now)

    async def async_stop_tracking(self, entity_id: str) -> None:
        """
        Stop tracking runtime for an entity.

        Args:
            entity_id: Entity ID to stop tracking
        """
        if entity_id not in self._tracked_entities:
            return

        _LOGGER.info("Stopping runtime tracking for %s", entity_id)

        # Flush any pending data
        if entity_id in self._pending_writes:
            await self._async_write_runtime_data(entity_id)

        # Remove from tracking
        self._tracked_entities.remove(entity_id)
        if entity_id in self._runtime_data:
            del self._runtime_data[entity_id]
        if entity_id in self._pending_writes:
            del self._pending_writes[entity_id]

    @callback
    def _async_handle_state_change(self, event: Event) -> None:
        """
        Handle state change events.

        Args:
            event: State change event
        """
        entity_id = event.data.get("entity_id")
        new_state = event.data.get("new_state")
        old_state = event.data.get("old_state")

        # Only track entities we're monitoring
        if entity_id not in self._tracked_entities:
            return

        if not new_state or new_state.state in (STATE_UNAVAILABLE, STATE_UNKNOWN):
            return

        # Schedule async update
        self.hass.async_create_task(
            self._async_update_device_state(entity_id, new_state, dt_util.now(), old_state)
        )

    async def _async_update_device_state(
        self,
        entity_id: str,
        new_state: State,
        timestamp: datetime,
        old_state: State | None = None
    ) -> None:
        """
        Update device state and detect on/off transitions.

        Args:
            entity_id: Entity ID
            new_state: New state
            timestamp: Event timestamp
            old_state: Previous state (optional)
        """
        if entity_id not in self._runtime_data:
            return

        runtime_data = self._runtime_data[entity_id]

        try:
            # Get power value from state
            power = self._get_power_from_state(new_state)

            if power is None:
                _LOGGER.debug("Could not extract power value from %s", entity_id)
                return

            # Determine new device state
            threshold = runtime_data["power_on_threshold"]
            new_device_state = "on" if power > threshold else "off"
            old_device_state = runtime_data["current_state"]

            # Detect state transition
            if new_device_state != old_device_state and old_device_state != "unknown":
                await self._async_handle_state_transition(
                    entity_id, old_device_state, new_device_state, timestamp, power
                )

            # Update current state
            runtime_data["current_state"] = new_device_state
            runtime_data["last_update"] = timestamp

            # Mark for batch write
            self._pending_writes[entity_id] = runtime_data

        except Exception as err:
            _LOGGER.error(
                "Error updating device state for %s: %s",
                entity_id, err, exc_info=True
            )

    def _get_power_from_state(self, state: State) -> float | None:
        """
        Extract power value from entity state.

        Args:
            state: Entity state

        Returns:
            Power value in watts, or None if not found
        """
        try:
            # Try direct state value
            if state.domain == "sensor":
                # Check if it's a power sensor
                if "power" in state.entity_id.lower():
                    return float(state.state)

            # Try attributes
            if "current_power_w" in state.attributes:
                return float(state.attributes["current_power_w"])

            if "power" in state.attributes:
                return float(state.attributes["power"])

            # Fallback: try to parse state as float
            return float(state.state)

        except (ValueError, TypeError):
            return None

    async def _async_handle_state_transition(
        self,
        entity_id: str,
        old_state: str,
        new_state: str,
        timestamp: datetime,
        power: float
    ) -> None:
        """
        Handle device state transition (on→off or off→on).

        Args:
            entity_id: Entity ID
            old_state: Previous state (on/off)
            new_state: New state (on/off)
            timestamp: Transition timestamp
            power: Current power reading
        """
        runtime_data = self._runtime_data[entity_id]

        if old_state == "off" and new_state == "on":
            # Device turned ON
            await self._async_handle_device_on(entity_id, timestamp)

        elif old_state == "on" and new_state == "off":
            # Device turned OFF
            await self._async_handle_device_off(entity_id, timestamp, power)

    async def _async_handle_device_on(
        self,
        entity_id: str,
        timestamp: datetime
    ) -> None:
        """
        Handle device turning on.

        Args:
            entity_id: Entity ID
            timestamp: On timestamp
        """
        runtime_data = self._runtime_data[entity_id]

        _LOGGER.debug("Device %s turned ON at %s", entity_id, timestamp)

        # Increment cycle count
        runtime_data["on_cycles_count"] += 1
        runtime_data["last_on_time"] = timestamp
        runtime_data["session_start"] = timestamp

        # Start new cycle in database
        await self._storage.start_device_cycle(
            entity_id=entity_id,
            cycle_start=timestamp
        )

        # Fire event
        self.hass.bus.async_fire(
            "alfred_device_powered_on",
            {
                "entity_id": entity_id,
                "timestamp": timestamp.isoformat(),
                "cycle_count": runtime_data["on_cycles_count"],
            }
        )

    async def _async_handle_device_off(
        self,
        entity_id: str,
        timestamp: datetime,
        final_power: float
    ) -> None:
        """
        Handle device turning off.

        Args:
            entity_id: Entity ID
            timestamp: Off timestamp
            final_power: Final power reading before off
        """
        runtime_data = self._runtime_data[entity_id]

        _LOGGER.debug("Device %s turned OFF at %s", entity_id, timestamp)

        runtime_data["last_off_time"] = timestamp

        # Calculate cycle duration
        if runtime_data["session_start"]:
            duration = (timestamp - runtime_data["session_start"]).total_seconds()
            runtime_data["session_start"] = None

            # End cycle in database
            await self._storage.end_device_cycle(
                entity_id=entity_id,
                cycle_end=timestamp,
                runtime_duration_seconds=duration
            )

            _LOGGER.debug(
                "Cycle for %s completed: %.1f seconds",
                entity_id, duration
            )

        # Fire event
        self.hass.bus.async_fire(
            "alfred_device_powered_off",
            {
                "entity_id": entity_id,
                "timestamp": timestamp.isoformat(),
                "total_cycles": runtime_data["on_cycles_count"],
            }
        )

    async def _async_update_runtime(self, now: datetime) -> None:
        """
        Periodic runtime update (called every 60s).

        Args:
            now: Current timestamp
        """
        if not self._enabled:
            return

        for entity_id, runtime_data in self._runtime_data.items():
            if runtime_data["current_state"] == "on":
                # Device is on, accumulate runtime
                last_update = runtime_data["last_update"]
                delta_hours = (now - last_update).total_seconds() / 3600.0

                runtime_data["total_runtime_hours"] += delta_hours
                runtime_data["runtime_since_baseline"] += delta_hours
                runtime_data["last_update"] = now

                # Mark for batch write
                self._pending_writes[entity_id] = runtime_data

                # Check for milestones (every 1000 hours)
                total_hours = runtime_data["total_runtime_hours"]
                if total_hours > 0 and total_hours % 1000 < 1:  # Within 1 hour of milestone
                    await self._async_fire_milestone_event(entity_id, total_hours)

    async def _async_fire_milestone_event(
        self,
        entity_id: str,
        total_hours: float
    ) -> None:
        """
        Fire runtime milestone event.

        Args:
            entity_id: Entity ID
            total_hours: Total runtime hours
        """
        milestone = int(total_hours / 1000) * 1000

        self.hass.bus.async_fire(
            "alfred_device_runtime_milestone",
            {
                "entity_id": entity_id,
                "total_runtime_hours": total_hours,
                "milestone_hours": milestone,
            }
        )

        _LOGGER.info(
            "Runtime milestone for %s: %d hours (total: %.1fh)",
            entity_id, milestone, total_hours
        )

    async def _async_flush_batch_writes(self, now: datetime | None) -> None:
        """
        Flush pending database writes (called every 60s).

        Args:
            now: Current timestamp (unused)
        """
        if not self._pending_writes:
            return

        _LOGGER.debug("Flushing %d pending runtime writes", len(self._pending_writes))

        for entity_id in list(self._pending_writes.keys()):
            try:
                await self._async_write_runtime_data(entity_id)
            except Exception as err:
                _LOGGER.error(
                    "Error writing runtime data for %s: %s",
                    entity_id, err, exc_info=True
                )

    async def _async_write_runtime_data(self, entity_id: str) -> None:
        """
        Write runtime data to database.

        Args:
            entity_id: Entity ID
        """
        if entity_id not in self._pending_writes:
            return

        runtime_data = self._pending_writes[entity_id]

        await self._storage.update_runtime_tracking(
            entity_id=entity_id,
            total_runtime_hours=runtime_data["total_runtime_hours"],
            runtime_since_baseline=runtime_data["runtime_since_baseline"],
            on_cycles_count=runtime_data["on_cycles_count"],
            current_state=runtime_data["current_state"],
            last_on_time=runtime_data.get("last_on_time"),
            last_off_time=runtime_data.get("last_off_time"),
            last_updated=runtime_data["last_update"],
        )

        # Remove from pending writes
        del self._pending_writes[entity_id]

    async def get_runtime_stats(self, entity_id: str) -> dict[str, Any] | None:
        """
        Get runtime statistics for an entity.

        Args:
            entity_id: Entity ID

        Returns:
            Runtime statistics dict, or None if not tracked
        """
        if entity_id not in self._runtime_data:
            # Try loading from database
            data = await self._storage.get_runtime_tracking(entity_id)
            if not data:
                return None
            return data

        runtime_data = self._runtime_data[entity_id]

        # Get cycle statistics from database
        cycle_stats = await self._storage.get_cycle_statistics(entity_id)

        return {
            "entity_id": entity_id,
            "total_runtime_hours": runtime_data["total_runtime_hours"],
            "runtime_since_baseline": runtime_data["runtime_since_baseline"],
            "on_cycles_count": runtime_data["on_cycles_count"],
            "current_state": runtime_data["current_state"],
            "last_on_time": runtime_data.get("last_on_time"),
            "last_off_time": runtime_data.get("last_off_time"),
            "power_on_threshold": runtime_data["power_on_threshold"],
            "cycle_statistics": cycle_stats or {},
        }

    async def reset_runtime_since_baseline(self, entity_id: str) -> None:
        """
        Reset runtime_since_baseline counter (e.g., after maintenance).

        Args:
            entity_id: Entity ID
        """
        if entity_id not in self._runtime_data:
            _LOGGER.warning("Cannot reset baseline for untracked entity %s", entity_id)
            return

        _LOGGER.info("Resetting runtime_since_baseline for %s", entity_id)

        self._runtime_data[entity_id]["runtime_since_baseline"] = 0.0
        self._pending_writes[entity_id] = self._runtime_data[entity_id]

        # Fire event
        self.hass.bus.async_fire(
            "alfred_runtime_baseline_reset",
            {
                "entity_id": entity_id,
                "total_runtime_hours": self._runtime_data[entity_id]["total_runtime_hours"],
            }
        )

    def get_tracked_entities(self) -> list[str]:
        """
        Get list of tracked entity IDs.

        Returns:
            List of entity IDs being tracked
        """
        return list(self._tracked_entities)
