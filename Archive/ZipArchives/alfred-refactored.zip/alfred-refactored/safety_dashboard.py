"""Comprehensive Safety Dashboard for Alfred.

Epic 5: Security & Environmental Safety
Story 5.8: Comprehensive Safety Dashboard

Aggregates security and environmental data into a unified safety dashboard.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any
from enum import Enum

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class SafetyStatus(Enum):
    """Overall safety status levels."""

    CLEAR = "clear"  # Green - all systems normal
    ATTENTION = "attention"  # Yellow - minor issues
    URGENT = "urgent"  # Red - immediate attention required
    CRITICAL = "critical"  # Red flashing - emergency


class SafetyDashboard:
    """Comprehensive safety dashboard data aggregator.

    Aggregates data from:
    - Emergency coordinator
    - Environmental hazard detector
    - Pipe freeze predictor
    - Security report generator
    - Camera intelligence
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize safety dashboard.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage

    async def get_dashboard_data(self) -> dict[str, Any]:
        """Get comprehensive dashboard data.

        Returns:
            Dashboard data with all safety sections
        """
        try:
            # Gather data from all sources
            security_status = await self._get_security_status()
            environmental_hazards = await self._get_environmental_hazards()
            recent_alerts = await self._get_recent_alerts()
            recent_events = await self._get_recent_events()
            risk_summary = await self._calculate_risk_summary(
                security_status,
                environmental_hazards,
                recent_alerts,
            )

            dashboard = {
                "generated_at": dt_util.now().isoformat(),
                "overall_status": risk_summary["overall_status"],
                "safety_score": risk_summary["safety_score"],
                "sections": {
                    "security": security_status,
                    "environmental": environmental_hazards,
                    "alerts": recent_alerts,
                    "events": recent_events,
                },
                "risk_summary": risk_summary,
                "quick_actions": self._get_quick_actions(security_status),
            }

            return dashboard

        except Exception as err:
            _LOGGER.error("Error generating dashboard data: %s", err, exc_info=True)
            return {
                "success": False,
                "error": str(err),
            }

    async def _get_security_status(self) -> dict[str, Any]:
        """Get security system status.

        Returns:
            Security status data
        """
        try:
            # Get lock states
            locks = self.hass.states.async_entity_ids("lock")
            locked_count = sum(
                1 for lock in locks
                if self.hass.states.get(lock).state == "locked"
            )

            # Get door/window states
            doors_windows = [
                e for e in self.hass.states.async_entity_ids("binary_sensor")
                if "door" in e.lower() or "window" in e.lower()
            ]
            open_count = sum(
                1 for entity in doors_windows
                if self.hass.states.get(entity).state == "on"
            )

            # Get alarm state
            alarm_states = self.hass.states.async_entity_ids("alarm_control_panel")
            alarm_status = None
            if alarm_states:
                alarm_status = self.hass.states.get(alarm_states[0]).state

            return {
                "locks": {
                    "total": len(locks),
                    "locked": locked_count,
                    "unlocked": len(locks) - locked_count,
                    "status": "secure" if locked_count == len(locks) else "attention",
                },
                "openings": {
                    "total": len(doors_windows),
                    "open": open_count,
                    "closed": len(doors_windows) - open_count,
                    "status": "clear" if open_count == 0 else "attention",
                },
                "alarm": {
                    "state": alarm_status or "unknown",
                    "status": "clear" if alarm_status == "armed_away" else "attention",
                },
                "overall_status": self._assess_security_status(
                    locked_count, len(locks), open_count
                ),
            }

        except Exception as err:
            _LOGGER.error("Error getting security status: %s", err, exc_info=True)
            return {"error": str(err)}

    def _assess_security_status(
        self,
        locked_count: int,
        total_locks: int,
        open_count: int,
    ) -> str:
        """Assess overall security status.

        Args:
            locked_count: Number of locked locks
            total_locks: Total number of locks
            open_count: Number of open doors/windows

        Returns:
            Status: "clear", "attention", or "urgent"
        """
        if locked_count == total_locks and open_count == 0:
            return "clear"
        elif open_count > 2 or locked_count < total_locks // 2:
            return "urgent"
        else:
            return "attention"

    async def _get_environmental_hazards(self) -> dict[str, Any]:
        """Get environmental hazard status.

        Returns:
            Environmental hazard data
        """
        try:
            hazards = {
                "active_hazards": [],
                "warnings": [],
                "pipe_freeze_risk": "none",
                "overall_status": "clear",
            }

            # Check temperature sensors for freeze risk
            outdoor_temp = None
            for entity_id in self.hass.states.async_entity_ids("sensor"):
                if "outdoor" in entity_id.lower() and "temp" in entity_id.lower():
                    state = self.hass.states.get(entity_id)
                    if state:
                        try:
                            outdoor_temp = float(state.state)
                            break
                        except (ValueError, TypeError):
                            pass

            if outdoor_temp is not None and outdoor_temp < 32:
                hazards["pipe_freeze_risk"] = "high" if outdoor_temp < 20 else "moderate"
                hazards["warnings"].append({
                    "type": "freeze_risk",
                    "severity": "high" if outdoor_temp < 20 else "moderate",
                    "message": f"Freezing temperature detected ({outdoor_temp}°F)",
                })
                hazards["overall_status"] = "attention"

            # Check for leak sensors
            leak_sensors = [
                e for e in self.hass.states.async_entity_ids("binary_sensor")
                if "leak" in e.lower() or "water" in e.lower()
            ]
            for sensor in leak_sensors:
                state = self.hass.states.get(sensor)
                if state and state.state == "on":
                    hazards["active_hazards"].append({
                        "type": "water_leak",
                        "sensor": sensor,
                        "severity": "urgent",
                        "message": f"Water leak detected: {sensor}",
                    })
                    hazards["overall_status"] = "urgent"

            return hazards

        except Exception as err:
            _LOGGER.error("Error getting environmental hazards: %s", err, exc_info=True)
            return {"error": str(err)}

    async def _get_recent_alerts(self, hours: int = 24) -> dict[str, Any]:
        """Get recent safety alerts.

        Args:
            hours: Hours to look back

        Returns:
            Recent alerts
        """
        try:
            alerts = {
                "count": 0,
                "critical": [],
                "warning": [],
                "info": [],
            }

            # In a full implementation, this would query the database
            # for actual stored alerts from all systems

            return alerts

        except Exception as err:
            _LOGGER.error("Error getting recent alerts: %s", err, exc_info=True)
            return {"error": str(err), "count": 0}

    async def _get_recent_events(self, hours: int = 24) -> dict[str, Any]:
        """Get recent security and safety events.

        Args:
            hours: Hours to look back

        Returns:
            Recent events timeline
        """
        try:
            events = {
                "count": 0,
                "timeline": [],
            }

            # Query recent state changes for security-relevant entities
            cutoff_time = dt_util.now() - timedelta(hours=hours)

            # Sample recent lock events
            for lock in self.hass.states.async_entity_ids("lock"):
                state = self.hass.states.get(lock)
                if state and state.last_changed >= cutoff_time:
                    events["timeline"].append({
                        "timestamp": state.last_changed.isoformat(),
                        "type": "security",
                        "category": "lock",
                        "entity": lock,
                        "state": state.state,
                        "message": f"{state.attributes.get('friendly_name', lock)} {state.state}",
                    })

            # Sort by timestamp (most recent first)
            events["timeline"].sort(key=lambda x: x["timestamp"], reverse=True)
            events["count"] = len(events["timeline"])

            # Limit to most recent 50
            events["timeline"] = events["timeline"][:50]

            return events

        except Exception as err:
            _LOGGER.error("Error getting recent events: %s", err, exc_info=True)
            return {"error": str(err), "count": 0}

    async def _calculate_risk_summary(
        self,
        security_status: dict[str, Any],
        environmental_hazards: dict[str, Any],
        recent_alerts: dict[str, Any],
    ) -> dict[str, Any]:
        """Calculate overall risk summary.

        Args:
            security_status: Security status
            environmental_hazards: Environmental hazards
            recent_alerts: Recent alerts

        Returns:
            Risk summary with safety score
        """
        try:
            # Calculate safety score (0-100, higher is better)
            safety_score = 100

            # Deduct for security issues
            sec_status = security_status.get("overall_status")
            if sec_status == "urgent":
                safety_score -= 30
            elif sec_status == "attention":
                safety_score -= 15

            # Deduct for environmental hazards
            env_status = environmental_hazards.get("overall_status")
            if env_status == "urgent":
                safety_score -= 30
            elif env_status == "attention":
                safety_score -= 15

            # Deduct for active alerts
            alert_count = recent_alerts.get("count", 0)
            critical_count = len(recent_alerts.get("critical", []))
            safety_score -= (critical_count * 10)
            safety_score -= min(alert_count * 2, 20)

            # Ensure score is within bounds
            safety_score = max(0, min(100, safety_score))

            # Determine overall status
            if safety_score >= 85:
                overall_status = SafetyStatus.CLEAR
            elif safety_score >= 65:
                overall_status = SafetyStatus.ATTENTION
            elif safety_score >= 40:
                overall_status = SafetyStatus.URGENT
            else:
                overall_status = SafetyStatus.CRITICAL

            return {
                "safety_score": safety_score,
                "overall_status": overall_status.value,
                "status_color": {
                    "clear": "green",
                    "attention": "yellow",
                    "urgent": "orange",
                    "critical": "red",
                }.get(overall_status.value, "gray"),
                "message": self._generate_status_message(overall_status, safety_score),
                "factors": {
                    "security": sec_status,
                    "environmental": env_status,
                    "active_alerts": alert_count,
                },
            }

        except Exception as err:
            _LOGGER.error("Error calculating risk summary: %s", err, exc_info=True)
            return {
                "safety_score": 0,
                "overall_status": "unknown",
                "error": str(err),
            }

    def _generate_status_message(
        self,
        status: SafetyStatus,
        score: int,
    ) -> str:
        """Generate human-readable status message.

        Args:
            status: Safety status
            score: Safety score

        Returns:
            Status message
        """
        messages = {
            SafetyStatus.CLEAR: f"✅ All systems normal (Safety Score: {score}/100)",
            SafetyStatus.ATTENTION: f"⚠️ Minor issues detected (Safety Score: {score}/100)",
            SafetyStatus.URGENT: f"🔴 Immediate attention required (Safety Score: {score}/100)",
            SafetyStatus.CRITICAL: f"🚨 CRITICAL - Take action now! (Safety Score: {score}/100)",
        }
        return messages.get(status, "Status unknown")

    def _get_quick_actions(self, security_status: dict[str, Any]) -> list[dict[str, Any]]:
        """Get available quick actions.

        Args:
            security_status: Current security status

        Returns:
            List of quick actions
        """
        actions = []

        # Lock all doors action
        unlocked_count = security_status.get("locks", {}).get("unlocked", 0)
        if unlocked_count > 0:
            actions.append({
                "id": "lock_all_doors",
                "label": "Lock All Doors",
                "icon": "mdi:lock",
                "service": "lock.lock",
                "target": {"domain": "lock"},
            })

        # Arm alarm action
        alarm_state = security_status.get("alarm", {}).get("state")
        if alarm_state not in ["armed_away", "armed_home"]:
            actions.append({
                "id": "arm_alarm",
                "label": "Arm Alarm",
                "icon": "mdi:shield-home",
                "service": "alarm_control_panel.alarm_arm_away",
                "target": {"domain": "alarm_control_panel"},
            })

        # Emergency mode trigger
        actions.append({
            "id": "trigger_emergency",
            "label": "Trigger Emergency",
            "icon": "mdi:alert",
            "service": "alfred.trigger_emergency",
            "confirmation_required": True,
        })

        return actions
