"""Access tracking and intelligence for smart locks.

Epic 5: Security & Environmental Safety
Story 5.3: Smart Lock Intelligence & Access Tracking

Provides detailed intelligence about lock usage and access patterns.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from ..pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class AccessTracker:
    """Track and analyze access patterns for smart locks.

    Features:
    - Access history: who, when, which door, duration inside
    - Access frequency analysis
    - Unusual access pattern detection
    - Searchable and exportable history
    - Privacy-preserved tracking
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize access tracker.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage

    async def get_access_history(
        self,
        entity_id: str | None = None,
        user_hash: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        event_types: list[str] | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get access history with flexible filtering.

        Args:
            entity_id: Optional filter by lock entity ID
            user_hash: Optional filter by user hash
            start_date: Optional start date
            end_date: Optional end date
            event_types: Optional filter by event types (e.g., ["unlock", "lock"])
            limit: Maximum number of results (default: 100)

        Returns:
            List of access event dictionaries
        """
        try:
            query = """
                SELECT event_id, entity_id, user_hash, access_method,
                       event_type, timestamp, duration_inside,
                       anomaly_detected, risk_level, context_data
                FROM access_events
                WHERE 1=1
            """
            params = []

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            if user_hash:
                query += " AND user_hash = ?"
                params.append(user_hash)

            if start_date:
                query += " AND timestamp >= ?"
                params.append(start_date.isoformat())

            if end_date:
                query += " AND timestamp <= ?"
                params.append(end_date.isoformat())

            if event_types:
                placeholders = ",".join(["?"] * len(event_types))
                query += f" AND event_type IN ({placeholders})"
                params.extend(event_types)

            query += " ORDER BY timestamp DESC LIMIT ?"
            params.append(limit)

            cursor = await self._storage._db.execute(query, params)
            rows = await cursor.fetchall()
            await cursor.close()

            return [
                {
                    "event_id": row[0],
                    "entity_id": row[1],
                    "user_hash": row[2],
                    "access_method": row[3],
                    "event_type": row[4],
                    "timestamp": row[5],
                    "duration_inside": row[6],
                    "anomaly_detected": bool(row[7]),
                    "risk_level": row[8],
                    "context_data": row[9],
                }
                for row in rows
            ]

        except Exception as err:
            _LOGGER.error("Failed to get access history: %s", err, exc_info=True)
            return []

    async def get_access_summary(
        self,
        entity_id: str | None = None,
        days: int = 7,
    ) -> dict[str, Any]:
        """Get access summary statistics.

        Args:
            entity_id: Optional filter by lock entity ID
            days: Number of days to analyze (default: 7)

        Returns:
            Dictionary with summary statistics
        """
        try:
            start_date = dt_util.now() - timedelta(days=days)

            # Total events
            query = "SELECT COUNT(*) FROM access_events WHERE timestamp >= ?"
            params = [start_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            cursor = await self._storage._db.execute(query, params)
            total_events = (await cursor.fetchone())[0]
            await cursor.close()

            # Events by type
            query = """
                SELECT event_type, COUNT(*) as count
                FROM access_events
                WHERE timestamp >= ?
            """
            params = [start_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " GROUP BY event_type"

            cursor = await self._storage._db.execute(query, params)
            events_by_type = {row[0]: row[1] for row in await cursor.fetchall()}
            await cursor.close()

            # Unique users
            query = """
                SELECT COUNT(DISTINCT user_hash)
                FROM access_events
                WHERE timestamp >= ? AND user_hash IS NOT NULL
            """
            params = [start_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            cursor = await self._storage._db.execute(query, params)
            unique_users = (await cursor.fetchone())[0]
            await cursor.close()

            # Anomalies
            query = """
                SELECT COUNT(*), risk_level
                FROM access_events
                WHERE timestamp >= ? AND anomaly_detected = TRUE
            """
            params = [start_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " GROUP BY risk_level"

            cursor = await self._storage._db.execute(query, params)
            anomalies = {row[1]: row[0] for row in await cursor.fetchall()}
            await cursor.close()

            # Peak hours
            query = """
                SELECT CAST(strftime('%H', timestamp) AS INTEGER) as hour,
                       COUNT(*) as count
                FROM access_events
                WHERE timestamp >= ?
            """
            params = [start_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " GROUP BY hour ORDER BY count DESC LIMIT 3"

            cursor = await self._storage._db.execute(query, params)
            peak_hours = [(row[0], row[1]) for row in await cursor.fetchall()]
            await cursor.close()

            return {
                "period_days": days,
                "start_date": start_date.isoformat(),
                "end_date": dt_util.now().isoformat(),
                "total_events": total_events,
                "events_by_type": events_by_type,
                "unique_users": unique_users,
                "anomalies": anomalies,
                "peak_hours": [
                    {"hour": hour, "count": count} for hour, count in peak_hours
                ],
            }

        except Exception as err:
            _LOGGER.error("Failed to get access summary: %s", err, exc_info=True)
            return {}

    async def get_user_access_history(
        self,
        user_hash: str,
        days: int = 30,
    ) -> dict[str, Any]:
        """Get detailed access history for a specific user.

        Args:
            user_hash: User hash to query
            days: Number of days to analyze (default: 30)

        Returns:
            Dictionary with user access details
        """
        try:
            start_date = dt_util.now() - timedelta(days=days)

            # Get all access events for user
            events = await self.get_access_history(
                user_hash=user_hash,
                start_date=start_date,
                limit=1000,
            )

            if not events:
                return {
                    "user_hash": user_hash,
                    "total_accesses": 0,
                    "events": [],
                }

            # Calculate statistics
            total_accesses = len(events)
            entities_accessed = list(set(e["entity_id"] for e in events))

            # Event types
            event_type_counts = {}
            for event in events:
                event_type = event["event_type"]
                event_type_counts[event_type] = event_type_counts.get(event_type, 0) + 1

            # Recent activity (last 7 days)
            recent_cutoff = dt_util.now() - timedelta(days=7)
            recent_events = [
                e
                for e in events
                if datetime.fromisoformat(e["timestamp"]) >= recent_cutoff
            ]

            # Anomalies
            anomalies = [e for e in events if e["anomaly_detected"]]

            return {
                "user_hash": user_hash,
                "period_days": days,
                "total_accesses": total_accesses,
                "entities_accessed": entities_accessed,
                "event_type_counts": event_type_counts,
                "recent_activity_count": len(recent_events),
                "anomaly_count": len(anomalies),
                "anomalies": anomalies,
                "latest_access": events[0] if events else None,
            }

        except Exception as err:
            _LOGGER.error("Failed to get user access history: %s", err, exc_info=True)
            return {"user_hash": user_hash, "total_accesses": 0, "error": str(err)}

    async def calculate_duration_inside(
        self,
        arrival_event_id: str,
    ) -> int | None:
        """Calculate duration inside based on arrival and departure events.

        Args:
            arrival_event_id: Event ID of arrival/unlock event

        Returns:
            Duration in seconds, or None if no departure found
        """
        try:
            # Get arrival event
            cursor = await self._storage._db.execute(
                """
                SELECT entity_id, user_hash, timestamp
                FROM access_events
                WHERE event_id = ?
                """,
                (arrival_event_id,),
            )

            arrival = await cursor.fetchone()
            await cursor.close()

            if not arrival:
                return None

            entity_id, user_hash, arrival_time = arrival

            # Find next departure event (lock or departure)
            cursor = await self._storage._db.execute(
                """
                SELECT timestamp
                FROM access_events
                WHERE entity_id = ?
                  AND user_hash = ?
                  AND timestamp > ?
                  AND event_type IN ('lock', 'departure')
                ORDER BY timestamp ASC
                LIMIT 1
                """,
                (entity_id, user_hash, arrival_time),
            )

            departure = await cursor.fetchone()
            await cursor.close()

            if not departure:
                return None

            departure_time = departure[0]

            # Calculate duration
            arrival_dt = datetime.fromisoformat(arrival_time)
            departure_dt = datetime.fromisoformat(departure_time)

            duration_seconds = int((departure_dt - arrival_dt).total_seconds())

            # Update the access event with duration
            await self._storage._db.execute(
                "UPDATE access_events SET duration_inside = ? WHERE event_id = ?",
                (duration_seconds, arrival_event_id),
            )

            await self._storage._db.commit()

            return duration_seconds

        except Exception as err:
            _LOGGER.error("Failed to calculate duration: %s", err, exc_info=True)
            return None

    async def detect_unusual_frequency(
        self,
        user_hash: str,
        days: int = 7,
        threshold_multiplier: float = 2.0,
    ) -> dict[str, Any]:
        """Detect unusual access frequency for a user.

        Args:
            user_hash: User hash to analyze
            days: Number of days to analyze
            threshold_multiplier: How many times above baseline is "unusual"

        Returns:
            Dictionary with frequency analysis
        """
        try:
            # Get baseline frequency (last 30 days)
            baseline_start = dt_util.now() - timedelta(days=30)
            baseline_end = dt_util.now() - timedelta(days=days)

            cursor = await self._storage._db.execute(
                """
                SELECT COUNT(*)
                FROM access_events
                WHERE user_hash = ?
                  AND timestamp >= ?
                  AND timestamp < ?
                """,
                (user_hash, baseline_start.isoformat(), baseline_end.isoformat()),
            )

            baseline_count = (await cursor.fetchone())[0]
            await cursor.close()

            # Get recent frequency (last N days)
            recent_start = dt_util.now() - timedelta(days=days)

            cursor = await self._storage._db.execute(
                """
                SELECT COUNT(*)
                FROM access_events
                WHERE user_hash = ?
                  AND timestamp >= ?
                """,
                (user_hash, recent_start.isoformat()),
            )

            recent_count = (await cursor.fetchone())[0]
            await cursor.close()

            # Calculate daily rates
            baseline_daily_rate = baseline_count / max((30 - days), 1)
            recent_daily_rate = recent_count / days

            # Check if unusual
            is_unusual = recent_daily_rate > (baseline_daily_rate * threshold_multiplier)

            return {
                "user_hash": user_hash,
                "analysis_period_days": days,
                "baseline_daily_rate": round(baseline_daily_rate, 2),
                "recent_daily_rate": round(recent_daily_rate, 2),
                "threshold_multiplier": threshold_multiplier,
                "is_unusual": is_unusual,
                "severity": "medium" if is_unusual else "normal",
                "message": (
                    f"Unusual access frequency detected: {round(recent_daily_rate, 1)} accesses/day "
                    f"vs baseline {round(baseline_daily_rate, 1)} accesses/day"
                    if is_unusual
                    else "Access frequency normal"
                ),
            }

        except Exception as err:
            _LOGGER.error("Failed to detect unusual frequency: %s", err, exc_info=True)
            return {"user_hash": user_hash, "is_unusual": False, "error": str(err)}

    async def export_access_history(
        self,
        entity_id: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        format: str = "json",
    ) -> dict[str, Any]:
        """Export access history in various formats.

        Args:
            entity_id: Optional filter by lock entity ID
            start_date: Optional start date
            end_date: Optional end date
            format: Export format ("json", "csv") - default: "json"

        Returns:
            Dictionary with export data
        """
        try:
            events = await self.get_access_history(
                entity_id=entity_id,
                start_date=start_date,
                end_date=end_date,
                limit=10000,
            )

            if format == "csv":
                # Convert to CSV format
                csv_lines = [
                    "timestamp,entity_id,user_hash,access_method,event_type,anomaly_detected,risk_level"
                ]

                for event in events:
                    csv_lines.append(
                        f"{event['timestamp']},{event['entity_id']},{event['user_hash'] or ''},"
                        f"{event['access_method'] or ''},{event['event_type']},"
                        f"{event['anomaly_detected']},{event['risk_level'] or ''}"
                    )

                return {
                    "format": "csv",
                    "count": len(events),
                    "data": "\n".join(csv_lines),
                }

            else:  # JSON format (default)
                return {
                    "format": "json",
                    "count": len(events),
                    "data": events,
                }

        except Exception as err:
            _LOGGER.error("Failed to export access history: %s", err, exc_info=True)
            return {"format": format, "count": 0, "error": str(err)}
