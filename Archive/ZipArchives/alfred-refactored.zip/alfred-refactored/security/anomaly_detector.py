"""Security anomaly detection for behavioral baseline deviations.

Epic 5: Security & Environmental Safety
Story 5.2: Anomaly Detection for Security Events

Detects security anomalies based on established behavioral baselines.
Provides risk scoring and actionable alerts.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from ..pattern_storage import PatternStorage
from .privacy import sanitize_security_data

_LOGGER = logging.getLogger(__name__)


class SecurityAnomalyDetector:
    """Detect anomalies in security events based on behavioral baselines.

    Analyzes security events against established baselines to identify:
    - Temporal anomalies (unusual time of access)
    - Spatial anomalies (unusual entry point)
    - Behavioral anomalies (unexpected sequence)

    Risk levels:
    - low: Minor deviation (e.g., 1-2 hours off normal time)
    - medium: Notable deviation (e.g., different door than usual)
    - high: Significant deviation (e.g., 3 AM access when normal is 6 PM)
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
        device_id: str = "",
    ) -> None:
        """Initialize anomaly detector.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
            device_id: Device/instance ID for privacy salt
        """
        self.hass = hass
        self._storage = pattern_storage
        self._device_id = device_id or hass.config.location_name

        # Risk thresholds
        self.temporal_deviation_hours = {
            "low": 2,  # 1-2 hours off
            "medium": 4,  # 2-4 hours off
            "high": 6,  # 6+ hours off
        }

        self.frequency_deviation = {
            "low": 0.10,  # 10% below normal frequency
            "medium": 0.25,  # 25% below normal
            "high": 0.50,  # 50%+ below normal (very unusual)
        }

    async def analyze_event(
        self,
        entity_id: str,
        event_type: str,
        user_hash: str | None,
        timestamp: datetime,
        context_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Analyze a security event for anomalies.

        Args:
            entity_id: Entity that triggered event
            event_type: Type of event (lock, unlock, open, close, etc.)
            user_hash: Hashed user identifier
            timestamp: Event timestamp
            context_data: Additional context

        Returns:
            Anomaly analysis with risk level and explanation
        """
        _LOGGER.debug(
            "Analyzing event: %s %s at %s",
            entity_id,
            event_type,
            timestamp,
        )

        # Get baselines for this entity and user
        baselines = await self._get_baselines(entity_id, user_hash)

        if not baselines:
            _LOGGER.debug(
                "No baseline found for %s (user: %s) - cannot detect anomalies",
                entity_id,
                user_hash or "any",
            )
            return {
                "anomaly_detected": False,
                "risk_level": "unknown",
                "reason": "No baseline established yet",
                "confidence": 0.0,
            }

        # Analyze different anomaly types
        temporal_anomaly = await self._check_temporal_anomaly(
            timestamp, baselines.get("temporal", {})
        )

        spatial_anomaly = await self._check_spatial_anomaly(
            entity_id, baselines.get("spatial", {})
        )

        behavioral_anomaly = await self._check_behavioral_anomaly(
            entity_id, event_type, timestamp, baselines.get("behavioral", {})
        )

        # Calculate overall risk
        risk_analysis = self._calculate_risk(
            temporal_anomaly, spatial_anomaly, behavioral_anomaly
        )

        # Store anomaly if detected
        if risk_analysis["anomaly_detected"]:
            await self._store_anomaly(
                entity_id,
                event_type,
                user_hash,
                timestamp,
                risk_analysis,
                context_data,
            )

        return risk_analysis

    async def _check_temporal_anomaly(
        self, timestamp: datetime, temporal_baseline: dict[str, Any]
    ) -> dict[str, Any]:
        """Check for temporal anomalies (unusual time of access).

        Args:
            timestamp: Event timestamp
            temporal_baseline: Temporal baseline data

        Returns:
            Temporal anomaly analysis
        """
        if not temporal_baseline or not temporal_baseline.get("peak_hours_by_day"):
            return {"anomaly": False, "severity": 0.0, "details": "No baseline"}

        day_of_week = timestamp.weekday()
        hour = timestamp.hour

        peak_hours = temporal_baseline.get("peak_hours_by_day", {})

        # Check if this day has baseline data
        if str(day_of_week) not in peak_hours:
            return {
                "anomaly": True,
                "severity": 0.3,
                "details": f"No typical pattern for {timestamp.strftime('%A')}",
            }

        peak_data = peak_hours[str(day_of_week)]
        peak_hour = peak_data["hour"]
        frequency = peak_data["frequency"]

        # Calculate hour deviation
        hour_diff = abs(hour - peak_hour)
        if hour_diff > 12:
            hour_diff = 24 - hour_diff  # Handle wrap-around

        # Check hour distribution
        hour_dist = temporal_baseline.get("hour_distribution", {})
        current_hour_freq = hour_dist.get(str(hour), {}).get("frequency", 0.0)

        # Anomaly if:
        # 1. More than 6 hours from peak AND
        # 2. Current hour has very low frequency (<5%)
        if hour_diff >= self.temporal_deviation_hours["high"] and current_hour_freq < 0.05:
            severity = 0.8
        elif hour_diff >= self.temporal_deviation_hours["medium"]:
            severity = 0.5
        elif hour_diff >= self.temporal_deviation_hours["low"]:
            severity = 0.2
        else:
            severity = 0.0

        return {
            "anomaly": severity > 0.3,
            "severity": severity,
            "details": (
                f"Access at {timestamp.strftime('%I:%M %p')} is {hour_diff}h "
                f"from typical time ({peak_hour:02d}:00). "
                f"Frequency at this hour: {current_hour_freq:.1%}"
            ),
            "peak_hour": peak_hour,
            "hour_deviation": hour_diff,
        }

    async def _check_spatial_anomaly(
        self, entity_id: str, spatial_baseline: dict[str, Any]
    ) -> dict[str, Any]:
        """Check for spatial anomalies (unusual entry point).

        Args:
            entity_id: Entity ID
            spatial_baseline: Spatial baseline data

        Returns:
            Spatial anomaly analysis
        """
        if not spatial_baseline or not spatial_baseline.get("typical_entry_points"):
            return {"anomaly": False, "severity": 0.0, "details": "No baseline"}

        entry_points = spatial_baseline["typical_entry_points"]

        # Find this entity in entry points
        entity_freq = 0.0
        for entry in entry_points:
            if entry["entity"] == entity_id:
                entity_freq = entry["frequency"]
                break

        # Anomaly if this entity is rarely used
        if entity_freq == 0.0:
            severity = 0.9
            details = f"{entity_id} has never been used in baseline period"
        elif entity_freq < self.frequency_deviation["high"]:
            severity = 0.7
            details = f"{entity_id} rarely used (only {entity_freq:.1%} of time)"
        elif entity_freq < self.frequency_deviation["medium"]:
            severity = 0.4
            details = f"{entity_id} used less than usual ({entity_freq:.1%})"
        else:
            severity = 0.0
            details = f"{entity_id} is typical entry ({entity_freq:.1%})"

        # Check if primary entry point
        primary = spatial_baseline.get("primary_entry")
        is_primary = primary and primary.get("entity") == entity_id

        return {
            "anomaly": severity > 0.3,
            "severity": severity,
            "details": details,
            "frequency": entity_freq,
            "is_primary": is_primary,
        }

    async def _check_behavioral_anomaly(
        self,
        entity_id: str,
        event_type: str,
        timestamp: datetime,
        behavioral_baseline: dict[str, Any],
    ) -> dict[str, Any]:
        """Check for behavioral anomalies (unusual sequences).

        Args:
            entity_id: Entity ID
            event_type: Event type
            timestamp: Event timestamp
            behavioral_baseline: Behavioral baseline data

        Returns:
            Behavioral anomaly analysis
        """
        if not behavioral_baseline or not behavioral_baseline.get("typical_sequences"):
            return {"anomaly": False, "severity": 0.0, "details": "No baseline"}

        # Get recent events (last 5 minutes) to check sequence
        recent_events = await self._get_recent_events(entity_id, minutes=5)

        if not recent_events:
            return {
                "anomaly": False,
                "severity": 0.0,
                "details": "No recent events to correlate",
            }

        # Build current sequence
        current_sequence = " → ".join(
            [e["entity_id"] for e in recent_events] + [entity_id]
        )

        typical_sequences = behavioral_baseline.get("typical_sequences", [])

        # Check if current sequence matches any typical sequence
        sequence_match = False
        for seq_data in typical_sequences:
            typical_seq = seq_data["sequence"]
            if typical_seq in current_sequence or current_sequence in typical_seq:
                sequence_match = True
                break

        if not sequence_match and len(recent_events) > 0:
            severity = 0.6
            details = f"Unusual sequence: {current_sequence}"
        else:
            severity = 0.0
            details = "Sequence matches typical pattern"

        return {
            "anomaly": severity > 0.3,
            "severity": severity,
            "details": details,
            "current_sequence": current_sequence,
        }

    def _calculate_risk(
        self,
        temporal: dict[str, Any],
        spatial: dict[str, Any],
        behavioral: dict[str, Any],
    ) -> dict[str, Any]:
        """Calculate overall risk level from anomaly components.

        Args:
            temporal: Temporal anomaly analysis
            spatial: Spatial anomaly analysis
            behavioral: Behavioral anomaly analysis

        Returns:
            Overall risk analysis
        """
        # Weighted severity score
        temporal_weight = 0.4
        spatial_weight = 0.3
        behavioral_weight = 0.3

        overall_severity = (
            temporal.get("severity", 0.0) * temporal_weight
            + spatial.get("severity", 0.0) * spatial_weight
            + behavioral.get("severity", 0.0) * behavioral_weight
        )

        # Determine risk level
        if overall_severity >= 0.7:
            risk_level = "high"
        elif overall_severity >= 0.4:
            risk_level = "medium"
        elif overall_severity >= 0.2:
            risk_level = "low"
        else:
            risk_level = "normal"

        anomaly_detected = risk_level != "normal"

        # Build explanation
        anomaly_details = []
        if temporal.get("anomaly"):
            anomaly_details.append(f"Temporal: {temporal['details']}")
        if spatial.get("anomaly"):
            anomaly_details.append(f"Spatial: {spatial['details']}")
        if behavioral.get("anomaly"):
            anomaly_details.append(f"Behavioral: {behavioral['details']}")

        explanation = " | ".join(anomaly_details) if anomaly_details else "Normal activity"

        # Suggested actions
        suggested_actions = []
        if risk_level == "high":
            suggested_actions = [
                "Verify this access is authorized",
                "Check camera footage if available",
                "Consider changing access codes if compromised",
            ]
        elif risk_level == "medium":
            suggested_actions = [
                "Review access pattern",
                "Confirm with household members",
            ]

        return {
            "anomaly_detected": anomaly_detected,
            "risk_level": risk_level,
            "severity": round(overall_severity, 2),
            "explanation": explanation,
            "suggested_actions": suggested_actions,
            "components": {
                "temporal": temporal,
                "spatial": spatial,
                "behavioral": behavioral,
            },
        }

    async def _get_baselines(
        self, entity_id: str, user_hash: str | None
    ) -> dict[str, Any]:
        """Get baselines for entity and user from database.

        Args:
            entity_id: Entity ID
            user_hash: User hash (optional)

        Returns:
            Combined baseline data
        """
        baselines = {"temporal": {}, "spatial": {}, "behavioral": {}}

        # Query all baseline types for this entity/user
        if user_hash:
            cursor = await self._storage._db.execute(
                """
                SELECT baseline_type, pattern_data, confidence
                FROM security_baselines
                WHERE entity_id = ? AND user_hash = ?
                ORDER BY last_updated DESC
                """,
                (entity_id, user_hash),
            )
        else:
            cursor = await self._storage._db.execute(
                """
                SELECT baseline_type, pattern_data, confidence
                FROM security_baselines
                WHERE entity_id = ? AND user_hash IS NULL
                ORDER BY last_updated DESC
                """,
                (entity_id,),
            )

        rows = await cursor.fetchall()
        await cursor.close()

        # Parse baseline data
        for row in rows:
            baseline_type = row[0]
            pattern_data = json.loads(row[1])
            confidence = row[2]

            if baseline_type in baselines:
                baselines[baseline_type] = pattern_data
                baselines[f"{baseline_type}_confidence"] = confidence

        return baselines if any(baselines.values()) else None

    async def _get_recent_events(
        self, entity_id: str, minutes: int = 5
    ) -> list[dict[str, Any]]:
        """Get recent events for sequence analysis.

        Args:
            entity_id: Entity ID
            minutes: Minutes of history to retrieve

        Returns:
            List of recent events
        """
        from datetime import timedelta

        cutoff = dt_util.now() - timedelta(minutes=minutes)

        cursor = await self._storage._db.execute(
            """
            SELECT entity_id, event_type, timestamp
            FROM access_events
            WHERE timestamp >= ?
            ORDER BY timestamp ASC
            """,
            (cutoff.isoformat(),),
        )

        rows = await cursor.fetchall()
        await cursor.close()

        events = []
        for row in rows:
            events.append({
                "entity_id": row[0],
                "event_type": row[1],
                "timestamp": row[2],
            })

        return events

    async def _store_anomaly(
        self,
        entity_id: str,
        event_type: str,
        user_hash: str | None,
        timestamp: datetime,
        risk_analysis: dict[str, Any],
        context_data: dict[str, Any] | None,
    ) -> None:
        """Store detected anomaly to database.

        Args:
            entity_id: Entity ID
            event_type: Event type
            user_hash: User hash
            timestamp: Event timestamp
            risk_analysis: Risk analysis results
            context_data: Additional context
        """
        try:
            # Update the corresponding access_event record
            await self._storage._db.execute(
                """
                UPDATE access_events
                SET anomaly_detected = 1,
                    risk_level = ?,
                    anomaly_details = ?
                WHERE entity_id = ? AND timestamp = ? AND user_hash IS ?
                """,
                (
                    risk_analysis["risk_level"],
                    json.dumps(risk_analysis),
                    entity_id,
                    timestamp.isoformat(),
                    user_hash,
                ),
            )

            await self._storage._db.commit()

            _LOGGER.info(
                "Anomaly detected: %s %s at %s - Risk: %s",
                entity_id,
                event_type,
                timestamp,
                risk_analysis["risk_level"],
            )

        except Exception as err:
            _LOGGER.error(
                "Failed to store anomaly for %s: %s",
                entity_id,
                err,
                exc_info=True,
            )
