"""Security baseline calculator for behavioral pattern analysis.

Epic 5: Security & Environmental Safety
Story 5.1: Security Behavioral Baseline Establishment
"""
from __future__ import annotations

import json
import logging
import statistics
from collections import defaultdict
from datetime import datetime, timedelta, date
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from ..pattern_storage import PatternStorage
from .privacy import anonymize_user_id, sanitize_security_data

_LOGGER = logging.getLogger(__name__)


class SecurityBaselineCalculator:
    """Calculate behavioral baselines for security devices.

    Tracks normal access patterns (who, when, which doors/locks) to establish
    baselines for anomaly detection.

    Privacy-first design:
    - User IDs are hashed before storage
    - No PII sent to LLM or stored in database
    - Aggregated patterns only
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
        device_id: str = "",
    ) -> None:
        """Initialize security baseline calculator.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
            device_id: Device/instance ID for privacy salt
        """
        self.hass = hass
        self._storage = pattern_storage
        self._device_id = device_id or hass.config.location_name

        # Configuration
        self.establishment_period_days = 30
        self.update_frequency_days = 30
        self.min_events_required = 30
        self.min_confidence_threshold = 0.70

    async def establish_baseline(
        self,
        entity_id: str,
        user_identifier: str | None = None,
    ) -> dict[str, Any]:
        """
        Establish security baseline for an entity over 30-day period.

        Args:
            entity_id: Security entity (lock, door sensor, etc.)
            user_identifier: Optional user ID/code to track (will be hashed)

        Returns:
            Dictionary containing baseline data with confidence scores

        Example:
            {
                "entity_id": "lock.front_door",
                "user_hash": "a3f2b1c9...",
                "temporal": {...},
                "spatial": {...},
                "behavioral": {...},
                "established_date": "2025-11-15",
                "confidence": 0.92
            }
        """
        _LOGGER.info(
            "Establishing security baseline for %s (period: %d days)",
            entity_id,
            self.establishment_period_days,
        )

        # Get access events from last 30 days
        events = await self._get_access_events(
            entity_id,
            days=self.establishment_period_days,
            user_identifier=user_identifier,
        )

        if len(events) < self.min_events_required:
            _LOGGER.warning(
                "Insufficient data for %s: %d events (need %d)",
                entity_id,
                len(events),
                self.min_events_required,
            )
            return {
                "error": "Insufficient data",
                "events_found": len(events),
                "required": self.min_events_required,
            }

        # Hash user identifier for privacy
        user_hash = None
        if user_identifier:
            user_hash = anonymize_user_id(user_identifier, self._device_id)

        # Calculate baseline patterns
        temporal = await self._calculate_temporal_baseline(events)
        spatial = await self._calculate_spatial_baseline(events)
        behavioral = await self._calculate_behavioral_baseline(events)

        # Calculate overall confidence
        confidence = self._calculate_confidence(events, temporal, spatial, behavioral)

        baseline = {
            "entity_id": entity_id,
            "user_hash": user_hash,
            "temporal": temporal,
            "spatial": spatial,
            "behavioral": behavioral,
            "established_date": date.today().isoformat(),
            "events_analyzed": len(events),
            "confidence": confidence,
        }

        # Store baseline
        await self._save_baseline(baseline)

        _LOGGER.info(
            "Baseline established for %s: %d events, %.0f%% confidence",
            entity_id,
            len(events),
            confidence * 100,
        )

        return baseline

    async def _calculate_temporal_baseline(
        self, events: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """
        Calculate time-based access patterns.

        Identifies typical access times by day of week and hour.

        Args:
            events: List of access events

        Returns:
            Temporal pattern data
        """
        # Group by day of week
        weekday_patterns = defaultdict(list)
        hour_patterns = defaultdict(list)

        for event in events:
            timestamp = event["timestamp"]
            if isinstance(timestamp, str):
                timestamp = datetime.fromisoformat(timestamp)

            day_of_week = timestamp.weekday()  # 0=Monday, 6=Sunday
            hour = timestamp.hour

            weekday_patterns[day_of_week].append(hour)
            hour_patterns[hour].append(day_of_week)

        # Calculate peak times
        peak_hours = {}
        for day in range(7):
            if day in weekday_patterns:
                hours = weekday_patterns[day]
                if len(hours) >= 3:
                    # Find most common hour
                    hour_counts = defaultdict(int)
                    for h in hours:
                        hour_counts[h] += 1

                    peak_hour = max(hour_counts, key=hour_counts.get)
                    frequency = hour_counts[peak_hour] / len(hours)

                    peak_hours[day] = {
                        "hour": peak_hour,
                        "frequency": round(frequency, 2),
                        "sample_count": len(hours),
                    }

        # Calculate overall hour distribution
        all_hours = [event["timestamp"].hour if isinstance(event["timestamp"], datetime)
                     else datetime.fromisoformat(event["timestamp"]).hour
                     for event in events]

        if all_hours:
            hour_distribution = {}
            for hour in range(24):
                count = all_hours.count(hour)
                if count > 0:
                    hour_distribution[hour] = {
                        "frequency": round(count / len(all_hours), 3),
                        "count": count,
                    }

        return {
            "peak_hours_by_day": peak_hours,
            "hour_distribution": hour_distribution if all_hours else {},
            "total_events": len(events),
        }

    async def _calculate_spatial_baseline(
        self, events: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """
        Calculate location-based access patterns.

        Identifies typical entry points and their frequencies.

        Args:
            events: List of access events

        Returns:
            Spatial pattern data
        """
        # Group by entity_id (different doors/locks)
        entity_counts = defaultdict(int)
        for event in events:
            entity_counts[event["entity_id"]] += 1

        total = len(events)

        # Calculate frequency distribution
        entry_points = []
        for entity_id, count in sorted(
            entity_counts.items(), key=lambda x: x[1], reverse=True
        ):
            entry_points.append({
                "entity": entity_id,
                "frequency": round(count / total, 2),
                "count": count,
            })

        return {
            "typical_entry_points": entry_points,
            "primary_entry": entry_points[0] if entry_points else None,
            "total_locations": len(entity_counts),
        }

    async def _calculate_behavioral_baseline(
        self, events: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """
        Calculate sequence and behavior patterns.

        Identifies typical sequences like "Garage → Arrival → Front Door Unlock".

        Args:
            events: List of access events

        Returns:
            Behavioral pattern data
        """
        # Sort events by timestamp
        sorted_events = sorted(
            events, key=lambda x: x["timestamp"] if isinstance(x["timestamp"], datetime)
            else datetime.fromisoformat(x["timestamp"])
        )

        # Detect sequences (events within 5 minutes)
        sequences = []
        sequence_window = timedelta(minutes=5)

        i = 0
        while i < len(sorted_events):
            sequence = [sorted_events[i]]
            current_time = (
                sorted_events[i]["timestamp"]
                if isinstance(sorted_events[i]["timestamp"], datetime)
                else datetime.fromisoformat(sorted_events[i]["timestamp"])
            )

            # Look ahead for related events
            j = i + 1
            while j < len(sorted_events):
                next_time = (
                    sorted_events[j]["timestamp"]
                    if isinstance(sorted_events[j]["timestamp"], datetime)
                    else datetime.fromisoformat(sorted_events[j]["timestamp"])
                )

                if next_time - current_time <= sequence_window:
                    sequence.append(sorted_events[j])
                    j += 1
                else:
                    break

            if len(sequence) > 1:
                # Record sequence
                sequence_str = " → ".join([e["entity_id"] for e in sequence])
                duration = (
                    (
                        sequence[-1]["timestamp"]
                        if isinstance(sequence[-1]["timestamp"], datetime)
                        else datetime.fromisoformat(sequence[-1]["timestamp"])
                    )
                    - current_time
                ).total_seconds()

                sequences.append({
                    "sequence": sequence_str,
                    "length": len(sequence),
                    "duration_seconds": round(duration, 1),
                })

            i = j if j > i + 1 else i + 1

        # Count sequence frequencies
        sequence_counts = defaultdict(int)
        for seq in sequences:
            sequence_counts[seq["sequence"]] += 1

        typical_sequences = []
        if sequences:
            total_sequences = len(sequences)
            for seq_str, count in sorted(
                sequence_counts.items(), key=lambda x: x[1], reverse=True
            ):
                if count >= 3:  # Minimum 3 occurrences
                    # Calculate average duration
                    durations = [
                        s["duration_seconds"]
                        for s in sequences
                        if s["sequence"] == seq_str
                    ]
                    avg_duration = statistics.mean(durations) if durations else 0

                    typical_sequences.append({
                        "sequence": seq_str,
                        "frequency": round(count / total_sequences, 2),
                        "count": count,
                        "avg_duration_seconds": round(avg_duration, 1),
                    })

        return {
            "typical_sequences": typical_sequences[:5],  # Top 5
            "total_sequences_detected": len(sequences),
        }

    def _calculate_confidence(
        self,
        events: list[dict[str, Any]],
        temporal: dict[str, Any],
        spatial: dict[str, Any],
        behavioral: dict[str, Any],
    ) -> float:
        """
        Calculate overall confidence score based on data quality.

        Factors:
        - Number of events (more = higher confidence)
        - Data consistency (less variance = higher)
        - Time coverage (full 30 days = higher)

        Args:
            events: Access events
            temporal: Temporal patterns
            spatial: Spatial patterns
            behavioral: Behavioral patterns

        Returns:
            Confidence score (0.0 to 1.0)
        """
        # Event count factor (0-1)
        event_factor = min(len(events) / 100, 1.0)

        # Time coverage factor (0-1)
        if events:
            timestamps = [
                e["timestamp"] if isinstance(e["timestamp"], datetime)
                else datetime.fromisoformat(e["timestamp"])
                for e in events
            ]
            unique_days = len(set(ts.date() for ts in timestamps))
            coverage_factor = min(unique_days / 30, 1.0)
        else:
            coverage_factor = 0.0

        # Pattern quality factor (0-1)
        pattern_score = 0.0
        if temporal.get("peak_hours_by_day"):
            pattern_score += 0.4
        if spatial.get("typical_entry_points"):
            pattern_score += 0.3
        if behavioral.get("typical_sequences"):
            pattern_score += 0.3

        # Weighted average
        confidence = (
            event_factor * 0.3 + coverage_factor * 0.4 + pattern_score * 0.3
        )

        return round(confidence, 2)

    async def _get_access_events(
        self,
        entity_id: str,
        days: int,
        user_identifier: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Get access events from database.

        Args:
            entity_id: Entity ID
            days: Number of days of history
            user_identifier: Optional user filter (will be hashed)

        Returns:
            List of access events
        """
        cutoff = dt_util.now() - timedelta(days=days)

        # Hash user identifier if provided
        user_hash = None
        if user_identifier:
            user_hash = anonymize_user_id(user_identifier, self._device_id)

        # Build query
        if user_hash:
            cursor = await self._storage._db.execute(
                """
                SELECT event_id, entity_id, user_hash, access_method,
                       event_type, timestamp, context_data
                FROM access_events
                WHERE entity_id = ? AND user_hash = ? AND timestamp >= ?
                ORDER BY timestamp ASC
                """,
                (entity_id, user_hash, cutoff.isoformat()),
            )
        else:
            cursor = await self._storage._db.execute(
                """
                SELECT event_id, entity_id, user_hash, access_method,
                       event_type, timestamp, context_data
                FROM access_events
                WHERE entity_id = ? AND timestamp >= ?
                ORDER BY timestamp ASC
                """,
                (entity_id, cutoff.isoformat()),
            )

        rows = await cursor.fetchall()
        await cursor.close()

        # Convert to list of dicts
        events = []
        for row in rows:
            events.append({
                "event_id": row[0],
                "entity_id": row[1],
                "user_hash": row[2],
                "access_method": row[3],
                "event_type": row[4],
                "timestamp": row[5],
                "context_data": row[6],
            })

        _LOGGER.debug(
            "Retrieved %d access events for %s (last %d days)",
            len(events),
            entity_id,
            days,
        )

        return events

    async def _save_baseline(self, baseline: dict[str, Any]) -> None:
        """
        Save baseline to database.

        Args:
            baseline: Baseline data to save
        """
        # Save temporal baselines
        temporal = baseline.get("temporal", {})
        for day, pattern in temporal.get("peak_hours_by_day", {}).items():
            await self._storage._db.execute(
                """
                INSERT OR REPLACE INTO security_baselines
                (entity_id, user_hash, baseline_type, day_of_week, hour_of_day,
                 access_frequency, pattern_data, confidence, sample_count,
                 established_date, last_updated)
                VALUES (?, ?, 'temporal', ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    baseline["entity_id"],
                    baseline.get("user_hash"),
                    int(day),
                    pattern["hour"],
                    pattern["frequency"],
                    json.dumps(pattern),
                    baseline["confidence"],
                    pattern["sample_count"],
                    baseline["established_date"],
                    dt_util.now().isoformat(),
                ),
            )

        # Save spatial baselines
        spatial = baseline.get("spatial", {})
        if spatial:
            await self._storage._db.execute(
                """
                INSERT OR REPLACE INTO security_baselines
                (entity_id, user_hash, baseline_type, pattern_data,
                 confidence, sample_count, established_date, last_updated)
                VALUES (?, ?, 'spatial', ?, ?, ?, ?, ?)
                """,
                (
                    baseline["entity_id"],
                    baseline.get("user_hash"),
                    json.dumps(spatial),
                    baseline["confidence"],
                    baseline["events_analyzed"],
                    baseline["established_date"],
                    dt_util.now().isoformat(),
                ),
            )

        # Save behavioral baselines
        behavioral = baseline.get("behavioral", {})
        if behavioral:
            await self._storage._db.execute(
                """
                INSERT OR REPLACE INTO security_baselines
                (entity_id, user_hash, baseline_type, pattern_data,
                 confidence, sample_count, established_date, last_updated)
                VALUES (?, ?, 'behavioral', ?, ?, ?, ?, ?)
                """,
                (
                    baseline["entity_id"],
                    baseline.get("user_hash"),
                    json.dumps(behavioral),
                    baseline["confidence"],
                    baseline["events_analyzed"],
                    baseline["established_date"],
                    dt_util.now().isoformat(),
                ),
            )

        await self._storage._db.commit()
        _LOGGER.info(
            "Saved security baseline for %s", baseline["entity_id"]
        )
