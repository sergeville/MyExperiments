"""Security event monitoring for Home Assistant events.

Epic 5: Security & Environmental Safety
Story 5.1: Security Behavioral Baseline Establishment
Story 5.2: Anomaly Detection for Security Events

Monitors HA event bus for security-related events (locks, doors, motion, etc.)
and stores them for baseline calculation. Automatically detects anomalies.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any, TYPE_CHECKING

from homeassistant.core import HomeAssistant, Event, callback
from homeassistant.const import (
    EVENT_STATE_CHANGED,
    STATE_ON,
    STATE_OFF,
)
from homeassistant.util import dt as dt_util

# Lock states (not in homeassistant.const in all versions)
STATE_LOCKED = "locked"
STATE_UNLOCKED = "unlocked"

from ..pattern_storage import PatternStorage
from .privacy import sanitize_security_data

if TYPE_CHECKING:
    from .anomaly_detector import SecurityAnomalyDetector
    from .guest_code_manager import GuestCodeManager

_LOGGER = logging.getLogger(__name__)


class SecurityEventMonitor:
    """Monitor Home Assistant events for security activity.

    Captures state changes for:
    - Locks (lock.*)
    - Door sensors (binary_sensor.*_door)
    - Motion sensors (binary_sensor.*_motion)
    - Occupancy sensors (binary_sensor.*_occupancy)
    - Person tracking (device_tracker.*, person.*)
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
        anomaly_detector: SecurityAnomalyDetector | None = None,
        guest_code_manager: GuestCodeManager | None = None,
        device_id: str = "",
    ) -> None:
        """Initialize security event monitor.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
            anomaly_detector: Optional anomaly detector for real-time analysis
            guest_code_manager: Optional guest code manager for tracking code usage
            device_id: Device/instance ID for privacy salt
        """
        self.hass = hass
        self._storage = pattern_storage
        self._anomaly_detector = anomaly_detector
        self._guest_code_manager = guest_code_manager
        self._device_id = device_id or hass.config.location_name
        self._unsub = None

        # Security entity patterns
        self._security_domains = ["lock", "binary_sensor", "device_tracker", "person"]
        self._security_patterns = ["door", "motion", "occupancy", "lock"]

    async def async_setup(self) -> None:
        """Set up the event monitor."""
        _LOGGER.info("Setting up security event monitor")

        # Subscribe to state change events
        self._unsub = self.hass.bus.async_listen(
            EVENT_STATE_CHANGED,
            self._handle_state_change,
        )

        _LOGGER.info("Security event monitor initialized")

    async def async_close(self) -> None:
        """Close the event monitor."""
        if self._unsub:
            self._unsub()
            self._unsub = None
        _LOGGER.info("Security event monitor closed")

    def _is_security_entity(self, entity_id: str) -> bool:
        """
        Check if entity is security-related.

        Args:
            entity_id: Entity ID to check

        Returns:
            True if security-related entity
        """
        domain = entity_id.split(".")[0]

        # Check domain
        if domain not in self._security_domains:
            return False

        # For binary_sensors, check for security patterns
        if domain == "binary_sensor":
            return any(pattern in entity_id for pattern in self._security_patterns)

        return True

    @callback
    def _handle_state_change(self, event: Event) -> None:
        """
        Handle state change events.

        Args:
            event: State change event
        """
        entity_id = event.data.get("entity_id")
        old_state = event.data.get("old_state")
        new_state = event.data.get("new_state")

        if not entity_id or not new_state:
            return

        # Filter to security entities only
        if not self._is_security_entity(entity_id):
            return

        # Determine event type
        event_type = self._determine_event_type(entity_id, old_state, new_state)

        if not event_type:
            return

        # Extract user information if available (from lock attributes)
        user_info = self._extract_user_info(new_state)

        # Create access event
        self.hass.async_create_task(
            self._store_access_event(
                entity_id=entity_id,
                event_type=event_type,
                user_info=user_info,
                timestamp=new_state.last_changed or dt_util.now(),
                context_data=self._build_context(event, new_state),
            )
        )

    def _determine_event_type(
        self,
        entity_id: str,
        old_state: Any,
        new_state: Any,
    ) -> str | None:
        """
        Determine the type of security event.

        Args:
            entity_id: Entity ID
            old_state: Previous state
            new_state: New state

        Returns:
            Event type or None if not significant
        """
        domain = entity_id.split(".")[0]
        new_state_value = new_state.state if new_state else None
        old_state_value = old_state.state if old_state else None

        # Locks
        if domain == "lock":
            if new_state_value == STATE_LOCKED:
                return "lock"
            elif new_state_value == STATE_UNLOCKED:
                return "unlock"

        # Doors
        if "door" in entity_id:
            if new_state_value == STATE_ON:
                return "open"
            elif new_state_value == STATE_OFF:
                return "close"

        # Motion
        if "motion" in entity_id:
            if new_state_value == STATE_ON:
                return "motion"

        # Occupancy
        if "occupancy" in entity_id:
            if new_state_value == STATE_ON:
                return "occupancy"

        # Person/device tracker (home arrival/departure)
        if domain in ["person", "device_tracker"]:
            if old_state_value != "home" and new_state_value == "home":
                return "arrival"
            elif old_state_value == "home" and new_state_value != "home":
                return "departure"

        return None

    def _extract_user_info(self, state: Any) -> dict[str, Any] | None:
        """
        Extract user information from state attributes.

        Args:
            state: State object

        Returns:
            User information dictionary or None
        """
        if not state or not state.attributes:
            return None

        user_info = {}

        # Check for user-related attributes
        user_attributes = [
            "user_id",
            "code_slot",
            "code_slot_name",
            "changed_by",
            "user_name",
        ]

        for attr in user_attributes:
            if attr in state.attributes:
                user_info[attr] = state.attributes[attr]

        return user_info if user_info else None

    def _build_context(self, event: Event, state: Any) -> dict[str, Any]:
        """
        Build context data for the event.

        Args:
            event: Event object
            state: State object

        Returns:
            Context dictionary
        """
        context = {
            "event_context_id": event.context.id if event.context else None,
            "state_attributes": {},
        }

        # Include relevant state attributes
        if state and state.attributes:
            relevant_attrs = [
                "battery",
                "signal_strength",
                "last_activity",
                "method",
            ]

            for attr in relevant_attrs:
                if attr in state.attributes:
                    context["state_attributes"][attr] = state.attributes[attr]

        return context

    async def _store_access_event(
        self,
        entity_id: str,
        event_type: str,
        user_info: dict[str, Any] | None,
        timestamp: datetime,
        context_data: dict[str, Any],
    ) -> None:
        """
        Store access event to database.

        Args:
            entity_id: Entity ID
            event_type: Type of event
            user_info: User information (will be sanitized)
            timestamp: Event timestamp
            context_data: Additional context
        """
        # Generate unique event ID
        event_id = str(uuid.uuid4())

        # Sanitize user info for privacy
        if user_info:
            user_info = sanitize_security_data(user_info, self._device_id)

        user_hash = user_info.get("user_hash") if user_info else None
        access_method = user_info.get("method") if user_info else None

        try:
            # Store to database
            await self._storage._db.execute(
                """
                INSERT INTO access_events
                (event_id, entity_id, user_hash, access_method, event_type,
                 timestamp, context_data, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event_id,
                    entity_id,
                    user_hash,
                    access_method,
                    event_type,
                    timestamp.isoformat(),
                    str(context_data),  # JSON string
                    dt_util.now().isoformat(),
                ),
            )

            await self._storage._db.commit()

            _LOGGER.debug(
                "Stored access event: %s %s (user: %s)",
                entity_id,
                event_type,
                user_hash or "anonymous",
            )

            # Run anomaly detection if detector available
            if self._anomaly_detector:
                anomaly_result = await self._anomaly_detector.analyze_event(
                    entity_id=entity_id,
                    event_type=event_type,
                    user_hash=user_hash,
                    timestamp=timestamp,
                    context_data=context_data,
                )

                if anomaly_result.get("anomaly_detected"):
                    _LOGGER.warning(
                        "Security anomaly detected: %s - %s",
                        anomaly_result.get("risk_level", "unknown").upper(),
                        anomaly_result.get("explanation", "No details"),
                    )

            # Track guest code usage if manager available and code slot present
            if self._guest_code_manager and context_data.get("code_slot"):
                code_slot = context_data.get("code_slot")

                # Increment guest code usage
                usage_result = await self._guest_code_manager.increment_usage(code_slot)

                # Check for alerts
                if usage_result.get("alerts"):
                    for alert in usage_result["alerts"]:
                        if alert["severity"] == "high":
                            _LOGGER.warning(
                                "Guest code alert: %s", alert["message"]
                            )
                        else:
                            _LOGGER.info(
                                "Guest code info: %s", alert["message"]
                            )

                # Check for impossible access patterns
                impossible_access = await self._guest_code_manager.detect_impossible_access(
                    code_slot=code_slot,
                    timestamp=timestamp,
                    entity_id=entity_id,
                    time_threshold_minutes=30,
                )

                if impossible_access.get("impossible_access_detected"):
                    _LOGGER.warning(
                        "Impossible access detected: %s",
                        impossible_access.get("message", "Unknown issue"),
                    )

        except Exception as err:
            _LOGGER.error(
                "Failed to store access event for %s: %s",
                entity_id,
                err,
                exc_info=True,
            )

    async def get_recent_events(
        self,
        entity_id: str | None = None,
        days: int = 7,
    ) -> list[dict[str, Any]]:
        """
        Get recent access events.

        Args:
            entity_id: Optional entity filter
            days: Number of days to retrieve

        Returns:
            List of access events
        """
        cutoff = dt_util.now() - timedelta(days=days)

        if entity_id:
            cursor = await self._storage._db.execute(
                """
                SELECT event_id, entity_id, user_hash, access_method,
                       event_type, timestamp, anomaly_detected, risk_level,
                       context_data
                FROM access_events
                WHERE entity_id = ? AND timestamp >= ?
                ORDER BY timestamp DESC
                """,
                (entity_id, cutoff.isoformat()),
            )
        else:
            cursor = await self._storage._db.execute(
                """
                SELECT event_id, entity_id, user_hash, access_method,
                       event_type, timestamp, anomaly_detected, risk_level,
                       context_data
                FROM access_events
                WHERE timestamp >= ?
                ORDER BY timestamp DESC
                LIMIT 1000
                """,
                (cutoff.isoformat(),),
            )

        rows = await cursor.fetchall()
        await cursor.close()

        events = []
        for row in rows:
            events.append({
                "event_id": row[0],
                "entity_id": row[1],
                "user_hash": row[2],
                "access_method": row[3],
                "event_type": row[4],
                "timestamp": row[5],
                "anomaly_detected": bool(row[6]),
                "risk_level": row[7],
                "context_data": row[8],
            })

        return events
