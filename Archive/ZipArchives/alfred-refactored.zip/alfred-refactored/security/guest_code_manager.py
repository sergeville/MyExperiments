"""Guest code management for smart locks.

Epic 5: Security & Environmental Safety
Story 5.3: Smart Lock Intelligence & Access Tracking

Manages guest codes with expiration, usage tracking, and alerts.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any, TYPE_CHECKING

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from ..pattern_storage import PatternStorage
from .privacy import anonymize_user_id

if TYPE_CHECKING:
    pass

_LOGGER = logging.getLogger(__name__)


class GuestCodeManager:
    """Manage guest codes for smart locks.

    Features:
    - Track guest codes with expiration dates
    - Monitor usage count vs max_uses
    - Detect expired code usage
    - Detect impossible access patterns (shared codes)
    - Privacy-preserved tracking
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
        device_id: str = "",
    ) -> None:
        """Initialize guest code manager.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
            device_id: Device/instance ID for privacy salt
        """
        self.hass = hass
        self._storage = pattern_storage
        self._device_id = device_id or hass.config.location_name

    async def add_guest_code(
        self,
        code_slot: str,
        code_name: str,
        entity_id: str,
        expiration_date: datetime | None = None,
        max_uses: int | None = None,
        code_value: str | None = None,
        created_by: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        """Add a new guest code.

        Args:
            code_slot: Lock code slot number (e.g., "1", "2", etc.)
            code_name: Friendly name for the guest (e.g., "Airbnb Guest")
            entity_id: Lock entity ID
            expiration_date: Optional expiration date
            max_uses: Optional maximum number of uses
            code_value: Optional code value (will be hashed for privacy)
            created_by: Optional creator identifier
            notes: Optional notes

        Returns:
            Dictionary with success status and guest code info
        """
        try:
            # Hash user if provided
            user_hash = None
            if code_value:
                user_hash = anonymize_user_id(code_value, self._device_id)

            # Insert guest code
            await self._storage._db.execute(
                """
                INSERT INTO guest_codes
                (code_slot, code_name, entity_id, user_hash, code_value,
                 expiration_date, max_uses, created_by, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    code_slot,
                    code_name,
                    entity_id,
                    user_hash,
                    code_value,  # Consider not storing this in production
                    expiration_date.isoformat() if expiration_date else None,
                    max_uses,
                    created_by,
                    notes,
                ),
            )

            await self._storage._db.commit()

            _LOGGER.info(
                "Added guest code: slot=%s, name=%s, entity=%s, expires=%s",
                code_slot,
                code_name,
                entity_id,
                expiration_date.isoformat() if expiration_date else "never",
            )

            return {
                "success": True,
                "code_slot": code_slot,
                "code_name": code_name,
                "entity_id": entity_id,
                "expiration_date": expiration_date,
                "max_uses": max_uses,
            }

        except Exception as err:
            _LOGGER.error("Failed to add guest code: %s", err, exc_info=True)
            return {"success": False, "error": str(err)}

    async def update_guest_code(
        self,
        code_slot: str,
        expiration_date: datetime | None = None,
        max_uses: int | None = None,
        is_active: bool | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        """Update an existing guest code.

        Args:
            code_slot: Lock code slot number
            expiration_date: New expiration date (None to keep current)
            max_uses: New max uses (None to keep current)
            is_active: Active status (None to keep current)
            notes: New notes (None to keep current)

        Returns:
            Dictionary with success status
        """
        try:
            updates = []
            params = []

            if expiration_date is not None:
                updates.append("expiration_date = ?")
                params.append(expiration_date.isoformat())

            if max_uses is not None:
                updates.append("max_uses = ?")
                params.append(max_uses)

            if is_active is not None:
                updates.append("is_active = ?")
                params.append(is_active)

            if notes is not None:
                updates.append("notes = ?")
                params.append(notes)

            if not updates:
                return {"success": False, "error": "No updates provided"}

            params.append(code_slot)

            await self._storage._db.execute(
                f"UPDATE guest_codes SET {', '.join(updates)} WHERE code_slot = ?",
                params,
            )

            await self._storage._db.commit()

            _LOGGER.info("Updated guest code: slot=%s", code_slot)

            return {"success": True, "code_slot": code_slot}

        except Exception as err:
            _LOGGER.error("Failed to update guest code: %s", err, exc_info=True)
            return {"success": False, "error": str(err)}

    async def deactivate_guest_code(self, code_slot: str) -> dict[str, Any]:
        """Deactivate a guest code.

        Args:
            code_slot: Lock code slot number

        Returns:
            Dictionary with success status
        """
        return await self.update_guest_code(code_slot, is_active=False)

    async def increment_usage(self, code_slot: str) -> dict[str, Any]:
        """Increment usage count for a guest code.

        Args:
            code_slot: Lock code slot number

        Returns:
            Dictionary with usage info and alerts
        """
        try:
            # Get current guest code info
            cursor = await self._storage._db.execute(
                """
                SELECT code_name, current_uses, max_uses, expiration_date, is_active
                FROM guest_codes
                WHERE code_slot = ?
                """,
                (code_slot,),
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row:
                return {"success": False, "error": "Guest code not found"}

            code_name, current_uses, max_uses, expiration_date, is_active = row

            alerts = []

            # Check if code is expired
            if expiration_date:
                exp_date = datetime.fromisoformat(expiration_date)
                if dt_util.now() > exp_date:
                    alerts.append({
                        "type": "expired_code_used",
                        "severity": "high",
                        "message": f"Guest code '{code_name}' used after expiration",
                        "code_slot": code_slot,
                        "code_name": code_name,
                        "expiration_date": expiration_date,
                    })

            # Check if code is inactive
            if not is_active:
                alerts.append({
                    "type": "inactive_code_used",
                    "severity": "high",
                    "message": f"Inactive guest code '{code_name}' was used",
                    "code_slot": code_slot,
                    "code_name": code_name,
                })

            # Increment usage
            new_uses = current_uses + 1

            await self._storage._db.execute(
                "UPDATE guest_codes SET current_uses = ? WHERE code_slot = ?",
                (new_uses, code_slot),
            )

            await self._storage._db.commit()

            # Check if max uses reached
            if max_uses and new_uses >= max_uses:
                alerts.append({
                    "type": "max_uses_reached",
                    "severity": "medium",
                    "message": f"Guest code '{code_name}' reached max uses ({max_uses})",
                    "code_slot": code_slot,
                    "code_name": code_name,
                    "current_uses": new_uses,
                    "max_uses": max_uses,
                })

                # Auto-deactivate if max uses reached
                await self.deactivate_guest_code(code_slot)

            return {
                "success": True,
                "code_slot": code_slot,
                "code_name": code_name,
                "current_uses": new_uses,
                "max_uses": max_uses,
                "alerts": alerts,
            }

        except Exception as err:
            _LOGGER.error("Failed to increment usage: %s", err, exc_info=True)
            return {"success": False, "error": str(err)}

    async def get_guest_code(self, code_slot: str) -> dict[str, Any] | None:
        """Get guest code information.

        Args:
            code_slot: Lock code slot number

        Returns:
            Guest code dictionary or None
        """
        try:
            cursor = await self._storage._db.execute(
                """
                SELECT code_slot, code_name, entity_id, user_hash,
                       expiration_date, max_uses, current_uses, is_active,
                       created_at, created_by, notes
                FROM guest_codes
                WHERE code_slot = ?
                """,
                (code_slot,),
            )

            row = await cursor.fetchone()
            await cursor.close()

            if not row:
                return None

            return {
                "code_slot": row[0],
                "code_name": row[1],
                "entity_id": row[2],
                "user_hash": row[3],
                "expiration_date": row[4],
                "max_uses": row[5],
                "current_uses": row[6],
                "is_active": bool(row[7]),
                "created_at": row[8],
                "created_by": row[9],
                "notes": row[10],
            }

        except Exception as err:
            _LOGGER.error("Failed to get guest code: %s", err, exc_info=True)
            return None

    async def get_all_guest_codes(
        self,
        entity_id: str | None = None,
        active_only: bool = True,
    ) -> list[dict[str, Any]]:
        """Get all guest codes.

        Args:
            entity_id: Optional filter by lock entity ID
            active_only: Only return active codes

        Returns:
            List of guest code dictionaries
        """
        try:
            query = """
                SELECT code_slot, code_name, entity_id, user_hash,
                       expiration_date, max_uses, current_uses, is_active,
                       created_at, created_by, notes
                FROM guest_codes
                WHERE 1=1
            """
            params = []

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            if active_only:
                query += " AND is_active = TRUE"

            query += " ORDER BY created_at DESC"

            cursor = await self._storage._db.execute(query, params)
            rows = await cursor.fetchall()
            await cursor.close()

            return [
                {
                    "code_slot": row[0],
                    "code_name": row[1],
                    "entity_id": row[2],
                    "user_hash": row[3],
                    "expiration_date": row[4],
                    "max_uses": row[5],
                    "current_uses": row[6],
                    "is_active": bool(row[7]),
                    "created_at": row[8],
                    "created_by": row[9],
                    "notes": row[10],
                }
                for row in rows
            ]

        except Exception as err:
            _LOGGER.error("Failed to get guest codes: %s", err, exc_info=True)
            return []

    async def check_expired_codes(self) -> list[dict[str, Any]]:
        """Check for expired guest codes that are still active.

        Returns:
            List of expired guest codes
        """
        try:
            now = dt_util.now().isoformat()

            cursor = await self._storage._db.execute(
                """
                SELECT code_slot, code_name, entity_id, expiration_date
                FROM guest_codes
                WHERE is_active = TRUE
                  AND expiration_date IS NOT NULL
                  AND expiration_date < ?
                """,
                (now,),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            expired_codes = [
                {
                    "code_slot": row[0],
                    "code_name": row[1],
                    "entity_id": row[2],
                    "expiration_date": row[3],
                }
                for row in rows
            ]

            # Auto-deactivate expired codes
            for code in expired_codes:
                await self.deactivate_guest_code(code["code_slot"])
                _LOGGER.warning(
                    "Auto-deactivated expired guest code: %s (%s)",
                    code["code_name"],
                    code["code_slot"],
                )

            return expired_codes

        except Exception as err:
            _LOGGER.error("Failed to check expired codes: %s", err, exc_info=True)
            return []

    async def detect_impossible_access(
        self,
        code_slot: str,
        timestamp: datetime,
        entity_id: str,
        time_threshold_minutes: int = 30,
    ) -> dict[str, Any]:
        """Detect impossible access patterns (same code at different locations).

        Args:
            code_slot: Lock code slot number
            timestamp: Current access timestamp
            entity_id: Current lock entity ID
            time_threshold_minutes: Time window to check for impossible access

        Returns:
            Dictionary with detection results
        """
        try:
            # Get recent access events for this code slot
            cutoff = timestamp - timedelta(minutes=time_threshold_minutes)

            cursor = await self._storage._db.execute(
                """
                SELECT entity_id, timestamp, event_type
                FROM access_events
                WHERE context_data LIKE ?
                  AND timestamp >= ?
                  AND timestamp < ?
                ORDER BY timestamp DESC
                LIMIT 5
                """,
                (f'%"code_slot": "{code_slot}"%', cutoff.isoformat(), timestamp.isoformat()),
            )

            rows = await cursor.fetchall()
            await cursor.close()

            # Check for access at different locations within threshold
            for prev_entity_id, prev_timestamp, prev_event_type in rows:
                if prev_entity_id != entity_id:
                    prev_dt = datetime.fromisoformat(prev_timestamp)
                    time_diff_minutes = (timestamp - prev_dt).total_seconds() / 60

                    if time_diff_minutes < time_threshold_minutes:
                        guest_code = await self.get_guest_code(code_slot)

                        return {
                            "impossible_access_detected": True,
                            "severity": "high",
                            "code_slot": code_slot,
                            "code_name": guest_code["code_name"] if guest_code else "Unknown",
                            "previous_entity": prev_entity_id,
                            "current_entity": entity_id,
                            "time_diff_minutes": round(time_diff_minutes, 1),
                            "message": f"Guest code '{code_slot}' used at two different locks within {round(time_diff_minutes, 1)} minutes - possible code sharing",
                        }

            return {"impossible_access_detected": False}

        except Exception as err:
            _LOGGER.error("Failed to detect impossible access: %s", err, exc_info=True)
            return {"impossible_access_detected": False, "error": str(err)}
