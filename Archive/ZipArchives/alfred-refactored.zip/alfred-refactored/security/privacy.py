"""Privacy utilities for security module.

Provides anonymization and privacy-preserving functions for security data.
"""
from __future__ import annotations

import hashlib
import logging
from typing import Any

_LOGGER = logging.getLogger(__name__)


def anonymize_user_id(user_identifier: str, device_id: str = "") -> str:
    """
    Hash user identifier to prevent PII exposure.

    Args:
        user_identifier: User code, name, or identifier to anonymize
        device_id: Optional device/instance ID for additional salt

    Returns:
        16-character hash of the user identifier

    Example:
        >>> anonymize_user_id("1234", "alfred_home")
        'a3f2b1c9e8d4f5a6'
    """
    if not user_identifier:
        return "anonymous"

    # Create salt from device ID
    salt = f"alfred_security_{device_id}"

    # Hash with SHA-256
    hash_input = f"{user_identifier}_{salt}".encode('utf-8')
    hash_digest = hashlib.sha256(hash_input).hexdigest()

    # Return first 16 characters for compact storage
    return hash_digest[:16]


def validate_privacy(data: dict[str, Any]) -> tuple[bool, list[str]]:
    """
    Validate that data contains no PII (personally identifying information).

    Args:
        data: Dictionary to validate

    Returns:
        Tuple of (is_valid, violations)
        - is_valid: True if no PII detected
        - violations: List of fields containing potential PII

    Example:
        >>> validate_privacy({"user_hash": "a3f2...", "timestamp": "..."})
        (True, [])
        >>> validate_privacy({"user_name": "John", "email": "john@example.com"})
        (False, ["user_name", "email"])
    """
    violations = []

    # PII field patterns to check for
    pii_patterns = [
        "name",
        "email",
        "phone",
        "address",
        "ssn",
        "credit_card",
        "password",
        "user_code",  # Raw user codes
        "fingerprint_data",  # Raw biometric data
    ]

    # Check all keys in data
    for key in data.keys():
        key_lower = key.lower()

        # Check if key contains PII pattern
        for pattern in pii_patterns:
            if pattern in key_lower:
                # Exception: hashed fields are OK
                if "hash" not in key_lower and "hashed" not in key_lower:
                    violations.append(key)
                    _LOGGER.warning(
                        "Potential PII detected in field: %s", key
                    )
                    break

    is_valid = len(violations) == 0
    return is_valid, violations


def sanitize_security_data(data: dict[str, Any], device_id: str = "") -> dict[str, Any]:
    """
    Sanitize security data by anonymizing user identifiers.

    Args:
        data: Dictionary containing security data
        device_id: Device/instance ID for salt

    Returns:
        Sanitized dictionary with anonymized user IDs

    Example:
        >>> sanitize_security_data({
        ...     "user_code": "1234",
        ...     "timestamp": "2025-11-15T10:00:00"
        ... })
        {
            "user_hash": "a3f2b1c9e8d4f5a6",
            "timestamp": "2025-11-15T10:00:00"
        }
    """
    sanitized = data.copy()

    # Fields to anonymize
    user_fields = ["user_code", "user_id", "user_name", "code"]

    for field in user_fields:
        if field in sanitized:
            original_value = sanitized.pop(field)
            sanitized["user_hash"] = anonymize_user_id(original_value, device_id)
            _LOGGER.debug(
                "Anonymized field '%s' to user_hash", field
            )

    return sanitized


def audit_log_privacy_check(log_data: dict[str, Any]) -> None:
    """
    Audit log data for privacy compliance before logging.

    Raises ValueError if PII detected.

    Args:
        log_data: Data to be logged

    Raises:
        ValueError: If PII is detected in log data
    """
    is_valid, violations = validate_privacy(log_data)

    if not is_valid:
        raise ValueError(
            f"Privacy violation: PII detected in log data. "
            f"Violating fields: {', '.join(violations)}"
        )

    _LOGGER.debug("Privacy audit passed for log data")
