"""Weekly access summary reporting.

Epic 5: Security & Environmental Safety
Story 5.3: Smart Lock Intelligence & Access Tracking

Generates weekly summary reports for lock access and security events.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from ..pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class WeeklyReporter:
    """Generate weekly access summary reports.

    Features:
    - Weekly access summary
    - Guest code usage tracking
    - Anomaly summaries
    - Privacy-preserved reporting
    - Exportable reports
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize weekly reporter.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage

    async def generate_weekly_report(
        self,
        entity_id: str | None = None,
    ) -> dict[str, Any]:
        """Generate comprehensive weekly access report.

        Args:
            entity_id: Optional filter by lock entity ID

        Returns:
            Dictionary with weekly report data
        """
        try:
            # Define report period (last 7 days)
            end_date = dt_util.now()
            start_date = end_date - timedelta(days=7)

            # Get overall access statistics
            access_stats = await self._get_access_statistics(
                entity_id, start_date, end_date
            )

            # Get guest code usage
            guest_code_usage = await self._get_guest_code_usage(
                entity_id, start_date, end_date
            )

            # Get anomalies summary
            anomalies = await self._get_anomalies_summary(
                entity_id, start_date, end_date
            )

            # Get daily breakdown
            daily_breakdown = await self._get_daily_breakdown(
                entity_id, start_date, end_date
            )

            # Get most active users
            top_users = await self._get_top_users(entity_id, start_date, end_date)

            # Generate insights
            insights = await self._generate_insights(
                access_stats, guest_code_usage, anomalies
            )

            return {
                "report_type": "weekly_access_summary",
                "generated_at": dt_util.now().isoformat(),
                "period": {
                    "start": start_date.isoformat(),
                    "end": end_date.isoformat(),
                    "days": 7,
                },
                "entity_id": entity_id or "all_locks",
                "access_statistics": access_stats,
                "guest_code_usage": guest_code_usage,
                "anomalies": anomalies,
                "daily_breakdown": daily_breakdown,
                "top_users": top_users,
                "insights": insights,
            }

        except Exception as err:
            _LOGGER.error("Failed to generate weekly report: %s", err, exc_info=True)
            return {"error": str(err)}

    async def _get_access_statistics(
        self,
        entity_id: str | None,
        start_date: datetime,
        end_date: datetime,
    ) -> dict[str, Any]:
        """Get overall access statistics for the period."""
        try:
            query = """
                SELECT
                    COUNT(*) as total_events,
                    COUNT(DISTINCT user_hash) as unique_users,
                    COUNT(DISTINCT entity_id) as locks_accessed,
                    SUM(CASE WHEN event_type = 'unlock' THEN 1 ELSE 0 END) as unlocks,
                    SUM(CASE WHEN event_type = 'lock' THEN 1 ELSE 0 END) as locks,
                    SUM(CASE WHEN anomaly_detected = TRUE THEN 1 ELSE 0 END) as anomalies,
                    AVG(CASE WHEN duration_inside IS NOT NULL THEN duration_inside ELSE NULL END) as avg_duration
                FROM access_events
                WHERE timestamp >= ? AND timestamp <= ?
            """
            params = [start_date.isoformat(), end_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            cursor = await self._storage._db.execute(query, params)
            row = await cursor.fetchone()
            await cursor.close()

            return {
                "total_events": row[0] or 0,
                "unique_users": row[1] or 0,
                "locks_accessed": row[2] or 0,
                "unlocks": row[3] or 0,
                "locks": row[4] or 0,
                "anomalies": row[5] or 0,
                "avg_duration_seconds": int(row[6]) if row[6] else None,
            }

        except Exception as err:
            _LOGGER.error("Failed to get access statistics: %s", err, exc_info=True)
            return {}

    async def _get_guest_code_usage(
        self,
        entity_id: str | None,
        start_date: datetime,
        end_date: datetime,
    ) -> list[dict[str, Any]]:
        """Get guest code usage summary."""
        try:
            # Get all guest codes (active and inactive)
            query = """
                SELECT code_slot, code_name, entity_id, current_uses,
                       max_uses, is_active, expiration_date
                FROM guest_codes
                WHERE 1=1
            """
            params = []

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " ORDER BY current_uses DESC"

            cursor = await self._storage._db.execute(query, params)
            rows = await cursor.fetchall()
            await cursor.close()

            guest_codes = []

            for row in rows:
                code_slot, code_name, ent_id, current_uses, max_uses, is_active, expiration = row

                # Count uses in this period
                uses_query = """
                    SELECT COUNT(*)
                    FROM access_events
                    WHERE context_data LIKE ?
                      AND timestamp >= ?
                      AND timestamp <= ?
                """
                uses_params = [
                    f'%"code_slot": "{code_slot}"%',
                    start_date.isoformat(),
                    end_date.isoformat(),
                ]

                cursor = await self._storage._db.execute(uses_query, uses_params)
                period_uses = (await cursor.fetchone())[0]
                await cursor.close()

                guest_codes.append({
                    "code_slot": code_slot,
                    "code_name": code_name,
                    "entity_id": ent_id,
                    "total_uses": current_uses,
                    "period_uses": period_uses,
                    "max_uses": max_uses,
                    "is_active": bool(is_active),
                    "is_expired": (
                        datetime.fromisoformat(expiration) < dt_util.now()
                        if expiration
                        else False
                    ),
                })

            return guest_codes

        except Exception as err:
            _LOGGER.error("Failed to get guest code usage: %s", err, exc_info=True)
            return []

    async def _get_anomalies_summary(
        self,
        entity_id: str | None,
        start_date: datetime,
        end_date: datetime,
    ) -> dict[str, Any]:
        """Get anomalies summary for the period."""
        try:
            query = """
                SELECT risk_level, COUNT(*) as count
                FROM access_events
                WHERE anomaly_detected = TRUE
                  AND timestamp >= ?
                  AND timestamp <= ?
            """
            params = [start_date.isoformat(), end_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " GROUP BY risk_level"

            cursor = await self._storage._db.execute(query, params)
            rows = await cursor.fetchall()
            await cursor.close()

            by_risk_level = {row[0]: row[1] for row in rows}

            # Get recent anomalies (last 3)
            recent_query = """
                SELECT entity_id, event_type, timestamp, risk_level
                FROM access_events
                WHERE anomaly_detected = TRUE
                  AND timestamp >= ?
                  AND timestamp <= ?
            """
            recent_params = [start_date.isoformat(), end_date.isoformat()]

            if entity_id:
                recent_query += " AND entity_id = ?"
                recent_params.append(entity_id)

            recent_query += " ORDER BY timestamp DESC LIMIT 3"

            cursor = await self._storage._db.execute(recent_query, recent_params)
            recent_rows = await cursor.fetchall()
            await cursor.close()

            recent_anomalies = [
                {
                    "entity_id": row[0],
                    "event_type": row[1],
                    "timestamp": row[2],
                    "risk_level": row[3],
                }
                for row in recent_rows
            ]

            return {
                "total": sum(by_risk_level.values()),
                "by_risk_level": by_risk_level,
                "recent_anomalies": recent_anomalies,
            }

        except Exception as err:
            _LOGGER.error("Failed to get anomalies summary: %s", err, exc_info=True)
            return {"total": 0, "by_risk_level": {}, "recent_anomalies": []}

    async def _get_daily_breakdown(
        self,
        entity_id: str | None,
        start_date: datetime,
        end_date: datetime,
    ) -> list[dict[str, Any]]:
        """Get daily access breakdown."""
        try:
            query = """
                SELECT DATE(timestamp) as day, COUNT(*) as count
                FROM access_events
                WHERE timestamp >= ? AND timestamp <= ?
            """
            params = [start_date.isoformat(), end_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " GROUP BY day ORDER BY day"

            cursor = await self._storage._db.execute(query, params)
            rows = await cursor.fetchall()
            await cursor.close()

            return [{"date": row[0], "count": row[1]} for row in rows]

        except Exception as err:
            _LOGGER.error("Failed to get daily breakdown: %s", err, exc_info=True)
            return []

    async def _get_top_users(
        self,
        entity_id: str | None,
        start_date: datetime,
        end_date: datetime,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Get most active users for the period."""
        try:
            query = """
                SELECT user_hash, COUNT(*) as access_count
                FROM access_events
                WHERE user_hash IS NOT NULL
                  AND timestamp >= ?
                  AND timestamp <= ?
            """
            params = [start_date.isoformat(), end_date.isoformat()]

            if entity_id:
                query += " AND entity_id = ?"
                params.append(entity_id)

            query += " GROUP BY user_hash ORDER BY access_count DESC LIMIT ?"
            params.append(limit)

            cursor = await self._storage._db.execute(query, params)
            rows = await cursor.fetchall()
            await cursor.close()

            return [
                {"user_hash": row[0], "access_count": row[1]} for row in rows
            ]

        except Exception as err:
            _LOGGER.error("Failed to get top users: %s", err, exc_info=True)
            return []

    async def _generate_insights(
        self,
        access_stats: dict[str, Any],
        guest_code_usage: list[dict[str, Any]],
        anomalies: dict[str, Any],
    ) -> list[str]:
        """Generate insights from the weekly data."""
        insights = []

        try:
            # Total activity insight
            total_events = access_stats.get("total_events", 0)
            if total_events > 0:
                insights.append(
                    f"Recorded {total_events} access events across {access_stats.get('locks_accessed', 0)} lock(s)"
                )

            # Unique users insight
            unique_users = access_stats.get("unique_users", 0)
            if unique_users > 0:
                insights.append(f"{unique_users} unique user(s) accessed the locks")

            # Guest code insight
            active_guest_codes = len([g for g in guest_code_usage if g["is_active"]])
            if active_guest_codes > 0:
                insights.append(f"{active_guest_codes} active guest code(s)")

            expired_codes = len([g for g in guest_code_usage if g["is_expired"]])
            if expired_codes > 0:
                insights.append(
                    f"⚠️ {expired_codes} guest code(s) expired and should be reviewed"
                )

            # Anomaly insight
            total_anomalies = anomalies.get("total", 0)
            if total_anomalies > 0:
                high_risk = anomalies.get("by_risk_level", {}).get("high", 0)
                if high_risk > 0:
                    insights.append(
                        f"⚠️ {high_risk} high-risk anomaly/anomalies detected - immediate review recommended"
                    )
                else:
                    insights.append(f"{total_anomalies} anomaly/anomalies detected")
            else:
                insights.append("✓ No anomalies detected - all access patterns normal")

            # Duration insight
            avg_duration = access_stats.get("avg_duration_seconds")
            if avg_duration:
                hours = avg_duration // 3600
                minutes = (avg_duration % 3600) // 60
                insights.append(
                    f"Average time inside: {hours}h {minutes}m"
                )

        except Exception as err:
            _LOGGER.error("Failed to generate insights: %s", err, exc_info=True)

        return insights

    async def format_report_text(self, report: dict[str, Any]) -> str:
        """Format report as human-readable text.

        Args:
            report: Report dictionary from generate_weekly_report()

        Returns:
            Formatted text report
        """
        try:
            lines = []
            lines.append("=" * 60)
            lines.append("WEEKLY ACCESS REPORT")
            lines.append("=" * 60)
            lines.append("")

            # Period
            period = report.get("period", {})
            start = datetime.fromisoformat(period.get("start", "")).strftime("%Y-%m-%d")
            end = datetime.fromisoformat(period.get("end", "")).strftime("%Y-%m-%d")
            lines.append(f"Period: {start} to {end}")
            lines.append(f"Lock: {report.get('entity_id', 'All locks')}")
            lines.append("")

            # Access Statistics
            stats = report.get("access_statistics", {})
            lines.append("ACCESS STATISTICS")
            lines.append("-" * 60)
            lines.append(f"Total Events:     {stats.get('total_events', 0)}")
            lines.append(f"Unique Users:     {stats.get('unique_users', 0)}")
            lines.append(f"Unlocks:          {stats.get('unlocks', 0)}")
            lines.append(f"Locks:            {stats.get('locks', 0)}")
            lines.append(f"Anomalies:        {stats.get('anomalies', 0)}")
            lines.append("")

            # Guest Codes
            guest_codes = report.get("guest_code_usage", [])
            if guest_codes:
                lines.append("GUEST CODE USAGE")
                lines.append("-" * 60)
                for code in guest_codes[:10]:  # Top 10
                    status = "✓" if code["is_active"] else "✗"
                    expired = " [EXPIRED]" if code.get("is_expired") else ""
                    lines.append(
                        f"{status} {code['code_name']}: {code['period_uses']} uses{expired}"
                    )
                lines.append("")

            # Insights
            insights = report.get("insights", [])
            if insights:
                lines.append("KEY INSIGHTS")
                lines.append("-" * 60)
                for insight in insights:
                    lines.append(f"• {insight}")
                lines.append("")

            lines.append("=" * 60)

            return "\n".join(lines)

        except Exception as err:
            _LOGGER.error("Failed to format report text: %s", err, exc_info=True)
            return "Error formatting report"
