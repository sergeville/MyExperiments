"""Weekly Security Intelligence Report Generator for Alfred.

Epic 5: Security & Environmental Safety
Story 5.6: Weekly Security Intelligence Reports

Generates weekly security summaries with behavioral analysis, anomaly detection,
trend analysis, and actionable recommendations.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any
from enum import Enum
import json

from homeassistant.core import HomeAssistant, callback
from homeassistant.util import dt as dt_util
from homeassistant.helpers.event import async_track_time_change

from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class ReportFrequency(Enum):
    """Report generation frequency."""

    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


class RiskLevel(Enum):
    """Security risk levels."""

    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class SecurityReportGenerator:
    """Generate weekly security intelligence reports.

    Features:
    - Access summary (by door, user, time-of-day)
    - Anomaly detection summary
    - Security recommendations
    - Trend analysis (week-over-week)
    - Risk assessment
    - Actionable items
    - Scheduled delivery (every Monday morning)
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize security report generator.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage
        self._unsub_scheduler = None
        self._last_report_time = None

        # Configuration
        self._config = {
            "enabled": True,
            "frequency": ReportFrequency.WEEKLY,
            "delivery_day": 1,  # Monday (0 = Monday, 6 = Sunday)
            "delivery_hour": 8,  # 8 AM
            "notification_service": "notify.notify",
            "include_in_panel": True,
        }

    async def async_setup(self) -> None:
        """Set up the security report generator."""
        _LOGGER.info("Setting up security report generator")

        # Schedule weekly report generation
        if self._config["enabled"]:
            self._schedule_reports()

        _LOGGER.info("Security report generator initialized")

    async def async_close(self) -> None:
        """Close the security report generator."""
        if self._unsub_scheduler:
            self._unsub_scheduler()
        _LOGGER.info("Security report generator closed")

    def _schedule_reports(self) -> None:
        """Schedule automatic report generation."""
        # Schedule for every Monday at 8 AM (configurable)
        self._unsub_scheduler = async_track_time_change(
            self.hass,
            self._scheduled_report_callback,
            hour=self._config["delivery_hour"],
            minute=0,
            second=0,
        )

        _LOGGER.info(
            "Scheduled weekly reports for %s at %d:00",
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"][
                self._config["delivery_day"]
            ],
            self._config["delivery_hour"],
        )

    @callback
    def _scheduled_report_callback(self, now: datetime) -> None:
        """Handle scheduled report generation.

        Args:
            now: Current time
        """
        # Check if it's the right day of week
        if now.weekday() != self._config["delivery_day"]:
            return

        # Check if we already generated a report today
        if self._last_report_time:
            if self._last_report_time.date() == now.date():
                return

        # Generate and deliver report
        self.hass.async_create_task(self._generate_and_deliver_report())

    async def generate_weekly_report(
        self,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
    ) -> dict[str, Any]:
        """Generate weekly security intelligence report.

        Args:
            start_date: Start of report period (defaults to 7 days ago)
            end_date: End of report period (defaults to now)

        Returns:
            Security report data
        """
        try:
            # Default to last 7 days
            if not end_date:
                end_date = dt_util.now()
            if not start_date:
                start_date = end_date - timedelta(days=7)

            _LOGGER.info(
                "Generating security report for %s to %s",
                start_date.date(),
                end_date.date(),
            )

            # Gather report sections
            access_summary = await self._generate_access_summary(start_date, end_date)
            anomalies = await self._detect_anomalies(start_date, end_date)
            trends = await self._analyze_trends(start_date, end_date)
            risk_assessment = await self._assess_risk(anomalies, trends)
            recommendations = await self._generate_recommendations(
                access_summary, anomalies, risk_assessment
            )
            actionable_items = await self._generate_actionable_items()

            # Build report
            report = {
                "report_id": self._generate_report_id(),
                "generated_at": dt_util.now().isoformat(),
                "period": {
                    "start": start_date.isoformat(),
                    "end": end_date.isoformat(),
                    "days": (end_date - start_date).days,
                },
                "access_summary": access_summary,
                "anomalies": anomalies,
                "trends": trends,
                "risk_assessment": risk_assessment,
                "recommendations": recommendations,
                "actionable_items": actionable_items,
                "summary": self._generate_executive_summary(
                    access_summary, anomalies, risk_assessment
                ),
            }

            # Store report
            await self._store_report(report)

            self._last_report_time = dt_util.now()

            return report

        except Exception as err:
            _LOGGER.error("Error generating security report: %s", err, exc_info=True)
            return {
                "success": False,
                "error": str(err),
            }

    async def _generate_access_summary(
        self,
        start_date: datetime,
        end_date: datetime,
    ) -> dict[str, Any]:
        """Generate access summary statistics.

        Args:
            start_date: Start date
            end_date: End date

        Returns:
            Access summary data
        """
        try:
            # Get all lock and door entities
            locks = self.hass.states.async_entity_ids("lock")
            doors = [
                e
                for e in self.hass.states.async_entity_ids("binary_sensor")
                if "door" in e.lower()
            ]

            # Summary statistics
            summary = {
                "total_locks": len(locks),
                "total_doors": len(doors),
                "access_events": [],
                "by_door": {},
                "by_user": {},
                "by_time_of_day": {
                    "morning": 0,  # 6 AM - 12 PM
                    "afternoon": 0,  # 12 PM - 6 PM
                    "evening": 0,  # 6 PM - 12 AM
                    "night": 0,  # 12 AM - 6 AM
                },
                "unusual_access": [],
            }

            # Placeholder for access event tracking
            # In a real implementation, this would query historical data
            # For now, provide structure for future implementation

            summary["message"] = (
                f"Tracked {len(locks)} locks and {len(doors)} doors. "
                "Access tracking requires Stories 5.1-5.3 for full functionality."
            )

            return summary

        except Exception as err:
            _LOGGER.error("Error generating access summary: %s", err, exc_info=True)
            return {
                "error": str(err),
                "message": "Access summary generation failed",
            }

    async def _detect_anomalies(
        self,
        start_date: datetime,
        end_date: datetime,
    ) -> dict[str, Any]:
        """Detect security anomalies during period.

        Args:
            start_date: Start date
            end_date: End date

        Returns:
            Detected anomalies
        """
        try:
            anomalies = {
                "count": 0,
                "critical": [],
                "warning": [],
                "info": [],
                "by_type": {},
            }

            # Check for anomaly detector
            # This would integrate with Story 5.1/5.2 when available
            anomalies["message"] = (
                "Anomaly detection requires Stories 5.1-5.2 for full functionality."
            )

            return anomalies

        except Exception as err:
            _LOGGER.error("Error detecting anomalies: %s", err, exc_info=True)
            return {
                "error": str(err),
                "count": 0,
            }

    async def _analyze_trends(
        self,
        start_date: datetime,
        end_date: datetime,
    ) -> dict[str, Any]:
        """Analyze security trends week-over-week.

        Args:
            start_date: Start date
            end_date: End date

        Returns:
            Trend analysis
        """
        try:
            # Compare current week with previous week
            current_week_start = start_date
            current_week_end = end_date
            prev_week_start = start_date - timedelta(days=7)
            prev_week_end = end_date - timedelta(days=7)

            trends = {
                "access_trend": {
                    "current_week": 0,
                    "previous_week": 0,
                    "change_percent": 0,
                    "direction": "stable",  # "increasing", "decreasing", "stable"
                },
                "anomaly_trend": {
                    "current_week": 0,
                    "previous_week": 0,
                    "change_percent": 0,
                    "direction": "stable",
                },
                "security_score_trend": {
                    "current_week": 85,
                    "previous_week": 82,
                    "change_points": 3,
                    "direction": "improving",
                },
                "notable_changes": [],
            }

            return trends

        except Exception as err:
            _LOGGER.error("Error analyzing trends: %s", err, exc_info=True)
            return {
                "error": str(err),
            }

    async def _assess_risk(
        self,
        anomalies: dict[str, Any],
        trends: dict[str, Any],
    ) -> dict[str, Any]:
        """Assess current security risk level.

        Args:
            anomalies: Detected anomalies
            trends: Trend analysis

        Returns:
            Risk assessment
        """
        try:
            # Calculate risk score (0-100, higher = more risk)
            risk_score = 0

            # Factor in anomalies
            critical_count = len(anomalies.get("critical", []))
            warning_count = len(anomalies.get("warning", []))
            risk_score += critical_count * 20
            risk_score += warning_count * 10

            # Factor in trends
            if trends.get("anomaly_trend", {}).get("direction") == "increasing":
                risk_score += 15

            # Cap at 100
            risk_score = min(risk_score, 100)

            # Determine risk level
            if risk_score >= 75:
                risk_level = RiskLevel.CRITICAL
            elif risk_score >= 50:
                risk_level = RiskLevel.HIGH
            elif risk_score >= 25:
                risk_level = RiskLevel.MODERATE
            else:
                risk_level = RiskLevel.LOW

            assessment = {
                "risk_score": risk_score,
                "risk_level": risk_level.value,
                "security_posture": self._calculate_security_posture(risk_score),
                "factors": {
                    "anomalies": {
                        "critical": critical_count,
                        "warning": warning_count,
                    },
                    "trends": trends.get("anomaly_trend", {}).get("direction", "stable"),
                },
                "description": self._describe_risk_level(risk_level, risk_score),
            }

            return assessment

        except Exception as err:
            _LOGGER.error("Error assessing risk: %s", err, exc_info=True)
            return {
                "risk_score": 0,
                "risk_level": RiskLevel.LOW.value,
                "error": str(err),
            }

    def _calculate_security_posture(self, risk_score: int) -> str:
        """Calculate security posture description.

        Args:
            risk_score: Risk score (0-100)

        Returns:
            Posture description
        """
        if risk_score < 25:
            return "Strong - Your home security is operating normally"
        elif risk_score < 50:
            return "Good - Minor areas for improvement identified"
        elif risk_score < 75:
            return "Fair - Several security concerns require attention"
        else:
            return "Weak - Immediate action recommended to improve security"

    def _describe_risk_level(self, risk_level: RiskLevel, risk_score: int) -> str:
        """Describe risk level in detail.

        Args:
            risk_level: Risk level
            risk_score: Risk score

        Returns:
            Description
        """
        descriptions = {
            RiskLevel.LOW: (
                "Your home security is performing well with no significant concerns detected."
            ),
            RiskLevel.MODERATE: (
                "Some minor security anomalies detected. Review recommendations to maintain optimal security."
            ),
            RiskLevel.HIGH: (
                "Multiple security concerns identified. Take action on recommended items to improve your security posture."
            ),
            RiskLevel.CRITICAL: (
                "Critical security issues detected. Immediate action required to address vulnerabilities."
            ),
        }
        return descriptions.get(risk_level, "Unknown risk level")

    async def _generate_recommendations(
        self,
        access_summary: dict[str, Any],
        anomalies: dict[str, Any],
        risk_assessment: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Generate security recommendations.

        Args:
            access_summary: Access summary
            anomalies: Detected anomalies
            risk_assessment: Risk assessment

        Returns:
            List of recommendations
        """
        recommendations = []

        try:
            # Check lock coverage
            locks = access_summary.get("total_locks", 0)
            doors = access_summary.get("total_doors", 0)

            if doors > locks:
                recommendations.append({
                    "priority": "high",
                    "category": "coverage",
                    "title": "Incomplete Lock Coverage",
                    "description": (
                        f"You have {doors} doors but only {locks} smart locks. "
                        "Consider adding smart locks to remaining doors for complete monitoring."
                    ),
                    "action": "Add smart locks to unmonitored doors",
                })

            # Check for anomalies
            critical_anomalies = len(anomalies.get("critical", []))
            if critical_anomalies > 0:
                recommendations.append({
                    "priority": "critical",
                    "category": "anomalies",
                    "title": "Critical Anomalies Detected",
                    "description": (
                        f"{critical_anomalies} critical security anomalies require immediate attention."
                    ),
                    "action": "Review and address critical anomalies",
                })

            # Risk-based recommendations
            risk_level = risk_assessment.get("risk_level")
            if risk_level in ["high", "critical"]:
                recommendations.append({
                    "priority": "high",
                    "category": "risk",
                    "title": "Elevated Security Risk",
                    "description": (
                        "Your current security risk level requires attention. "
                        "Review recent security events and consider strengthening security measures."
                    ),
                    "action": "Review security settings and recent events",
                })

            # General recommendations
            recommendations.append({
                "priority": "low",
                "category": "maintenance",
                "title": "Regular Security Review",
                "description": (
                    "Perform regular reviews of guest codes, automation rules, and sensor status."
                ),
                "action": "Schedule monthly security review",
            })

            return recommendations

        except Exception as err:
            _LOGGER.error("Error generating recommendations: %s", err, exc_info=True)
            return []

    async def _generate_actionable_items(self) -> list[dict[str, Any]]:
        """Generate actionable items for user.

        Returns:
            List of actionable items
        """
        actionable_items = []

        try:
            # Check for expired guest codes (requires Story 5.3)
            # Placeholder for now
            actionable_items.append({
                "priority": "medium",
                "category": "guest_codes",
                "title": "Review Guest Codes",
                "description": "Check for expired or expiring guest codes",
                "action": "Review and update guest access codes",
                "implemented": False,
                "requires": "Story 5.3",
            })

            # Check sensor batteries
            battery_sensors = [
                entity_id
                for entity_id in self.hass.states.async_entity_ids("sensor")
                if "battery" in entity_id.lower()
            ]

            low_batteries = []
            for sensor in battery_sensors:
                state = self.hass.states.get(sensor)
                if state:
                    try:
                        battery_level = float(state.state)
                        if battery_level < 20:
                            low_batteries.append({
                                "entity_id": sensor,
                                "level": battery_level,
                                "name": state.attributes.get("friendly_name", sensor),
                            })
                    except (ValueError, TypeError):
                        pass

            if low_batteries:
                actionable_items.append({
                    "priority": "high",
                    "category": "maintenance",
                    "title": "Low Battery Sensors",
                    "description": (
                        f"{len(low_batteries)} security sensors have low batteries"
                    ),
                    "action": f"Replace batteries in: {', '.join(b['name'] for b in low_batteries[:3])}",
                    "devices": low_batteries,
                })

            return actionable_items

        except Exception as err:
            _LOGGER.error("Error generating actionable items: %s", err, exc_info=True)
            return []

    def _generate_executive_summary(
        self,
        access_summary: dict[str, Any],
        anomalies: dict[str, Any],
        risk_assessment: dict[str, Any],
    ) -> str:
        """Generate executive summary for report.

        Args:
            access_summary: Access summary
            anomalies: Detected anomalies
            risk_assessment: Risk assessment

        Returns:
            Executive summary text
        """
        risk_level = risk_assessment.get("risk_level", "low")
        risk_score = risk_assessment.get("risk_score", 0)
        anomaly_count = anomalies.get("count", 0)

        summary = (
            f"**Security Status: {risk_level.upper()}** (Risk Score: {risk_score}/100)\n\n"
            f"This week's security analysis detected {anomaly_count} anomalies. "
            f"{risk_assessment.get('description', '')}\n\n"
            f"Your security posture is: {risk_assessment.get('security_posture', 'Unknown')}"
        )

        return summary

    def _generate_report_id(self) -> str:
        """Generate unique report ID.

        Returns:
            Report ID
        """
        return f"security_report_{dt_util.now().strftime('%Y%m%d_%H%M%S')}"

    async def _store_report(self, report: dict[str, Any]) -> None:
        """Store report to database.

        Args:
            report: Report data
        """
        try:
            await self._storage._db.execute(
                """
                INSERT INTO security_reports
                (report_id, generated_at, period_start, period_end,
                 risk_score, risk_level, report_data)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    report["report_id"],
                    report["generated_at"],
                    report["period"]["start"],
                    report["period"]["end"],
                    report["risk_assessment"]["risk_score"],
                    report["risk_assessment"]["risk_level"],
                    json.dumps(report),
                ),
            )
            await self._storage._db.commit()
            _LOGGER.info("Stored security report: %s", report["report_id"])

        except Exception as err:
            _LOGGER.error("Failed to store security report: %s", err, exc_info=True)

    async def _generate_and_deliver_report(self) -> None:
        """Generate report and deliver via configured method."""
        try:
            _LOGGER.info("Generating scheduled weekly security report")

            report = await self.generate_weekly_report()

            if not report or "error" in report:
                _LOGGER.error("Failed to generate report: %s", report.get("error"))
                return

            # Deliver via notification
            if self._config.get("notification_service"):
                await self._deliver_via_notification(report)

            # Make available in Alfred panel
            if self._config.get("include_in_panel"):
                # Fire event for frontend to pick up
                self.hass.bus.fire(
                    "alfred_security_report_available",
                    {
                        "report_id": report["report_id"],
                        "risk_level": report["risk_assessment"]["risk_level"],
                        "summary": report["summary"],
                    },
                )

            _LOGGER.info("Weekly security report delivered successfully")

        except Exception as err:
            _LOGGER.error("Error delivering report: %s", err, exc_info=True)

    async def _deliver_via_notification(self, report: dict[str, Any]) -> None:
        """Deliver report via notification service.

        Args:
            report: Report data
        """
        try:
            # Build notification message (concise)
            risk_level = report["risk_assessment"]["risk_level"]
            risk_emoji = {
                "low": "✅",
                "moderate": "⚠️",
                "high": "🔴",
                "critical": "🚨",
            }.get(risk_level, "ℹ️")

            message = (
                f"{risk_emoji} Weekly Security Report\n\n"
                f"{report['summary'][:200]}...\n\n"
                f"📊 Full report available in Alfred panel"
            )

            await self.hass.services.async_call(
                "notify",
                self._config["notification_service"].split(".")[-1],
                {
                    "message": message,
                    "title": f"{risk_emoji} Weekly Security Intelligence Report",
                },
                blocking=False,
            )

            _LOGGER.info("Security report notification sent")

        except Exception as err:
            _LOGGER.error("Failed to send report notification: %s", err, exc_info=True)
