"""Service handlers for Alfred Digital Butler.

This module extracts all service handler logic from __init__.py to improve
maintainability and reduce the size of the main module.
"""
from __future__ import annotations

import functools
import logging
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Callable, TypeVar

from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.exceptions import Unauthorized, ServiceValidationError
from homeassistant.components import conversation
from homeassistant.core import Context

from .const import (
    DOMAIN,
    SERVICE_SEND_MESSAGE,
    SERVICE_START_CONVERSATION,
    SERVICE_CHAT_WITH_MEMORY,
    SERVICE_GET_DEVICE_RUNTIME,
    SERVICE_RESET_DEVICE_RUNTIME,
    SERVICE_GET_POWER_QUALITY,
    SERVICE_GET_DEVICE_HEALTH,
    SERVICE_ANALYZE_DEGRADATION,
    SERVICE_DISMISS_DEGRADATION_ALERT,
    SERVICE_DIAGNOSE_DEVICE,
    SERVICE_GET_BATTERY_STATUS,
    SERVICE_GET_BATTERY_SHOPPING_LIST,
    SERVICE_RECORD_BATTERY_REPLACEMENT,
    SERVICE_SET_BATTERY_TYPE,
    SERVICE_GET_ENERGY_CONSUMPTION,
    SERVICE_GET_ENERGY_PATTERNS,
    SERVICE_GET_ENERGY_INSIGHTS,
    SERVICE_ANALYZE_ENERGY_DEVICE,
    SERVICE_PREDICT_PIPE_FREEZE,
    SERVICE_TRIGGER_EMERGENCY,
    SERVICE_RESOLVE_EMERGENCY,
    SERVICE_GET_EMERGENCY_STATUS,
    SERVICE_GET_EMERGENCY_LOG,
    SERVICE_GENERATE_SECURITY_REPORT,
    SERVICE_ADD_GUEST_CODE,
    SERVICE_GET_ACCESS_HISTORY,
    SERVICE_GET_GUEST_CODES,
    SERVICE_GENERATE_WEEKLY_ACCESS_SUMMARY,
)

_LOGGER = logging.getLogger(__name__)

# Type variable for generic handler functions
F = TypeVar('F', bound=Callable[..., Any])


class RateLimiter:
    """Rate limiter for service calls."""

    def __init__(self, max_calls_per_minute: int = 10):
        """Initialize the rate limiter.
        
        Args:
            max_calls_per_minute: Maximum number of calls allowed per minute per user
        """
        self._tracker: dict[str, list[datetime]] = defaultdict(list)
        self._max_calls = max_calls_per_minute

    def check(self, user_id: str) -> bool:
        """Check if user is within rate limit.
        
        Args:
            user_id: The user ID to check
            
        Returns:
            True if within limit, False if exceeded
        """
        now = datetime.now()
        
        # Clean old entries (older than 1 minute)
        self._tracker[user_id] = [
            ts for ts in self._tracker[user_id]
            if now - ts < timedelta(minutes=1)
        ]
        
        # Check if limit exceeded
        if len(self._tracker[user_id]) >= self._max_calls:
            return False
        
        # Record this call
        self._tracker[user_id].append(now)
        return True

    def get_call_count(self, user_id: str) -> int:
        """Get current call count for user."""
        now = datetime.now()
        return len([
            ts for ts in self._tracker[user_id]
            if now - ts < timedelta(minutes=1)
        ])


class AlfredServiceHandlers:
    """Centralized service handlers for Alfred.
    
    This class manages all service handlers with consistent:
    - Authorization checks
    - Rate limiting
    - Audit logging
    - Error handling
    """

    def __init__(
        self,
        hass: HomeAssistant,
        conversation_agent: Any,
        max_calls_per_minute: int = 10,
    ) -> None:
        """Initialize service handlers.
        
        Args:
            hass: Home Assistant instance
            conversation_agent: The Alfred conversation agent
            max_calls_per_minute: Rate limit for service calls
        """
        self.hass = hass
        self.conversation_agent = conversation_agent
        self._rate_limiter = RateLimiter(max_calls_per_minute)

    def _get_entry_id(self) -> str:
        """Get the first config entry ID for Alfred."""
        entry_ids = list(self.hass.data.get(DOMAIN, {}).keys())
        if not entry_ids:
            raise ServiceValidationError("Alfred integration not configured")
        return entry_ids[0]

    def _get_component(self, component_name: str) -> Any:
        """Get a component from hass.data.
        
        Args:
            component_name: Name of the component (e.g., 'intelligence_engine')
            
        Returns:
            The component instance
            
        Raises:
            ServiceValidationError: If component not found
        """
        entry_id = self._get_entry_id()
        component = self.hass.data[DOMAIN][entry_id].get(component_name)
        if not component:
            raise ServiceValidationError(f"{component_name} not available")
        return component

    async def _check_authorization(self, call: ServiceCall) -> None:
        """Verify caller has proper permissions.
        
        Args:
            call: The service call
            
        Raises:
            Unauthorized: If user is not authenticated or inactive
        """
        if not call.context.user_id:
            _LOGGER.error("Alfred service call without user_id - rejecting")
            raise Unauthorized("Authentication required for Alfred services")

        user = await self.hass.auth.async_get_user(call.context.user_id)
        if not user or not user.is_active:
            _LOGGER.error(
                "Alfred service call from invalid/inactive user %s - rejecting",
                call.context.user_id
            )
            raise Unauthorized("Invalid or inactive user")

        _LOGGER.debug("Authorization check passed for user: %s", user.name)

    async def _check_rate_limit(self, call: ServiceCall) -> None:
        """Check and enforce rate limiting.
        
        Args:
            call: The service call
            
        Raises:
            ServiceValidationError: If rate limit exceeded
        """
        user_id = call.context.user_id
        if not self._rate_limiter.check(user_id):
            user = await self.hass.auth.async_get_user(user_id)
            call_count = self._rate_limiter.get_call_count(user_id)
            _LOGGER.warning(
                "Rate limit exceeded for user %s (%s calls in last minute)",
                user.name if user else user_id,
                call_count
            )
            raise ServiceValidationError(
                f"Rate limit exceeded. Maximum {self._rate_limiter._max_calls} calls per minute."
            )

    async def _audit_log(
        self,
        call: ServiceCall,
        service_name: str,
        success: bool = True,
        error: str | None = None,
    ) -> None:
        """Log service call for security audit.
        
        Args:
            call: The service call
            service_name: Name of the service
            success: Whether the call succeeded
            error: Error message if failed
        """
        user = None
        if call.context.user_id:
            user = await self.hass.auth.async_get_user(call.context.user_id)
        user_name = user.name if user else "unknown"

        log_data = {
            "service": service_name,
            "user": user_name,
            "user_id": call.context.user_id,
            "timestamp": datetime.now().isoformat(),
            "success": success,
        }

        if error:
            log_data["error"] = error

        if service_name == SERVICE_SEND_MESSAGE:
            message = call.data.get("message", "")
            log_data["message_length"] = len(message)
            log_data["message_preview"] = message[:50] + ("..." if len(message) > 50 else "")

        if success:
            _LOGGER.info("Alfred service call: %s", log_data)
        else:
            _LOGGER.error("Alfred service call failed: %s", log_data)

    def secured_handler(self, service_name: str) -> Callable[[F], F]:
        """Decorator for secured service handlers.
        
        Applies authorization, rate limiting, and audit logging to a handler.
        
        Args:
            service_name: Name of the service for logging
            
        Returns:
            Decorator function
        """
        def decorator(func: F) -> F:
            @functools.wraps(func)
            async def wrapper(call: ServiceCall) -> Any:
                try:
                    await self._check_authorization(call)
                    await self._check_rate_limit(call)
                    
                    result = await func(call)
                    
                    await self._audit_log(call, service_name, success=True)
                    return result
                    
                except (Unauthorized, ServiceValidationError) as err:
                    await self._audit_log(call, service_name, success=False, error=str(err))
                    raise
                except Exception as err:
                    await self._audit_log(call, service_name, success=False, error=str(err))
                    _LOGGER.exception("Unexpected error in %s", service_name)
                    raise
            
            return wrapper  # type: ignore
        return decorator

    # =========================================================================
    # Communication Services
    # =========================================================================

    async def handle_send_message(self, call: ServiceCall) -> dict[str, Any]:
        """Handle send_message service call."""
        message = call.data.get("message")
        mode = call.data.get("mode", "text")

        user_input = conversation.ConversationInput(
            text=message,
            context=call.context or Context(),
            conversation_id=call.data.get("conversation_id"),
            device_id=None,
            language="en",
            agent_id=self.conversation_agent.entry.entry_id,
            satellite_id=None,
        )

        result = await self.conversation_agent.async_process(user_input)

        response_text = ""
        if result and result.response and result.response.speech:
            response_text = result.response.speech.get("plain", {}).get("speech", "")

        return {"response": response_text or "I'm at your service, sir."}

    async def handle_start_conversation(self, call: ServiceCall) -> None:
        """Handle start_conversation service call."""
        await self.conversation_agent.async_acknowledge_user()

    async def handle_chat_with_memory(self, call: ServiceCall) -> dict[str, Any]:
        """Handle chat_with_memory service - calls Alfred agent with Michael Caine voice."""
        import aiohttp

        message = call.data.get("message")
        session_id = call.data.get("session_id", "ha-session")

        if not message:
            raise ServiceValidationError("message is required")

        # TODO: Move URL to configuration
        agent_url = "http://host.docker.internal:8052/agent/chat"

        async with aiohttp.ClientSession() as session:
            async with session.post(
                agent_url,
                json={"session_id": session_id, "message": message},
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    response_text = data.get("response", "")
                    _LOGGER.info("Michael Caine Alfred responded: %s...", response_text[:100])
                    return {
                        "response": response_text,
                        "session_id": session_id
                    }
                else:
                    error_text = await resp.text()
                    _LOGGER.error("Alfred agent error: %s - %s", resp.status, error_text)
                    raise ServiceValidationError(f"Alfred agent error: {resp.status}")

    # =========================================================================
    # Device Runtime Services
    # =========================================================================

    async def handle_get_device_runtime(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_device_runtime service call."""
        entity_id = call.data.get("entity_id")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        intelligence_engine = self._get_component("intelligence_engine")

        if not intelligence_engine._runtime_tracker:
            raise ServiceValidationError("Runtime tracker not initialized")

        stats = await intelligence_engine._runtime_tracker.get_runtime_stats(entity_id)

        if not stats:
            return {
                "entity_id": entity_id,
                "error": "No runtime data available for this entity"
            }

        return stats

    async def handle_reset_device_runtime(self, call: ServiceCall) -> dict[str, Any]:
        """Handle reset_device_runtime service call."""
        entity_id = call.data.get("entity_id")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        intelligence_engine = self._get_component("intelligence_engine")

        if not intelligence_engine._runtime_tracker:
            raise ServiceValidationError("Runtime tracker not initialized")

        await intelligence_engine._pattern_storage.update_runtime_tracking(
            entity_id=entity_id,
            total_runtime_hours=0.0,
            cycle_count=0,
        )

        _LOGGER.info("Runtime reset for %s", entity_id)

        return {
            "entity_id": entity_id,
            "message": "Runtime counters reset successfully"
        }

    # =========================================================================
    # Power Quality Services
    # =========================================================================

    async def handle_get_power_quality(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_power_quality service call."""
        entity_id = call.data.get("entity_id")
        seconds = call.data.get("seconds", 60)

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        intelligence_engine = self._get_component("intelligence_engine")

        if not intelligence_engine._metrics_collector:
            raise ServiceValidationError("Metrics collector not initialized")

        recent_data = await intelligence_engine._metrics_collector.get_recent_power_data(
            entity_id, seconds
        )

        if not recent_data:
            return {
                "entity_id": entity_id,
                "error": "No power quality data available for this entity"
            }

        aggregated = await intelligence_engine._metrics_collector.aggregate_power_data(
            recent_data, interval="1m"
        )

        aggregated["entity_id"] = entity_id
        aggregated["sample_period_seconds"] = seconds

        return aggregated

    # =========================================================================
    # Device Health Services
    # =========================================================================

    async def handle_get_device_health(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_device_health service call."""
        entity_id = call.data.get("entity_id")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        intelligence_engine = self._get_component("intelligence_engine")
        degradation_detector = intelligence_engine._degradation_detector

        if not degradation_detector:
            raise ServiceValidationError("Degradation detector not initialized")

        report = await degradation_detector.analyze_device_performance(entity_id)

        if not report:
            alerts = await intelligence_engine._pattern_storage.get_active_alerts(entity_id)

            if alerts:
                return {
                    "entity_id": entity_id,
                    "status": "degraded",
                    "active_alerts": len(alerts),
                    "alerts": alerts,
                }
            else:
                return {
                    "entity_id": entity_id,
                    "status": "healthy",
                    "message": "No degradation detected",
                }

        return {
            "entity_id": entity_id,
            "status": "degraded",
            "degradation_type": report.degradation_type,
            "severity": report.severity,
            "metric": report.metric_name,
            "current_value": report.current_value,
            "baseline_value": report.baseline_value,
            "deviation_percentage": report.deviation_percentage,
            "recommendation": report.recommendation,
            "trend_type": report.trend_type,
            "days_degraded": report.days_degraded,
        }

    async def handle_analyze_degradation(self, call: ServiceCall) -> dict[str, Any]:
        """Handle analyze_degradation service call to force immediate analysis."""
        entity_id = call.data.get("entity_id")

        intelligence_engine = self._get_component("intelligence_engine")
        degradation_detector = intelligence_engine._degradation_detector

        if not degradation_detector:
            raise ServiceValidationError("Degradation detector not initialized")

        _LOGGER.info("Running forced degradation analysis (requested by user)")

        if entity_id:
            report = await degradation_detector.analyze_device_performance(entity_id)

            if report:
                return {
                    "entity_id": entity_id,
                    "degradation_detected": True,
                    "severity": report.severity,
                    "degradation_type": report.degradation_type,
                }
            else:
                return {
                    "entity_id": entity_id,
                    "degradation_detected": False,
                    "message": "No degradation detected",
                }
        else:
            stats = await degradation_detector.analyze_all_devices()
            return stats

    async def handle_dismiss_degradation_alert(self, call: ServiceCall) -> dict[str, Any]:
        """Handle dismiss_degradation_alert service call."""
        alert_id = call.data.get("alert_id")

        if not alert_id:
            raise ServiceValidationError("alert_id is required")

        intelligence_engine = self._get_component("intelligence_engine")

        await intelligence_engine._pattern_storage.mark_alert_acknowledged(int(alert_id))

        _LOGGER.info("Alert %s dismissed by user", alert_id)

        return {
            "alert_id": alert_id,
            "status": "dismissed",
            "message": "Alert acknowledged",
        }

    async def handle_diagnose_device(self, call: ServiceCall) -> dict[str, Any]:
        """Handle diagnose_device service call with AI diagnosis."""
        import homeassistant.util.dt as dt_util
        from .degradation_detector import DegradationReport

        entity_id = call.data.get("entity_id")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        diagnosis_engine = self._get_component("diagnosis_engine")
        degradation_detector = self._get_component("degradation_detector")

        state = self.hass.states.get(entity_id)
        if not state:
            raise ServiceValidationError(f"Entity {entity_id} not found")

        observations = await degradation_detector.get_recent_observations(
            entity_id,
            days=5
        )

        if not observations:
            _LOGGER.info(
                "No recent degradation for %s, analyzing current state",
                entity_id
            )

            degradation_report = await degradation_detector.analyze_device_performance(
                entity_id
            )

            if not degradation_report:
                return {
                    "success": False,
                    "error": "Device appears healthy, no degradation detected",
                    "entity_id": entity_id,
                }
        else:
            latest = observations[0]

            degradation_report = DegradationReport(
                entity_id=entity_id,
                metric_name=latest["metric_name"],
                degradation_type=latest["degradation_type"],
                severity=latest["severity"],
                current_value=latest["current_value"],
                baseline_value=latest["baseline_value"],
                deviation_percentage=latest["deviation_percentage"],
                z_score=latest["z_score"],
                statistical_significance=True,
                trend_type=latest.get("trend_type"),
                degradation_rate=latest.get("degradation_rate"),
                days_degraded=len(observations),
                confidence=0.85,
                recommendation="Diagnosis requested by user",
                timestamp=dt_util.now(),
            )

        diagnosis = await diagnosis_engine.diagnose_device_failure(
            entity_id,
            degradation_report,
        )

        _LOGGER.info("Diagnosis complete for %s: %s", entity_id, diagnosis.primary_cause)

        return {
            "success": True,
            "entity_id": entity_id,
            "diagnosis": diagnosis.to_dict(),
            "degradation_detected": True,
        }

    # =========================================================================
    # Battery Services
    # =========================================================================

    async def handle_get_battery_status(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_battery_status service call."""
        entity_id = call.data.get("entity_id")

        intelligence_engine = self._get_component("intelligence_engine")
        battery_manager = intelligence_engine._battery_manager

        if not battery_manager:
            raise ServiceValidationError("Battery manager not initialized")

        if entity_id:
            status = await battery_manager.monitor_battery(entity_id)

            if not status:
                return {
                    "success": False,
                    "error": f"No battery data available for {entity_id}"
                }

            tracking = await intelligence_engine._pattern_storage.get_battery_tracking(entity_id)

            return {
                "success": True,
                "entity_id": entity_id,
                "name": status.name,
                "current_level": status.current_level,
                "battery_type": status.battery_type,
                "drain_rate_per_day": tracking.get("drain_rate_per_day") if tracking else None,
                "predicted_replacement_date": (
                    tracking.get("predicted_replacement_date").isoformat()
                    if tracking and tracking.get("predicted_replacement_date")
                    else None
                ),
                "days_remaining": tracking.get("days_remaining") if tracking else None,
                "prediction_confidence": tracking.get("prediction_confidence") if tracking else None,
                "abnormal_drain": tracking.get("abnormal_drain_detected") if tracking else False,
            }
        else:
            batteries = await battery_manager.monitor_all_batteries()

            result = {
                "success": True,
                "battery_count": len(batteries),
                "batteries": []
            }

            for eid, status in batteries.items():
                tracking = await intelligence_engine._pattern_storage.get_battery_tracking(eid)

                battery_data = {
                    "entity_id": eid,
                    "name": status.name,
                    "current_level": status.current_level,
                    "battery_type": status.battery_type,
                    "drain_rate_per_day": tracking.get("drain_rate_per_day") if tracking else None,
                    "predicted_replacement_date": (
                        tracking.get("predicted_replacement_date").isoformat()
                        if tracking and tracking.get("predicted_replacement_date")
                        else None
                    ),
                    "days_remaining": tracking.get("days_remaining") if tracking else None,
                    "abnormal_drain": tracking.get("abnormal_drain_detected") if tracking else False,
                }

                result["batteries"].append(battery_data)

            result["batteries"].sort(key=lambda x: x["current_level"] or 100)

            return result

    async def handle_get_battery_shopping_list(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_battery_shopping_list service call."""
        days_threshold = call.data.get("days_threshold", 60)

        intelligence_engine = self._get_component("intelligence_engine")
        battery_manager = intelligence_engine._battery_manager

        if not battery_manager:
            raise ServiceValidationError("Battery manager not initialized")

        shopping_list = await battery_manager.generate_shopping_list(days_threshold)

        return {
            "success": True,
            "days_threshold": days_threshold,
            "shopping_list": shopping_list,
        }

    async def handle_record_battery_replacement(self, call: ServiceCall) -> dict[str, Any]:
        """Handle record_battery_replacement service call."""
        entity_id = call.data.get("entity_id")
        replacement_date = call.data.get("replacement_date")
        battery_type = call.data.get("battery_type")
        cost = call.data.get("cost")
        notes = call.data.get("notes")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        intelligence_engine = self._get_component("intelligence_engine")
        battery_manager = intelligence_engine._battery_manager

        if not battery_manager:
            raise ServiceValidationError("Battery manager not initialized")

        result = await battery_manager.record_replacement(
            entity_id=entity_id,
            replacement_date=replacement_date,
            battery_type=battery_type,
            cost=cost,
            notes=notes,
        )

        return result

    async def handle_set_battery_type(self, call: ServiceCall) -> dict[str, Any]:
        """Handle set_battery_type service call."""
        entity_id = call.data.get("entity_id")
        battery_type = call.data.get("battery_type")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")
        if not battery_type:
            raise ServiceValidationError("battery_type is required")

        intelligence_engine = self._get_component("intelligence_engine")
        battery_manager = intelligence_engine._battery_manager

        if not battery_manager:
            raise ServiceValidationError("Battery manager not initialized")

        await battery_manager.set_battery_type(entity_id, battery_type)

        return {
            "success": True,
            "entity_id": entity_id,
            "battery_type": battery_type,
        }

    # =========================================================================
    # Energy Services
    # =========================================================================

    async def handle_get_energy_consumption(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_energy_consumption service call."""
        entity_id = call.data.get("entity_id")
        period = call.data.get("period", "day")

        intelligence_engine = self._get_component("intelligence_engine")
        energy_analyzer = intelligence_engine._energy_analyzer

        if not energy_analyzer:
            raise ServiceValidationError("Energy analyzer not initialized")

        if entity_id:
            consumption = await energy_analyzer.get_device_consumption(entity_id, period)
            return consumption
        else:
            consumption = await energy_analyzer.get_total_consumption(period)
            return consumption

    async def handle_get_energy_patterns(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_energy_patterns service call."""
        entity_id = call.data.get("entity_id")
        days = call.data.get("days", 7)

        intelligence_engine = self._get_component("intelligence_engine")
        energy_analyzer = intelligence_engine._energy_analyzer

        if not energy_analyzer:
            raise ServiceValidationError("Energy analyzer not initialized")

        patterns = await energy_analyzer.analyze_patterns(entity_id, days)
        return patterns

    async def handle_get_energy_insights(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_energy_insights service call."""
        intelligence_engine = self._get_component("intelligence_engine")
        energy_analyzer = intelligence_engine._energy_analyzer

        if not energy_analyzer:
            raise ServiceValidationError("Energy analyzer not initialized")

        insights = await energy_analyzer.generate_insights()
        return insights

    async def handle_analyze_energy_device(self, call: ServiceCall) -> dict[str, Any]:
        """Handle analyze_energy_device service call."""
        entity_id = call.data.get("entity_id")

        if not entity_id:
            raise ServiceValidationError("entity_id is required")

        intelligence_engine = self._get_component("intelligence_engine")
        energy_analyzer = intelligence_engine._energy_analyzer

        if not energy_analyzer:
            raise ServiceValidationError("Energy analyzer not initialized")

        analysis = await energy_analyzer.analyze_device(entity_id)
        return analysis

    # =========================================================================
    # Emergency Services
    # =========================================================================

    async def handle_predict_pipe_freeze(self, call: ServiceCall) -> dict[str, Any]:
        """Handle predict_pipe_freeze service call."""
        intelligence_engine = self._get_component("intelligence_engine")
        freeze_predictor = intelligence_engine._freeze_predictor

        if not freeze_predictor:
            raise ServiceValidationError("Pipe freeze predictor not initialized")

        prediction = await freeze_predictor.predict()
        return prediction

    async def handle_trigger_emergency(self, call: ServiceCall) -> dict[str, Any]:
        """Handle trigger_emergency service call."""
        emergency_type = call.data.get("emergency_type", "manual")
        severity = call.data.get("severity", "high")
        description = call.data.get("description", "Manual emergency triggered")

        emergency_coordinator = self._get_component("emergency_coordinator")

        result = await emergency_coordinator.trigger_emergency(
            emergency_type=emergency_type,
            severity=severity,
            description=description,
        )

        return result

    async def handle_resolve_emergency(self, call: ServiceCall) -> dict[str, Any]:
        """Handle resolve_emergency service call."""
        notes = call.data.get("notes", "")

        emergency_coordinator = self._get_component("emergency_coordinator")

        result = await emergency_coordinator.resolve_emergency(notes=notes)

        return result

    async def handle_get_emergency_status(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_emergency_status service call."""
        emergency_coordinator = self._get_component("emergency_coordinator")

        return {
            "is_emergency": emergency_coordinator._is_emergency,
            "active_emergency": emergency_coordinator._active_emergency,
            "start_time": (
                emergency_coordinator._emergency_start_time.isoformat()
                if emergency_coordinator._emergency_start_time
                else None
            ),
            "actions_executed": len(emergency_coordinator._actions_executed),
        }

    async def handle_get_emergency_log(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_emergency_log service call."""
        limit = call.data.get("limit", 100)

        emergency_coordinator = self._get_component("emergency_coordinator")

        return {
            "log": emergency_coordinator._emergency_log[-limit:],
            "total_entries": len(emergency_coordinator._emergency_log),
        }

    # =========================================================================
    # Security Report Services
    # =========================================================================

    async def handle_generate_security_report(self, call: ServiceCall) -> dict[str, Any]:
        """Handle generate_security_report service call."""
        start_date = call.data.get("start_date")
        end_date = call.data.get("end_date")

        security_report_generator = self._get_component("security_report_generator")

        result = await security_report_generator.generate_weekly_report(
            start_date=start_date,
            end_date=end_date,
        )

        return result

    # =========================================================================
    # Smart Lock Services
    # =========================================================================

    async def handle_add_guest_code(self, call: ServiceCall) -> dict[str, Any]:
        """Handle add_guest_code service call."""
        smart_lock_intelligence = self._get_component("smart_lock_intelligence")

        result = await smart_lock_intelligence.add_guest_code(
            lock_entity_id=call.data.get("lock_entity_id"),
            code_slot=call.data.get("code_slot"),
            code_name=call.data.get("code_name"),
            user_code=call.data.get("user_code"),
            start_date=call.data.get("start_date"),
            end_date=call.data.get("end_date"),
            is_one_time=call.data.get("is_one_time", False),
            notes=call.data.get("notes"),
        )

        return result

    async def handle_get_access_history(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_access_history service call."""
        smart_lock_intelligence = self._get_component("smart_lock_intelligence")

        result = await smart_lock_intelligence.get_access_history(
            lock_entity_id=call.data.get("lock_entity_id"),
            user_code=call.data.get("user_code"),
            days=call.data.get("days", 30),
            include_anomalies_only=call.data.get("include_anomalies_only", False),
        )

        return result

    async def handle_get_guest_codes(self, call: ServiceCall) -> dict[str, Any]:
        """Handle get_guest_codes service call."""
        smart_lock_intelligence = self._get_component("smart_lock_intelligence")

        result = await smart_lock_intelligence.get_guest_codes(
            lock_entity_id=call.data.get("lock_entity_id"),
            include_expired=call.data.get("include_expired", False),
        )

        return result

    async def handle_generate_weekly_access_summary(self, call: ServiceCall) -> dict[str, Any]:
        """Handle generate_weekly_access_summary service call."""
        smart_lock_intelligence = self._get_component("smart_lock_intelligence")

        result = await smart_lock_intelligence.generate_weekly_summary(
            lock_entity_id=call.data.get("lock_entity_id"),
        )

        return result

    # =========================================================================
    # Registration
    # =========================================================================

    async def async_register_all(self) -> None:
        """Register all services with Home Assistant."""
        # Define service registrations: (service_name, handler, needs_security)
        services = [
            # Communication - with security
            (SERVICE_SEND_MESSAGE, self.handle_send_message, True),
            (SERVICE_START_CONVERSATION, self.handle_start_conversation, True),
            (SERVICE_CHAT_WITH_MEMORY, self.handle_chat_with_memory, False),  # Has its own error handling
            
            # Device Runtime - no security (info only)
            (SERVICE_GET_DEVICE_RUNTIME, self.handle_get_device_runtime, False),
            (SERVICE_RESET_DEVICE_RUNTIME, self.handle_reset_device_runtime, False),
            
            # Power Quality - no security (info only)
            (SERVICE_GET_POWER_QUALITY, self.handle_get_power_quality, False),
            
            # Device Health - no security (info only)
            (SERVICE_GET_DEVICE_HEALTH, self.handle_get_device_health, False),
            (SERVICE_ANALYZE_DEGRADATION, self.handle_analyze_degradation, False),
            (SERVICE_DISMISS_DEGRADATION_ALERT, self.handle_dismiss_degradation_alert, False),
            (SERVICE_DIAGNOSE_DEVICE, self.handle_diagnose_device, False),
            
            # Battery - no security (info only)
            (SERVICE_GET_BATTERY_STATUS, self.handle_get_battery_status, False),
            (SERVICE_GET_BATTERY_SHOPPING_LIST, self.handle_get_battery_shopping_list, False),
            (SERVICE_RECORD_BATTERY_REPLACEMENT, self.handle_record_battery_replacement, False),
            (SERVICE_SET_BATTERY_TYPE, self.handle_set_battery_type, False),
            
            # Energy - no security (info only)
            (SERVICE_GET_ENERGY_CONSUMPTION, self.handle_get_energy_consumption, False),
            (SERVICE_GET_ENERGY_PATTERNS, self.handle_get_energy_patterns, False),
            (SERVICE_GET_ENERGY_INSIGHTS, self.handle_get_energy_insights, False),
            (SERVICE_ANALYZE_ENERGY_DEVICE, self.handle_analyze_energy_device, False),
            
            # Emergency - with security
            (SERVICE_PREDICT_PIPE_FREEZE, self.handle_predict_pipe_freeze, False),
            (SERVICE_TRIGGER_EMERGENCY, self.handle_trigger_emergency, True),
            (SERVICE_RESOLVE_EMERGENCY, self.handle_resolve_emergency, True),
            (SERVICE_GET_EMERGENCY_STATUS, self.handle_get_emergency_status, True),
            (SERVICE_GET_EMERGENCY_LOG, self.handle_get_emergency_log, True),
            
            # Security Report - with security
            (SERVICE_GENERATE_SECURITY_REPORT, self.handle_generate_security_report, True),
            
            # Smart Lock - with security
            (SERVICE_ADD_GUEST_CODE, self.handle_add_guest_code, True),
            (SERVICE_GET_ACCESS_HISTORY, self.handle_get_access_history, True),
            (SERVICE_GET_GUEST_CODES, self.handle_get_guest_codes, True),
            (SERVICE_GENERATE_WEEKLY_ACCESS_SUMMARY, self.handle_generate_weekly_access_summary, True),
        ]

        for service_name, handler, needs_security in services:
            if needs_security:
                # Wrap with security decorator
                secured_handler = self.secured_handler(service_name)(handler)
                self.hass.services.async_register(
                    DOMAIN,
                    service_name,
                    secured_handler,
                    supports_response=True
                )
            else:
                # Register directly
                self.hass.services.async_register(
                    DOMAIN,
                    service_name,
                    handler,
                    supports_response=True
                )

        _LOGGER.info("Registered %d Alfred services", len(services))
