"""Smart Lock Intelligence & Access Tracking for Alfred.

Epic 5: Security & Environmental Safety
Story 5.3: Smart Lock Intelligence & Access Tracking

Provides detailed intelligence about lock usage, access patterns, guest code management,
and weekly access summaries.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any
from enum import Enum
import json

from homeassistant.core import HomeAssistant, Event, callback
from homeassistant.const import EVENT_STATE_CHANGED
from homeassistant.util import dt as dt_util
from homeassistant.components.lock import DOMAIN as LOCK_DOMAIN

from .pattern_storage import PatternStorage

_LOGGER = logging.getLogger(__name__)


class AccessMethod(Enum):
    """Methods of lock access."""

    USER_CODE = "user_code"
    FINGERPRINT = "fingerprint"
    KEY = "key"
    MANUAL = "manual"
    AUTO = "auto"
    UNKNOWN = "unknown"


class AccessType(Enum):
    """Types of access events."""

    LOCK = "lock"
    UNLOCK = "unlock"


class GuestCodeStatus(Enum):
    """Guest code status."""

    ACTIVE = "active"
    EXPIRED = "expired"
    DISABLED = "disabled"
    ONE_TIME_USED = "one_time_used"


class SmartLockIntelligence:
    """Smart lock intelligence and access tracking.

    Features:
    - Access tracking by user code, fingerprint, or key
    - Access history with who, when, where, duration
    - Guest code management with expiration tracking
    - Usage alerts (expired codes, unusual frequency)
    - Weekly access summary reports
    - Anomaly detection (shared codes, impossible times)
    """

    def __init__(
        self,
        hass: HomeAssistant,
        pattern_storage: PatternStorage,
    ) -> None:
        """Initialize smart lock intelligence.

        Args:
            hass: Home Assistant instance
            pattern_storage: Pattern storage instance
        """
        self.hass = hass
        self._storage = pattern_storage
        self._unsub = None
        self._lock_entities = []
        self._guest_codes = {}
        self._access_history = []
        self._user_profiles = {}

        # Configuration
        self._config = {
            "enabled": True,
            "track_duration": True,  # Track how long door stays unlocked
            "anomaly_detection": True,
            "guest_code_alerts": True,
            "weekly_reports": True,
        }

    async def async_setup(self) -> None:
        """Set up smart lock intelligence."""
        _LOGGER.info("Setting up smart lock intelligence")

        # Discover lock entities
        await self._discover_locks()

        # Set up lock state listeners
        if self._config["enabled"]:
            self._setup_lock_listeners()

        # Load stored guest codes
        await self._load_guest_codes()

        # Load user profiles
        await self._load_user_profiles()

        _LOGGER.info(
            "Smart lock intelligence initialized (%d locks found)",
            len(self._lock_entities),
        )

    async def async_close(self) -> None:
        """Close smart lock intelligence."""
        if self._unsub:
            self._unsub()
        _LOGGER.info("Smart lock intelligence closed")

    async def _discover_locks(self) -> None:
        """Discover smart lock entities."""
        self._lock_entities = self.hass.states.async_entity_ids(LOCK_DOMAIN)
        _LOGGER.info("Discovered %d lock entities", len(self._lock_entities))

    def _setup_lock_listeners(self) -> None:
        """Set up lock state change listeners."""
        self._unsub = self.hass.bus.async_listen(
            EVENT_STATE_CHANGED,
            self._handle_lock_state_change,
        )

    @callback
    def _handle_lock_state_change(self, event: Event) -> None:
        """Handle lock state change events.

        Args:
            event: State change event
        """
        entity_id = event.data.get("entity_id")
        new_state = event.data.get("new_state")
        old_state = event.data.get("old_state")

        # Only process lock entities
        if not entity_id or entity_id not in self._lock_entities:
            return

        if not new_state or not old_state:
            return

        # Track state change
        self.hass.async_create_task(
            self._process_lock_event(entity_id, old_state, new_state)
        )

    async def _process_lock_event(
        self,
        entity_id: str,
        old_state: Any,
        new_state: Any,
    ) -> None:
        """Process lock state change event.

        Args:
            entity_id: Lock entity ID
            old_state: Previous state
            new_state: New state
        """
        try:
            # Determine access type
            access_type = None
            if new_state.state == "unlocked" and old_state.state == "locked":
                access_type = AccessType.UNLOCK
            elif new_state.state == "locked" and old_state.state == "unlocked":
                access_type = AccessType.LOCK

            if not access_type:
                return

            # Extract access details from attributes
            user_code = new_state.attributes.get("lock_status")
            user_id = new_state.attributes.get("user_id")
            code_slot = new_state.attributes.get("code_slot")

            # Determine access method
            access_method = self._determine_access_method(new_state.attributes)

            # Create access record
            access_record = {
                "timestamp": dt_util.now().isoformat(),
                "entity_id": entity_id,
                "friendly_name": new_state.attributes.get("friendly_name", entity_id),
                "access_type": access_type.value,
                "access_method": access_method.value,
                "user_code": user_code,
                "user_id": user_id,
                "code_slot": code_slot,
                "context": self._build_access_context(entity_id),
            }

            # Store access record
            await self._store_access_record(access_record)

            # Check for anomalies
            if self._config["anomaly_detection"]:
                await self._check_access_anomalies(access_record)

            # Check guest code status
            if self._config["guest_code_alerts"] and code_slot:
                await self._check_guest_code_status(code_slot, access_record)

            # Track duration if unlock
            if access_type == AccessType.UNLOCK and self._config["track_duration"]:
                self.hass.async_create_task(
                    self._track_access_duration(entity_id, access_record)
                )

        except Exception as err:
            _LOGGER.error("Error processing lock event: %s", err, exc_info=True)

    def _determine_access_method(self, attributes: dict[str, Any]) -> AccessMethod:
        """Determine method used to access lock.

        Args:
            attributes: State attributes

        Returns:
            Access method
        """
        # Check for user code
        if attributes.get("code_slot") or attributes.get("user_id"):
            return AccessMethod.USER_CODE

        # Check for fingerprint
        if "fingerprint" in str(attributes.get("lock_status", "")).lower():
            return AccessMethod.FINGERPRINT

        # Check for key/manual
        if attributes.get("lock_status") == "manual":
            return AccessMethod.KEY

        # Check for auto-lock/unlock
        if attributes.get("lock_status") == "auto":
            return AccessMethod.AUTO

        return AccessMethod.UNKNOWN

    def _build_access_context(self, entity_id: str) -> dict[str, Any]:
        """Build context for access event.

        Args:
            entity_id: Lock entity ID

        Returns:
            Context information
        """
        context = {}

        # Check if people are home
        person_count = sum(
            1
            for person in self.hass.states.async_entity_ids("person")
            if self.hass.states.get(person).state == "home"
        )
        context["people_home"] = person_count

        # Get time of day
        now = dt_util.now()
        hour = now.hour
        if 6 <= hour < 12:
            context["time_of_day"] = "morning"
        elif 12 <= hour < 17:
            context["time_of_day"] = "afternoon"
        elif 17 <= hour < 22:
            context["time_of_day"] = "evening"
        else:
            context["time_of_day"] = "night"

        context["day_of_week"] = now.strftime("%A")

        return context

    async def _store_access_record(self, record: dict[str, Any]) -> None:
        """Store access record to database.

        Args:
            record: Access record
        """
        try:
            await self._storage._db.execute(
                """
                INSERT INTO lock_access_history
                (timestamp, entity_id, friendly_name, access_type, access_method,
                 user_code, user_id, code_slot, context)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record["timestamp"],
                    record["entity_id"],
                    record["friendly_name"],
                    record["access_type"],
                    record["access_method"],
                    record.get("user_code"),
                    record.get("user_id"),
                    record.get("code_slot"),
                    json.dumps(record["context"]),
                ),
            )
            await self._storage._db.commit()

            _LOGGER.debug(
                "Stored access record: %s %s via %s",
                record["friendly_name"],
                record["access_type"],
                record["access_method"],
            )

        except Exception as err:
            _LOGGER.error("Failed to store access record: %s", err, exc_info=True)

    async def _track_access_duration(
        self,
        entity_id: str,
        unlock_record: dict[str, Any],
    ) -> None:
        """Track how long lock stays unlocked.

        Args:
            entity_id: Lock entity ID
            unlock_record: Unlock event record
        """
        try:
            # Wait for lock to be locked again
            start_time = dt_util.now()

            # Monitor lock state
            while True:
                await self.hass.async_add_executor_job(lambda: None)
                await self.hass.helpers.event.async_wait_for_event(
                    EVENT_STATE_CHANGED,
                    lambda event: (
                        event.data.get("entity_id") == entity_id
                        and event.data.get("new_state").state == "locked"
                    ),
                    timeout=3600,  # 1 hour max
                )

                # Calculate duration
                end_time = dt_util.now()
                duration_seconds = (end_time - start_time).total_seconds()

                # Update record with duration
                await self._storage._db.execute(
                    """
                    UPDATE lock_access_history
                    SET duration_seconds = ?
                    WHERE timestamp = ? AND entity_id = ?
                    """,
                    (
                        duration_seconds,
                        unlock_record["timestamp"],
                        entity_id,
                    ),
                )
                await self._storage._db.commit()

                _LOGGER.debug(
                    "Lock %s was unlocked for %.1f seconds",
                    entity_id,
                    duration_seconds,
                )
                break

        except Exception as err:
            _LOGGER.error("Error tracking access duration: %s", err, exc_info=True)

    async def _check_access_anomalies(self, access_record: dict[str, Any]) -> None:
        """Check for access anomalies.

        Args:
            access_record: Access record to check
        """
        try:
            anomalies = []

            # Check for impossible timing (same code used twice within minutes)
            if access_record.get("code_slot"):
                recent_uses = await self._get_recent_code_uses(
                    access_record["code_slot"],
                    minutes=5,
                )
                if len(recent_uses) > 1:
                    anomalies.append({
                        "type": "impossible_timing",
                        "severity": "high",
                        "message": (
                            f"Code {access_record['code_slot']} used multiple times "
                            "within 5 minutes - possible code sharing"
                        ),
                    })

            # Check for unusual time of day
            hour = dt_util.now().hour
            if hour >= 2 and hour < 5:  # 2 AM - 5 AM
                anomalies.append({
                    "type": "unusual_time",
                    "severity": "medium",
                    "message": f"Access at unusual hour: {hour}:00",
                })

            # Check for person tracking mismatch
            if access_record["access_type"] == "unlock":
                people_home = access_record["context"].get("people_home", 0)
                if people_home == 0:
                    anomalies.append({
                        "type": "no_person_detected",
                        "severity": "medium",
                        "message": "Lock unlocked but no person detected as home",
                    })

            # Fire events for anomalies
            for anomaly in anomalies:
                self.hass.bus.fire(
                    "alfred_lock_anomaly_detected",
                    {
                        **anomaly,
                        "entity_id": access_record["entity_id"],
                        "timestamp": access_record["timestamp"],
                    },
                )

                _LOGGER.warning(
                    "Lock anomaly detected: %s - %s",
                    anomaly["type"],
                    anomaly["message"],
                )

        except Exception as err:
            _LOGGER.error("Error checking anomalies: %s", err, exc_info=True)

    async def _get_recent_code_uses(
        self,
        code_slot: int,
        minutes: int = 5,
    ) -> list[dict[str, Any]]:
        """Get recent uses of a code.

        Args:
            code_slot: Code slot number
            minutes: Minutes to look back

        Returns:
            List of recent uses
        """
        try:
            cutoff_time = dt_util.now() - timedelta(minutes=minutes)
            cursor = await self._storage._db.execute(
                """
                SELECT * FROM lock_access_history
                WHERE code_slot = ?
                AND timestamp >= ?
                ORDER BY timestamp DESC
                """,
                (code_slot, cutoff_time.isoformat()),
            )
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

        except Exception:
            return []

    async def _check_guest_code_status(
        self,
        code_slot: int,
        access_record: dict[str, Any],
    ) -> None:
        """Check guest code status and send alerts.

        Args:
            code_slot: Code slot number
            access_record: Access record
        """
        try:
            guest_code = self._guest_codes.get(code_slot)
            if not guest_code:
                return

            # Check expiration
            if guest_code["status"] == GuestCodeStatus.EXPIRED.value:
                self.hass.bus.fire(
                    "alfred_expired_code_used",
                    {
                        "code_slot": code_slot,
                        "guest_name": guest_code.get("name", "Unknown"),
                        "expired_date": guest_code.get("expiration_date"),
                        "entity_id": access_record["entity_id"],
                    },
                )

                _LOGGER.warning(
                    "Expired guest code %d used by %s",
                    code_slot,
                    guest_code.get("name", "Unknown"),
                )

            # Update usage count
            guest_code["usage_count"] = guest_code.get("usage_count", 0) + 1
            guest_code["last_used"] = dt_util.now().isoformat()

            # Check for one-time code
            if guest_code.get("one_time") and guest_code["usage_count"] > 1:
                self.hass.bus.fire(
                    "alfred_one_time_code_reused",
                    {
                        "code_slot": code_slot,
                        "guest_name": guest_code.get("name", "Unknown"),
                        "usage_count": guest_code["usage_count"],
                    },
                )

            # Store updated guest code
            await self._store_guest_code(code_slot, guest_code)

        except Exception as err:
            _LOGGER.error("Error checking guest code status: %s", err, exc_info=True)

    async def add_guest_code(
        self,
        code_slot: int,
        name: str,
        expiration_date: datetime | None = None,
        one_time: bool = False,
        notes: str = "",
    ) -> dict[str, Any]:
        """Add or update guest code.

        Args:
            code_slot: Code slot number
            name: Guest name
            expiration_date: When code expires
            one_time: If code is one-time use
            notes: Additional notes

        Returns:
            Guest code data
        """
        try:
            guest_code = {
                "code_slot": code_slot,
                "name": name,
                "expiration_date": expiration_date.isoformat() if expiration_date else None,
                "one_time": one_time,
                "notes": notes,
                "status": GuestCodeStatus.ACTIVE.value,
                "usage_count": 0,
                "created_at": dt_util.now().isoformat(),
                "last_used": None,
            }

            self._guest_codes[code_slot] = guest_code
            await self._store_guest_code(code_slot, guest_code)

            _LOGGER.info("Added guest code for %s (slot %d)", name, code_slot)

            return {
                "success": True,
                "guest_code": guest_code,
            }

        except Exception as err:
            _LOGGER.error("Error adding guest code: %s", err, exc_info=True)
            return {
                "success": False,
                "error": str(err),
            }

    async def _store_guest_code(
        self,
        code_slot: int,
        guest_code: dict[str, Any],
    ) -> None:
        """Store guest code to database.

        Args:
            code_slot: Code slot number
            guest_code: Guest code data
        """
        try:
            await self._storage._db.execute(
                """
                INSERT OR REPLACE INTO guest_codes
                (code_slot, name, expiration_date, one_time, notes, status,
                 usage_count, created_at, last_used)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    code_slot,
                    guest_code["name"],
                    guest_code.get("expiration_date"),
                    guest_code["one_time"],
                    guest_code.get("notes", ""),
                    guest_code["status"],
                    guest_code["usage_count"],
                    guest_code["created_at"],
                    guest_code.get("last_used"),
                ),
            )
            await self._storage._db.commit()

        except Exception as err:
            _LOGGER.error("Failed to store guest code: %s", err, exc_info=True)

    async def _load_guest_codes(self) -> None:
        """Load guest codes from database."""
        try:
            cursor = await self._storage._db.execute(
                "SELECT * FROM guest_codes"
            )
            rows = await cursor.fetchall()

            for row in rows:
                code_slot = row["code_slot"]
                self._guest_codes[code_slot] = dict(row)

                # Check and update expiration status
                if row["expiration_date"]:
                    expiration = datetime.fromisoformat(row["expiration_date"])
                    if expiration < dt_util.now():
                        self._guest_codes[code_slot]["status"] = GuestCodeStatus.EXPIRED.value

            _LOGGER.info("Loaded %d guest codes", len(self._guest_codes))

        except Exception as err:
            _LOGGER.debug("Could not load guest codes: %s", err)

    async def _load_user_profiles(self) -> None:
        """Load user profiles from database."""
        # Placeholder for user profile loading
        pass

    async def get_access_history(
        self,
        entity_id: str | None = None,
        hours: int = 24,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Get access history.

        Args:
            entity_id: Filter by lock entity (None = all)
            hours: Hours to look back
            limit: Maximum records to return

        Returns:
            List of access records
        """
        try:
            cutoff_time = dt_util.now() - timedelta(hours=hours)

            if entity_id:
                cursor = await self._storage._db.execute(
                    """
                    SELECT * FROM lock_access_history
                    WHERE entity_id = ?
                    AND timestamp >= ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (entity_id, cutoff_time.isoformat(), limit),
                )
            else:
                cursor = await self._storage._db.execute(
                    """
                    SELECT * FROM lock_access_history
                    WHERE timestamp >= ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (cutoff_time.isoformat(), limit),
                )

            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

        except Exception as err:
            _LOGGER.error("Error getting access history: %s", err, exc_info=True)
            return []

    async def generate_weekly_summary(self) -> dict[str, Any]:
        """Generate weekly access summary.

        Returns:
            Weekly summary data
        """
        try:
            start_date = dt_util.now() - timedelta(days=7)

            # Get all access records for the week
            cursor = await self._storage._db.execute(
                """
                SELECT * FROM lock_access_history
                WHERE timestamp >= ?
                ORDER BY timestamp
                """,
                (start_date.isoformat(),),
            )
            records = await cursor.fetchall()

            # Analyze access patterns
            summary = {
                "period": {
                    "start": start_date.isoformat(),
                    "end": dt_util.now().isoformat(),
                },
                "total_accesses": len(records),
                "by_door": {},
                "by_user": {},
                "by_time_of_day": {
                    "morning": 0,
                    "afternoon": 0,
                    "evening": 0,
                    "night": 0,
                },
                "by_day": {},
                "anomalies_detected": 0,
            }

            for record in records:
                # Count by door
                door = record["friendly_name"]
                summary["by_door"][door] = summary["by_door"].get(door, 0) + 1

                # Count by user
                user = record.get("user_id") or record.get("code_slot") or "Unknown"
                summary["by_user"][str(user)] = summary["by_user"].get(str(user), 0) + 1

                # Count by time of day
                context = json.loads(record["context"])
                time_of_day = context.get("time_of_day", "unknown")
                if time_of_day in summary["by_time_of_day"]:
                    summary["by_time_of_day"][time_of_day] += 1

                # Count by day
                day = context.get("day_of_week", "Unknown")
                summary["by_day"][day] = summary["by_day"].get(day, 0) + 1

            return summary

        except Exception as err:
            _LOGGER.error("Error generating weekly summary: %s", err, exc_info=True)
            return {
                "success": False,
                "error": str(err),
            }

    def get_guest_codes(self) -> dict[int, dict[str, Any]]:
        """Get all guest codes.

        Returns:
            Dictionary of guest codes by slot number
        """
        return self._guest_codes.copy()
