"""Views for Alfred Digital Butler."""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from aiohttp import web
from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant

_LOGGER = logging.getLogger(__name__)


class AlfredPanelView(HomeAssistantView):
    """View to serve Alfred panel JavaScript."""

    requires_auth = False  # Frontend modules must be publicly accessible
    url = "/api/alfred/panel.js"
    name = "api:alfred:panel.js"

    def __init__(self, hass: HomeAssistant):
        """Initialize the view."""
        self.hass = hass

    async def get(self, request):
        """Serve the panel JavaScript."""
        try:
            # Get the path to the frontend file
            integration_dir = Path(__file__).parent
            panel_file = integration_dir / "frontend" / "panel.js"

            if not panel_file.exists():
                _LOGGER.error("Alfred panel.js not found at %s", panel_file)
                return web.Response(
                    text="// Alfred panel.js not found",
                    content_type="application/javascript",
                    status=404,
                )

            # Read and return the file (async to avoid blocking event loop)
            content = await self.hass.async_add_executor_job(
                lambda: panel_file.read_text(encoding="utf-8")
            )

            # Security headers with cache control to prevent stale cache issues
            return web.Response(
                text=content,
                content_type="application/javascript",
                headers={
                    "Content-Security-Policy": "default-src 'self'; script-src 'self' https://unpkg.com; style-src 'self' 'unsafe-inline'",
                    "X-Content-Type-Options": "nosniff",
                    "X-Frame-Options": "DENY",
                    "Referrer-Policy": "no-referrer",
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    "Pragma": "no-cache",
                    "Expires": "0",
                },
            )

        except Exception as err:
            _LOGGER.error("Error serving Alfred panel: %s", err)
            return web.Response(
                text=f"// Error loading Alfred panel: {err}",
                content_type="application/javascript",
                status=500,
            )


class AlfredAnalyticsView(HomeAssistantView):
    """View to serve Alfred analytics data."""

    requires_auth = True
    url = "/api/alfred/analytics"
    name = "api:alfred:analytics"

    def __init__(self, hass: HomeAssistant):
        """Initialize the view."""
        self.hass = hass

    async def get(self, request):
        """Serve analytics data from intelligence engine."""
        from .const import DOMAIN

        try:
            # Get intelligence engine from hass.data
            entry_id = list(self.hass.data.get(DOMAIN, {}).keys())[0] if DOMAIN in self.hass.data else None

            if not entry_id:
                return web.json_response(
                    {"error": "Alfred integration not configured"},
                    status=503
                )

            intelligence_engine = self.hass.data[DOMAIN][entry_id]["intelligence_engine"]
            pattern_storage = intelligence_engine._pattern_storage

            # Gather analytics data
            analytics_data = {
                "patterns": await self._get_pattern_insights(intelligence_engine, pattern_storage),
                "device_health": await self._get_device_health(intelligence_engine, pattern_storage),
                "energy": await self._get_energy_insights(intelligence_engine, pattern_storage),
                "battery": await self._get_battery_status(intelligence_engine, pattern_storage),
                "security": await self._get_security_insights(self.hass.data[DOMAIN][entry_id]),
                "timestamp": datetime.now().isoformat(),
            }

            return web.json_response(analytics_data)

        except Exception as err:
            _LOGGER.error("Error serving analytics data: %s", err, exc_info=True)
            return web.json_response(
                {"error": f"Failed to load analytics: {str(err)}"},
                status=500
            )

    async def _get_pattern_insights(self, intelligence_engine, pattern_storage):
        """Get detected patterns."""
        try:
            # Get all patterns from database (sorted by confidence)
            patterns = await pattern_storage.get_all_patterns(min_confidence=0.7, limit=10)
            return {
                "total_patterns": len(patterns),
                "patterns": [
                    {
                        "entity_id": p["entity_id"],
                        "type": p["pattern_type"],
                        "confidence": round(p["confidence"] * 100, 1),
                        "last_seen": p["last_seen"],
                        "occurrences": p["occurrences"],
                    }
                    for p in patterns
                ]
            }
        except Exception as err:
            _LOGGER.error("Error getting pattern insights: %s", err)
            return {"total_patterns": 0, "patterns": []}

    async def _get_device_health(self, intelligence_engine, pattern_storage):
        """Get device health status."""
        try:
            # Get active degradation alerts
            alerts = await pattern_storage.get_active_alerts()

            # Get database stats to find monitored devices count
            stats = await pattern_storage.get_database_stats()

            return {
                "total_devices_monitored": stats.get("baselines", 0),
                "active_alerts": len(alerts),
                "alerts": [
                    {
                        "entity_id": a["entity_id"],
                        "severity": a["severity"],
                        "degradation_type": a["degradation_type"],
                        "detected_at": a["detected_at"],
                    }
                    for a in alerts[:5]  # Top 5
                ]
            }
        except Exception as err:
            _LOGGER.error("Error getting device health: %s", err)
            return {"total_devices_monitored": 0, "active_alerts": 0, "alerts": []}

    async def _get_energy_insights(self, intelligence_engine, pattern_storage):
        """Get energy consumption insights."""
        try:
            if not intelligence_engine._energy_analyzer:
                return {"available": False}

            # Query energy_insights table directly
            cursor = await pattern_storage._db.execute(
                """
                SELECT entity_id, insight_type, insight_data, severity, created_at
                FROM energy_insights
                WHERE acknowledged = 0
                ORDER BY created_at DESC
                LIMIT 5
                """
            )
            rows = await cursor.fetchall()
            await cursor.close()

            insights = [
                {
                    "entity_id": row[0],
                    "type": row[1],
                    "severity": row[3],
                    "created_at": row[4],
                }
                for row in rows
            ]

            return {
                "available": True,
                "total_insights": len(insights),
                "insights": insights
            }
        except Exception as err:
            _LOGGER.error("Error getting energy insights: %s", err)
            return {"available": False, "total_insights": 0, "insights": []}

    async def _get_battery_status(self, intelligence_engine, pattern_storage):
        """Get battery status summary."""
        try:
            if not intelligence_engine._battery_manager:
                return {"available": False}

            # Get all batteries
            batteries = await intelligence_engine._battery_manager.monitor_all_batteries()

            low_batteries = [
                {"entity_id": eid, "level": status.current_level, "name": status.name}
                for eid, status in batteries.items()
                if status.current_level < 20
            ]

            return {
                "available": True,
                "total_batteries": len(batteries),
                "low_batteries": len(low_batteries),
                "low_battery_list": low_batteries[:5]
            }
        except Exception as err:
            _LOGGER.error("Error getting battery status: %s", err)
            return {"available": False}

    async def _get_security_insights(self, alfred_data):
        """Get security insights."""
        try:
            smart_lock_intelligence = alfred_data.get("smart_lock_intelligence")
            if not smart_lock_intelligence:
                return {"available": False}

            # Get recent anomalies
            # (Would need to implement get_recent_anomalies method)
            return {
                "available": True,
                "anomalies_detected": 0,
                "recent_anomalies": []
            }
        except Exception as err:
            _LOGGER.error("Error getting security insights: %s", err)
            return {"available": False}


async def async_register_views(hass: HomeAssistant) -> None:
    """Register Alfred views."""
    hass.http.register_view(AlfredPanelView(hass))
    hass.http.register_view(AlfredAnalyticsView(hass))
    _LOGGER.info("Alfred views registered")
