
import React, { useState } from 'react';
import { AgentCard } from './components/AgentCard';
import { AgentConfig } from './types';
import { Wrench, Settings, ShieldAlert, Clock, Phone, MapPin, CheckCircle2, ArrowRight } from 'lucide-react';
import { Tool } from '@google/genai';

// --- Configuration Constants ---

// Define the transfer tool
const transferTool: Tool = {
  functionDeclarations: [{
    name: 'transfer_to_dispatch',
    description: 'Transfers the call to the emergency dispatch department. Use this immediately when the user mentions a roadside emergency, flat tire, smoke, accident, or safety issue.',
  }]
};

const FRONT_DESK_AGENT: AgentConfig = {
  id: 'front_desk',
  name: 'Sarah',
  role: 'Front Desk',
  description: 'Handles appointments, status checks, and shop hours with a friendly demeanor.',
  voiceName: 'Kore', // Friendly, professional
  themeColor: 'blue',
  tools: [transferTool],
  systemInstruction: `
    You are Sarah, the professional and friendly front desk receptionist for "MechanicShop", a high-end auto repair center.
    
    Context:
    You work alongside a specialized 24/7 Emergency Dispatch team led by Mike. While you handle the shop schedule, Mike handles all roadside emergencies, towing, and distressed drivers. You should always defer to him for safety issues.

    Your Capabilities:
    1. Scheduling: Book appointments for oil changes ($50), brake inspections ($80), and diagnostics ($120). Ask for preferred dates.
    2. Status Checks: If a customer asks about their car, ask for their name. Simulate checking a computer. (Invent a plausible status like "It's on the lift, ready by 4pm").
    3. General Info: Hours (Mon-Fri 8-6) and Location (123 Grease Ave).
    4. EMERGENCY TRANSFER: If the caller sounds distressed or mentions being stranded, having a flat tire, smoke, or any roadside issue, explicitly inform them about the Emergency Dispatch service. Say something like: "Oh no, that sounds dangerous. We have a dedicated Emergency Dispatch team for this. I'm going to transfer you to Mike immediately so he can get a tow truck out to you." THEN CALL THE 'transfer_to_dispatch' FUNCTION. Do not try to solve emergency issues yourself.

    Tone: Helpful, efficient, polite. Keep responses concise (1-2 sentences) as you are speaking over the phone.
    Start the conversation immediately with: "MechanicShop Front Desk, Sarah speaking. How can I help you today?"
  `
};

const DISPATCH_AGENT: AgentConfig = {
  id: 'dispatch',
  name: 'Mike',
  role: 'Emergency Dispatch',
  description: 'Manages roadside emergencies, urgent towing, and distressed drivers.',
  voiceName: 'Fenrir', // Deep, authoritative, calm
  themeColor: 'red',
  systemInstruction: `
    You are Mike, the Emergency Dispatch Coordinator for "MechanicShop". You handle urgent roadside assistance calls.
    
    Your Goals:
    1. Safety First: Ask if the driver is in a safe location immediately.
    2. Information Gathering: Get the location, vehicle make/model, and the issue (flat, smoke, stall).
    3. Action: Dispatch a tow truck (ETA usually 20-30 mins). Quote a dispatch fee of $150.
    
    Tone: Calm, authoritative, reassuring, urgent but controlled. Speak clearly and concisely.
    Start the conversation immediately with: "Emergency Dispatch, Mike speaking. Are you safe right now?"
  `
};

function App() {
  const [activeTab, setActiveTab] = useState<'demo' | 'services'>('demo');
  
  // State to manage transfer logic
  const [shouldConnectDispatch, setShouldConnectDispatch] = useState(false);

  const handleTransfer = () => {
      console.log("App: Transfer triggered from Sarah -> Mike");
      setShouldConnectDispatch(true);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-50 selection:bg-blue-500/30">
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Wrench className="text-white h-5 w-5" />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                MechanicShop AI
              </span>
            </div>
            <div className="flex gap-6 text-sm font-medium">
              <button 
                onClick={() => setActiveTab('demo')}
                className={`hover:text-blue-400 transition-colors ${activeTab === 'demo' ? 'text-blue-400' : 'text-slate-400'}`}
              >
                Live Demo
              </button>
              <button 
                onClick={() => setActiveTab('services')}
                className={`hover:text-blue-400 transition-colors ${activeTab === 'services' ? 'text-blue-400' : 'text-slate-400'}`}
              >
                Agency Services
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {activeTab === 'demo' ? (
          <div className="space-y-12">
            <div className="text-center space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white">
                Experience <span className="text-blue-500">Voice AI</span> for Mechanics
              </h1>
              <p className="text-lg text-slate-400 max-w-2xl mx-auto">
                Test our specialized agents designed to streamline your auto shop operations. 
                From booking appointments to handling roadside emergencies.
              </p>
              
              <div className="flex items-center justify-center gap-4 text-xs text-slate-500 mt-4">
                 <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-green-500"/> Low Latency</span>
                 <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-green-500"/> Natural Speech</span>
                 <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-green-500"/> Intelligent Hand-offs</span>
              </div>
            </div>

            <div className="relative grid md:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
              
              {/* Visual Connection Line (Optional aesthetic) */}
              {shouldConnectDispatch && (
                <div className="hidden md:block absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-0 w-32 border-t-2 border-dashed border-slate-600 animate-pulse">
                     <div className="absolute top-[-10px] left-1/2 transform -translate-x-1/2 bg-slate-900 px-2 text-xs text-slate-500">Transferring</div>
                </div>
              )}

              {/* Front Desk Agent */}
              <div className="space-y-4 z-10">
                <div className="flex items-center gap-2 text-blue-400 mb-2 px-2">
                  <Clock size={16} />
                  <span className="text-sm font-semibold uppercase tracking-wide">Business Hours Support</span>
                </div>
                <AgentCard 
                    config={FRONT_DESK_AGENT} 
                    onTransfer={handleTransfer}
                />
                <div className="bg-slate-800/50 rounded-xl p-4 text-sm text-slate-400 border border-slate-800">
                  <strong className="text-slate-200 block mb-2">Try asking Sarah:</strong>
                  <ul className="list-disc list-inside space-y-1">
                    <li>"Can I book an oil change for Friday?"</li>
                    <li>"Is my car, the Honda Civic, ready yet?"</li>
                    <li className="text-blue-300 font-medium">"I have a flat tire on the highway!" (Triggers Transfer)</li>
                  </ul>
                </div>
              </div>

              {/* Dispatch Agent */}
              <div className="space-y-4 z-10">
                <div className="flex items-center gap-2 text-red-400 mb-2 px-2">
                  <ShieldAlert size={16} />
                  <span className="text-sm font-semibold uppercase tracking-wide">Emergency Response</span>
                </div>
                <AgentCard 
                    config={DISPATCH_AGENT} 
                    autoConnect={shouldConnectDispatch}
                />
                <div className="bg-slate-800/50 rounded-xl p-4 text-sm text-slate-400 border border-slate-800">
                  <strong className="text-slate-200 block mb-2">Try telling Mike:</strong>
                  <ul className="list-disc list-inside space-y-1">
                    <li>"My engine is smoking, I'm scared."</li>
                    <li>"I need a tow truck immediately."</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-16 animate-in fade-in duration-500">
            {/* Services Section */}
            <div className="text-center max-w-3xl mx-auto space-y-6">
              <h2 className="text-3xl font-bold text-white">Why Mechanics Choose Our AI Agency</h2>
              <p className="text-slate-400 leading-relaxed">
                Running a shop is hard. Managing the phones shouldn't be. We deploy custom-trained voice agents that understand automotive terminology and integrate directly with your shop management software.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-slate-800 border border-slate-700 p-8 rounded-2xl hover:border-blue-500/50 transition-colors">
                <div className="w-12 h-12 bg-blue-900/50 rounded-lg flex items-center justify-center mb-6 text-blue-400">
                  <Phone size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3">Missed Call Recovery</h3>
                <p className="text-slate-400 text-sm">
                  Never miss a lead. Our AI calls back instantly or answers overflow calls when your mechanics are busy under a hood.
                </p>
              </div>
              <div className="bg-slate-800 border border-slate-700 p-8 rounded-2xl hover:border-blue-500/50 transition-colors">
                <div className="w-12 h-12 bg-purple-900/50 rounded-lg flex items-center justify-center mb-6 text-purple-400">
                  <Settings size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3">Service Integration</h3>
                <p className="text-slate-400 text-sm">
                  We integrate with ShopWare, Mitchell 1, and other CRMs to check parts inventory and schedule bay times automatically.
                </p>
              </div>
              <div className="bg-slate-800 border border-slate-700 p-8 rounded-2xl hover:border-blue-500/50 transition-colors">
                <div className="w-12 h-12 bg-green-900/50 rounded-lg flex items-center justify-center mb-6 text-green-400">
                  <MapPin size={24} />
                </div>
                <h3 className="text-xl font-bold mb-3">Dispatch Coordination</h3>
                <p className="text-slate-400 text-sm">
                  For towing operations, our AI triangulates driver locations and assigns the nearest truck, reducing ETA by 20%.
                </p>
              </div>
            </div>
            
            {/* CTA */}
            <div className="bg-gradient-to-r from-blue-900 to-slate-900 rounded-3xl p-12 text-center border border-blue-800/50">
              <h2 className="text-2xl md:text-3xl font-bold mb-6 text-white">Ready to modernize your shop?</h2>
              <button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-full font-bold transition-all transform hover:scale-105 shadow-lg shadow-blue-500/25">
                Book a Consultation
              </button>
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 mt-24 py-12 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
          <p>&copy; 2024 MechanicShop Voice AI Agency. Powered by Google Gemini.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
