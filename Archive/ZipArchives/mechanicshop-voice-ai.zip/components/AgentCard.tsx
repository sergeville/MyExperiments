
import React, { useEffect } from 'react';
import { AgentConfig } from '../types';
import { useLiveAgent } from '../hooks/useLiveAgent';
import { Visualizer } from './Visualizer';
import { Phone, PhoneOff, Radio } from 'lucide-react';

interface AgentCardProps {
  config: AgentConfig;
  autoConnect?: boolean;
  onTransfer?: () => void;
}

export const AgentCard: React.FC<AgentCardProps> = ({ config, autoConnect, onTransfer }) => {
  // Inject the onTransfer callback into the config passed to the hook
  const hookConfig = { ...config, onTransfer };
  const { connect, disconnect, isConnected, isSpeaking, volume, error } = useLiveAgent(hookConfig);

  // Handle auto-connection (e.g., from a transfer)
  useEffect(() => {
    if (autoConnect && !isConnected) {
        // Small timeout to allow previous socket to clear/UI to settle
        const timer = setTimeout(() => {
            connect();
        }, 500);
        return () => clearTimeout(timer);
    }
  }, [autoConnect, connect, isConnected]);

  const themeColor = config.themeColor === 'red' ? 'bg-red-500' : 'bg-blue-500';
  const textColor = config.themeColor === 'red' ? 'text-red-500' : 'text-blue-500';
  const borderColor = config.themeColor === 'red' ? 'border-red-500' : 'border-blue-500';
  const glowColor = config.themeColor === 'red' ? 'shadow-red-500/20' : 'shadow-blue-500/20';

  const handleToggle = () => {
    if (isConnected) {
      disconnect();
    } else {
      connect();
    }
  };

  return (
    <div className={`relative overflow-hidden bg-slate-800 border border-slate-700 rounded-2xl p-6 shadow-2xl ${isConnected ? `border-opacity-100 ${borderColor} shadow-[0_0_30px_rgba(0,0,0,0.3)]` : ''} transition-all duration-500`}>
      
      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className={`px-2 py-0.5 text-xs font-bold uppercase tracking-wider rounded bg-slate-900 ${textColor}`}>
              {config.role}
            </span>
            {isConnected && (
              <span className="flex h-2 w-2 relative">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${themeColor}`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${themeColor}`}></span>
              </span>
            )}
          </div>
          <h3 className="text-2xl font-bold text-white">{config.name}</h3>
          <p className="text-slate-400 text-sm mt-1 max-w-xs">{config.description}</p>
        </div>
        <div className={`p-3 rounded-full bg-slate-900 ${textColor}`}>
          <Radio size={24} />
        </div>
      </div>

      {/* Visualizer Area */}
      <div className="mb-8 relative">
        <div className="absolute top-2 right-2 z-10">
             {isConnected ? (
                 <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur px-2 py-1 rounded text-xs text-green-400 border border-green-900">
                     <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                     Live
                 </div>
             ) : (
                 <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur px-2 py-1 rounded text-xs text-slate-500 border border-slate-700">
                     <div className="w-1.5 h-1.5 bg-slate-600 rounded-full"></div>
                     Offline
                 </div>
             )}
        </div>
        <Visualizer isActive={isConnected} volume={volume} color={config.themeColor} />
        
        {/* Status Text Overlay */}
        {isConnected && (
            <div className="absolute bottom-2 left-2 text-xs text-slate-400 flex items-center gap-1">
                {isSpeaking ? (
                    <span className={textColor}>Agent Speaking...</span>
                ) : (
                    <span>Listening...</span>
                )}
            </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex flex-col gap-4">
        {error && (
          <div className="bg-red-900/20 border border-red-900/50 text-red-200 text-xs p-3 rounded">
            Error: {error}
          </div>
        )}
        
        <button
          onClick={handleToggle}
          className={`w-full py-4 px-6 rounded-xl font-bold text-lg flex items-center justify-center gap-3 transition-all duration-300
            ${isConnected 
              ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20 border border-red-500/50' 
              : `bg-white text-slate-900 hover:bg-slate-200 ${glowColor} shadow-lg`
            }`}
        >
          {isConnected ? (
            <>
              <PhoneOff size={20} />
              End Call
            </>
          ) : (
            <>
              <Phone size={20} />
              Call Agent
            </>
          )}
        </button>
        
        <p className="text-center text-slate-500 text-xs">
            {isConnected ? "Microphone active. Speak naturally." : "Tap to start the simulation."}
        </p>
      </div>
    </div>
  );
};
