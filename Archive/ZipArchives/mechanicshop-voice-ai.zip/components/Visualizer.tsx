import React, { useRef, useEffect } from 'react';

interface VisualizerProps {
  isActive: boolean;
  volume: number; // 0-255 roughly
  color: string; // Hex or tailwind class logic
}

export const Visualizer: React.FC<VisualizerProps> = ({ isActive, volume, color }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    // Configuration
    const barCount = 30;
    const barWidth = canvas.width / barCount;
    const baseHeight = 4;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!isActive) {
        // Idle state - straight line
        ctx.fillStyle = '#334155'; // Slate 700
        ctx.fillRect(0, canvas.height / 2 - 1, canvas.width, 2);
        return;
      }

      for (let i = 0; i < barCount; i++) {
        // Create a wave effect based on volume and time
        // If volume is 0, it's flat. If volume is high, bars jump.
        // Add some randomness to look organic
        const noise = Math.random() * 0.5 + 0.5;
        const timeShift = Math.sin((Date.now() / 200) + i);
        
        // Scale volume for visual height (volume is roughly 0-100 from hook)
        const dynamicHeight = Math.max(baseHeight, (volume * 2.5 * noise) + (timeShift * 5));
        
        const x = i * barWidth;
        const y = (canvas.height - dynamicHeight) / 2;

        // Color parsing simple
        ctx.fillStyle = color === 'red' ? '#ef4444' : '#3b82f6';
        
        // Rounded bars
        ctx.beginPath();
        ctx.roundRect(x + 2, y, barWidth - 4, dynamicHeight, 4);
        ctx.fill();
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isActive, volume, color]);

  return (
    <canvas 
      ref={canvasRef} 
      width={400} 
      height={100} 
      className="w-full h-24 bg-slate-900/50 rounded-lg border border-slate-700/50"
    />
  );
};
