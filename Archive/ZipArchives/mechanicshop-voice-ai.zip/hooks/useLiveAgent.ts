
import { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { AgentConfig } from '../types';
import { createPcmBlob, decodeAudioData, base64ToArrayBuffer } from '../utils/audio';

export function useLiveAgent(config: AgentConfig) {
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [volume, setVolume] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Refs for audio handling
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef<any>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const disconnect = useCallback(async () => {
    console.log('Disconnecting agent...');
    
    // 1. Update State Immediately
    setIsConnected(false);
    setIsSpeaking(false);
    setVolume(0);

    // 2. Stop the loop immediately
    if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
    }

    // 3. Clear promise ref
    sessionPromiseRef.current = null;

    // 4. Close Session
    const currentSession = sessionRef.current;
    sessionRef.current = null;
    if (currentSession) {
        try {
            await currentSession.close();
        } catch (e) {
            console.error("Error closing LiveSession:", e);
        }
    }

    // 5. Stop Audio Tracks (Microphone)
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    // 6. Disconnect Audio Nodes
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }
    if (inputSourceRef.current) {
      inputSourceRef.current.disconnect();
      inputSourceRef.current = null;
    }

    // 7. Stop Playback
    sourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) {}
    });
    sourcesRef.current.clear();

    // 8. Close AudioContexts
    const closeContext = async (ctx: AudioContext | null) => {
        if (ctx && ctx.state !== 'closed') {
            try { await ctx.close(); } catch (e) { console.error("Context close error", e); }
        }
    };
    
    await closeContext(inputAudioContextRef.current);
    inputAudioContextRef.current = null;
    
    await closeContext(outputAudioContextRef.current);
    outputAudioContextRef.current = null;
  }, []);

  const connect = useCallback(async () => {
    // Reset state
    setError(null);
    if (!process.env.API_KEY) {
        setError("API Key not found");
        return;
    }

    try {
        // Initialize Audio Contexts
        inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

        // Ensure Output Context is Resumed (Critical for hearing audio)
        if (outputAudioContextRef.current.state === 'suspended') {
            await outputAudioContextRef.current.resume();
        }

        // Analyser for visualization
        analyserRef.current = outputAudioContextRef.current.createAnalyser();
        analyserRef.current.fftSize = 256;

        // Start Visualization Loop
        const updateVolume = () => {
            if (analyserRef.current && sessionRef.current) {
                const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
                analyserRef.current.getByteFrequencyData(dataArray);
                const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
                setVolume(avg); 
            } else {
                setVolume(0);
            }
            animationFrameRef.current = requestAnimationFrame(updateVolume);
        };
        updateVolume();

        // Get Mic Stream
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        // Initialize GenAI Client
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // Live API Config
        const liveConfig = {
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            config: {
                responseModalities: [Modality.AUDIO],
                systemInstruction: config.systemInstruction,
                speechConfig: {
                    voiceConfig: { prebuiltVoiceConfig: { voiceName: config.voiceName } }
                },
                tools: config.tools,
            },
        };

        const sessionPromise = ai.live.connect({
            ...liveConfig,
            callbacks: {
                onopen: () => {
                    console.log("Session opened");
                    
                    // Setup Input Processing
                    if (!inputAudioContextRef.current || !mediaStreamRef.current) return;
                    
                    const source = inputAudioContextRef.current.createMediaStreamSource(mediaStreamRef.current);
                    inputSourceRef.current = source;
                    
                    const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = processor;

                    processor.onaudioprocess = (e) => {
                        if (!sessionRef.current) return; // Stale check

                        const inputData = e.inputBuffer.getChannelData(0);
                        const pcmBlob = createPcmBlob(inputData);
                        sessionRef.current.sendRealtimeInput({ media: pcmBlob });
                    };

                    source.connect(processor);
                    processor.connect(inputAudioContextRef.current.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    // Handle Tool Calls (Transfer)
                    if (message.toolCall) {
                        console.log("Tool Call detected:", message.toolCall);
                        const calls = message.toolCall.functionCalls;
                        const transferCall = calls.find(c => c.name === 'transfer_to_dispatch');
                        
                        if (transferCall && config.onTransfer) {
                            console.log("Transferring call...");
                            // We execute the callback to parent
                            config.onTransfer();
                            // And immediately disconnect this agent
                            disconnect();
                            return; 
                        }
                    }

                    // Iterate through parts to find audio data
                    const parts = message.serverContent?.modelTurn?.parts || [];
                    for (const part of parts) {
                        const base64Audio = part.inlineData?.data;
                        
                        if (base64Audio && outputAudioContextRef.current) {
                            setIsSpeaking(true);
                            const ctx = outputAudioContextRef.current;
                            
                            // Double check resume state
                            if (ctx.state === 'suspended') {
                                await ctx.resume();
                            }

                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                            
                            try {
                                const audioBuffer = await decodeAudioData(
                                    base64ToArrayBuffer(base64Audio),
                                    ctx
                                );
                                
                                const source = ctx.createBufferSource();
                                source.buffer = audioBuffer;
                                
                                // Connect Source -> Analyser -> Destination
                                if (analyserRef.current) {
                                    source.connect(analyserRef.current);
                                    analyserRef.current.connect(ctx.destination);
                                } else {
                                    source.connect(ctx.destination);
                                }

                                source.start(nextStartTimeRef.current);
                                nextStartTimeRef.current += audioBuffer.duration;
                                sourcesRef.current.add(source);

                                source.onended = () => {
                                    sourcesRef.current.delete(source);
                                    if (sourcesRef.current.size === 0) {
                                        setIsSpeaking(false);
                                    }
                                };
                            } catch (err) {
                                console.error("Audio decoding error:", err);
                            }
                        }
                    }

                    if (message.serverContent?.interrupted) {
                        console.log("Interrupted!");
                        sourcesRef.current.forEach(s => {
                            try { s.stop(); } catch(e) {}
                        });
                        sourcesRef.current.clear();
                        nextStartTimeRef.current = 0;
                        setIsSpeaking(false);
                    }
                },
                onclose: () => {
                    console.log("Session closed remotely");
                    disconnect(); 
                },
                onerror: (err) => {
                    console.error("Session error:", err);
                    setError("Connection lost.");
                    disconnect();
                }
            }
        });

        sessionPromiseRef.current = sessionPromise;
        const session = await sessionPromise;
        
        // Check if disconnected while connecting
        if (sessionPromiseRef.current !== sessionPromise) {
            await session.close();
            return;
        }
        
        sessionRef.current = session;
        setIsConnected(true);

    } catch (err: any) {
        console.error("Connection failed:", err);
        setError(err.message || "Failed to connect");
        disconnect();
    }
  }, [config, disconnect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
        // Ensure we close everything when component unmounts
        if (sessionRef.current) {
             sessionRef.current.close().catch(console.error);
        }
        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(t => t.stop());
        }
        if (inputAudioContextRef.current) inputAudioContextRef.current.close();
        if (outputAudioContextRef.current) outputAudioContextRef.current.close();
    };
  }, []);

  return {
    connect,
    disconnect,
    isConnected,
    isSpeaking,
    volume,
    error
  };
}
