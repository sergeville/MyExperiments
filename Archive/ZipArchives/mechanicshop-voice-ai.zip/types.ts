
import { Tool } from "@google/genai";

// Basic types for the application state and Live API interaction

export interface AgentConfig {
  id: string;
  name: string;
  role: string;
  description: string;
  systemInstruction: string;
  voiceName: string; // 'Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'
  themeColor: string; // Tailwind class fragment, e.g., 'blue', 'red'
  tools?: Tool[];
  onTransfer?: () => void;
}

export interface LiveSessionState {
  isConnected: boolean;
  isSpeaking: boolean;
  volume: number; // 0-100 for visualizer
  error: string | null;
}

// Simplified types for @google/genai messages since we can't import types directly easily without the lib in this env context
// In a real app with the package installed, we would import these.
export interface LiveServerMessage {
  serverContent?: {
    modelTurn?: {
      parts: Array<{
        inlineData: {
          mimeType: string;
          data: string;
        };
      }>;
    };
    interrupted?: boolean;
    turnComplete?: boolean;
  };
  toolCall?: {
    functionCalls: Array<{
      id: string;
      name: string;
      args: any;
    }>;
  };
}
